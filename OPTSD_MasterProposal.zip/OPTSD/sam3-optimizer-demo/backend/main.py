from __future__ import annotations

import base64
import gc
import json
import logging
import os
import platform
import subprocess
import shutil
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request
from flask_cors import CORS

import numpy as np
import onnx
import onnxruntime as ort
from onnx import numpy_helper
from onnxruntime.quantization import QuantType, quantize_dynamic

try:
    from onnxconverter_common import float16 as onnx_float16
except ImportError:
    onnx_float16 = None


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

SUPPORTED_EXTENSIONS = {".onnx"}
DEFAULT_PRUNING_RATIO = 0.10
DEFAULT_BENCHMARK_WARMUP_RUNS = 1
DEFAULT_BENCHMARK_TEST_RUNS = 5
DEFAULT_DYNAMIC_DIM_VALUE = 4


def get_total_memory_gb() -> float | None:
    try:
        if hasattr(os, "sysconf"):
            page_size = os.sysconf("SC_PAGE_SIZE")
            page_count = os.sysconf("SC_PHYS_PAGES")
            return round((page_size * page_count) / (1024**3), 2)
    except (AttributeError, ValueError, OSError):
        pass

    if platform.system() == "Windows":
        try:
            import ctypes

            class MemoryStatusEx(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

                def __init__(self) -> None:
                    super().__init__()
                    self.dwLength = ctypes.sizeof(type(self))

            status = MemoryStatusEx()
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return round(status.ullTotalPhys / (1024**3), 2)
        except (AttributeError, OSError, ValueError):
            logger.exception("Unable to read Windows memory status")

    return None


def detect_nvidia_gpus() -> list[dict[str, Any]]:
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.total,driver_version",
                "--format=csv,noheader,nounits",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return []

    devices: list[dict[str, Any]] = []
    for index, raw_line in enumerate(result.stdout.splitlines()):
        parts = [part.strip() for part in raw_line.split(",")]
        if not parts or not parts[0]:
            continue

        memory_mb = None
        if len(parts) > 1:
            try:
                memory_mb = int(parts[1])
            except ValueError:
                memory_mb = None

        driver_version = parts[2] if len(parts) > 2 else None
        devices.append(
            {
                "id": f"gpu-{index}",
                "name": parts[0],
                "type": "GPU",
                "memoryGB": round(memory_mb / 1024, 2) if memory_mb is not None else None,
                "driverVersion": driver_version,
                "provider": "CUDAExecutionProvider",
                "source": "backend-host",
            }
        )

    return devices


def get_device_resources() -> dict[str, Any]:
    providers = ort.get_available_providers()
    gpu_devices = detect_nvidia_gpus()

    if not gpu_devices:
        for provider in providers:
            if provider == "CPUExecutionProvider":
                continue
            gpu_devices.append(
                {
                    "id": f"provider-{provider.lower()}",
                    "name": provider.replace("ExecutionProvider", "").strip() or provider,
                    "type": "GPU",
                    "provider": provider,
                    "source": "backend-host",
                }
            )

    cpu_count = os.cpu_count()
    devices = gpu_devices + [
        {
            "id": "cpu-0",
            "name": f"Host CPU ({cpu_count} cores)" if cpu_count else "Host CPU",
            "type": "CPU",
            "provider": "CPUExecutionProvider",
            "source": "backend-host",
        }
    ]

    return {
        "devices": devices,
        "host": {
            "hostname": platform.node() or os.getenv("COMPUTERNAME") or "unknown-host",
            "os": platform.platform(),
            "pythonVersion": platform.python_version(),
        },
        "cpuCores": cpu_count,
        "totalMemoryGB": get_total_memory_gb(),
        "availableProviders": providers,
        "dataSource": "backend-host",
    }


def sanitize_export_name(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in {"-", "_"} else "-" for char in (value or "optimized-model"))
    cleaned = cleaned.strip("-")
    return cleaned or "optimized-model"


def get_process_memory_mb() -> float | None:
    if platform.system() == "Windows":
        try:
            import ctypes

            class ProcessMemoryCounters(ctypes.Structure):
                _fields_ = [
                    ("cb", ctypes.c_ulong),
                    ("PageFaultCount", ctypes.c_ulong),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                ]

                def __init__(self) -> None:
                    super().__init__()
                    self.cb = ctypes.sizeof(type(self))

            counters = ProcessMemoryCounters()
            process_handle = ctypes.windll.kernel32.GetCurrentProcess()
            if ctypes.windll.psapi.GetProcessMemoryInfo(process_handle, ctypes.byref(counters), counters.cb):
                return round(counters.WorkingSetSize / (1024**2), 2)
        except (AttributeError, OSError, ValueError):
            logger.exception("Unable to read process memory info")

    return None


def get_gpu_memory_map() -> dict[str, int]:
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=index,memory.used",
                "--format=csv,noheader,nounits",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return {}

    memory_map: dict[str, int] = {}
    for raw_line in result.stdout.splitlines():
        parts = [part.strip() for part in raw_line.split(",")]
        if len(parts) != 2:
            continue

        try:
            memory_map[parts[0]] = int(parts[1])
        except ValueError:
            continue

    return memory_map


def resolve_benchmark_provider(device_label: str | None) -> str:
    providers = ort.get_available_providers()
    wants_gpu = bool(device_label and "gpu" in device_label.lower())
    if wants_gpu and "CUDAExecutionProvider" in providers:
        return "CUDAExecutionProvider"
    return "CPUExecutionProvider"


def resolve_dim_value(dimension: Any) -> int:
    if isinstance(dimension, int) and dimension > 0:
        return dimension

    dim_text = str(dimension or "").lower()
    if "batch" in dim_text:
        return 1
    if any(token in dim_text for token in ["seq", "token", "length", "time"]):
        return 16
    if any(token in dim_text for token in ["height", "width", "spatial"]):
        return 64
    if "channel" in dim_text:
        return 3
    return DEFAULT_DYNAMIC_DIM_VALUE


def build_sample_input(input_meta: ort.NodeArg) -> np.ndarray:
    shape = [resolve_dim_value(dimension) for dimension in input_meta.shape]
    rng = np.random.default_rng(0)
    input_type = input_meta.type or ""

    if "float16" in input_type:
        return rng.standard_normal(shape).astype(np.float16)
    if "float" in input_type or "double" in input_type:
        return rng.standard_normal(shape).astype(np.float32)
    if "int64" in input_type:
        return np.zeros(shape, dtype=np.int64)
    if "int32" in input_type:
        return np.zeros(shape, dtype=np.int32)
    if "bool" in input_type:
        return np.zeros(shape, dtype=bool)

    raise RuntimeError(f"Unsupported benchmark input type: {input_meta.type}")


def build_benchmark_inputs(session: ort.InferenceSession) -> dict[str, np.ndarray]:
    inputs: dict[str, np.ndarray] = {}
    for input_meta in session.get_inputs():
        inputs[input_meta.name] = build_sample_input(input_meta)

    if not inputs:
        raise RuntimeError("The ONNX graph does not expose any inputs for inference benchmarking.")

    return inputs


def diff_gpu_memory_mb(before_map: dict[str, int], after_map: dict[str, int]) -> float | None:
    deltas = []
    for gpu_index, before_value in before_map.items():
        after_value = after_map.get(gpu_index)
        if after_value is None:
            continue
        deltas.append(after_value - before_value)

    if not deltas:
        return None

    return round(max(deltas), 2)


def benchmark_model(model_path: Path, provider: str, warmup_runs: int, test_runs: int) -> dict[str, Any]:
    gc.collect()
    gpu_memory_before = get_gpu_memory_map()
    ram_before = get_process_memory_mb()

    session = ort.InferenceSession(str(model_path), providers=[provider])
    inputs = build_benchmark_inputs(session)

    gpu_memory_after_load = get_gpu_memory_map()
    ram_after_load = get_process_memory_mb()

    for _ in range(max(warmup_runs, 0)):
        session.run(None, inputs)

    timings_ms = []
    peak_gpu_delta_mb = diff_gpu_memory_mb(gpu_memory_before, gpu_memory_after_load) or 0.0
    peak_ram_delta_mb = round((ram_after_load or 0) - (ram_before or 0), 2) if None not in (ram_before, ram_after_load) else None

    for _ in range(max(test_runs, 1)):
        loop_gpu_before = get_gpu_memory_map()
        loop_ram_before = get_process_memory_mb()
        started_at = time.perf_counter()
        session.run(None, inputs)
        duration_ms = (time.perf_counter() - started_at) * 1000
        loop_gpu_after = get_gpu_memory_map()
        loop_ram_after = get_process_memory_mb()
        timings_ms.append(round(duration_ms, 3))

        current_gpu_delta = diff_gpu_memory_mb(loop_gpu_before, loop_gpu_after)
        if current_gpu_delta is not None:
            peak_gpu_delta_mb = max(peak_gpu_delta_mb, current_gpu_delta)

        if None not in (loop_ram_before, loop_ram_after):
            current_ram_delta = round(loop_ram_after - loop_ram_before, 2)
            if peak_ram_delta_mb is None:
                peak_ram_delta_mb = current_ram_delta
            else:
                peak_ram_delta_mb = max(peak_ram_delta_mb, current_ram_delta)

    benchmark = {
        "provider": provider,
        "warmupRuns": max(warmup_runs, 0),
        "testRuns": max(test_runs, 1),
        "inputCount": len(inputs),
        "timingsMs": timings_ms,
        "averageLatencyMs": round(float(np.mean(timings_ms)), 3),
        "minLatencyMs": round(float(np.min(timings_ms)), 3),
        "maxLatencyMs": round(float(np.max(timings_ms)), 3),
        "modelSizeMB": round(model_path.stat().st_size / (1024**2), 3),
        "gpuMemoryLoadDeltaMB": diff_gpu_memory_mb(gpu_memory_before, gpu_memory_after_load),
        "gpuMemoryPeakDeltaMB": round(peak_gpu_delta_mb, 2) if gpu_memory_after_load else None,
        "ramLoadDeltaMB": round((ram_after_load - ram_before), 2) if None not in (ram_before, ram_after_load) else None,
        "ramPeakDeltaMB": peak_ram_delta_mb,
    }

    del session
    gc.collect()
    return benchmark


def summarize_benchmark_comparison(original: dict[str, Any], optimized: dict[str, Any]) -> dict[str, Any]:
    latency_delta_ms = round(original["averageLatencyMs"] - optimized["averageLatencyMs"], 3)
    latency_reduction_pct = round((latency_delta_ms / original["averageLatencyMs"]) * 100, 2) if original["averageLatencyMs"] else None

    original_memory_mb = original.get("gpuMemoryLoadDeltaMB")
    optimized_memory_mb = optimized.get("gpuMemoryLoadDeltaMB")
    memory_metric = "VRAM"
    if original_memory_mb is None or optimized_memory_mb is None:
        original_memory_mb = original.get("ramLoadDeltaMB")
        optimized_memory_mb = optimized.get("ramLoadDeltaMB")
        memory_metric = "RAM"

    memory_delta_mb = None
    memory_reduction_pct = None
    if original_memory_mb is not None and optimized_memory_mb is not None:
        memory_delta_mb = round(original_memory_mb - optimized_memory_mb, 2)
        memory_reduction_pct = round((memory_delta_mb / original_memory_mb) * 100, 2) if original_memory_mb else None

    return {
        "latencyDeltaMs": latency_delta_ms,
        "latencyReductionPct": latency_reduction_pct,
        "memoryMetric": memory_metric,
        "memoryDeltaMB": memory_delta_mb,
        "memoryReductionPct": memory_reduction_pct,
        "modelSizeDeltaMB": round(original["modelSizeMB"] - optimized["modelSizeMB"], 3),
    }


def optimize_graph(input_path: Path, output_path: Path, log_lines: list[str]) -> Path:
    log_lines.append("Running ONNX Runtime graph optimization pass.")
    session_options = ort.SessionOptions()
    session_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_EXTENDED
    session_options.optimized_model_filepath = str(output_path)
    ort.InferenceSession(str(input_path), session_options=session_options, providers=["CPUExecutionProvider"])

    if not output_path.exists():
        shutil.copyfile(input_path, output_path)
        log_lines.append("Graph optimizer did not emit a new file; original graph copied forward.")
    else:
        log_lines.append(f"Graph optimization wrote {output_path.name}.")

    return output_path


def prune_model_weights(input_path: Path, output_path: Path, pruning_ratio: float, log_lines: list[str]) -> tuple[Path, dict[str, int]]:
    model = onnx.load(str(input_path))
    pruned_initializers = 0
    total_zeroed = 0

    for index, initializer in enumerate(model.graph.initializer):
        array = numpy_helper.to_array(initializer)
        if array.size < 16 or array.dtype.kind not in {"f", "c"}:
            continue

        working = np.array(array, copy=True)
        nonzero_mask = working != 0
        nonzero_values = np.abs(working[nonzero_mask])
        if nonzero_values.size == 0:
            continue

        threshold = float(np.quantile(nonzero_values, pruning_ratio))
        prune_mask = np.abs(working) <= threshold
        zeroed_now = int(np.count_nonzero(working[prune_mask]))
        if zeroed_now == 0:
            continue

        working[prune_mask] = 0
        replacement = numpy_helper.from_array(working, initializer.name)
        model.graph.initializer.remove(initializer)
        model.graph.initializer.insert(index, replacement)
        pruned_initializers += 1
        total_zeroed += zeroed_now

    onnx.save(model, str(output_path))
    log_lines.append(
        f"Applied magnitude pruning to {pruned_initializers} initializer(s); zeroed {total_zeroed} weight value(s)."
    )

    return output_path, {
        "prunedInitializers": pruned_initializers,
        "zeroedWeights": total_zeroed,
    }


def quantize_model(input_path: Path, output_path: Path, quantization_type: str, log_lines: list[str]) -> tuple[Path, dict[str, Any]]:
    normalized_type = (quantization_type or "Int8").upper()
    applied_type = normalized_type
    fallback_reason = None

    if normalized_type == "INT8":
        quantize_dynamic(str(input_path), str(output_path), weight_type=QuantType.QInt8)
        log_lines.append("Applied ONNX Runtime dynamic Int8 quantization.")
    elif normalized_type == "FP16":
        if onnx_float16 is None:
            raise RuntimeError("onnxconverter-common is required for FP16 export.")
        model = onnx.load(str(input_path))
        converted = onnx_float16.convert_float_to_float16(model, keep_io_types=True)
        onnx.save(converted, str(output_path))
        log_lines.append("Converted ONNX weights to FP16.")
    elif normalized_type == "INT4":
        applied_type = "INT8"
        fallback_reason = "Int4 export is not implemented in this demo backend; dynamic Int8 quantization was applied instead."
        quantize_dynamic(str(input_path), str(output_path), weight_type=QuantType.QInt8)
        log_lines.append(fallback_reason)
    else:
        raise RuntimeError(f"Unsupported quantization type: {quantization_type}")

    return output_path, {
        "requestedType": quantization_type,
        "appliedType": applied_type,
        "fallbackReason": fallback_reason,
    }


def build_runtime_notes(config: dict[str, Any], log_lines: list[str]) -> list[str]:
    notes: list[str] = []

    if config.get("flashAttentionEnabled"):
        note = "Flash Attention remains a runtime execution hint; this backend does not rewrite generic ONNX attention blocks into vendor-specific Flash Attention kernels."
        notes.append(note)
        log_lines.append(note)

    if config.get("kvCacheEnabled"):
        note = "KV cache is recorded as an inference-time recommendation; generic ONNX export does not inject KV cache state management automatically."
        notes.append(note)
        log_lines.append(note)

    return notes


def encode_file_payload(path: Path, mime_type: str) -> dict[str, str]:
    return {
        "name": path.name,
        "mimeType": mime_type,
        "contentBase64": base64.b64encode(path.read_bytes()).decode("ascii"),
    }


@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify(
        {
            "status": "ok",
            "timestamp": datetime.now().isoformat(),
            "service": "sam3-optimizer-demo-backend",
        }
    )


@app.route("/api/device-resources", methods=["GET"])
def device_resources_endpoint():
    return jsonify(
        {
            "success": True,
            **get_device_resources(),
        }
    )


@app.route("/api/optimize-onnx", methods=["POST"])
def optimize_onnx_endpoint():
    if "model" not in request.files:
        return jsonify({"success": False, "error": "Missing uploaded model file."}), 400

    uploaded_file = request.files["model"]
    config_text = request.form.get("config", "{}")

    try:
        config = json.loads(config_text)
    except json.JSONDecodeError as exc:
        return jsonify({"success": False, "error": f"Invalid config payload: {exc}"}), 400

    suffix = Path(uploaded_file.filename or "model.onnx").suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        return jsonify({"success": False, "error": "Only .onnx models are supported by the backend optimizer."}), 400

    export_name = sanitize_export_name(config.get("exportName", "optimized-model"))
    log_lines = [
        f"Optimization started at {datetime.now().isoformat()}",
        f"Source model: {uploaded_file.filename}",
        f"Requested export name: {export_name}",
    ]

    with tempfile.TemporaryDirectory(prefix="sam3-opt-") as temp_dir:
        temp_path = Path(temp_dir)
        source_path = temp_path / (uploaded_file.filename or "model.onnx")
        uploaded_file.save(source_path)
        log_lines.append(f"Uploaded model saved to temporary path {source_path.name}.")

        current_path = source_path
        graph_output_path = temp_path / f"{export_name}-graph.onnx"
        current_path = optimize_graph(current_path, graph_output_path, log_lines)

        pruning_stats = {"prunedInitializers": 0, "zeroedWeights": 0}
        if config.get("pruningEnabled"):
            pruning_path = temp_path / f"{export_name}-pruned.onnx"
            current_path, pruning_stats = prune_model_weights(
                current_path,
                pruning_path,
                float(config.get("pruningRatio", DEFAULT_PRUNING_RATIO)),
                log_lines,
            )
        else:
            log_lines.append("Pruning step skipped.")

        quantization_result = {
            "requestedType": config.get("quantizationType"),
            "appliedType": None,
            "fallbackReason": None,
        }
        if config.get("quantizationEnabled"):
            quantized_path = temp_path / f"{export_name}-quantized.onnx"
            current_path, quantization_result = quantize_model(
                current_path,
                quantized_path,
                str(config.get("quantizationType", "Int8")),
                log_lines,
            )
        else:
            log_lines.append("Quantization step skipped.")

        runtime_notes = build_runtime_notes(config, log_lines)

        optimized_model_path = temp_path / f"{export_name}.onnx"
        shutil.copyfile(current_path, optimized_model_path)
        log_lines.append(f"Final optimized ONNX artifact created as {optimized_model_path.name}.")

        metadata = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "sourceModel": uploaded_file.filename,
            "exportName": export_name,
            "device": config.get("device"),
            "validation": config.get("validation"),
            "architecture": config.get("architecture"),
            "testRuns": config.get("testRuns"),
            "techniques": {
                "quantizationEnabled": config.get("quantizationEnabled"),
                "quantizationType": quantization_result["appliedType"],
                "pruningEnabled": config.get("pruningEnabled"),
                "flashAttentionEnabled": config.get("flashAttentionEnabled"),
                "kvCacheEnabled": config.get("kvCacheEnabled"),
            },
            "quantization": quantization_result,
            "pruning": pruning_stats,
            "runtimeNotes": runtime_notes,
            "artifacts": {
                "optimizedModel": optimized_model_path.name,
                "report": "optimized-model.json",
                "log": "optimization-log.txt",
            },
        }

        report_path = temp_path / "optimized-model.json"
        report_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

        log_path = temp_path / "optimization-log.txt"
        log_path.write_text("\n".join(log_lines) + "\n", encoding="utf-8")

        logger.info("Optimization completed for %s", uploaded_file.filename)

        return jsonify(
            {
                "success": True,
                "metadata": metadata,
                "files": {
                    "optimizedModel": encode_file_payload(optimized_model_path, "application/octet-stream"),
                    "report": encode_file_payload(report_path, "application/json"),
                    "log": encode_file_payload(log_path, "text/plain"),
                },
            }
        )


@app.route("/api/benchmark-onnx", methods=["POST"])
def benchmark_onnx_endpoint():
    if "originalModel" not in request.files or "optimizedModel" not in request.files:
        return jsonify({"success": False, "error": "Both originalModel and optimizedModel files are required."}), 400

    config_text = request.form.get("config", "{}")

    try:
        config = json.loads(config_text)
    except json.JSONDecodeError as exc:
        return jsonify({"success": False, "error": f"Invalid config payload: {exc}"}), 400

    original_upload = request.files["originalModel"]
    optimized_upload = request.files["optimizedModel"]

    original_suffix = Path(original_upload.filename or "original.onnx").suffix.lower()
    optimized_suffix = Path(optimized_upload.filename or "optimized.onnx").suffix.lower()
    if original_suffix not in SUPPORTED_EXTENSIONS or optimized_suffix not in SUPPORTED_EXTENSIONS:
        return jsonify({"success": False, "error": "Benchmarking currently supports .onnx models only."}), 400

    warmup_runs = max(int(config.get("warmupRuns", DEFAULT_BENCHMARK_WARMUP_RUNS)), 0)
    test_runs = max(int(config.get("testRuns", DEFAULT_BENCHMARK_TEST_RUNS)), 1)
    provider = resolve_benchmark_provider(config.get("device"))
    log_lines = [
        f"Verification started at {datetime.now().isoformat()}",
        f"Original model: {original_upload.filename}",
        f"Optimized model: {optimized_upload.filename}",
        f"Benchmark provider: {provider}",
    ]

    with tempfile.TemporaryDirectory(prefix="sam3-verify-") as temp_dir:
        temp_path = Path(temp_dir)
        original_path = temp_path / (original_upload.filename or "original.onnx")
        optimized_path = temp_path / (optimized_upload.filename or "optimized.onnx")
        original_upload.save(original_path)
        optimized_upload.save(optimized_path)

        original_benchmark = benchmark_model(original_path, provider, warmup_runs, test_runs)
        optimized_benchmark = benchmark_model(optimized_path, provider, warmup_runs, test_runs)
        summary = summarize_benchmark_comparison(original_benchmark, optimized_benchmark)

        log_lines.append(
            f"Latency delta: {summary['latencyDeltaMs']} ms. Memory delta: {summary['memoryDeltaMB']} {summary['memoryMetric']} MB."
        )

    return jsonify(
        {
            "success": True,
            "benchmark": {
                "provider": provider,
                "original": original_benchmark,
                "optimized": optimized_benchmark,
                "summary": summary,
            },
            "quality": {
                "imageReview": config.get("imageReview", "pending-manual-review"),
                "videoReview": config.get("videoReview", "pending-manual-review"),
                "note": "Image and video quality still need manual side-by-side review because this generic ONNX verifier does not know how to render task-specific outputs for every model family.",
            },
            "metadata": {
                "device": config.get("device"),
                "sourceModel": original_upload.filename,
                "optimizedModel": optimized_upload.filename,
                "warmupRuns": warmup_runs,
                "testRuns": test_runs,
                "timestamp": datetime.now().isoformat(),
                "log": log_lines,
            },
        }
    )


@app.errorhandler(Exception)
def handle_unexpected_error(error: Exception):
    logger.exception("Unhandled backend error")
    return jsonify({"success": False, "error": str(error)}), 500


if __name__ == "__main__":
    port = int(os.getenv("SAM3_OPTIMIZER_PORT", "5050"))
    app.run(host="127.0.0.1", port=port, debug=True)
