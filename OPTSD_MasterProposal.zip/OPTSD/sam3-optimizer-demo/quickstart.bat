@echo off
setlocal

cd /d "%~dp0"

set "BACKEND_DIR=%CD%\backend"
set "VENV_PY=%BACKEND_DIR%\.venv\Scripts\python.exe"
set "FRONTEND_PORT=8080"
set "BACKEND_PORT=5050"

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY_BOOTSTRAP=py -3"
) else (
  set "PY_BOOTSTRAP=python"
)

echo [1/5] Checking Python virtual environment...
if not exist "%VENV_PY%" (
  echo Creating backend virtual environment...
  %PY_BOOTSTRAP% -m venv "%BACKEND_DIR%\.venv"
  if errorlevel 1 goto :fail
)

echo [2/5] Installing backend dependencies...
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail

"%VENV_PY%" -m pip install -r "%BACKEND_DIR%\requirements.txt"
if errorlevel 1 goto :fail

echo [3/5] Starting backend on http://127.0.0.1:%BACKEND_PORT% ...
start "SAM3 Backend" cmd /k "cd /d ""%BACKEND_DIR%"" && ""%VENV_PY%"" main.py"

echo [4/5] Starting frontend on http://127.0.0.1:%FRONTEND_PORT% ...
start "SAM3 Frontend" cmd /k "cd /d ""%~dp0"" && ""%VENV_PY%"" -m http.server %FRONTEND_PORT%"

echo [5/5] Opening browser...
start "" "http://127.0.0.1:%FRONTEND_PORT%/"

echo.
echo Quickstart launched.
echo Backend:  http://127.0.0.1:%BACKEND_PORT%/api/health
echo Frontend: http://127.0.0.1:%FRONTEND_PORT%/
echo.
echo If the browser opens before the backend is fully ready, wait a few seconds and refresh.
goto :eof

:fail
echo.
echo Quickstart failed. Check the error output above.
exit /b 1