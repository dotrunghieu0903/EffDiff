const BACKEND_BASE_URL = "http://127.0.0.1:5050";

const toast = document.getElementById("toast");
const deviceSelect = document.getElementById("device-select");
const providerChip = document.getElementById("providerChip");
const warmupRunsInput = document.getElementById("warmup-runs");
const testRunsInput = document.getElementById("test-runs");
const originalModelInput = document.getElementById("original-model-input");
const optimizedModelInput = document.getElementById("optimized-model-input");
const originalModelNote = document.getElementById("original-model-note");
const optimizedModelNote = document.getElementById("optimized-model-note");
const runBenchmarkBtn = document.getElementById("run-benchmark-btn");
const benchmarkStatus = document.getElementById("benchmark-status");
const latencyDelta = document.getElementById("latency-delta");
const latencyFootnote = document.getElementById("latency-footnote");
const memoryDelta = document.getElementById("memory-delta");
const memoryFootnote = document.getElementById("memory-footnote");
const qualityVerdict = document.getElementById("quality-verdict");
const qualityFootnote = document.getElementById("quality-footnote");
const originalMetricsList = document.getElementById("original-metrics-list");
const optimizedMetricsList = document.getElementById("optimized-metrics-list");
const imageReviewChip = document.getElementById("image-review-chip");
const videoReviewChip = document.getElementById("video-review-chip");
const imageReviewSelect = document.getElementById("image-review-select");
const videoReviewSelect = document.getElementById("video-review-select");
const backendNote = document.getElementById("backend-note");
const resultTimestamp = document.getElementById("result-timestamp");
const checklistSummary = document.getElementById("checklist-summary");

const previewBindings = [
  {
    input: document.getElementById("reference-image-input"),
    media: document.getElementById("reference-image-preview"),
    empty: document.getElementById("reference-image-empty"),
    kind: "image",
  },
  {
    input: document.getElementById("optimized-image-input"),
    media: document.getElementById("optimized-image-preview"),
    empty: document.getElementById("optimized-image-empty"),
    kind: "image",
  },
  {
    input: document.getElementById("reference-video-input"),
    media: document.getElementById("reference-video-preview"),
    empty: document.getElementById("reference-video-empty"),
    kind: "video",
  },
  {
    input: document.getElementById("optimized-video-input"),
    media: document.getElementById("optimized-video-preview"),
    empty: document.getElementById("optimized-video-empty"),
    kind: "video",
  },
];

const state = {
  devices: [],
};

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatMetric(value, suffix = "") {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return "Unavailable";
  }

  return `${value}${suffix}`;
}

function formatDelta(deltaValue, percentValue, unit) {
  if (deltaValue === null || deltaValue === undefined || Number.isNaN(deltaValue)) {
    return "Unavailable";
  }

  if (percentValue === null || percentValue === undefined || Number.isNaN(percentValue)) {
    return `${deltaValue} ${unit}`;
  }

  return `${deltaValue} ${unit} (${percentValue}%)`;
}

function getSelectedDeviceLabel() {
  const selected = state.devices.find((device) => device.id === deviceSelect.value);
  if (!selected) {
    return deviceSelect.value || "CPU";
  }

  return selected.type === "GPU" ? `${selected.name} (GPU)` : `${selected.name} (CPU)`;
}

function renderDeviceSelect(devices) {
  state.devices = devices;
  deviceSelect.innerHTML = devices
    .map((device) => {
      const suffix = device.type === "GPU" ? "GPU" : "CPU";
      return `<option value="${escapeHtml(device.id)}">${escapeHtml(device.name)} (${suffix})</option>`;
    })
    .join("");

  providerChip.textContent = devices[0] ? `${devices[0].name}` : "No backend devices";
}

async function initDevices() {
  try {
    const response = await fetch(`${BACKEND_BASE_URL}/api/device-resources`);
    const payload = await response.json();
    if (!response.ok || !payload.success || !Array.isArray(payload.devices) || !payload.devices.length) {
      throw new Error(payload.error || "Cannot detect backend devices.");
    }

    renderDeviceSelect(payload.devices);
  } catch (error) {
    deviceSelect.innerHTML = '<option value="cpu-0">CPU fallback</option>';
    providerChip.textContent = "Backend unavailable";
    benchmarkStatus.textContent = "Backend device detection failed. Benchmark will fall back to CPU when available.";
    showToast(error.message || "Cannot detect backend devices.");
  }
}

function updateModelNote(input, noteElement, label) {
  const file = input.files?.[0];
  noteElement.textContent = file ? `${label}: ${file.name}` : `No ${label.toLowerCase()} selected.`;
}

function renderMetrics(target, benchmark, memoryMetric) {
  const memoryLoadKey = memoryMetric === "VRAM" ? "gpuMemoryLoadDeltaMB" : "ramLoadDeltaMB";
  const memoryPeakKey = memoryMetric === "VRAM" ? "gpuMemoryPeakDeltaMB" : "ramPeakDeltaMB";

  target.innerHTML = [
    `<li><span>Provider</span><strong>${escapeHtml(benchmark.provider || "Unknown")}</strong></li>`,
    `<li><span>Average Latency</span><strong>${escapeHtml(formatMetric(benchmark.averageLatencyMs, " ms"))}</strong></li>`,
    `<li><span>Min / Max</span><strong>${escapeHtml(formatMetric(benchmark.minLatencyMs, " ms"))} / ${escapeHtml(formatMetric(benchmark.maxLatencyMs, " ms"))}</strong></li>`,
    `<li><span>${escapeHtml(memoryMetric)} Load Delta</span><strong>${escapeHtml(formatMetric(benchmark[memoryLoadKey], " MB"))}</strong></li>`,
    `<li><span>${escapeHtml(memoryMetric)} Peak Delta</span><strong>${escapeHtml(formatMetric(benchmark[memoryPeakKey], " MB"))}</strong></li>`,
    `<li><span>Model Size</span><strong>${escapeHtml(formatMetric(benchmark.modelSizeMB, " MB"))}</strong></li>`,
    `<li><span>Warmup / Test Runs</span><strong>${escapeHtml(String(benchmark.warmupRuns || 0))} / ${escapeHtml(String(benchmark.testRuns || 0))}</strong></li>`,
    `<li><span>Input Tensors</span><strong>${escapeHtml(String(benchmark.inputCount || 0))}</strong></li>`,
  ].join("");
}

function summarizeQualityStatus() {
  const imageState = imageReviewSelect.value;
  const videoState = videoReviewSelect.value;

  imageReviewChip.textContent = imageReviewSelect.options[imageReviewSelect.selectedIndex].text;
  videoReviewChip.textContent = videoReviewSelect.options[videoReviewSelect.selectedIndex].text;

  if (imageState === "fail" || videoState === "fail") {
    qualityVerdict.textContent = "Fail";
    qualityFootnote.textContent = "At least one manual review failed.";
    checklistSummary.textContent = `Image review: ${imageState}. Video review: ${videoState}.`;
    return;
  }

  if (imageState === "pass" && videoState === "pass") {
    qualityVerdict.textContent = "Pass";
    qualityFootnote.textContent = "Image and video review both passed.";
    checklistSummary.textContent = "Image and video review completed successfully.";
    return;
  }

  if (imageState === "needs-check" || videoState === "needs-check") {
    qualityVerdict.textContent = "Needs Check";
    qualityFootnote.textContent = "A reviewer flagged image or video quality for follow-up.";
    checklistSummary.textContent = `Image review: ${imageState}. Video review: ${videoState}.`;
    return;
  }

  qualityVerdict.textContent = "Pending";
  qualityFootnote.textContent = "Manual image/video review pending.";
  checklistSummary.textContent = "Image and video review have not been completed yet.";
}

function bindMediaPreview(binding) {
  binding.input.addEventListener("change", () => {
    const file = binding.input.files?.[0];
    if (!file) {
      binding.media.classList.add("hidden");
      binding.empty.classList.remove("hidden");
      if (binding.kind === "video") {
        binding.media.removeAttribute("src");
        binding.media.load();
      } else {
        binding.media.removeAttribute("src");
      }
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    binding.media.src = objectUrl;
    binding.media.classList.remove("hidden");
    binding.empty.classList.add("hidden");
  });
}

async function runBenchmark() {
  const originalModel = originalModelInput.files?.[0];
  const optimizedModel = optimizedModelInput.files?.[0];

  if (!originalModel || !optimizedModel) {
    showToast("Select both original and optimized ONNX models first.");
    benchmarkStatus.textContent = "Verification blocked. Both ONNX files are required.";
    return;
  }

  runBenchmarkBtn.disabled = true;
  runBenchmarkBtn.textContent = "Running...";
  benchmarkStatus.textContent = `Benchmarking ${originalModel.name} against ${optimizedModel.name}.`;

  try {
    const formData = new FormData();
    formData.append("originalModel", originalModel, originalModel.name);
    formData.append("optimizedModel", optimizedModel, optimizedModel.name);
    formData.append(
      "config",
      JSON.stringify({
        device: getSelectedDeviceLabel(),
        warmupRuns: Number.parseInt(warmupRunsInput.value, 10) || 0,
        testRuns: Number.parseInt(testRunsInput.value, 10) || 1,
        imageReview: imageReviewSelect.value,
        videoReview: videoReviewSelect.value,
      }),
    );

    const response = await fetch(`${BACKEND_BASE_URL}/api/benchmark-onnx`, {
      method: "POST",
      body: formData,
    });
    const payload = await response.json();
    if (!response.ok || !payload.success) {
      throw new Error(payload.error || "Backend benchmark failed.");
    }

    const memoryMetric = payload.benchmark.summary.memoryMetric || "VRAM";
    providerChip.textContent = payload.benchmark.provider || "Unknown Provider";
    latencyDelta.textContent = formatDelta(
      payload.benchmark.summary.latencyDeltaMs,
      payload.benchmark.summary.latencyReductionPct,
      "ms",
    );
    latencyFootnote.textContent = `Baseline ${formatMetric(payload.benchmark.original.averageLatencyMs, " ms")} -> Optimized ${formatMetric(payload.benchmark.optimized.averageLatencyMs, " ms")}`;
    memoryDelta.textContent = formatDelta(
      payload.benchmark.summary.memoryDeltaMB,
      payload.benchmark.summary.memoryReductionPct,
      "MB",
    );
    memoryFootnote.textContent = `${memoryMetric} load delta: ${formatMetric(payload.benchmark.original[memoryMetric === "VRAM" ? "gpuMemoryLoadDeltaMB" : "ramLoadDeltaMB"], " MB")} -> ${formatMetric(payload.benchmark.optimized[memoryMetric === "VRAM" ? "gpuMemoryLoadDeltaMB" : "ramLoadDeltaMB"], " MB")}`;
    renderMetrics(originalMetricsList, payload.benchmark.original, memoryMetric);
    renderMetrics(optimizedMetricsList, payload.benchmark.optimized, memoryMetric);
    backendNote.textContent = payload.quality?.note || "Benchmark completed.";
    resultTimestamp.textContent = payload.metadata?.timestamp || new Date().toISOString();
    benchmarkStatus.textContent = `Verification completed on ${payload.benchmark.provider}.`;
    showToast("Benchmark completed.");
  } catch (error) {
    benchmarkStatus.textContent = "Verification failed while calling the backend benchmark API.";
    showToast(error.message || "Cannot reach backend benchmark API.");
  } finally {
    runBenchmarkBtn.disabled = false;
    runBenchmarkBtn.textContent = "Run Benchmark";
  }
}

originalModelInput.addEventListener("change", () => {
  updateModelNote(originalModelInput, originalModelNote, "Original model");
});

optimizedModelInput.addEventListener("change", () => {
  updateModelNote(optimizedModelInput, optimizedModelNote, "Optimized model");
});

imageReviewSelect.addEventListener("change", summarizeQualityStatus);
videoReviewSelect.addEventListener("change", summarizeQualityStatus);
runBenchmarkBtn.addEventListener("click", runBenchmark);

previewBindings.forEach(bindMediaPreview);
initDevices();
summarizeQualityStatus();
