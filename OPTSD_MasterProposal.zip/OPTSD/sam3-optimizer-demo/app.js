const optimizeBtn = document.getElementById("optimizeBtn");
const runStatus = document.getElementById("runStatus");
const optimizeProgress = document.getElementById("optimize-progress");
const progressLabel = document.getElementById("progress-label");
const progressPercent = document.getElementById("progress-percent");
const progressFill = document.getElementById("progress-fill");
const toast = document.getElementById("toast");
const deviceSelect = document.getElementById("device-select");
const selectedDeviceLabel = document.getElementById("selected-device-label");
const selectedDeviceSummary = document.getElementById("selected-device-summary");
const systemInfoList = document.getElementById("system-info-list");
const modelSourceSelect = document.getElementById("model-source-select");
const localFileWrap = document.getElementById("local-file-wrap");
const urlFileWrap = document.getElementById("url-file-wrap");
const localModelInput = document.getElementById("local-model-input");
const modelUrlInput = document.getElementById("model-url-input");
const chooseFolderBtn = document.getElementById("chooseFolderBtn");
const loadModelBtn = document.getElementById("loadModelBtn");
const folderPathLabel = document.getElementById("folderPathLabel");
const localModelList = document.getElementById("local-model-list");
const modelSourceValue = document.getElementById("model-source-value");
const modelFileValue = document.getElementById("model-file-value");
const modelValidationValue = document.getElementById("model-validation-value");
const modelArchitectureValue = document.getElementById("model-architecture-value");
const modelTechniquesValue = document.getElementById("model-techniques-value");
const validationHint = document.getElementById("validationHint");
const quantizationToggle = document.getElementById("quantization-toggle");
const quantType = document.getElementById("quant-type");
const quantTypeWrap = document.getElementById("quant-type-wrap");
const pruningToggle = document.getElementById("pruning-toggle");
const pruningItem = document.getElementById("pruning-item");
const flashAttentionToggle = document.getElementById("flash-attention-toggle");
const kvCacheToggle = document.getElementById("kv-cache-toggle");
const techniqueSuggestionNote = document.getElementById("techniqueSuggestionNote");
const exportNameInput = document.getElementById("export-name");

const validateBtn = document.getElementById("validateBtn");
const BACKEND_BASE_URL = "http://127.0.0.1:5050";

const appState = {
  devices: [],
  modelStorageDirHandle: null,
  localInputModelFile: null,
  localModels: [],
  latestLoadedModel: null,
  selectedModelName: "",
  optimizationConfig: {
    quantizationEnabled: quantizationToggle.checked,
    quantizationType: quantType.value,
    pruningEnabled: pruningToggle.checked,
    flashAttentionEnabled: flashAttentionToggle.checked,
    kvCacheEnabled: kvCacheToggle.checked,
    exportName: exportNameInput.value.trim(),
  },
};

const architectureProfiles = [
  {
    id: "decoder-transformer",
    label: "Decoder Transformer / LLM",
    keywords: ["llama", "qwen", "mistral", "gpt", "phi", "gemma", "falcon", "mixtral"],
    suggestedTechniques: ["Quantization", "Flash Attention", "KV Cache"],
    note: "Autoregressive transformer models usually benefit most from lower-bit quantization, Flash Attention, and KV cache reuse.",
    applyRecommendations() {
      quantizationToggle.checked = true;
      quantType.value = "Int4";
      pruningToggle.checked = false;
      flashAttentionToggle.checked = true;
      kvCacheToggle.checked = true;
      pruningItem.classList.remove("disabled");
    },
  },
  {
    id: "encoder-transformer",
    label: "Encoder Transformer",
    keywords: ["bert", "roberta", "albert", "deberta", "xlnet", "distilbert"],
    suggestedTechniques: ["Quantization", "Structured Pruning"],
    note: "Encoder-only transformers usually gain from quantization and structured pruning, while KV cache is typically not relevant.",
    applyRecommendations() {
      quantizationToggle.checked = true;
      quantType.value = "Int8";
      pruningToggle.checked = true;
      flashAttentionToggle.checked = false;
      kvCacheToggle.checked = false;
      pruningItem.classList.remove("disabled");
    },
  },
  {
    id: "diffusion",
    label: "Diffusion / U-Net Pipeline",
    keywords: ["diffusion", "stable-diffusion", "sdxl", "unet", "vae", "effdiff"],
    suggestedTechniques: ["Quantization", "Selective Pruning", "Flash Attention"],
    note: "Diffusion pipelines often prefer FP16 or Int8 quantization, selective pruning on convolution-heavy blocks, and Flash Attention on attention layers.",
    applyRecommendations() {
      quantizationToggle.checked = true;
      quantType.value = "FP16";
      pruningToggle.checked = true;
      flashAttentionToggle.checked = true;
      kvCacheToggle.checked = false;
      pruningItem.classList.remove("disabled");
    },
  },
  {
    id: "vision-cnn",
    label: "CNN / Vision Backbone",
    keywords: ["resnet", "mobilenet", "efficientnet", "yolo", "convnext", "densenet"],
    suggestedTechniques: ["Quantization", "Structured Pruning"],
    note: "Vision backbones usually benefit from quantization and channel/filter pruning; KV cache and Flash Attention are not primary levers.",
    applyRecommendations() {
      quantizationToggle.checked = true;
      quantType.value = "Int8";
      pruningToggle.checked = true;
      flashAttentionToggle.checked = false;
      kvCacheToggle.checked = false;
      pruningItem.classList.remove("disabled");
    },
  },
  {
    id: "speech-transformer",
    label: "Speech Transformer / Seq2Seq",
    keywords: ["whisper", "wav2vec", "conformer", "speech", "asr", "tts"],
    suggestedTechniques: ["Quantization", "Flash Attention"],
    note: "Speech transformer stacks usually respond well to quantization and attention optimization; KV cache only helps decoder-style generation stages.",
    applyRecommendations() {
      quantizationToggle.checked = true;
      quantType.value = "Int8";
      pruningToggle.checked = false;
      flashAttentionToggle.checked = true;
      kvCacheToggle.checked = false;
      pruningItem.classList.remove("disabled");
    },
  },
];

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function supportsFolderPicker() {
  return typeof window.showDirectoryPicker === "function";
}

function formatDeviceName(device) {
  if (!device) return "Unknown device";
  if (device.type === "GPU") return `${device.name} (GPU)`;
  if (device.type === "CPU") return `${device.name} (CPU)`;
  return device.name;
}

function setModelInfo(sourceLabel, fileName) {
  modelSourceValue.textContent = sourceLabel;
  modelFileValue.textContent = fileName || "Not loaded yet";
}

function setValidationState(status, architecture = "Unknown", techniques = "Validate a loaded model to see suggestions.") {
  modelValidationValue.textContent = status;
  modelArchitectureValue.textContent = architecture;
  modelTechniquesValue.textContent = techniques;
}

function getSelectedModelFileName() {
  return appState.selectedModelName || appState.latestLoadedModel?.fileName || "";
}

function updateOptimizationConfig(patch = {}) {
  appState.optimizationConfig = {
    ...appState.optimizationConfig,
    ...patch,
  };
}

function syncQuantTypeVisibility() {
  quantTypeWrap.classList.toggle("hidden", !quantizationToggle.checked);
}

function syncOptimizationConfigFromControls() {
  updateOptimizationConfig({
    quantizationEnabled: quantizationToggle.checked,
    quantizationType: quantType.value,
    pruningEnabled: pruningToggle.checked,
    flashAttentionEnabled: flashAttentionToggle.checked,
    kvCacheEnabled: kvCacheToggle.checked,
    exportName: sanitizeExportName(exportNameInput.value),
  });
}

function syncOptimizationSummary() {
  const enabledTechniques = [];

  if (appState.optimizationConfig.quantizationEnabled) {
    enabledTechniques.push(`Quantization (${appState.optimizationConfig.quantizationType})`);
  }
  if (appState.optimizationConfig.pruningEnabled) {
    enabledTechniques.push("Pruning");
  }
  if (appState.optimizationConfig.flashAttentionEnabled) {
    enabledTechniques.push("Flash Attention");
  }
  if (appState.optimizationConfig.kvCacheEnabled) {
    enabledTechniques.push("KV Cache");
  }

  modelTechniquesValue.textContent = enabledTechniques.length
    ? enabledTechniques.join(", ")
    : "No technique enabled";
}

function rememberLoadedModel({ source, fileName, fileSize = null, mimeType = "", origin = "" }) {
  appState.latestLoadedModel = {
    source,
    fileName,
    fileSize,
    mimeType,
    origin,
    loadedAt: new Date().toISOString(),
  };
  appState.selectedModelName = fileName;
  setValidationState("Pending validation");
}

function normalizeModelDescriptor(model) {
  if (!model) return "";
  return [model.fileName, model.mimeType, model.origin]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

function inferArchitectureProfile(model) {
  const descriptor = normalizeModelDescriptor(model);

  for (const profile of architectureProfiles) {
    if (profile.keywords.some((keyword) => descriptor.includes(keyword))) {
      return profile;
    }
  }

  if (/\.onnx$/i.test(model?.fileName || "")) {
    return {
      label: "Generic ONNX Graph",
      suggestedTechniques: ["Quantization", "Graph Simplification"],
      note: "The model format is valid for graph-level optimization, but the architecture cannot be inferred reliably from the file name alone.",
      applyRecommendations() {
        quantizationToggle.checked = true;
        quantType.value = "Int8";
        pruningToggle.checked = false;
        flashAttentionToggle.checked = false;
        kvCacheToggle.checked = false;
        pruningItem.classList.remove("disabled");
      },
    };
  }

  return {
    label: "Unknown Architecture",
    suggestedTechniques: ["Quantization"],
    note: "Only a generic quantization recommendation is available because the file name does not expose the model family.",
    applyRecommendations() {
      quantizationToggle.checked = true;
      quantType.value = "Int8";
      pruningToggle.checked = false;
      flashAttentionToggle.checked = false;
      kvCacheToggle.checked = false;
      pruningItem.classList.remove("disabled");
    },
  };
}

function validateLoadedModel() {
  const selectedModelName = getSelectedModelFileName();
  const model = selectedModelName
    ? {
        ...(appState.latestLoadedModel || {}),
        fileName: selectedModelName,
      }
    : null;

  if (!model?.fileName) {
    showToast("Please load a model file first.");
    setValidationState("Missing model", "Unknown", "Load a local file or URL model before validation.");
    validationHint.textContent = "No model has been loaded into the workspace yet.";
    return;
  }

  const extension = model.fileName.split(".").pop()?.toLowerCase() || "";
  const supportedExtensions = ["onnx", "pt", "pth", "bin"];
  const isSupported = supportedExtensions.includes(extension);

  if (!isSupported) {
    setValidationState(
      "Unsupported format",
      "Unknown",
      `Supported formats: ${supportedExtensions.join(", ")}.`,
    );
    validationHint.textContent = `Loaded file ${model.fileName} is not a supported model artifact.`;
    showToast("Model file format is not supported.");
    return;
  }

  const profile = inferArchitectureProfile(model);
  profile.applyRecommendations();
  syncQuantTypeVisibility();
  syncOptimizationConfigFromControls();

  const techniquesSummary = profile.suggestedTechniques.join(", ");
  setValidationState("Validated", profile.label, techniquesSummary);
  validationHint.textContent = profile.note;
  techniqueSuggestionNote.textContent = `Suggested for ${profile.label}: ${techniquesSummary}.`;
  runStatus.textContent = `${model.fileName} validated as ${profile.label}. Suggested: ${techniquesSummary}.`;
  showToast(`Validated ${model.fileName}. Suggested: ${techniquesSummary}.`);
  syncOptimizationSummary();
}

function sanitizeExportName(value) {
  const normalized = (value || "optimized-model")
    .trim()
    .replace(/[^a-z0-9-_]+/gi, "-")
    .replace(/^-+|-+$/g, "");
  return normalized || "optimized-model";
}

function decodeBase64ToBytes(base64Value) {
  const binary = window.atob(base64Value);
  const bytes = new Uint8Array(binary.length);

  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }

  return bytes;
}

async function readSelectedModelFile() {
  const selectedModelName = getSelectedModelFileName();
  if (!selectedModelName) {
    return null;
  }

  if (
    modelSourceSelect.value === "local" &&
    appState.localInputModelFile &&
    appState.localInputModelFile.name === selectedModelName
  ) {
    return appState.localInputModelFile;
  }

  if (!appState.modelStorageDirHandle) {
    return null;
  }

  const fileHandle = await appState.modelStorageDirHandle.getFileHandle(selectedModelName);
  return fileHandle.getFile();
}

async function saveArtifactToFolder(fileDescriptor) {
  const fileHandle = await appState.modelStorageDirHandle.getFileHandle(fileDescriptor.name, {
    create: true,
  });
  const writable = await fileHandle.createWritable();
  const bytes = decodeBase64ToBytes(fileDescriptor.contentBase64);
  const blob = new Blob([bytes], { type: fileDescriptor.mimeType || "application/octet-stream" });
  await writable.write(blob);
  await writable.close();
  return fileDescriptor.name;
}

function downloadArtifactToClient(fileDescriptor) {
  const bytes = decodeBase64ToBytes(fileDescriptor.contentBase64);
  const blob = new Blob([bytes], { type: fileDescriptor.mimeType || "application/octet-stream" });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = objectUrl;
  link.download = fileDescriptor.name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  return fileDescriptor.name;
}

async function optimizeModelViaBackend(modelFile) {
  const formData = new FormData();
  formData.append("model", modelFile, modelFile.name);
  formData.append(
    "config",
    JSON.stringify({
      exportName: appState.optimizationConfig.exportName,
      quantizationEnabled: appState.optimizationConfig.quantizationEnabled,
      quantizationType: appState.optimizationConfig.quantizationType,
      pruningEnabled: appState.optimizationConfig.pruningEnabled,
      flashAttentionEnabled: appState.optimizationConfig.flashAttentionEnabled,
      kvCacheEnabled: appState.optimizationConfig.kvCacheEnabled,
      device: selectedDeviceSummary.textContent,
      validation: modelValidationValue.textContent,
      architecture: modelArchitectureValue.textContent,
    }),
  );

  const response = await fetch(`${BACKEND_BASE_URL}/api/optimize-onnx`, {
    method: "POST",
    body: formData,
  });

  const payload = await response.json();
  if (!response.ok || !payload.success) {
    throw new Error(payload.error || "Backend optimization failed.");
  }

  return payload;
}

function buildOptimizationPlan() {
  const steps = [];

  if (appState.optimizationConfig.quantizationEnabled) {
    steps.push(`Apply ${appState.optimizationConfig.quantizationType} quantization`);
  }
  if (appState.optimizationConfig.pruningEnabled) {
    steps.push("Run pruning pass");
  }
  if (appState.optimizationConfig.flashAttentionEnabled) {
    steps.push("Enable Flash Attention kernels");
  }
  if (appState.optimizationConfig.kvCacheEnabled) {
    steps.push("Prepare KV cache path");
  }

  return steps;
}

let progressTimer = null;
let progressHideTimer = null;

function setProgress(percent, label) {
  const clamped = Math.max(0, Math.min(100, percent));
  progressFill.style.width = `${clamped}%`;
  progressPercent.textContent = `${Math.round(clamped)}%`;
  optimizeProgress.setAttribute("aria-valuenow", String(Math.round(clamped)));
  if (label) {
    progressLabel.textContent = label;
  }
}

function startProgress(steps) {
  clearInterval(progressTimer);
  clearTimeout(progressHideTimer);
  optimizeProgress.classList.remove("hidden", "done", "error");
  setProgress(0, steps[0] ? `${steps[0]}...` : "Preparing optimization...");

  let current = 0;
  const totalSteps = steps.length;
  const cap = 92; // Reserve the last stretch for the real completion signal.

  progressTimer = setInterval(() => {
    if (current >= cap) return;
    current = Math.min(cap, current + Math.random() * 4 + 1.5);
    const stepIndex = Math.min(totalSteps - 1, Math.floor((current / cap) * totalSteps));
    setProgress(current, `${steps[stepIndex]}...`);
  }, 380);
}

function finishProgress(label) {
  clearInterval(progressTimer);
  optimizeProgress.classList.remove("error");
  optimizeProgress.classList.add("done");
  setProgress(100, label || "Optimization completed.");
  clearTimeout(progressHideTimer);
  progressHideTimer = setTimeout(() => {
    optimizeProgress.classList.add("hidden");
    optimizeProgress.classList.remove("done");
  }, 3200);
}

function failProgress(label) {
  clearInterval(progressTimer);
  optimizeProgress.classList.remove("done");
  optimizeProgress.classList.add("error");
  progressLabel.textContent = label || "Optimization failed.";
  clearTimeout(progressHideTimer);
  progressHideTimer = setTimeout(() => {
    optimizeProgress.classList.add("hidden");
    optimizeProgress.classList.remove("error");
  }, 4200);
}

async function runOptimization() {
  const selectedModelName = getSelectedModelFileName();
  if (!selectedModelName) {
    showToast("Select or load a model before optimization.");
    runStatus.textContent = "Optimization blocked. No model selected.";
    return;
  }

  const steps = buildOptimizationPlan();
  if (!steps.length) {
    showToast("Enable at least one optimization technique.");
    runStatus.textContent = "Optimization blocked. No technique enabled.";
    return;
  }

  if (!/\.onnx$/i.test(selectedModelName)) {
    showToast("Backend optimizer currently supports ONNX models only.");
    runStatus.textContent = "Optimization blocked. Selected model is not an ONNX file.";
    return;
  }

  exportNameInput.value = sanitizeExportName(exportNameInput.value);
  syncOptimizationConfigFromControls();
  const modelFile = await readSelectedModelFile();
  if (!modelFile) {
    showToast("Cannot read the selected model file.");
    runStatus.textContent = "Optimization blocked. Selected model file is unavailable.";
    return;
  }

  optimizeBtn.disabled = true;
  optimizeBtn.textContent = "Optimizing...";
  runStatus.textContent = `Optimizing ${selectedModelName} with ${steps.join(", ")}.`;
  startProgress(steps);

  try {
    const payload = await optimizeModelViaBackend(modelFile);
    let savedFiles = [];

    if (appState.modelStorageDirHandle) {
      savedFiles = await Promise.all([
        saveArtifactToFolder(payload.files.optimizedModel),
        saveArtifactToFolder(payload.files.report),
        saveArtifactToFolder(payload.files.log),
      ]);
      runStatus.textContent = `Optimization completed. Saved ${savedFiles.join(", ")} to the storage folder.`;
    } else {
      savedFiles = [
        downloadArtifactToClient(payload.files.optimizedModel),
        downloadArtifactToClient(payload.files.report),
        downloadArtifactToClient(payload.files.log),
      ];
      runStatus.textContent = `Optimization completed. Downloaded ${savedFiles.join(", ")} to this machine.`;
    }

    techniqueSuggestionNote.textContent = payload.metadata.runtimeNotes?.length
      ? payload.metadata.runtimeNotes.join(" ")
      : techniqueSuggestionNote.textContent;
    finishProgress("Optimization completed.");
    showToast(`Saved ${payload.files.optimizedModel.name}, optimized-model.json, and optimization-log.txt.`);
  } catch (error) {
    runStatus.textContent = "Optimization failed while calling the backend optimizer.";
    failProgress("Optimization failed.");
    showToast(error.message || "Cannot reach backend optimizer.");
  } finally {
    optimizeBtn.disabled = false;
    optimizeBtn.textContent = "Start Optimization";
  }
}

function getFileNameFromUrl(urlValue) {
  try {
    const parsed = new URL(urlValue);
    const segment = parsed.pathname.split("/").pop();
    return segment || "downloaded-model.bin";
  } catch {
    return "downloaded-model.bin";
  }
}

function renderLocalModelList() {
  if (!appState.localModels.length) {
    localModelList.innerHTML = "<li>No local model saved yet.</li>";
    return;
  }

  localModelList.innerHTML = appState.localModels
    .map((name) => {
      const isSelected = name === appState.selectedModelName;
      return `
        <li>
          <button
            type="button"
            class="model-list-item${isSelected ? " is-selected" : ""}"
            data-model-name="${escapeHtml(name)}"
          >
            ${escapeHtml(name)}
          </button>
        </li>
      `;
    })
    .join("");
}

function selectLocalModel(modelName) {
  if (!modelName || !appState.localModels.includes(modelName)) {
    return;
  }

  appState.selectedModelName = modelName;
  setModelInfo("Local Library", modelName);
  setValidationState("Pending validation");
  validationHint.textContent = `Selected ${modelName}. Validate it to infer architecture and suggestions.`;
  renderLocalModelList();
}

function renderSourceMode() {
  const mode = modelSourceSelect.value;
  const isLocal = mode === "local";
  loadModelBtn.textContent = isLocal ? "Load Model" : "Load And Save Model";
  localFileWrap.classList.toggle("hidden", !isLocal);
  urlFileWrap.classList.toggle("hidden", isLocal);
  chooseFolderBtn.classList.toggle("hidden", isLocal);
  folderPathLabel.classList.toggle("hidden", isLocal);
}

async function syncLocalModelsFromFolder() {
  if (!appState.modelStorageDirHandle) {
    appState.localModels = [];
    renderLocalModelList();
    return;
  }

  const modelFiles = [];
  for await (const [name, entry] of appState.modelStorageDirHandle.entries()) {
    if (entry.kind === "file") {
      modelFiles.push(name);
    }
  }

  modelFiles.sort((a, b) => a.localeCompare(b));
  appState.localModels = modelFiles;
  renderLocalModelList();
}

async function chooseStorageFolder() {
  if (!supportsFolderPicker()) {
    showToast("Browser does not support folder picker. Use recent Chrome/Edge.");
    return;
  }

  try {
    const directoryHandle = await window.showDirectoryPicker({ mode: "readwrite" });
    const permission = await directoryHandle.requestPermission({ mode: "readwrite" });
    if (permission !== "granted") {
      showToast("Storage folder permission was not granted.");
      return;
    }

    appState.modelStorageDirHandle = directoryHandle;
    folderPathLabel.textContent = `Storage folder: ${directoryHandle.name}`;
    await syncLocalModelsFromFolder();
    showToast("Storage folder selected.");
  } catch {
    showToast("Folder selection cancelled.");
  }
}

async function saveBlobToFolder(fileBlob, targetFileName) {
  if (!appState.modelStorageDirHandle) {
    showToast("Choose a storage folder first.");
    return false;
  }

  const safeName = (targetFileName || "model.bin").trim() || "model.bin";
  const fileHandle = await appState.modelStorageDirHandle.getFileHandle(safeName, { create: true });
  const writable = await fileHandle.createWritable();
  await writable.write(fileBlob);
  await writable.close();
  return true;
}

async function loadLocalModelToFolder() {
  const file = localModelInput.files?.[0];
  if (!file) {
    showToast("Please pick a local model file first.");
    return;
  }

  appState.localInputModelFile = file;
  appState.selectedModelName = file.name;
  renderLocalModelList();
  setModelInfo("Local", file.name);
  rememberLoadedModel({
    source: "Local",
    fileName: file.name,
    fileSize: file.size,
    mimeType: file.type,
  });
  showToast(`Model saved: ${file.name}`);
}

async function loadUrlModelToFolder() {
  const urlValue = modelUrlInput.value.trim();
  if (!urlValue) {
    showToast("Please enter a model URL.");
    return;
  }

  runStatus.textContent = "Downloading model from URL...";

  try {
    const response = await fetch(urlValue);
    if (!response.ok) {
      throw new Error(`Download failed (${response.status})`);
    }

    const fileBlob = await response.blob();
    const targetName = getFileNameFromUrl(urlValue);
    const saved = await saveBlobToFolder(fileBlob, targetName);
    if (!saved) {
      runStatus.textContent = "System idle. Ready to optimize.";
      return;
    }

    await syncLocalModelsFromFolder();
    setModelInfo("URL", targetName);
    rememberLoadedModel({
      source: "URL",
      fileName: targetName,
      fileSize: fileBlob.size,
      mimeType: fileBlob.type,
      origin: urlValue,
    });
    runStatus.textContent = `Downloaded and saved ${targetName}.`;
    showToast(`Model downloaded: ${targetName}`);
  } catch (error) {
    runStatus.textContent = "System idle. Ready to optimize.";
    showToast(error.message || "Cannot download model from URL.");
  }
}

function renderSystemInfo(data) {
  const rows = [];
  const gpuDevices = data.devices.filter((device) => device.type === "GPU");

  rows.push(`<li><span>GPU slots</span><strong>${gpuDevices.length}</strong></li>`);

  gpuDevices.forEach((gpu, index) => {
    rows.push(
      `<li><span>GPU ${index}</span><strong>${escapeHtml(gpu.name)}</strong></li>`,
    );

    if (gpu.memoryGB) {
      rows.push(
        `<li><span>GPU ${index} RAM</span><strong>${escapeHtml(String(gpu.memoryGB))} GB</strong></li>`,
      );
    }
  });

  if (data.cpuCores) {
    rows.push(`<li><span>CPU Cores</span><strong>${escapeHtml(String(data.cpuCores))}</strong></li>`);
  } else if (typeof navigator.hardwareConcurrency === "number") {
    rows.push(`<li><span>CPU Cores</span><strong>${navigator.hardwareConcurrency}</strong></li>`);
  }

  if (data.totalMemoryGB) {
    rows.push(`<li><span>RAM</span><strong>${escapeHtml(String(data.totalMemoryGB))} GB</strong></li>`);
  } else if (typeof navigator.deviceMemory === "number") {
    rows.push(`<li><span>RAM (approx)</span><strong>${navigator.deviceMemory} GB</strong></li>`);
  }

  if (data.host?.hostname) {
    rows.push(`<li><span>Host</span><strong>${escapeHtml(data.host.hostname)}</strong></li>`);
  }

  if (data.host?.os) {
    rows.push(`<li><span>OS</span><strong>${escapeHtml(data.host.os)}</strong></li>`);
  }

  if (Array.isArray(data.availableProviders) && data.availableProviders.length) {
    rows.push(
      `<li><span>ORT Providers</span><strong>${escapeHtml(data.availableProviders.join(", "))}</strong></li>`,
    );
  }

  if (typeof data.webgpuAvailable === "boolean") {
    rows.push(
      `<li><span>WebGPU</span><strong>${data.webgpuAvailable ? "Available" : "Unavailable"}</strong></li>`,
    );
  }

  if (data.dataSource) {
    rows.push(`<li><span>Data Source</span><strong>${escapeHtml(data.dataSource)}</strong></li>`);
  }

  systemInfoList.innerHTML = rows.join("");
}

function setSelectedDevice(deviceId) {
  const selected = appState.devices.find((device) => device.id === deviceId);
  const displayName = formatDeviceName(selected);
  selectedDeviceLabel.textContent = `Using ${displayName}`;
  selectedDeviceSummary.textContent = displayName;
}

async function detectHardwareDevices() {
  try {
    const response = await fetch(`${BACKEND_BASE_URL}/api/device-resources`);
    const payload = await response.json();

    if (response.ok && payload.success && Array.isArray(payload.devices) && payload.devices.length) {
      return payload;
    }
  } catch {
    // Fall back to browser-side detection when backend is unavailable.
  }

  const devices = [];
  let webgpuAvailable = false;

  if (navigator.gpu?.requestAdapter) {
    webgpuAvailable = true;
    try {
      const adapter = await navigator.gpu.requestAdapter();
      if (adapter) {
        const gpuName =
          adapter.info?.description || adapter.info?.vendor || "Detected GPU (name unavailable)";

        devices.push({
          id: "gpu-0",
          name: gpuName,
          type: "GPU",
        });
      }
    } catch {
      // Browser may block adapter details in non-secure contexts.
    }
  }

  const cpuLabel =
    typeof navigator.hardwareConcurrency === "number"
      ? `System CPU (${navigator.hardwareConcurrency} cores)`
      : "System CPU";

  devices.push({
    id: "cpu-0",
    name: cpuLabel,
    type: "CPU",
  });

  return {
    devices,
    webgpuAvailable,
    cpuCores: typeof navigator.hardwareConcurrency === "number" ? navigator.hardwareConcurrency : null,
    totalMemoryGB: typeof navigator.deviceMemory === "number" ? navigator.deviceMemory : null,
    dataSource: "browser-client",
  };
}

function renderDeviceSelect() {
  deviceSelect.innerHTML = appState.devices
    .map((device) => {
      const label = formatDeviceName(device);
      return `<option value="${escapeHtml(device.id)}">${escapeHtml(label)}</option>`;
    })
    .join("");

  if (appState.devices[0]) {
    deviceSelect.value = appState.devices[0].id;
    setSelectedDevice(appState.devices[0].id);
  }
}

async function initDeviceDetection() {
  const hardware = await detectHardwareDevices();
  appState.devices = hardware.devices;
  renderDeviceSelect();
  renderSystemInfo(hardware);
}

localModelList.addEventListener("click", (event) => {
  const trigger = event.target.closest("[data-model-name]");
  if (!trigger) return;
  selectLocalModel(trigger.dataset.modelName || "");
});

quantizationToggle.addEventListener("change", () => {
  updateOptimizationConfig({ quantizationEnabled: quantizationToggle.checked });
  syncQuantTypeVisibility();
  syncOptimizationSummary();
});

quantType.addEventListener("change", () => {
  updateOptimizationConfig({ quantizationType: quantType.value });
  syncOptimizationSummary();
});

pruningToggle.addEventListener("change", () => {
  updateOptimizationConfig({ pruningEnabled: pruningToggle.checked });
  syncOptimizationSummary();
});

flashAttentionToggle.addEventListener("change", () => {
  updateOptimizationConfig({ flashAttentionEnabled: flashAttentionToggle.checked });
  syncOptimizationSummary();
});

kvCacheToggle.addEventListener("change", () => {
  updateOptimizationConfig({ kvCacheEnabled: kvCacheToggle.checked });
  syncOptimizationSummary();
});

exportNameInput.addEventListener("change", () => {
  exportNameInput.value = sanitizeExportName(exportNameInput.value);
  updateOptimizationConfig({ exportName: exportNameInput.value });
});

modelSourceSelect.addEventListener("change", () => {
  renderSourceMode();
});

chooseFolderBtn.addEventListener("click", async () => {
  await chooseStorageFolder();
});

loadModelBtn.addEventListener("click", async () => {
  const sourceMode = modelSourceSelect.value;
  if (sourceMode === "local") {
    await loadLocalModelToFolder();
  } else {
    if (!appState.modelStorageDirHandle) {
      showToast("Choose a storage folder first.");
      return;
    }
    await loadUrlModelToFolder();
  }
});

deviceSelect.addEventListener("change", () => {
  setSelectedDevice(deviceSelect.value);
});

validateBtn.addEventListener("click", () => {
  validateLoadedModel();
});

optimizeBtn.addEventListener("click", async () => {
  await runOptimization();
});

initDeviceDetection();
renderSourceMode();
renderLocalModelList();
exportNameInput.value = sanitizeExportName(exportNameInput.value);
syncQuantTypeVisibility();
syncOptimizationConfigFromControls();
syncOptimizationSummary();
