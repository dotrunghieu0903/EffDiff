# SAM3 Optimizer Demo - Run on Another Machine

This guide runs the demo with a separate Python environment so it does not modify the machine's global Python packages.

## 1. Prerequisites

Install these first:
- Python 3.11 or 3.12
- A Chromium browser: Chrome or Edge
- Windows PowerShell

Recommended:
- Use a fresh virtual environment for the backend
- Use an `.onnx` model for real backend optimization

## 2. Copy the project

Copy this folder to the other machine:
- `sam3-optimizer-demo/`

The folder should contain:
- `index.html`
- `app.js`
- `styles.css`
- `backend/main.py`
- `backend/requirements.txt`

## 3. Create a Python virtual environment

Open PowerShell in `sam3-optimizer-demo/backend` and run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

If PowerShell blocks activation, run this once in the same terminal:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\.venv\Scripts\Activate.ps1
```

## 4. Install backend dependencies

Still inside `sam3-optimizer-demo/backend`, run:

```powershell
python -m pip install -r .\requirements.txt
```

This installs:
- Flask backend
- ONNX runtime
- ONNX graph utilities
- FP16 conversion support

## 5. Start the backend

From `sam3-optimizer-demo/backend`, run:

```powershell
python .\main.py
```

Expected result:
- Flask starts on `http://127.0.0.1:5050`
- Health endpoint: `http://127.0.0.1:5050/api/health`

Quick health test from a second terminal:

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:5050/api/health | Select-Object -ExpandProperty Content
```

## 6. Start the frontend on localhost

Open a second PowerShell terminal in `sam3-optimizer-demo` and run:

```powershell
python -m http.server 8080
```

Then open:
- `http://127.0.0.1:8080`

Do not open `index.html` directly with `file://`.
Use localhost so browser APIs and backend calls behave consistently.

## 7. Use the demo

In the browser:

1. Click `Choose Storage Folder`
2. Pick a writable local folder for model artifacts
3. Load a model using:
   - `Local File`, or
   - `URL`
4. Click `Validate Model File`
5. Review suggested techniques
6. Adjust optimization settings if needed
7. Set `Output Name`
8. Click `Start Optimization`

## 8. What works for real right now

Real backend optimization currently supports:
- `.onnx` only
- Graph optimization with ONNX Runtime
- Weight pruning pass
- Quantization:
  - `Int8`
  - `FP16`

Current limitation:
- `Int4` falls back to `Int8`
- `Flash Attention` and `KV Cache` are recorded as runtime notes, not rewritten directly into the ONNX graph
- `.pt`, `.pth`, `.bin` are still UI-loadable, but real backend optimization is ONNX-only

## 9. Output files

After a successful optimization, the selected storage folder will receive:
- `<output-name>.onnx`
- `optimized-model.json`
- `optimization-log.txt`

Meaning:
- `<output-name>.onnx`: optimized model artifact
- `optimized-model.json`: metadata and optimization summary
- `optimization-log.txt`: backend execution log for demo/debugging

## 10. Troubleshooting

If backend does not start:

```powershell
python -m pip install -r .\requirements.txt
python -m py_compile .\main.py
```

If the frontend says it cannot reach backend:
- Confirm backend is still running on port `5050`
- Open `http://127.0.0.1:5050/api/health`
- Make sure the frontend is opened from `http://127.0.0.1:8080`

If optimization is blocked:
- Use an `.onnx` model
- Make sure a storage folder was selected
- Make sure at least one optimization technique is enabled

## 11. Clean shutdown

Stop both processes with `Ctrl+C`:
- backend terminal
- frontend `http.server` terminal

## 12. Optional one-line startup summary

Terminal 1:

```powershell
cd .\sam3-optimizer-demo\backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r .\requirements.txt
python .\main.py
```

Terminal 2:

```powershell
cd .\sam3-optimizer-demo
python -m http.server 8080
```
