# Flash Attention + KV Cache Quantization + Attention-Score Pruning
## Mechanism Explained — English Academic & Vietnamese

---

# PART I — ENGLISH (Academic)

## Overview

This method addresses a fundamental bottleneck in autoregressive LLM inference: as sequence length grows, the **KV cache** consumes an increasingly large portion of GPU HBM, and the associated memory bandwidth becomes the primary throughput bottleneck. The proposed system integrates three orthogonal but synergistic optimizations:

1. **Per-head, group-wise quantization** of the KV cache.
2. **Attention-score-based token pruning** to evict unimportant cached tokens.
3. **Flash Attention** as the underlying tiled attention kernel, with on-the-fly dequantization.

---

## 1. The Memory Bottleneck in Autoregressive Decoding

During each decode step, the model must attend over all previously generated tokens. The KV cache stores the key/value projections of every past token:

$$
K_{cache} \in \mathbb{R}^{B \times H \times T \times d}, \quad V_{cache} \in \mathbb{R}^{B \times H \times T \times d}
$$

Memory footprint scales as $\mathcal{O}(T \cdot H \cdot d)$ per layer. For a 70B-parameter model with $H=64$, $d=128$, and $T=8192$, the KV cache alone can exceed 64 GB across 80 layers in FP16 — far exceeding single-GPU memory. **Reducing the memory cost of the KV cache is therefore the central challenge.**

---

## 2. Per-Head, Group-wise Quantization

### 2.1 Why Finer Granularity?

Per-tensor quantization assigns a single `(scale, zero-point)` pair to an entire tensor. The issue is that different attention heads learn qualitatively different representations, and within a head, different channel groups exhibit different magnitude distributions. A single scale factor either wastes range on small activations or clips large ones, causing substantial INT4 error.

**Per-head, group-wise quantization** partitions the channel dimension $d$ into groups of size $g$ (e.g., $g = 128$). Each `(head h, group j)` pair receives its own `(scale, zero-point)`:

$$
s^{(h,j)} = \frac{\alpha^{(h,j)}}{2^{b-1} - 1}, \quad z^{(h,j)} = 0 \quad \text{(symmetric)}
$$

where $\alpha^{(h,j)} = \mathrm{Percentile}(|x^{(h,j)}|,\, p)$ clips outliers at the $p$-th percentile before computing the scale.

### 2.2 Offline Calibration

The `(scale, zero-point)` table is computed once offline on a small calibration set $\mathcal{D}_{cal}$:

1. Forward the model on $\mathcal{D}_{cal}$; collect $K^{(h)}, V^{(h)}$ tensors across all layers and heads.
2. For each `(h, j)`, compute $\alpha$ via percentile clipping, then derive $s$ and $z$.
3. Store the resulting table — its size is negligible: $H \cdot d/g$ scalars per tensor.

### 2.3 Online Quantization / Dequantization

At each decode step, new key/value vectors are quantized before being appended to cache:

$$
\tilde{x}^{(h,j)} = \mathrm{clip}\!\left(\mathrm{round}\!\left(\frac{x^{(h,j)}}{s^{(h,j)}}\right) + z^{(h,j)},\; q_{\min},\, q_{\max}\right)
$$

During attention computation, the Flash Attention kernel reads INT$b$ values from HBM and dequantizes them **on-the-fly in SRAM** before the matrix multiplication:

$$
\hat{x}^{(h,j)} = s^{(h,j)} \cdot \left(\tilde{x}^{(h,j)} - z^{(h,j)}\right)
$$

This avoids writing a dequantized FP16 copy back to HBM, preserving the bandwidth savings.

| Precision | Bytes/element | Reduction vs FP16 |
|-----------|--------------|-------------------|
| FP16      | 2            | 1×                |
| INT8      | 1            | 2×                |
| INT4      | 0.5          | 4×                |

---

## 3. Attention-Score-Based Token Pruning

### 3.1 The Limitation of Magnitude-Based Pruning

A naive approach evicts tokens whose $K$ vectors have small $\ell_2$ norm. However, norm magnitude does not measure **relevance to the current query**. A key vector with a small norm but a direction closely aligned with the query can contribute substantially to the softmax output. Magnitude-based pruning therefore systematically removes tokens that may be critical.

### 3.2 Importance Scoring

Every $\Delta$ decode steps, a **pruning pass** is triggered:

1. Compute the attention score matrix using the current (or averaged) query:

$$
A = \mathrm{softmax}\!\left(\frac{Q\hat{K}^\top}{\sqrt{d}}\right) \in \mathbb{R}^{H \times T_q \times T_k}
$$

2. Aggregate scores across heads and query positions to obtain a per-token scalar importance:

$$
\sigma_t = \frac{1}{H \cdot T_q} \sum_{h,i} A[h, i, t]
$$

3. Apply Exponential Moving Average (EMA) to smooth across refresh cycles:

$$
\bm{\sigma} \leftarrow \beta\,\bm{\sigma}_{prev} + (1-\beta)\,\bm{\sigma}_{new}, \quad \beta \approx 0.9
$$

### 3.3 Cache Eviction

Retain only the top-$k$ tokens by smoothed importance:

$$
\mathcal{I}_{keep} = \mathrm{TopK}\!\left(\bm{\sigma},\; k = \lceil (1-\rho)\, T_k \rceil\right)
$$

**Protected tokens** (never evicted):
- **Sink tokens**: the first 4–8 tokens of the sequence. LLMs (particularly those trained with StreamingLLM-style objectives) divert a disproportionate share of attention to these tokens; evicting them collapses model quality.
- **Sliding window**: the most recent $w$ tokens. Recency is a strong prior for relevance in causal language models.

### 3.4 Why This Works

The attention distribution $A$ directly reflects how much each cached token influences the current output. Token eviction guided by $A$ is thus a principled, task-aware compression strategy — it preserves the tokens that **matter** while discarding those that do not.

---

## 4. Flash Attention as the Underlying Kernel

Flash Attention replaces the standard $\mathcal{O}(T^2)$ attention algorithm by computing attention in **tiles** that fit entirely within SRAM:

1. The $Q, K, V$ tensors are loaded in blocks from HBM.
2. The softmax is computed incrementally using the online normalization trick (log-sum-exp rescaling).
3. The output $O$ is accumulated in SRAM and written back to HBM **once**.

The key saving: the full $T \times T$ attention matrix is **never materialized in HBM**, reducing memory I/O from $\mathcal{O}(T^2)$ to $\mathcal{O}(T)$. This is precisely where on-the-fly dequantization is performed — INT$b$ values are expanded to FP16/BF16 within the SRAM tile, with no additional HBM round-trip.

---

## 5. System-Level Interaction

```
Offline:
  (s_k, z_k), (s_v, z_v) ← Calibrate(model, D_cal, b, g, p)

Online (decode step t):
  ┌─ New token:
  │   K_q ← Quantize(K_new, s_k, z_k, b)      # INT{b}, stays in cache
  │   V_q ← Quantize(V_new, s_v, z_v, b)
  │   K_cache ← Append(K_cache, K_q)
  │
  ├─ Pruning (every Δ steps):
  │   σ ← AttentionScores(Q, Dequantize(K_cache)) .mean(heads, queries)
  │   σ_ema ← β·σ_prev + (1−β)·σ
  │   keep ← TopK(σ_ema, k=(1−ρ)·T) ∪ SinkTokens ∪ SlidingWindow
  │   K_cache, V_cache ← K_cache[keep], V_cache[keep]
  │
  └─ Attention:
      Output ← FlashAttn(Q, K_cache, V_cache,
                         dequant_fn=(s_k,z_k,s_v,z_v))
      # Dequant happens on-the-fly inside the tiled SRAM kernel
```

---

## 6. Complexity and Memory Analysis

| Component | Before | After |
|-----------|--------|-------|
| KV cache memory | $2 \cdot B \cdot H \cdot T \cdot d \cdot 2$ bytes (FP16) | $\div 2$ (INT8) or $\div 4$ (INT4), then $\times (1-\rho)$ |
| HBM bandwidth per step | $\mathcal{O}(T \cdot H \cdot d)$ | $\mathcal{O}((1-\rho) \cdot T \cdot H \cdot d / 2)$ (INT8) |
| Pruning overhead | — | $\mathcal{O}(H \cdot T_q \cdot T_k)$ every $\Delta$ steps |
| Calibration | — | One-time offline, negligible size |

Combined, the method achieves **2–8× KV cache size reduction** depending on $(b, \rho)$, with negligible perplexity degradation for $b=8, \rho \le 0.4$ on typical benchmarks.

---

---

# PHẦN II — TIẾNG VIỆT (Giải thích học thuật)

## Tổng quan

Phương pháp này giải quyết nút thắt cổ chai cơ bản trong inference LLM tự hồi quy: khi chuỗi dài ra, **KV Cache** chiếm ngày càng nhiều bộ nhớ HBM của GPU, và băng thông bộ nhớ trở thành yếu tố giới hạn thông lượng chính. Hệ thống kết hợp ba tối ưu hóa độc lập nhưng bổ trợ nhau:

1. **Lượng tử hóa per-head, group-wise** cho KV Cache.
2. **Cắt tỉa token dựa trên attention-score** để loại bỏ các token ít quan trọng.
3. **Flash Attention** làm kernel tính attention theo từng tile, với giải lượng tử on-the-fly.

---

## 1. Nút Thắt Bộ Nhớ Trong Autoregressive Decoding

Tại mỗi bước decode, mô hình phải attend qua toàn bộ token đã sinh. KV Cache lưu trữ phép chiếu key/value của mọi token quá khứ:

$$
K_{cache} \in \mathbb{R}^{B \times H \times T \times d}, \quad V_{cache} \in \mathbb{R}^{B \times H \times T \times d}
$$

Dung lượng bộ nhớ tăng tuyến tính theo $T \cdot H \cdot d$ mỗi layer. Với một mô hình 70B ($H=64$, $d=128$, $T=8192$), chỉ riêng KV Cache đã có thể vượt 64 GB trên 80 layer — vượt xa bộ nhớ của một GPU đơn. **Giảm dung lượng KV Cache là thách thức trung tâm.**

---

## 2. Lượng Tử Hóa Per-Head, Group-wise

### 2.1 Tại sao cần granularity mịn hơn?

Lượng tử hóa per-tensor gán một cặp `(scale, zero-point)` duy nhất cho toàn bộ tensor. Vấn đề là các attention head khác nhau học các biểu diễn về bản chất khác nhau, và trong cùng một head, các nhóm kênh khác nhau có phân phối biên độ khác nhau. Một scale factor duy nhất hoặc lãng phí range với các activation nhỏ, hoặc clip bỏ các giá trị lớn, gây ra sai số INT4 đáng kể.

**Lượng tử hóa per-head, group-wise** chia chiều kênh $d$ thành các group kích thước $g$ (ví dụ $g=128$). Mỗi cặp `(head h, group j)` nhận `(scale, zero-point)` riêng:

$$
s^{(h,j)} = \frac{\alpha^{(h,j)}}{2^{b-1} - 1}, \quad z^{(h,j)} = 0 \quad \text{(symmetric)}
$$

trong đó $\alpha^{(h,j)} = \mathrm{Percentile}(|x^{(h,j)}|, p)$ clip outlier trước khi tính scale.

### 2.2 Calibration Offline

Bảng `(scale, zero-point)` được tính **một lần duy nhất** offline trên tập calibration nhỏ $\mathcal{D}_{cal}$:

1. Forward mô hình qua $\mathcal{D}_{cal}$; thu thập tensor $K^{(h)}, V^{(h)}$ ở mọi layer, mọi head.
2. Với mỗi `(h, j)`, tính $\alpha$ qua percentile clipping, rồi tính $s$ và $z$.
3. Lưu bảng kết quả — kích thước cực nhỏ: $H \cdot d/g$ scalar mỗi tensor.

### 2.3 Lượng Tử Hóa / Giải Lượng Tử Online

Tại mỗi bước decode, key/value vector mới được lượng tử hóa trước khi append vào cache:

$$
\tilde{x}^{(h,j)} = \mathrm{clip}\!\left(\mathrm{round}\!\left(\frac{x^{(h,j)}}{s^{(h,j)}}\right) + z^{(h,j)},\; q_{\min},\, q_{\max}\right)
$$

Trong quá trình tính attention, Flash Attention kernel đọc giá trị INT$b$ từ HBM và giải lượng tử **on-the-fly trong SRAM** trước khi thực hiện phép nhân ma trận:

$$
\hat{x}^{(h,j)} = s^{(h,j)} \cdot \left(\tilde{x}^{(h,j)} - z^{(h,j)}\right)
$$

Cách làm này tránh phải ghi một bản copy FP16 sau giải lượng tử trở lại HBM, giữ nguyên lợi ích tiết kiệm băng thông.

| Precision | Bytes/phần tử | Giảm so với FP16 |
|-----------|--------------|-----------------|
| FP16      | 2            | 1×              |
| INT8      | 1            | 2×              |
| INT4      | 0.5          | 4×              |

---

## 3. Cắt Tỉa Token Dựa Trên Attention-Score

### 3.1 Hạn Chế Của Pruning Theo Magnitude

Cách tiếp cận đơn giản là loại bỏ token có vector $K$ có chuẩn $\ell_2$ nhỏ. Tuy nhiên, biên độ chuẩn không đo mức độ **liên quan đến query hiện tại**. Một key vector có chuẩn nhỏ nhưng hướng căn chỉnh tốt với query vẫn có thể đóng góp đáng kể vào output softmax. Pruning theo magnitude do đó loại bỏ có hệ thống các token có thể là quan trọng.

### 3.2 Tính Điểm Quan Trọng

Mỗi $\Delta$ bước decode, một **pruning pass** được kích hoạt:

1. Tính ma trận attention score sử dụng query hiện tại (hoặc trung bình):

$$
A = \mathrm{softmax}\!\left(\frac{Q\hat{K}^\top}{\sqrt{d}}\right) \in \mathbb{R}^{H \times T_q \times T_k}
$$

2. Tổng hợp điểm qua các head và vị trí query để ra scalar importance cho mỗi token:

$$
\sigma_t = \frac{1}{H \cdot T_q} \sum_{h,i} A[h, i, t]
$$

3. Áp dụng Exponential Moving Average (EMA) để làm mượt qua các chu kỳ refresh:

$$
\bm{\sigma} \leftarrow \beta\,\bm{\sigma}_{prev} + (1-\beta)\,\bm{\sigma}_{new}, \quad \beta \approx 0.9
$$

### 3.3 Evict Token Khỏi Cache

Chỉ giữ lại top-$k$ token theo importance đã làm mượt:

$$
\mathcal{I}_{keep} = \mathrm{TopK}\!\left(\bm{\sigma},\; k = \lceil (1-\rho)\, T_k \rceil\right)
$$

**Token được bảo vệ** (không bao giờ bị evict):
- **Sink tokens**: 4–8 token đầu chuỗi. LLM (đặc biệt những mô hình được train theo kiểu StreamingLLM) phân bổ một lượng attention không cân xứng cho các token này; evict chúng làm chất lượng mô hình sụp đổ.
- **Sliding window**: $w$ token gần nhất. Tính gần đây là prior mạnh cho sự liên quan trong causal LM.

### 3.4 Tại Sao Cơ Chế Này Hoạt Động?

Phân phối attention $A$ trực tiếp phản ánh mức độ ảnh hưởng của mỗi token cached đến output hiện tại. Token eviction được dẫn dắt bởi $A$ do đó là một chiến lược nén có nguyên tắc, nhận thức tác vụ — nó giữ lại các token **thực sự quan trọng** và loại bỏ những token không quan trọng.

---

## 4. Flash Attention Là Kernel Nền Tảng

Flash Attention thay thế thuật toán attention tiêu chuẩn $\mathcal{O}(T^2)$ bằng cách tính attention theo **các tile** vừa khít trong SRAM:

1. Tensor $Q, K, V$ được load theo block từ HBM.
2. Softmax được tính tăng dần sử dụng kỹ thuật online normalization (log-sum-exp rescaling).
3. Output $O$ được tích lũy trong SRAM và ghi lại HBM **một lần duy nhất**.

Điểm mấu chốt: ma trận attention $T \times T$ đầy đủ **không bao giờ được materialized trong HBM**, giảm memory I/O từ $\mathcal{O}(T^2)$ xuống $\mathcal{O}(T)$. Đây chính xác là nơi giải lượng tử on-the-fly diễn ra — giá trị INT$b$ được expand sang FP16/BF16 ngay trong SRAM tile, không cần round-trip HBM bổ sung.

---

## 5. Tương Tác Ở Cấp Độ Hệ Thống

```
Offline:
  (s_k, z_k), (s_v, z_v) ← Calibrate(model, D_cal, b, g, p)

Online (bước decode t):
  ┌─ Token mới:
  │   K_q ← Quantize(K_new, s_k, z_k, b)      # INT{b}, lưu trong cache
  │   V_q ← Quantize(V_new, s_v, z_v, b)
  │   K_cache ← Append(K_cache, K_q)
  │
  ├─ Pruning (mỗi Δ bước):
  │   σ ← AttentionScores(Q, Dequantize(K_cache)) .mean(heads, queries)
  │   σ_ema ← β·σ_prev + (1−β)·σ
  │   keep ← TopK(σ_ema, k=(1−ρ)·T) ∪ SinkTokens ∪ SlidingWindow
  │   K_cache, V_cache ← K_cache[keep], V_cache[keep]
  │
  └─ Attention:
      Output ← FlashAttn(Q, K_cache, V_cache,
                         dequant_fn=(s_k,z_k,s_v,z_v))
      # Giải lượng tử diễn ra on-the-fly bên trong tiled SRAM kernel
```

---

## 6. Phân Tích Độ Phức Tạp và Bộ Nhớ

| Thành phần | Trước khi tối ưu | Sau khi tối ưu |
|------------|-----------------|----------------|
| Bộ nhớ KV Cache | $2 \cdot B \cdot H \cdot T \cdot d \cdot 2$ bytes (FP16) | $\div 2$ (INT8) hoặc $\div 4$ (INT4), rồi $\times (1-\rho)$ |
| HBM bandwidth mỗi bước | $\mathcal{O}(T \cdot H \cdot d)$ | $\mathcal{O}((1-\rho) \cdot T \cdot H \cdot d / 2)$ (INT8) |
| Overhead pruning | — | $\mathcal{O}(H \cdot T_q \cdot T_k)$ mỗi $\Delta$ bước |
| Calibration | — | Một lần offline, kích thước không đáng kể |

Kết hợp lại, phương pháp đạt được **giảm 2–8× kích thước KV Cache** tùy thuộc vào $(b, \rho)$, với độ suy giảm perplexity không đáng kể khi $b=8, \rho \le 0.4$ trên các benchmark điển hình.

---

## 7. Tóm Tắt Trực Quan

```
                  ┌──────────────────────────────────────────────┐
                  │           LLM Inference Pipeline             │
                  └──────────────────────────────────────────────┘

  Token mới đến
       │
       ▼
  ┌─────────────┐    Scale/ZP      ┌──────────────────┐
  │  Quantize   │◄─────────────────│  Calibration DB  │
  │  K, V       │   (per-head,     │  (offline, tiny) │
  │  → INT4/8   │    group-wise)   └──────────────────┘
  └──────┬──────┘
         │ append
         ▼
  ┌─────────────────────────────┐
  │         KV Cache            │  ← nhỏ hơn 2–4× nhờ quantization
  │  [INT4/8: token_0..token_T] │
  └──────────────┬──────────────┘
                 │  mỗi Δ bước
                 ▼
  ┌─────────────────────────────┐
  │    Attention-Score Pruning  │  ← loại bỏ ρ×T token ít quan trọng
  │    giữ: TopK + Sink + Slide │    cache nhỏ thêm (1−ρ)×
  └──────────────┬──────────────┘
                 │
                 ▼
  ┌─────────────────────────────┐
  │       Flash Attention       │  ← tính theo tile trong SRAM
  │   (dequant on-the-fly)      │    không materiialize T×T matrix
  └──────────────┬──────────────┘
                 │
                 ▼
             Output token
```

**Kết quả cuối cùng:**
- Bộ nhớ giảm: **2–4× (quantization) × thêm (1−ρ) (pruning)**
- Băng thông HBM giảm tương ứng → tốc độ decode tăng
- Chất lượng mô hình gần như không đổi với cài đặt bảo thủ ($b=8$, $\rho \le 0.4$)

**Nguyên lý cốt lõi**
Original problem: Khi LLM sinh ra văn bản dài, KV Cache tốn nhiều bộ nhớ băng thông - read/write chậm.
Solution: Vừa nén vừa cắt bỏ cache trong khi vẫn tính attention hiệu quả

Three layers mechanism:
1. Quantization(nén token)
"Lưu key/value bằng số nguyên thay vì float"
- Offline: học bảng (scale, zero-point) cho từng head × nhóm kênh từ dữ liệu mẫu.
- Online: ghi INT4/INT8 vào cache → tiết kiệm 2–4× bộ nhớ.
- Khi compute: giải nén nhanh trong SRAM (không cần đọc lại từ HBM)

2. Pruning(xóa token không quan trọng)
"Ai không được chú ý thì bỏ đi"
- Định kỳ tính attention score 
$$
A = \mathrm{softmax}\!\left(\frac{Q\hat{K}^\top}{\sqrt{d}}\right)
$$
- Token nào có điểm trung bình thấp → loại khỏi cache.
- Bảo vệ: sink tokens đầu cuối + cửa sổ w token gần nhất luôn được giữ

3. Flash Attention (tính toán hiệu quả)
"Tính attention theo từng block nhỏ, không lưu ma trận đầy đủ ra bộ nhớ"
- Tránh materialization ma trận T×T → giảm IO với HBM.
- Dequant on-the-fly ngay trong kernel SRAM.

Luồng hoạt động
Mỗi bước decode:
  Token mới  →  Quantize  →  Append vào cache
  Định kỳ   →  Tính attention score  →  Xóa token kém quan trọng
  Compute    →  Flash Attn (dequant on-the-fly trong kernel)

  Kết quả: Bộ nhớ giảm 2–4× (quantization) × thêm 30–50% (pruning), tốc độ tăng do ít đọc HBM hơn, độ chính xác gần như không đổi vì chỉ bỏ các token "ít được nhìn tới".