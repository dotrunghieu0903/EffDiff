# 📊 Paper Data Sources Comparison & Analysis

## Available Paper Data Sources

### 1. **Papers with Code** (paperswithcode.com)
```
Purpose: AI/ML papers + code + benchmarks
URL: https://paperswithcode.com
Citation Growth Tracking: ✅ Yes (daily/weekly/monthly/quarterly/yearly)
```

**Pros:**
- ✅ Excellent citation growth tracking
- ✅ Links to code implementations
- ✅ Benchmark comparisons
- ✅ Easy to scrape/navigate
- ✅ Mobile-friendly UI

**Cons:**
- ❌ Slower update frequency than arXiv
- ❌ Limited to papers with code/benchmarks
- ❌ No official API

**How to Fetch:**
- Web scraping with BeautifulSoup (recommended)
- Manual URL parsing: `paperswithcode.com/?order_by=citation_count_week`

---

### 2. **arXiv** (arxiv.org)
```
Purpose: Preprints in physics, math, CS, etc.
URL: https://arxiv.org
Citation Growth Tracking: ⚠️ Partial (submission date, not citation growth)
Public API: ✅ Yes, Free
```

**Pros:**
- ✅ Official public API (no key needed)
- ✅ 2.6M+ papers
- ✅ Real-time submissions (daily updates)
- ✅ No rate limiting for reasonable use
- ✅ Excellent documentation
- ✅ Categories & subcategories
- ✅ Rich metadata (abstract, authors, dates)

**Cons:**
- ❌ No citation count in API
- ❌ No citation growth metrics
- ❌ Recent papers only (not historical)
- ❌ Need to integrate with Semantic Scholar for citations

**How to Fetch:**
```python
# arXiv API Endpoint
http://export.arxiv.org/api/query?search_query=...&start=0&max_results=10

# Example: Recent CS papers
http://export.arxiv.org/api/query?search_query=cat:cs.LG AND submittedDate:[202406010000 TO 202406302359]&start=0&max_results=10
```

**Use Cases:**
- Latest papers in specific fields
- Recent submissions (trending by date, not citations)
- Paper metadata
- Combined with Semantic Scholar for citation info

---

### 3. **Semantic Scholar API** (semanticscholar.org)
```
Purpose: Comprehensive academic paper database with citations
URL: https://www.semanticscholar.org/product/api
Citation Growth Tracking: ✅ Yes (citation counts available)
Public API: ✅ Yes, Free (rate limited without key)
```

**Pros:**
- ✅ 214M papers, 2.49B citations
- ✅ Citation count data
- ✅ Author information
- ✅ Paper embeddings (SPECTER2)
- ✅ Free API access
- ✅ Works across all domains
- ✅ Recommendations engine

**Cons:**
- ⚠️ Rate limit: 1000 req/sec (shared)
- ⚠️ API key recommended for higher limits
- ⚠️ Response time can be slow
- ⚠️ Citation growth not tracked historically (only current counts)

**How to Fetch:**
```python
# Search papers
GET /graph/v1/paper/search?query=language%20models&limit=100

# Get paper details with citations
GET /graph/v1/paper/{paper_id}?fields=citationCount,citations,year

# Get cited papers
GET /graph/v1/paper/{paper_id}/citations
```

**Use Cases:**
- Search by keywords
- Get citation counts
- Find highly-cited papers
- Explore paper relationships
- Cross-domain research

---

### 4. **Hugging Face Papers** (huggingface.co/papers)
```
Purpose: Daily AI/ML papers with community engagement
URL: https://huggingface.co/papers
Citation Growth Tracking: ✅ Daily/Weekly/Monthly Trending
Public API: ⚠️ Partial (mainly scraping)
```

**Pros:**
- ✅ Daily updated papers
- ✅ Weekly/Monthly trending rankings
- ✅ Community upvotes visible
- ✅ AI-curated selection
- ✅ Easy to scrape

**Cons:**
- ❌ No official API
- ❌ Limited to ~20 papers per day
- ❌ Trending score not standardized
- ❌ Sometimes slow to load

**How to Fetch:**
```python
# Daily papers
https://huggingface.co/papers?day=today

# Weekly trending
https://huggingface.co/papers/trending?range=week

# Monthly trending
https://huggingface.co/papers/trending?range=month

# Scraping approach: BeautifulSoup + Selenium
```

**Use Cases:**
- Latest trending papers
- Community-selected papers
- Quick daily digest
- AI/ML focused content

---

### 5. **OpenReview** (openreview.net)
```
Purpose: Conference papers (NeurIPS, ICLR, ICML, etc.)
URL: https://openreview.net
Citation Growth Tracking: ⚠️ Limited (conference papers with scores)
Public API: ✅ Yes, Free
```

**Pros:**
- ✅ Official conference papers
- ✅ Peer review scores available
- ✅ Free API access
- ✅ Search & filter capabilities
- ✅ Venue-specific papers

**Cons:**
- ❌ Limited to specific conferences
- ❌ Not real-time (updated after conference)
- ❌ Smaller dataset than others
- ❌ Citation data requires Semantic Scholar integration

**How to Fetch:**
```python
# API endpoint
https://api.openreview.net/venues/

# Search papers
https://api.openreview.net/notes?venueid=ICLR.cc/2024/Conference
```

**Use Cases:**
- Top-tier conference papers
- Peer-reviewed papers only
- Venue-specific research

---

### 6. **Other Potential Sources**

| Source | URL | API | Citations | Notes |
|--------|-----|-----|-----------|-------|
| **DBLP** | dblp.org | ✅ REST API | Indirect | CS/DB focus |
| **IEEE Xplore** | ieeexplore.ieee.org | ⚠️ Limited | ✅ Yes | Technical papers, requires subscription |
| **ACM Digital Library** | dl.acm.org | ⚠️ Limited | ✅ Yes | Computer science |
| **CrossRef** | crossref.org | ✅ REST API | ⚠️ Limited | Multi-domain, DOI based |
| **PubMed** | pubmed.ncbi.nlm.nih.gov | ✅ EUTLS API | ⚠️ Limited | Biomedical only |

---

## 📊 Comparison Matrix

| Feature | Papers with Code | arXiv | Semantic Scholar | HF Papers | OpenReview |
|---------|-----------------|-------|------------------|-----------|-----------|
| **Citation Counts** | ✅ Good | ❌ No | ✅ Excellent | ✅ Good | ⚠️ Limited |
| **Growth Tracking** | ✅ Daily/Weekly | ❌ No | ⚠️ Static counts | ✅ Daily/Weekly | ⚠️ Conference only |
| **API Available** | ❌ No | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes |
| **Data Volume** | ~500K (with code) | 2.6M | 214M | ~20/day | ~10K/year |
| **Real-time Updates** | Daily | Hourly | Hourly | Daily | Yearly |
| **Scrape-ability** | ✅ Easy | ✅ Easy | ✅ Via API | ✅ Easy | ✅ Via API |
| **Code Links** | ✅ Yes | ❌ No | ⚠️ Limited | ⚠️ Limited | ❌ No |
| **Benchmarks** | ✅ Yes | ❌ No | ❌ No | ❌ No | ❌ No |
| **Rate Limit** | N/A | ✅ None | ⚠️ 1000 req/s | N/A | ✅ Generous |
| **Auth Required** | ❌ No | ❌ No | ⚠️ Optional | ❌ No | ❌ No |

---

## 🎯 **Recommended Data Source Strategy**

### For Top Papers by Citation Growth:
```
PRIMARY: Papers with Code
├─ 1st choice: Scrape weekly/daily
├─ Filters: order_by=citation_count_week
├─ Fallback: Combine with Semantic Scholar for more data

SECONDARY: Semantic Scholar
├─ Search high-citation papers
├─ Filter by date and citation_count
├─ API endpoint: /graph/v1/paper/search

TERTIARY: Hugging Face Papers
├─ Daily trending
├─ Weekly/Monthly rankings
├─ Use for trendy/hot papers
```

### For Latest Papers (Trending by Date):
```
PRIMARY: arXiv API
├─ Most recent submissions
├─ Specific categories (cs.LG, cs.NLP, etc.)
├─ NO citation data (needs integration)

SECONDARY: Hugging Face Papers
├─ Curated daily selection
├─ Community feedback
```

### For Conference Papers (SOTA):
```
PRIMARY: OpenReview
├─ NeurIPS, ICLR, ICML
├─ Peer review scores
├─ Top-tier research
```

---

## 🔧 Implementation Strategy

### **Best Approach for Your Use Case:**

#### **For "Top 5 Papers with Highest Citation Growth":**

**Option 1: Multi-Source Aggregation** ⭐ RECOMMENDED
```python
# 1. Fetch from all sources
papers_pwc = scrape_papers_with_code(period='weekly')      # Top 5-10
papers_s2 = query_semantic_scholar(query='', limit=100)    # Top 100 by citation
papers_hf = scrape_hugging_face_trending(range='week')     # Top 5-10

# 2. Aggregate & score
aggregated = combine_and_score(papers_pwc, papers_s2, papers_hf)

# 3. Get top 5
top_5 = aggregated.sort_by('citation_growth_score').head(5)
```

**Option 2: Primary + Fallback**
```python
# Primary: Papers with Code
try:
    papers = scrape_papers_with_code(period=period)
    if len(papers) >= 5:
        return papers[:5]
except:
    # Fallback: Semantic Scholar
    papers = query_semantic_scholar_trending()
    return papers[:5]
```

**Option 3: Hybrid Smart Selection**
```python
# Combine multiple metrics
top_5_pwc = scrape_papers_with_code(period='week')                    # Citation growth
top_5_s2 = get_trending_papers_semantic_scholar(days=7, min_cites=100) # Recent citations
top_5_hf = scrape_hugging_face_trending()                            # Community votes

# Merge and deduplicate, score by multiple factors
final_ranking = merge_and_rank([
    (papers_pwc, weight=0.5),      # 50% weight on PWC citation growth
    (papers_s2, weight=0.3),        # 30% weight on S2 citations
    (papers_hf, weight=0.2)         # 20% weight on HF community
])
```

---

## 📈 Citation Growth Tracking

### **Approaches:**

1. **Daily Snapshot Method**
   - Store paper citations daily
   - Calculate growth: (today - yesterday) / yesterday
   - Pros: Simple, accurate
   - Cons: Need historical data

2. **Papers with Code Method**
   - Use their built-in metrics
   - Filter by order_by parameter
   - Pros: Already calculated
   - Cons: Limited to their data

3. **Semantic Scholar + Historical Data**
   - Get current citation count
   - Need baseline (requires storage)
   - Calculate rate of change
   - Pros: Most accurate
   - Cons: Need database

---

## 🚀 Recommended Implementation

### **For Your Agent/Skill:**

```python
class PaperSourceManager:
    sources = {
        'papers_with_code': {
            'scraper': PaperWithCodeScraper(),
            'priority': 1,  # Try first
            'supported_periods': ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
            'has_citations': True,
            'real_time': False
        },
        'semantic_scholar': {
            'scraper': SemanticScholarAPI(),
            'priority': 2,   # Try second
            'supported_periods': ['any'],  # Manual filtering
            'has_citations': True,
            'real_time': True
        },
        'hugging_face': {
            'scraper': HuggingFaceScraper(),
            'priority': 3,   # Try third
            'supported_periods': ['daily', 'weekly', 'monthly'],
            'has_citations': False,  # Use community votes instead
            'real_time': True
        },
        'arxiv': {
            'scraper': arXivAPI(),
            'priority': 4,
            'supported_periods': ['daily'],  # Recent submissions
            'has_citations': False,
            'real_time': True
        }
    }
    
    def get_top_papers(self, period='weekly', count=5):
        for source_name in sorted(sources.items(), key=lambda x: x[1]['priority']):
            try:
                papers = source_name['scraper'].fetch(period, count)
                if papers:
                    return papers
            except:
                continue
        raise Exception("All sources failed")
```

---

## 📝 Next Steps

1. ✅ Identify data sources
2. ✅ Compare pros/cons
3. → Update Agent/Skill with multi-source support
4. → Implement scrapers for each source
5. → Add smart fallback logic
6. → Cache results for performance

---

## 📚 API Quick Reference

### arXiv
```
GET http://export.arxiv.org/api/query?
    search_query=cat:cs.LG&
    start=0&
    max_results=10&
    sortBy=submittedDate&
    sortOrder=descending
```

### Semantic Scholar
```
GET https://api.semanticscholar.org/graph/v1/paper/search?
    query=transformer&
    limit=10&
    fields=citationCount,year,authors
```

### Hugging Face (Scraping)
```
GET https://huggingface.co/papers?date=today
GET https://huggingface.co/papers/trending?range=week
```

### OpenReview
```
GET https://api.openreview.net/notes?
    venueid=ICLR.cc/2024/Conference&
    limit=100
```

---

## 🎯 Summary

**Best for Top 5 Papers by Citation Growth:**
1. **Primary:** Papers with Code (order_by=citation_count_week)
2. **Fallback 1:** Semantic Scholar (query recent + sort by citations)
3. **Fallback 2:** Hugging Face Trending (community curated)
4. **Fallback 3:** arXiv + Semantic Scholar (integrate APIs)

**Recommended Implementation:** Multi-source with smart fallback and deduplication.

