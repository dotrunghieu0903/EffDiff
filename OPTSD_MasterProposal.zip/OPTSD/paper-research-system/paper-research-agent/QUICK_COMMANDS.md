# 📚 Paper Research System - Quick Command Reference

## VS Code Agent Commands

### Basic Usage
```bash
@find-top-papers                                    # Interactive mode (prompts for options)
@find-top-papers weekly                            # Weekly papers (default count=5)
@find-top-papers daily 10                          # Daily papers, top 10
```

### With Topic Filter
```bash
@find-top-papers weekly 5 "large language models"
@find-top-papers monthly 3 "computer vision"
@find-top-papers daily 5 "attention mechanism"
```

### With Source Selection
```bash
@find-top-papers weekly 5 "" papers-with-code      # Specific source
@find-top-papers weekly 5 "" semantic-scholar
@find-top-papers daily 5 "" arxiv
@find-top-papers weekly 5 "" hugging-face
@find-top-papers yearly 5 "" openreview
```

### Advanced Modes
```bash
@find-top-papers weekly 5 "" auto                  # Smart source selection (fallback)
@find-top-papers weekly 5 "" combined              # Aggregate all sources
@find-top-papers weekly 5 "LLM" combined           # Topic filter + combined
```

---

## Citation Growth Periods

```
@find-top-papers daily       # 24-hour citation growth
@find-top-papers weekly      # 7-day citation growth (DEFAULT)
@find-top-papers monthly     # 30-day citation growth
@find-top-papers quarterly   # 90-day citation growth
@find-top-papers yearly      # 365-day citation growth
```

---

## Popular Command Patterns

### 📊 Weekly Citation Growth (Default)
```bash
@find-top-papers weekly 5                          # Best all-around
@find-top-papers weekly 5 "" auto                  # With smart fallback
@find-top-papers weekly 5 "" combined              # Aggregate all sources
```

### 🔥 Daily Trending
```bash
@find-top-papers daily 5                           # Latest hot papers
@find-top-papers daily 5 "" arxiv                  # Latest preprints
@find-top-papers daily 5 "" hugging-face           # Community trending
```

### 📈 Monthly Analysis
```bash
@find-top-papers monthly 10                        # Top 10 papers/month
@find-top-papers monthly 5 "transformers"          # Monthly in topic
```

### 🏆 SOTA (Best Papers)
```bash
@find-top-papers yearly 5 "" openreview            # Top conference papers
@find-top-papers yearly 10                         # Yearly top 10
```

### 🎯 Topic-Specific
```bash
@find-top-papers weekly 5 "language models"
@find-top-papers weekly 5 "vision transformers"
@find-top-papers weekly 5 "reinforcement learning"
@find-top-papers weekly 5 "graph neural networks"
@find-top-papers weekly 5 "diffusion models"
```

### 🔗 Multi-Source
```bash
@find-top-papers weekly 5 "" combined              # Best + most comprehensive
@find-top-papers weekly 5 "LLM" combined          # Topic + combined
@find-top-papers daily 5 "" combined               # Daily + combined
```

---

## Data Source Selection Guide

### When to Use Each Source

**Papers with Code** (Default for citation growth)
```bash
@find-top-papers weekly 5 "" papers-with-code      # Citation growth metrics
@find-top-papers monthly 5 "" papers-with-code     # Code + benchmarks included
@find-top-papers yearly 5 "" papers-with-code      # Long-term trends
```

**Semantic Scholar** (Best for comprehensive data)
```bash
@find-top-papers weekly 5 "" semantic-scholar      # Citation counts + metadata
@find-top-papers monthly 5 "AI" semantic-scholar   # Broad topic search
```

**arXiv** (Best for latest preprints)
```bash
@find-top-papers daily 5 "" arxiv                  # Latest submissions
@find-top-papers daily 10 "neural networks" arxiv  # Latest + topic
```

**Hugging Face** (Best for trending AI/ML)
```bash
@find-top-papers daily 5 "" hugging-face           # Today's trending
@find-top-papers weekly 5 "" hugging-face          # This week's trending
```

**OpenReview** (Best for conference papers)
```bash
@find-top-papers yearly 5 "" openreview            # Top conferences (NeurIPS, ICLR)
```

---

## Output Examples

### Command
```bash
@find-top-papers weekly 3 "LLM"
```

### Output
```
✅ Found 3 top papers (From: Papers with Code - Weekly)

Paper 1: "Llama 3: Open Foundation Models"
├─ Authors: Meta AI
├─ Citations: 2,543 (+312 this week)
├─ Highlights: Open source, 70B parameter model
└─ Output: slides.pptx, video.mp4, summary.md

Paper 2: "Mamba: Linear-Time Sequence Modeling"
├─ Authors: CMU, Princeton, MIT
├─ Citations: 1,892 (+278 this week)
├─ Highlights: State-space models, efficient
└─ Output: slides.pptx, video.mp4, summary.md

Paper 3: "Code as Policies: Language Models for Robot Control"
├─ Authors: Google DeepMind
├─ Citations: 1,456 (+245 this week)
├─ Highlights: Robotics + LLMs, zero-shot
└─ Output: slides.pptx, video.mp4, summary.md

💾 Files saved to: ./outputs/
⏱️  Total time: 25 minutes
```

---

## Configuration Options

### .env Settings
```bash
# Enable/disable sources
PAPERS_WITH_CODE_ENABLED=true
SEMANTIC_SCHOLAR_ENABLED=true
ARXIV_ENABLED=true
HUGGING_FACE_ENABLED=true
OPENREVIEW_ENABLED=true

# API Keys (optional)
SEMANTIC_SCHOLAR_API_KEY=your_key

# Source priority order
PAPER_SOURCES_ORDER=papers-with-code,semantic-scholar,hugging-face,arxiv,openreview
```

### config.json Settings
```json
{
  "paper_sources_priority": {
    "daily": ["papers-with-code", "arxiv", "hugging-face"],
    "weekly": ["papers-with-code", "semantic-scholar", "hugging-face"],
    "monthly": ["papers-with-code", "semantic-scholar"],
    "quarterly": ["papers-with-code", "semantic-scholar"],
    "yearly": ["papers-with-code", "semantic-scholar", "openreview"]
  },
  "cache": {
    "enabled": true,
    "ttl_hours": 24
  }
}
```

---

## Shorthand Aliases

```bash
# You can use these shortcuts
@find daily 5              # @find-top-papers daily 5
@find week 5 LLM           # @find-top-papers weekly 5 "LLM"
@find month 10             # @find-top-papers monthly 10
@find quarter 5            # @find-top-papers quarterly 5
@find year 5 arxiv         # @find-top-papers yearly 5 "" arxiv
```

---

## Common Workflows

### Workflow 1: Morning Research Update (5 min setup)
```bash
@find-top-papers weekly 5                          # Top 5 of the week
# Browse output slides and videos
# Read summaries during breakfast
```

### Workflow 2: Deep Dive on Specific Topic (15 min setup)
```bash
@find-top-papers weekly 10 "attention mechanisms" combined
# Get comprehensive view from all sources
# Generate videos for presentation
```

### Workflow 3: Keep Up with Latest Research (5 min setup)
```bash
@find-top-papers daily 5 "" arxiv                  # Latest preprints
# Check what's new today
# Quick video overviews
```

### Workflow 4: Academic Presentation Prep (20 min setup)
```bash
@find-top-papers monthly 5 "conference-topic" openreview
# Get top peer-reviewed papers
# Export slides for presentation
# Use videos as reference
```

### Workflow 5: Competitive Analysis (10 min setup)
```bash
@find-top-papers weekly 5 "our-focus-area" combined
# Monitor competitor research
# Track trends across all sources
# Quick video summaries
```

---

## Tips & Tricks

### Tip 1: Auto-Fallback
```bash
@find-top-papers weekly 5 "" auto                  # Smart selection, auto-fallback
# If primary source fails, automatically tries next
```

### Tip 2: Combine Sources for Comprehensive View
```bash
@find-top-papers weekly 5 "" combined              # Aggregate all
# Get best papers from all 5 sources
# Deduplicated results
```

### Tip 3: Use Specific Source When You Know What You Want
```bash
@find-top-papers daily 5 "" arxiv                  # Latest + fastest
@find-top-papers yearly 5 "" openreview            # Best conference papers
```

### Tip 4: Filter by Topic
```bash
@find-top-papers weekly 5 "transformer"            # Only transformers
@find-top-papers daily 5 "LLM"                     # Only LLMs
```

### Tip 5: Get More Papers
```bash
@find-top-papers weekly 10                         # Top 10 instead of 5
@find-top-papers weekly 15 "" combined             # Top 15 aggregated
```

---

## Troubleshooting Commands

### Check Configuration
```bash
@find-top-papers config check                      # Validate API keys & sources
```

### Clear Cache
```bash
@find-top-papers cache clear                       # Clear cached results
```

### View Source Status
```bash
@find-top-papers sources status                    # Check which sources are available
```

### Get Help
```bash
@find-top-papers help                              # Show detailed help
@find-top-papers sources list                      # List all available sources
```

---

## API Response Format

```json
{
  "success": true,
  "data": [
    {
      "id": "paper_1",
      "title": "Paper Title",
      "authors": "Author1, Author2",
      "year": 2024,
      "citations": 1543,
      "growth_daily": 45,
      "growth_weekly": 312,
      "abstract": "Paper abstract...",
      "url": "https://arxiv.org/abs/...",
      "keywords": ["keyword1", "keyword2"],
      "source": "papers-with-code",
      "highlights": ["Contribution 1", "Contribution 2"]
    }
  ],
  "source": "papers-with-code",
  "count": 5,
  "timestamp": "2024-07-03T10:30:00Z"
}
```

---

## Performance Benchmarks

| Command | Time | Source | Notes |
|---------|------|--------|-------|
| `@find daily 5 "" arxiv` | ~20min | arXiv | Fastest |
| `@find weekly 5 "" papers-with-code` | ~25min | PWC | Default |
| `@find weekly 5 "" semantic-scholar` | ~30min | S2 | Comprehensive |
| `@find weekly 5 "" combined` | ~35min | All | Most complete |

*Time includes: fetch (5-15s) + analysis (30-45s per paper) + slides (20-30s) + video (2-3 min per paper)*

---

## Need Help?

- See [MULTI_SOURCE_GUIDE.md](MULTI_SOURCE_GUIDE.md) for detailed guide
- See [DATA_SOURCES.md](DATA_SOURCES.md) for source comparison
- See [README.md](README.md) for complete documentation
- Check [SETUP.md](SETUP.md) for installation help

