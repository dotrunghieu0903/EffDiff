# Paper Research Skill

## Description
This skill enables VS Code to find top research papers from multiple sources (Papers with Code, Semantic Scholar, arXiv, Hugging Face Papers, etc.) with rapidly growing citations, analyze their key contributions, and automatically generate academic-style PowerPoint presentations and short educational videos.

## Key Features
- **Multi-Source Paper Discovery**: Fetch from Papers with Code, Semantic Scholar, arXiv, Hugging Face Papers, and OpenReview
- **Smart Citation Growth Tracking**: Track daily/weekly/monthly/quarterly/yearly citation increases
- **Content Analysis**: Extract key insights using LLM (OpenAI, Claude, local models)
- **Slide Generation**: Create Google Slides or PowerPoint presentations
- **Video Creation**: Generate narrated videos with AI voice
- **Batch Processing**: Handle multiple papers (top 5)
- **Intelligent Fallback**: Automatic source switching if primary source unavailable
- **Citation Aggregation**: Combine data from multiple sources for comprehensive analysis

## When to Use
- Research overview needed for multiple papers
- Want academic summaries of trending papers
- Need visual presentations for papers
- Want short video explanations
- Batch processing multiple papers
- Need papers with high citation growth metrics
- Want to aggregate data from multiple academic sources

## Data Sources Supported
- **Papers with Code** (paperswithcode.com) - Best for citation growth tracking
- **Semantic Scholar API** - Comprehensive 214M paper database with citations
- **arXiv** - Latest preprints with official API
- **Hugging Face Papers** - Daily AI/ML trending papers
- **OpenReview** - Top-tier conference papers (NeurIPS, ICLR, ICML)
- **Manual Input** - Custom paper lists via JSON

See [DATA_SOURCES.md](../DATA_SOURCES.md) for detailed comparison and selection strategy.

## Invocation
The skill is invoked via:
```
@find-top-papers [criteria] [count] [topic] [source]

Examples:
@find-top-papers daily top5                                      # Default: Papers with Code
@find-top-papers weekly top5 LLM                                 # Filter by topic
@find-top-papers monthly top5 "" semantic-scholar               # Use specific source
@find-top-papers weekly top10 "" combined                        # Aggregate multiple sources
@find-top-papers daily top5 "computer vision" papers-with-code  # Specific source + topic
@find-top-papers quarterly top5 "" auto                          # Smart source selection (fallback if one fails)
```

### Command Variations
```
# Interactive mode (user selects options in VS Code UI)
@find-top-papers

# Quick mode with defaults
@find-top-papers weekly

# Advanced mode with all parameters
@find-top-papers daily 5 "neural networks" semantic-scholar
```

## Inputs
- **Search Criteria**: daily, weekly, monthly, quarterly, yearly
- **Paper Count**: 1-10 (default: 5)
- **Topics** (optional): filter by research area (e.g., "LLM", "computer vision", "NLP")
- **Data Source** (optional): 
  - `auto` - Smart selection (try Papers with Code first, fallback to others)
  - `papers-with-code` - Best for citation growth tracking
  - `semantic-scholar` - Best for comprehensive data
  - `arxiv` - Best for latest preprints
  - `hugging-face` - Best for trending AI/ML papers
  - `openreview` - Best for conference papers
  - `combined` - Aggregate from multiple sources

## Outputs
- Google Slides link
- MP4 video file
- JSON summary with key insights
- Markdown document with full analysis

## Data Source Selection Strategy

### Automatic Source Selection (`auto` mode)
```
Priority order if primary source fails:
1. Papers with Code (paperswithcode.com)
   ├─ Best for: Citation growth metrics, code links
   ├─ Period support: daily, weekly, monthly, quarterly, yearly
   └─ Fallback if: Timeout or parsing fails

2. Semantic Scholar API (semanticscholar.org)
   ├─ Best for: Comprehensive data, all domains
   ├─ Period support: via date filtering
   └─ Fallback if: PWC unavailable

3. Hugging Face Papers (huggingface.co/papers)
   ├─ Best for: Daily/weekly trending
   ├─ Period support: daily, weekly, monthly
   └─ Fallback if: S2 unavailable

4. arXiv API (arxiv.org)
   ├─ Best for: Latest preprints
   ├─ Period support: daily submissions
   └─ Fallback if: All above fail

5. OpenReview (openreview.net)
   ├─ Best for: Conference papers
   └─ Fallback if: All above fail
```

### Recommended Configurations by Use Case

**📈 For Citation Growth Analysis (DEFAULT)**
```
Command: @find-top-papers weekly 5 "" auto
Source: Papers with Code → Semantic Scholar → Hugging Face
Rationale: PWC has best citation growth tracking
```

**🔬 For Comprehensive Research**
```
Command: @find-top-papers monthly 5 "" combined
Source: Aggregate all sources
Rationale: Multiple perspectives on same papers
```

**📅 For Latest Preprints**
```
Command: @find-top-papers daily 5 "" arxiv
Source: arXiv API only
Rationale: Most recent submissions, real-time
```

**🏆 For Top-Tier Conferences**
```
Command: @find-top-papers yearly 5 "" openreview
Source: OpenReview only
Rationale: Peer-reviewed, high-quality papers
```

**🤖 For AI/ML Trending**
```
Command: @find-top-papers weekly 5 "LLM" hugging-face
Source: Hugging Face Papers
Rationale: Community-curated, AI-focused

## Configuration Required
Create `config/.env` with (at minimum one source per category):

```
# LLM Configuration
OPENAI_API_KEY=sk-...
CLAUDE_API_KEY=sk-...

# TTS Configuration  
ELEVEN_LABS_API_KEY=...
GOOGLE_CLOUD_API_KEY=...

# Slide Generation
GOOGLE_SLIDES_CREDENTIALS=path/to/service_account.json

# Paper Data Sources (in order of priority)
# Papers with Code (scraping - no API key needed)
PAPERS_WITH_CODE_ENABLED=true

# Semantic Scholar (API - optional key for higher rate limits)
SEMANTIC_SCHOLAR_ENABLED=true
SEMANTIC_SCHOLAR_API_KEY=...  # Optional

# arXiv (no API key needed)
ARXIV_ENABLED=true

# Hugging Face Papers (scraping - no API key needed)
HUGGING_FACE_ENABLED=true

# OpenReview (no API key needed)
OPENREVIEW_ENABLED=true

# Output Configuration
OUTPUT_DIR=./outputs
FFMPEG_PATH=ffmpeg
```

### Minimum Configuration
At minimum, you need:
- ✅ One **LLM provider** (OpenAI or Claude)
- ✅ One **TTS provider** (Eleven Labs or Google Cloud)
- ✅ One **Paper source** (Papers with Code works without any API key!)
- ✅ Google Slides credentials for presentations

## Architecture
- **Frontend**: VS Code chat interface
- **Orchestrator**: Python Flask backend with intelligent source routing
- **Paper Scrapers**: 
  - Papers with Code (BeautifulSoup scraping)
  - Semantic Scholar (REST API)
  - arXiv (REST API)
  - Hugging Face Papers (BeautifulSoup scraping)
  - OpenReview (REST API)
- **Analysis Engine**: LLM integration (OpenAI/Claude/Local)
- **Output Services**: 
  - Slide generator (Google Slides API / python-pptx)
  - Video generator (FFmpeg + TTS)

## Performance
- Fetching 5 papers: ~10-15 seconds
- Analyzing each paper: ~30-45 seconds
- Generating slides: ~20-30 seconds
- Generating video: ~2-3 minutes
- **Total for 5 papers: ~20-25 minutes**

### Performance by Source
| Source | Fetch Time | Status | Notes |
|--------|-----------|--------|-------|
| Papers with Code | 5-10s | ⚡ Fast | Direct scraping |
| Semantic Scholar | 10-15s | ⚡ Fast | API calls with batching |
| Hugging Face | 5-10s | ⚡ Fast | Direct scraping, small dataset |
| arXiv | 3-5s | ⚡ Very Fast | Official API, efficient |
| OpenReview | 5-10s | ⚡ Fast | API with good response time |

### Supported Periods by Source
```
Period         PWC    S2    arXiv  HF     OpenReview
─────────────────────────────────────────────────
daily          ✅     ⚠️   ✅     ✅     ❌
weekly         ✅     ⚠️   ⚠️     ✅     ❌
monthly        ✅     ⚠️   ⚠️     ✅     ❌
quarterly      ✅     ❌   ❌     ❌     ❌
yearly         ✅     ❌   ❌     ❌     ✅

Legend: ✅ Full support, ⚠️ Partial (via filtering), ❌ Not supported
```

## Reliability
- Retry on API failures (3 attempts with exponential backoff)
- Intelligent fallback: automatic source switching if primary source unavailable
- Local caching of papers to speed up repeated queries
- Error recovery and detailed logging
- Graceful degradation: continue with partial results if some sources fail

### Fallback Logic Flow
```
User Request (e.g., "weekly 5 papers on LLM")
       ↓
[Source Mode = "auto"]
       ↓
Try Papers with Code (primary source)
├─ Success? → Return top 5 + proceed to analysis
├─ Timeout? → Try Semantic Scholar (2nd choice)
├─ Error? → Try Hugging Face (3rd choice)
├─ Fail? → Try arXiv (4th choice)
└─ Fail? → Manual input or error message

[Source Mode = "specific" (e.g., "semantic-scholar")]
       ↓
Try Semantic Scholar (single source)
├─ Success? → Return results
├─ Error? → Try backup sources in priority order
└─ All fail? → Error message with suggestions

[Source Mode = "combined"]
       ↓
Fetch from all sources in parallel
├─ Deduplicate papers
├─ Score by multiple metrics
├─ Return top 5 aggregated
└─ Report which sources were used
```

## Related Skills
- General code analysis
- Documentation generation
- Presentation creation

## Example Workflows

### Workflow 1: Weekly Research Update
```
User: @find-top-papers weekly 5

Execution:
1. Search: "Find top 5 papers with highest weekly citation growth"
2. Source: Papers with Code (auto-selected as best for this)
3. Analysis: Extract key insights for each paper
4. Output: 5 slides + 5 videos
5. Presentation: "Top AI/ML Papers - Week of July 3, 2026"

Time: ~25 minutes
```

### Workflow 2: Specific Topic Research
```
User: @find-top-papers monthly 3 "large language models"

Execution:
1. Search: Papers on LLMs with monthly citation growth
2. Source: Auto (tries PWC → S2 → HF → arXiv)
3. Filter: Only papers matching "large language models"
4. Output: 3 highly-relevant slides + videos
5. Focus: Language models, transformers, training efficiency

Time: ~18 minutes
```

### Workflow 3: Multi-Source Comparison
```
User: @find-top-papers quarterly 5 "" combined

Execution:
1. Search: Highest citation growth papers (quarterly)
2. Sources: ALL (PWC + S2 + HF + arXiv + OpenReview in parallel)
3. Aggregation: Score papers by citation growth + community votes + recency
4. Deduplication: Remove duplicates across sources
5. Output: Top 5 consensus papers with source attribution

Time: ~30 minutes
```

### Workflow 4: Latest Preprints
```
User: @find-top-papers daily 5 "" arxiv

Execution:
1. Search: Latest papers submitted to arXiv (today)
2. Source: arXiv API only (most recent)
3. Category: Computer Science (default)
4. Output: 5 newest papers + summaries + videos
5. Focus: Latest research trends

Time: ~20 minutes
```

### Workflow 5: Conference Papers Only
```
User: @find-top-papers yearly 5 "" openreview

Execution:
1. Search: Top papers from recent conferences (NeurIPS, ICLR, ICML)
2. Source: OpenReview only
3. Filter: Top-tier venues, peer-reviewed
4. Output: 5 best conference papers + presentations
5. Focus: State-of-the-art research

Time: ~22 minutes
```

## Dependencies
- Node.js 18+
- Python 3.10+
- FFmpeg
- Google Cloud SDK
- Eleven Labs API access (or Google Cloud TTS)
- At least one LLM provider (OpenAI or Claude)
- Optional: SQLite for result caching

## Troubleshooting & FAQ

### Q: "All sources failed to find papers"
**A:** Check:
1. Internet connection is working
2. At least one paper source is enabled in `.env`
3. No network firewall blocking requests
4. Try with `source=manual` and provide papers JSON

### Q: "Citation growth not showing for my period"
**A:** Not all sources support all periods:
- Use `papers-with-code` for all periods (daily through yearly)
- Use `arxiv` only for daily
- Use `openreview` only for yearly

### Q: "How do I combine results from multiple sources?"
**A:** Use command:
```
@find-top-papers weekly 5 "" combined
```
This aggregates results from all available sources and scores them.

### Q: "Can I use it without API keys?"
**A:** Yes! Basic setup works without any API keys:
- Paper sources: Papers with Code, arXiv, Hugging Face (all work without keys)
- LLM: NOT possible (need OpenAI or Claude)
- TTS: NOT possible (need Eleven Labs or Google Cloud)

### Q: "How do I prioritize specific sources?"
**A:** Edit `config/.env`:
```
# Reorder these to change priority
PAPER_SOURCES_ORDER=papers-with-code,semantic-scholar,hugging-face,arxiv,openreview
```

### Q: "Why is execution slow?"
**A:** Top sources by speed:
1. arXiv (~3-5s) - fastest
2. Papers with Code (~5-10s)
3. Semantic Scholar (~10-15s) - slowest

Use `source=arxiv` for fastest results if available for your period.

### Q: "Can I cache results to speed up repeated queries?"
**A:** Yes, caching is built-in:
- Results cached locally in `./outputs/{paper_id}`
- Configure in `config/config.json`:
  ```json
  {
    "cache": {
      "enabled": true,
      "ttl_hours": 24,
      "directory": "./outputs"
    }
  }
  ```

## Best Practices

1. **For Production Use**: Use `source=combined` for most robust results
2. **For Speed**: Use `source=arxiv` for daily, `source=papers-with-code` for weekly
3. **For Specific Topics**: Always include topic filter in command
4. **For Reproducibility**: Specify exact source instead of "auto"
5. **For Cost Control**: Set up API key rate limits in provider dashboard
