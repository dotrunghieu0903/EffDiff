# 🔗 Multi-Source Paper Discovery Guide

## Overview
The Paper Research System now supports fetching papers from 5+ major academic sources with intelligent fallback and aggregation capabilities.

## Supported Data Sources

### 1️⃣ **Papers with Code** (Default for citation growth)
- **URL**: https://paperswithcode.com
- **Best For**: Citation growth metrics, code implementations
- **Periods**: ✅ All (daily, weekly, monthly, quarterly, yearly)
- **Speed**: ⚡ ~5-10 seconds
- **API Key**: ❌ Not needed
- **Recommendation**: Use this for citation growth analysis

**Usage**:
```python
scraper.fetch_papers(period='weekly', source='papers-with-code')
```

---

### 2️⃣ **Semantic Scholar** (Best for comprehensive data)
- **URL**: https://www.semanticscholar.org/product/api
- **Best For**: Citation counts, author info, all domains
- **Periods**: ⚠️ Via filtering (any date range)
- **Speed**: ⚡ ~10-15 seconds
- **API Key**: ⚠️ Optional (recommended)
- **Database Size**: 214M papers, 2.49B citations
- **Recommendation**: Use when you want citation metrics

**Usage**:
```python
scraper.fetch_papers(
    period='weekly',
    source='semantic-scholar',
    topic_filter='large language models'
)
```

**API Key Setup**:
```
1. Go to https://www.semanticscholar.org/product/api
2. Request API key (free for research)
3. Add to .env:
   SEMANTIC_SCHOLAR_API_KEY=your_key
```

---

### 3️⃣ **arXiv** (Best for latest preprints)
- **URL**: https://arxiv.org
- **Best For**: Latest research, real-time submissions
- **Periods**: ✅ Daily (recent submissions)
- **Speed**: ⚡⚡ ~3-5 seconds (fastest!)
- **API Key**: ❌ Not needed
- **Database**: 2.6M preprints
- **Recommendation**: Use for trending papers by date (not citations)

**Usage**:
```python
scraper.fetch_papers(
    period='daily',
    source='arxiv',
    topic_filter='transformer'  # Optional
)
```

**Categories**:
```
cs.LG   - Machine Learning
cs.AI   - AI
cs.CL   - Computational Linguistics  
cs.NLP  - Natural Language Processing
stat.ML - Statistics: Machine Learning
```

---

### 4️⃣ **Hugging Face Papers** (Best for trending AI/ML)
- **URL**: https://huggingface.co/papers
- **Best For**: Community-curated trending papers
- **Periods**: ✅ Daily, weekly, monthly
- **Speed**: ⚡ ~5-10 seconds
- **API Key**: ❌ Not needed
- **Community**: Upvotes from ML researchers
- **Recommendation**: Use for what's trending in AI community

**Usage**:
```python
scraper.fetch_papers(
    period='weekly',
    source='hugging-face'
)
```

**URL Patterns**:
```
Daily:   https://huggingface.co/papers?date=today
Weekly:  https://huggingface.co/papers/trending?range=week
Monthly: https://huggingface.co/papers/trending?range=month
```

---

### 5️⃣ **OpenReview** (Best for conference papers)
- **URL**: https://openreview.net
- **Best For**: Top-tier conference papers (NeurIPS, ICLR, ICML)
- **Periods**: ⚠️ Yearly/all-time
- **Speed**: ⚡ ~5-10 seconds
- **API Key**: ❌ Not needed
- **Peer Review**: Available
- **Recommendation**: Use for SOTA papers from conferences

**Usage**:
```python
scraper.fetch_papers(
    period='yearly',
    source='openreview'
)
```

---

## Intelligent Source Selection

### Auto Mode (Recommended)
```python
# Automatically selects best source for your period
papers, source = scraper.fetch_papers(
    period='weekly',
    count=5,
    source='auto'  # Smart selection
)

# Selection logic:
# - weekly → Try Papers with Code → Semantic Scholar → Hugging Face
# - daily  → Try Papers with Code → arXiv → Hugging Face
# - yearly → Try Papers with Code → Semantic Scholar → OpenReview
```

### Combined Mode (Multi-source aggregation)
```python
# Fetch from ALL sources and combine
papers, sources = scraper.fetch_papers(
    period='weekly',
    count=5,
    source='combined'  # Aggregate all sources
)
# Returns: (papers, "combined (papers-with-code, semantic-scholar, hugging-face, arxiv)")
```

### Specific Source
```python
# Use exact source (with fallback if it fails)
papers, source = scraper.fetch_papers(
    period='daily',
    source='arxiv'  # Specific source
)
# If arxiv fails, falls back to auto mode
```

---

## Code Examples

### Example 1: Get top 5 papers with highest weekly citation growth
```python
from services.enhanced_paper_scraper import EnhancedPaperScraper

scraper = EnhancedPaperScraper()

papers, source_used = scraper.fetch_papers(
    period='weekly',
    count=5,
    source='auto'  # Auto-selects best source
)

print(f"Fetched from: {source_used}")
for paper in papers:
    print(f"- {paper['title']}")
    print(f"  Citations: {paper['citations']}, Growth: +{paper['growth_weekly']}/week")
```

### Example 2: Get latest ML papers from arXiv
```python
papers, source = scraper.fetch_papers(
    period='daily',
    count=10,
    topic_filter='neural networks',
    source='arxiv'
)

for paper in papers:
    print(f"{paper['title']}")
    print(f"  Authors: {paper['authors']}")
    print(f"  URL: {paper['url']}\n")
```

### Example 3: Aggregate papers from multiple sources
```python
# Combine results from all sources for comprehensive view
papers, sources = scraper.fetch_papers(
    period='weekly',
    count=5,
    topic_filter='LLM',
    source='combined'  # Multi-source aggregation
)

print(f"Combined results from: {sources}")
print(f"Total unique papers: {len(papers)}")

# Each paper includes source information
for paper in papers:
    print(f"{paper['title']} (from {paper.get('source', 'unknown')})")
```

### Example 4: Fallback to next source on error
```python
# Try specific source, auto-fallback if fails
papers, source = scraper.fetch_papers(
    period='monthly',
    source='papers-with-code',
    retry_count=3  # Try 3 times per source
)

print(f"Successfully used: {source}")
```

---

## Comparison Table

| Metric | PWC | S2 | arXiv | HF | OpenReview |
|--------|-----|----|----|----|----|
| **Citation Growth** | ✅✅✅ | ✅✅ | ❌ | ⚠️ | ⚠️ |
| **Latest Papers** | ⚠️ | ✅ | ✅✅✅ | ✅ | ⚠️ |
| **Data Volume** | 500K | 214M | 2.6M | Daily | ~10K/yr |
| **API Key Needed** | ❌ | ⚠️ | ❌ | ❌ | ❌ |
| **Speed** | ⚡⚡ | ⚡ | ⚡⚡⚡ | ⚡⚡ | ⚡⚡ |
| **Code Links** | ✅ | ⚠️ | ❌ | ❌ | ❌ |
| **Peer Reviewed** | ✅ | ⚠️ | ✅ | ⚠️ | ✅ |

---

## Configuration

### Enable/Disable Sources
Edit `.env`:
```
# Enable/disable sources (true/false)
PAPERS_WITH_CODE_ENABLED=true
SEMANTIC_SCHOLAR_ENABLED=true
ARXIV_ENABLED=true
HUGGING_FACE_ENABLED=true
OPENREVIEW_ENABLED=true

# API Keys (optional)
SEMANTIC_SCHOLAR_API_KEY=your_key
```

### Change Source Priority Order
Edit `config/config.json`:
```json
{
  "paper_sources_priority": {
    "daily": ["papers-with-code", "arxiv", "hugging-face"],
    "weekly": ["papers-with-code", "semantic-scholar", "hugging-face"],
    "monthly": ["papers-with-code", "semantic-scholar"],
    "quarterly": ["papers-with-code", "semantic-scholar"],
    "yearly": ["papers-with-code", "semantic-scholar", "openreview"]
  }
}
```

---

## Recommendations by Use Case

### 📈 Citation Growth Analysis
```
PRIMARY: Papers with Code (best metrics)
COMMAND: @find-top-papers weekly 5 "" papers-with-code
```

### 📰 Latest Research Trends
```
PRIMARY: arXiv (most recent)
COMMAND: @find-top-papers daily 5 "" arxiv
```

### 🏆 Conference Papers (SOTA)
```
PRIMARY: OpenReview (top-tier papers)
COMMAND: @find-top-papers yearly 5 "" openreview
```

### 🤖 AI/ML Community Trending
```
PRIMARY: Hugging Face (trending)
COMMAND: @find-top-papers weekly 5 "" hugging-face
```

### 🔬 Comprehensive Research
```
PRIMARY: Semantic Scholar (most comprehensive)
COMMAND: @find-top-papers weekly 5 "" semantic-scholar
```

### 🎯 Everything (Best of all)
```
PRIMARY: Combined (aggregate all sources)
COMMAND: @find-top-papers weekly 5 "" combined
```

---

## Error Handling

### Source Unavailable
```python
# If specific source fails, automatically tries next in priority order
papers, source = scraper.fetch_papers(
    period='weekly',
    source='papers-with-code'  # If fails...
)
# Falls back to semantic-scholar, then hugging-face, etc.
```

### All Sources Failed
```python
# Returns mock data as last resort
papers, source = scraper.fetch_papers(period='weekly')
# Returns: (mock_papers, 'mock')
```

### Network Timeout
```python
# Includes retry logic with exponential backoff
papers, source = scraper.fetch_papers(
    period='weekly',
    retry_count=3  # Tries each source 3 times
)
```

---

## Troubleshooting

### Q: Why did it use Source X instead of Source Y?
**A:** Check priority order in `config.json`. The system tries sources in priority order until one succeeds.

### Q: How do I force a specific source?
**A:** Use: `@find-top-papers weekly 5 "" specific-source-name`

### Q: Can I use all sources at once?
**A:** Yes: `@find-top-papers weekly 5 "" combined`

### Q: Why is it slow?
**A:** Semantic Scholar is slowest (~15s). Use arXiv for speed (~5s).

### Q: How do I cache results?
**A:** Results are automatically cached in `./outputs/{paper_id}`

---

## Integration with Existing Code

### Update Backend API
Replace old scraper call with:
```python
from services.enhanced_paper_scraper import EnhancedPaperScraper

scraper = EnhancedPaperScraper()
papers, source_used = scraper.fetch_papers(
    period=citation_growth,
    count=count,
    topic_filter=topic_filter,
    source=data_source  # from request body
)
```

### Update Frontend
Add source selector in web app:
```html
<select id="dataSource">
    <option value="auto">Auto-select (Smart)</option>
    <option value="combined">Combined (All sources)</option>
    <option value="papers-with-code">Papers with Code</option>
    <option value="semantic-scholar">Semantic Scholar</option>
    <option value="arxiv">arXiv</option>
    <option value="hugging-face">Hugging Face</option>
    <option value="openreview">OpenReview</option>
</select>
```

---

## Performance Metrics

### Typical Response Times
- **Papers with Code**: 5-10s
- **Semantic Scholar**: 10-15s (slower due to filtering)
- **arXiv**: 3-5s (fastest)
- **Hugging Face**: 5-10s
- **OpenReview**: 5-10s

### Combined Mode
- **Time**: ~20-25s (fetches all in parallel)
- **Results**: Deduplicated unique papers from all sources

---

## API Rate Limits

| Source | Limit | Notes |
|--------|-------|-------|
| Papers with Code | Unlimited | Scraping, respect robots.txt |
| Semantic Scholar | 1000 req/s (shared) | Higher with API key |
| arXiv | Unlimited | Respectful usage |
| Hugging Face | Unlimited | Scraping-based |
| OpenReview | Generous | Official API |

---

## Next Steps

1. ✅ Integrate enhanced scraper into backend
2. ✅ Update frontend with source selector
3. ✅ Add source selection to Agent/Skill
4. ✅ Test all sources
5. ✅ Monitor performance & success rates
6. → Add caching layer for popular queries
7. → Add analytics on source usage
8. → Allow user preferences for preferred sources

---

## Questions?

See [DATA_SOURCES.md](../DATA_SOURCES.md) for detailed source comparison.

