// ============================================
// CONFIG.JS - Configuration & Constants
// ============================================

const CONFIG = {
    // API Endpoints
    BACKEND_URL: 'http://localhost:5000',
    PAPERS_WITH_CODE_URL: 'https://paperswithcode.com',
    
    // Service Keys (loaded from localStorage or environment)
    API_KEYS: {
        OPENAI: localStorage.getItem('openai_key') || '',
        ELEVEN_LABS: localStorage.getItem('eleven_labs_key') || '',
        GOOGLE_SLIDES: localStorage.getItem('google_slides_key') || ''
    },
    
    // Default Settings
    DEFAULTS: {
        CITATION_GROWTH: 'weekly',
        PAPER_COUNT: 5,
        VIDEO_DURATION: 3,
        LLM_PROVIDER: 'openai',
        SLIDES_FORMAT: 'google-slides',
        VOICE: 'male-english'
    },
    
    // Timeouts
    TIMEOUTS: {
        PAPER_FETCH: 15000,      // 15s
        LLM_ANALYSIS: 60000,     // 60s
        SLIDES_GENERATION: 30000, // 30s
        VIDEO_GENERATION: 180000  // 3 minutes
    },
    
    // Retry Settings
    RETRY: {
        MAX_ATTEMPTS: 3,
        INITIAL_DELAY: 1000, // 1s
        MAX_DELAY: 5000      // 5s
    }
};

// ============================================
// MOCK DATA FOR TESTING
// ============================================
const MOCK_PAPERS = [
    {
        id: 'llama3-2024',
        title: 'Llama 3: Open Foundation and Fine-Tuned Chat Models',
        authors: 'Meta AI',
        year: 2024,
        citations: 2543,
        growth_daily: 45,
        growth_weekly: 312,
        abstract: 'We present Llama 3, a new large language model trained on 15 trillion tokens of data...',
        url: 'https://arxiv.org/abs/2405.00663',
        keywords: ['LLM', 'Foundation Model', 'Open Source'],
        highlights: [
            'Improved instruction-following capabilities',
            '15 trillion token training corpus',
            'State-of-the-art performance on benchmarks',
            'Extensive safety evaluation'
        ]
    },
    {
        id: 'mamba-2024',
        title: 'Mamba: Linear-Time Sequence Modeling with Selective State Spaces',
        authors: 'CMU, Princeton, MIT',
        year: 2024,
        citations: 1892,
        growth_daily: 38,
        growth_weekly: 278,
        abstract: 'We introduce Mamba, a new state space model architecture that achieves linear time complexity...',
        url: 'https://arxiv.org/abs/2312.08956',
        keywords: ['SSM', 'Efficiency', 'Sequence Modeling'],
        highlights: [
            'Linear time complexity inference',
            'Better scaling than Transformers',
            'Superior language modeling performance',
            'Efficient hardware implementation'
        ]
    },
    {
        id: 'qwen2-2024',
        title: 'Qwen2 Technical Report',
        authors: 'Alibaba DAMO Academy',
        year: 2024,
        citations: 1456,
        growth_daily: 32,
        growth_weekly: 245,
        abstract: 'Qwen2 is a large language model series including base and instruction-tuned variants...',
        url: 'https://arxiv.org/abs/2407.10671',
        keywords: ['LLM', 'Multilingual', 'Benchmark'],
        highlights: [
            'Superior performance on coding tasks',
            'Support for multiple languages',
            'Competitive results on all benchmarks',
            'Efficient inference optimization'
        ]
    },
    {
        id: 'flash-attention2-2023',
        title: 'Flash-2: Faster Attention with A Simplified Complexity',
        authors: 'Tri Dao, Daniel Y. Fu, Stefano Ermon, Atri Rudra, Christopher Ré',
        year: 2023,
        citations: 3214,
        growth_daily: 28,
        growth_weekly: 198,
        abstract: 'Flash-2 is an improved version of the Flash-Attention algorithm with reduced complexity...',
        url: 'https://arxiv.org/abs/2307.08691',
        keywords: ['Attention', 'Efficiency', 'CUDA'],
        highlights: [
            '2x speedup on attention computation',
            'Reduced memory footprint',
            'Better scaling on long sequences',
            'Hardware-aware implementation'
        ]
    },
    {
        id: 'vision-transformer-2024',
        title: 'Vision Transformers at Scale: A Survey and Benchmark',
        authors: 'Stanford AI Lab',
        year: 2024,
        citations: 892,
        growth_daily: 24,
        growth_weekly: 167,
        abstract: 'This survey provides a comprehensive overview of Vision Transformers and their scaling...',
        url: 'https://arxiv.org/abs/2406.01230',
        keywords: ['Vision Transformers', 'Computer Vision', 'Scaling'],
        highlights: [
            'Comprehensive benchmarking framework',
            'Scaling laws for vision models',
            'Cross-model performance comparison',
            'Best practices for optimization'
        ]
    }
];

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Format numbers with commas and abbreviations
 */
function formatNumber(num) {
    if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
    if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
    return num.toString();
}

/**
 * Load configuration from localStorage
 */
function loadConfig() {
    const saved = localStorage.getItem('app_config');
    if (saved) {
        try {
            return JSON.parse(saved);
        } catch (e) {
            console.error('Failed to load config:', e);
        }
    }
    return CONFIG.DEFAULTS;
}

/**
 * Save configuration to localStorage
 */
function saveConfig(config) {
    localStorage.setItem('app_config', JSON.stringify(config));
}

/**
 * Add status message
 */
function addStatus(message, type = 'info') {
    const container = document.getElementById('statusContainer');
    const msgEl = document.createElement('div');
    msgEl.className = `status-message status-${type}`;
    msgEl.textContent = message;
    container.appendChild(msgEl);
    
    // Auto-remove after 5s for info messages
    if (type === 'info') {
        setTimeout(() => msgEl.remove(), 5000);
    }
}

/**
 * Update progress bar
 */
function updateProgress(current, total) {
    const container = document.getElementById('progressContainer');
    const fill = document.getElementById('progressFill');
    const text = document.getElementById('progressText');
    const percent = document.getElementById('progressPercent');
    
    const percentage = (current / total) * 100;
    fill.style.width = percentage + '%';
    percent.textContent = Math.round(percentage) + '%';
    text.textContent = `Processing: ${current} of ${total} papers...`;
}

/**
 * Show progress container
 */
function showProgress() {
    document.getElementById('progressContainer').style.display = 'block';
}

/**
 * Hide progress container
 */
function hideProgress() {
    document.getElementById('progressContainer').style.display = 'none';
}

/**
 * Format citation growth text
 */
function formatGrowth(period, value) {
    const periods = {
        'daily': '/ day',
        'weekly': '/ week',
        'monthly': '/ month',
        'quarterly': '/ quarter',
        'yearly': '/ year'
    };
    return `+${value} ${periods[period] || period}`;
}

/**
 * Retry function with exponential backoff
 */
async function retryAsync(fn, maxAttempts = CONFIG.RETRY.MAX_ATTEMPTS) {
    let lastError;
    for (let i = 0; i < maxAttempts; i++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;
            if (i < maxAttempts - 1) {
                const delay = Math.min(
                    CONFIG.RETRY.INITIAL_DELAY * Math.pow(2, i),
                    CONFIG.RETRY.MAX_DELAY
                );
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    throw lastError;
}

/**
 * API Call with timeout
 */
async function apiCall(url, options = {}, timeout = 30000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        clearTimeout(timeoutId);
        throw error;
    }
}

/**
 * Export functions for use in app.js
 */
window.CONFIG = CONFIG;
window.MOCK_PAPERS = MOCK_PAPERS;
window.formatNumber = formatNumber;
window.loadConfig = loadConfig;
window.saveConfig = saveConfig;
window.addStatus = addStatus;
window.updateProgress = updateProgress;
window.showProgress = showProgress;
window.hideProgress = hideProgress;
window.formatGrowth = formatGrowth;
window.retryAsync = retryAsync;
window.apiCall = apiCall;
