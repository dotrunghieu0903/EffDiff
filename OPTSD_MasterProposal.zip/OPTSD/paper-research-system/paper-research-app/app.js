// ============================================
// APP.JS - Main Application Logic
// ============================================

class PaperResearchApp {
    constructor() {
        this.papers = [];
        this.selectedPaper = null;
        this.isProcessing = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSavedConfig();
        addStatus('Application loaded successfully', 'success');
    }

    setupEventListeners() {
        // Main buttons
        document.getElementById('searchBtn').addEventListener('click', () => this.search());
        document.getElementById('testModeBtn').addEventListener('click', () => this.testMode());
        document.getElementById('saveConfigBtn').addEventListener('click', () => this.saveConfiguration());
        document.getElementById('downloadAllBtn').addEventListener('click', () => this.downloadAll());
        document.getElementById('openFolderBtn').addEventListener('click', () => this.openFolder());

        // Modal close
        document.querySelector('.close-btn').addEventListener('click', () => this.closeModal());
        document.getElementById('paperDetailModal').addEventListener('click', (e) => {
            if (e.target.id === 'paperDetailModal') this.closeModal();
        });
    }

    loadSavedConfig() {
        const config = loadConfig();
        document.getElementById('citationGrowth').value = config.CITATION_GROWTH;
        document.getElementById('paperCount').value = config.PAPER_COUNT;
        document.getElementById('videoDuration').value = config.VIDEO_DURATION;
        document.getElementById('llmProvider').value = config.LLM_PROVIDER;
        document.getElementById('slidesFormat').value = config.SLIDES_FORMAT;
        document.getElementById('videoVoice').value = config.VOICE;

        // Load API keys if they exist
        if (CONFIG.API_KEYS.OPENAI) {
            document.getElementById('openaiKey').value = '••••••••';
        }
        if (CONFIG.API_KEYS.ELEVEN_LABS) {
            document.getElementById('elevenLabsKey').value = '••••••••';
        }
    }

    saveConfiguration() {
        const config = {
            CITATION_GROWTH: document.getElementById('citationGrowth').value,
            PAPER_COUNT: parseInt(document.getElementById('paperCount').value),
            VIDEO_DURATION: parseInt(document.getElementById('videoDuration').value),
            LLM_PROVIDER: document.getElementById('llmProvider').value,
            SLIDES_FORMAT: document.getElementById('slidesFormat').value,
            VOICE: document.getElementById('videoVoice').value
        };

        // Handle API keys
        const openaiKey = document.getElementById('openaiKey').value;
        const elevenLabsKey = document.getElementById('elevenLabsKey').value;

        if (openaiKey && !openaiKey.startsWith('•')) {
            localStorage.setItem('openai_key', openaiKey);
            CONFIG.API_KEYS.OPENAI = openaiKey;
        }

        if (elevenLabsKey && !elevenLabsKey.startsWith('•')) {
            localStorage.setItem('eleven_labs_key', elevenLabsKey);
            CONFIG.API_KEYS.ELEVEN_LABS = elevenLabsKey;
        }

        // Handle Google service account file
        const googleKeyInput = document.getElementById('googleKey');
        if (googleKeyInput.files.length > 0) {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const key = JSON.parse(e.target.result);
                    localStorage.setItem('google_slides_key', JSON.stringify(key));
                    CONFIG.API_KEYS.GOOGLE_SLIDES = key;
                    addStatus('Google Slides credentials saved', 'success');
                } catch (err) {
                    addStatus('Invalid JSON file', 'error');
                }
            };
            reader.readAsText(googleKeyInput.files[0]);
        }

        saveConfig(config);
        addStatus('Configuration saved successfully', 'success');
    }

    testMode() {
        addStatus('⚡ Loading mock data for testing...', 'info');
        this.papers = MOCK_PAPERS;
        this.displayPapers();
        addStatus('✅ Mock data loaded! Click on papers to view details or generate content.', 'success');
    }

    async search() {
        if (this.isProcessing) {
            addStatus('Search already in progress...', 'warning');
            return;
        }

        this.isProcessing = true;
        document.getElementById('searchBtn').disabled = true;

        try {
            const citationGrowth = document.getElementById('citationGrowth').value;
            const paperCount = document.getElementById('paperCount').value;
            const topicFilter = document.getElementById('topicFilter').value;
            const dataSource = document.getElementById('dataSource').value;

            addStatus(`Searching for ${paperCount} papers with ${citationGrowth} citation growth...`, 'info');
            showProgress();

            // Call backend API
            const response = await retryAsync(async () => {
                return await apiCall(`${CONFIG.BACKEND_URL}/api/papers/search`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        citation_growth: citationGrowth,
                        count: parseInt(paperCount),
                        topic_filter: topicFilter,
                        data_source: dataSource
                    })
                }, CONFIG.TIMEOUTS.PAPER_FETCH);
            });

            if (response.success) {
                this.papers = response.data;
                this.displayPapers();
                addStatus(`✅ Found ${this.papers.length} papers!`, 'success');
            } else {
                throw new Error(response.error || 'Search failed');
            }
        } catch (error) {
            addStatus(`❌ Search failed: ${error.message}`, 'error');
        } finally {
            this.isProcessing = false;
            hideProgress();
            document.getElementById('searchBtn').disabled = false;
        }
    }

    displayPapers() {
        const papersList = document.getElementById('papersList');
        papersList.innerHTML = '';

        this.papers.forEach((paper, index) => {
            const card = document.createElement('div');
            card.className = 'paper-card';
            card.innerHTML = `
                <div class="paper-title">${index + 1}. ${paper.title}</div>
                <div class="paper-meta">
                    <span>👤 ${paper.authors}</span>
                    <span>📅 ${paper.year}</span>
                </div>
                <div class="paper-stats">
                    <div class="stat">
                        <span>📈 Citations:</span>
                        <span class="stat-badge">${formatNumber(paper.citations)}</span>
                    </div>
                    <div class="stat">
                        <span>⚡ Growth:</span>
                        <span class="stat-badge">+${paper.growth_daily}/day</span>
                    </div>
                </div>
                <div class="paper-actions">
                    <button onclick="app.viewDetails('${paper.id}')">📖 View Details</button>
                    <button onclick="app.generateContent('${paper.id}')">🚀 Generate</button>
                </div>
            `;
            papersList.appendChild(card);
        });
    }

    viewDetails(paperId) {
        const paper = this.papers.find(p => p.id === paperId);
        if (!paper) return;

        const modal = document.getElementById('paperDetailModal');
        const content = document.getElementById('paperDetailContent');

        content.innerHTML = `
            <h2>${paper.title}</h2>
            <p><strong>Authors:</strong> ${paper.authors}</p>
            <p><strong>Year:</strong> ${paper.year}</p>
            <p><strong>Citations:</strong> ${formatNumber(paper.citations)} (Growth: ${formatGrowth('daily', paper.growth_daily)})</p>
            <p><strong>Keywords:</strong> ${paper.keywords.join(', ')}</p>
            
            <h3>Abstract</h3>
            <p>${paper.abstract}</p>
            
            <h3>Key Highlights</h3>
            <ul>
                ${paper.highlights.map(h => `<li>${h}</li>`).join('')}
            </ul>
            
            <h3>Links</h3>
            <p><a href="${paper.url}" target="_blank">📄 View on arXiv</a></p>
        `;

        modal.style.display = 'block';
    }

    closeModal() {
        document.getElementById('paperDetailModal').style.display = 'none';
    }

    async generateContent(paperId) {
        const paper = this.papers.find(p => p.id === paperId);
        if (!paper) return;

        if (this.isProcessing) {
            addStatus('Content generation already in progress...', 'warning');
            return;
        }

        this.isProcessing = true;
        showProgress();

        try {
            addStatus(`Analyzing paper: ${paper.title}...`, 'info');
            updateProgress(1, 4);

            // Step 1: Analyze paper
            const analysis = await retryAsync(async () => {
                return await apiCall(`${CONFIG.BACKEND_URL}/api/papers/${paperId}/analyze`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        llm_provider: document.getElementById('llmProvider').value,
                        abstract: paper.abstract,
                        title: paper.title
                    })
                }, CONFIG.TIMEOUTS.LLM_ANALYSIS);
            });

            if (!analysis.success) throw new Error('Analysis failed');
            addStatus('✅ Paper analyzed', 'success');
            updateProgress(2, 4);

            // Step 2: Generate slides
            addStatus('Generating Google Slides...', 'info');
            const slides = await retryAsync(async () => {
                return await apiCall(`${CONFIG.BACKEND_URL}/api/papers/${paperId}/generate-slides`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        analysis: analysis.data,
                        title: paper.title,
                        format: document.getElementById('slidesFormat').value
                    })
                }, CONFIG.TIMEOUTS.SLIDES_GENERATION);
            });

            if (!slides.success) throw new Error('Slides generation failed');
            addStatus('✅ Slides created', 'success');
            updateProgress(3, 4);

            // Step 3: Generate video
            addStatus('Generating video with narration...', 'info');
            const video = await retryAsync(async () => {
                return await apiCall(`${CONFIG.BACKEND_URL}/api/papers/${paperId}/generate-video`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        script: analysis.data.summary_script,
                        voice: document.getElementById('videoVoice').value,
                        duration: document.getElementById('videoDuration').value
                    })
                }, CONFIG.TIMEOUTS.VIDEO_GENERATION);
            });

            if (!video.success) throw new Error('Video generation failed');
            addStatus('✅ Video created', 'success');
            updateProgress(4, 4);

            // Show results
            this.showResults({
                paper: paper,
                analysis: analysis.data,
                slides: slides.data,
                video: video.data
            });

        } catch (error) {
            addStatus(`❌ Content generation failed: ${error.message}`, 'error');
        } finally {
            this.isProcessing = false;
            hideProgress();
        }
    }

    showResults(results) {
        const summary = document.getElementById('resultsSummary');
        const links = document.getElementById('outputLinks');

        links.innerHTML = `
            <h4>Generated Content:</h4>
            <a href="${results.slides.url}" target="_blank" class="output-link">🎯 Google Slides: ${results.slides.title}</a>
            <a href="${results.video.url}" target="_blank" class="output-link">🎬 Video: ${results.paper.title}.mp4</a>
            <a href="${results.analysis.summary_url}" target="_blank" class="output-link">📋 Summary: ${results.paper.title}_summary.json</a>
        `;

        summary.style.display = 'block';
        addStatus('✅ All content generated! Check the results below.', 'success');
    }

    downloadAll() {
        addStatus('Preparing download...', 'info');
        // Implementation for downloading all files
        setTimeout(() => {
            addStatus('Download started', 'success');
        }, 1000);
    }

    openFolder() {
        addStatus('Opening output folder...', 'info');
        // Implementation for opening output folder
    }
}

// ============================================
// INITIALIZE APPLICATION
// ============================================
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new PaperResearchApp();
});
