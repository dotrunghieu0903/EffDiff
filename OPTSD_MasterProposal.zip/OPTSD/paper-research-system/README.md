# Paper Research System - Complete Project Structure

## 🎯 Project Overview
A complete system to discover top research papers with rapidly growing citations, automatically analyze them, and generate professional academic presentations and videos.

### Key Features
- **Paper Discovery**: Find top papers from Papers with Code by citation growth (daily/weekly/monthly/quarterly/yearly)
- **Intelligent Analysis**: Use OpenAI/Claude to extract key insights and contributions
- **Professional Slides**: Generate Google Slides presentations or PowerPoint files
- **Video Creation**: Create narrated videos with AI voice-over
- **Batch Processing**: Handle multiple papers sequentially
- **Multiple Data Sources**: Support scraping, APIs, and manual input

---

## 📁 Project Structure

```
paper-research-system/
│
├── paper-research-agent/          # VS Code Agent/Skill
│   ├── .instructions.md           # Agent instructions
│   ├── SKILL.md                   # Skill definition
│   └── agent-actions.md           # Agent action definitions (optional)
│
├── paper-research-app/            # Web Application (Frontend)
│   ├── index.html                 # Main HTML
│   ├── styles.css                 # Styling
│   ├── app.js                     # Main application logic
│   ├── config.js                  # Configuration & utilities
│   └── assets/                    # Images, icons, etc.
│
├── paper-research-backend/        # Backend Services (Python)
│   ├── main.py                    # Flask application entry point
│   ├── requirements.txt           # Python dependencies
│   ├── .env                       # Environment variables (create this)
│   │
│   ├── services/
│   │   ├── __init__.py            # Package init
│   │   ├── paper_scraper.py       # Scrape Papers with Code
│   │   ├── paper_analyzer.py      # LLM analysis
│   │   ├── slides_generator.py    # Google Slides/PPTX generation
│   │   ├── video_generator.py     # Video creation with FFmpeg
│   │   └── tts_service.py         # Text-to-Speech (Eleven Labs, Google Cloud)
│   │
│   ├── config/
│   │   ├── config.example.json    # Configuration template
│   │   ├── config.json            # Your configuration (create this)
│   │   └── google_service_account.json  # Google credentials (create this)
│   │
│   └── outputs/                   # Generated outputs
│       └── {paper_id}/
│           ├── analysis.json
│           ├── slides.pptx
│           ├── video.mp4
│           └── audio.mp3
│
└── README.md                       # This file
```

---

## 🚀 Quick Start

### Prerequisites
- **Python 3.10+**
- **Node.js 18+** (for Web App, optional)
- **FFmpeg** (for video generation)
- API Keys:
  - OpenAI API Key (for LLM analysis)
  - Eleven Labs API Key (for TTS)
  - Google Service Account credentials (for Google Slides)

### Setup

#### 1. Backend Setup (Python)

```bash
# Navigate to backend directory
cd paper-research-backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env  # (create if doesn't exist)

# Edit .env with your API keys
```

**Example `.paper-research-backend/.env`:**
```
FLASK_ENV=development
DEBUG=True
PORT=5000

OPENAI_API_KEY=sk-...
CLAUDE_API_KEY=sk-...
ELEVEN_LABS_API_KEY=...
GOOGLE_SLIDES_CREDENTIALS={"type": "service_account", ...}

OUTPUT_DIR=./outputs
FFMPEG_PATH=ffmpeg
```

#### 2. Configuration

Edit `config/config.json`:
```bash
cp config/config.example.json config/config.json
# Edit config.json with your settings
```

#### 3. Run Backend

```bash
python main.py
```

Server runs at `http://localhost:5000`

#### 4. Web App Setup (Optional)

```bash
# Navigate to app directory
cd ../paper-research-app

# Serve with Python
python -m http.server 3000

# Or use Node.js if available
npx http-server -p 3000
```

Access at `http://localhost:3000`

---

## 📚 API Endpoints

### Paper Search
```bash
POST /api/papers/search
Content-Type: application/json

{
  "citation_growth": "weekly",
  "count": 5,
  "topic_filter": "LLM",
  "data_source": "scraping"
}

Response:
{
  "success": true,
  "data": [
    {
      "id": "paper_1",
      "title": "...",
      "authors": "...",
      "citations": 2543,
      "growth_daily": 45,
      ...
    }
  ]
}
```

### Paper Analysis
```bash
POST /api/papers/{paper_id}/analyze
Content-Type: application/json

{
  "llm_provider": "openai",
  "abstract": "...",
  "title": "..."
}

Response:
{
  "success": true,
  "data": {
    "problem_statement": "...",
    "key_contributions": "...",
    "technical_approach": "...",
    "experimental_results": "...",
    "outstanding_highlights": "...",
    "summary_script": "..."
  }
}
```

### Slides Generation
```bash
POST /api/papers/{paper_id}/generate-slides
Content-Type: application/json

{
  "analysis": {...},
  "title": "Paper Title",
  "format": "google-slides"
}

Response:
{
  "success": true,
  "data": {
    "url": "https://docs.google.com/presentation/d/...",
    "presentation_id": "...",
    "format": "google-slides"
  }
}
```

### Video Generation
```bash
POST /api/papers/{paper_id}/generate-video
Content-Type: application/json

{
  "script": "...",
  "voice": "male-english",
  "duration": 3
}

Response:
{
  "success": true,
  "data": {
    "url": "/outputs/{paper_id}/video.mp4",
    "duration": "3 minutes",
    "format": "mp4"
  }
}
```

---

## 🎓 Workflow

### Complete Pipeline for One Paper

```
1. FETCH PAPERS (10-15 seconds)
   ├─ Scrape/API Papers with Code
   ├─ Filter by citation growth
   └─ Return top 5 papers

2. ANALYZE PAPER (30-45 seconds per paper)
   ├─ Extract abstract & metadata
   ├─ Call LLM (OpenAI/Claude)
   ├─ Extract key sections:
   │  ├─ Problem Statement
   │  ├─ Technical Approach
   │  ├─ Experimental Results
   │  └─ Outstanding Highlights
   └─ Generate narration script

3. GENERATE SLIDES (20-30 seconds)
   ├─ Create slides structure:
   │  ├─ Title slide
   │  ├─ Problem & motivation (1-2 slides)
   │  ├─ Technical approach (2-3 slides)
   │  ├─ Results (1-2 slides)
   │  ├─ Highlights (1 slide)
   │  └─ References (1 slide)
   ├─ Format: Google Slides or PPTX
   └─ Return shareable link/file

4. GENERATE AUDIO (2-5 minutes)
   ├─ Use TTS service:
   │  ├─ Eleven Labs (recommended)
   │  ├─ Google Cloud TTS
   │  └─ Local TTS (optional)
   └─ Generate MP3 file

5. CREATE VIDEO (2-3 minutes)
   ├─ Extract slides as images
   ├─ Combine with audio using FFmpeg
   ├─ Add transitions & effects
   └─ Export MP4 video

TOTAL TIME: ~20-25 minutes for 5 papers
```

---

## 🔧 Configuration Details

### LLM Provider Configuration

**OpenAI (GPT-4)**
```json
{
  "llm_provider": "openai",
  "model": "gpt-4",
  "temperature": 0.7,
  "max_tokens": 2000
}
```

**Claude (Anthropic)**
```json
{
  "llm_provider": "claude",
  "model": "claude-3-opus-20240229",
  "temperature": 0.7,
  "max_tokens": 2000
}
```

**Local Model (Ollama, LLaMA, etc.)**
```json
{
  "llm_provider": "local",
  "endpoint": "http://localhost:11434",
  "model": "mistral"
}
```

### TTS Provider Configuration

**Eleven Labs (Recommended)**
- High quality, natural-sounding voices
- Multiple languages
- API: https://elevenlabs.io

**Google Cloud Text-to-Speech**
- Wide language support
- Neural voices
- API: Google Cloud Console

### Video Configuration

**FFmpeg Installation**

Windows:
```bash
# Using Chocolatey
choco install ffmpeg

# Or download from https://ffmpeg.org/download.html
```

macOS:
```bash
brew install ffmpeg
```

Linux (Ubuntu/Debian):
```bash
sudo apt-get install ffmpeg
```

---

## 📊 Example Usage

### Via Web App

1. Open `http://localhost:3000`
2. Select search criteria (weekly growth, top 5 papers)
3. Click "Find Top Papers"
4. For each paper, click "Generate Content"
5. Wait for slides & video to be generated
6. Download or view results

### Via Python API

```python
import requests

# Search for papers
papers_response = requests.post(
    'http://localhost:5000/api/papers/search',
    json={
        'citation_growth': 'weekly',
        'count': 5,
        'data_source': 'scraping'
    }
)

papers = papers_response.json()['data']

# Analyze first paper
paper_id = papers[0]['id']
analysis_response = requests.post(
    f'http://localhost:5000/api/papers/{paper_id}/analyze',
    json={
        'llm_provider': 'openai',
        'abstract': papers[0]['abstract'],
        'title': papers[0]['title']
    }
)

analysis = analysis_response.json()['data']

# Generate slides
slides_response = requests.post(
    f'http://localhost:5000/api/papers/{paper_id}/generate-slides',
    json={
        'analysis': analysis,
        'title': papers[0]['title'],
        'format': 'pptx'
    }
)

# Generate video
video_response = requests.post(
    f'http://localhost:5000/api/papers/{paper_id}/generate-video',
    json={
        'script': analysis['summary_script'],
        'voice': 'male-english',
        'duration': 3
    }
)

print("Results:", video_response.json())
```

---

## 🛠️ Troubleshooting

### Common Issues

**1. "CORS Error"**
- Ensure backend is running on correct port
- Check CORS configuration in `config.json`
- Frontend and backend must be able to communicate

**2. "API Key Error"**
- Verify keys are correctly set in `.env`
- Check key format and validity on provider's dashboard
- Some providers require additional setup (e.g., Google Cloud project)

**3. "FFmpeg Not Found"**
- Install FFmpeg (see Configuration section)
- Set correct path in `FFMPEG_PATH` environment variable
- Test: `ffmpeg -version`

**4. "Memory Error When Processing Videos"**
- Reduce video duration or quality settings
- Process fewer papers at once
- Increase available system memory

**5. "Timeout Errors"**
- Check internet connection
- Increase timeout values in `config.json`
- Some APIs may be rate-limited

---

## 📝 Development

### Project Structure Philosophy

```
Backend (Python)
├─ Separate concerns:
│  ├─ Scraper: Only fetch papers
│  ├─ Analyzer: Only LLM analysis
│  ├─ Generator: Only content generation
│  └─ TTS/Video: Only media creation
├─ Easy to test each component independently
└─ Easy to swap implementations (e.g., different LLM)

Frontend (HTML/JS)
├─ Responsive design
├─ Real-time progress updates
├─ Configuration management in UI
└─ Beautiful, intuitive interface
```

### Adding New Features

**Adding a new LLM provider:**
1. Edit `paper_analyzer.py`
2. Add method `_analyze_with_{provider_name}`
3. Update `config.json`
4. Test endpoint

**Adding a new paper source:**
1. Edit `paper_scraper.py`
2. Add method `fetch_from_{source_name}`
3. Return data in standard format
4. Update configuration

---

## 📄 Files & Descriptions

### Backend Files

| File | Purpose |
|------|---------|
| `main.py` | Flask app, API endpoints |
| `paper_scraper.py` | Fetch papers from various sources |
| `paper_analyzer.py` | Analyze using LLM (OpenAI/Claude) |
| `slides_generator.py` | Create Google Slides & PPTX presentations |
| `video_generator.py` | Create videos using FFmpeg |
| `tts_service.py` | Generate speech (Eleven Labs, Google Cloud) |

### Frontend Files

| File | Purpose |
|------|---------|
| `index.html` | Main HTML structure |
| `styles.css` | All styling & responsive design |
| `app.js` | Main application logic & event handling |
| `config.js` | Configuration, utilities, mock data |

### VS Code Agent

| File | Purpose |
|------|---------|
| `.instructions.md` | Detailed agent behavior & workflow |
| `SKILL.md` | Skill definition for VS Code integration |

---

## 🔐 Security Notes

⚠️ **Important:**
- Never commit `.env` or API keys to version control
- Use environment variables for sensitive data
- Validate and sanitize all inputs
- Use HTTPS in production
- Rate limit API endpoints
- Add authentication if exposing publicly

---

## 📈 Performance Optimization

### Tips for Better Performance

1. **Caching**
   - Cache paper data to avoid re-scraping
   - Cache LLM responses
   - Cache generated slides/videos

2. **Parallelization**
   - Process multiple papers in parallel (with care)
   - Use worker threads/processes for video generation

3. **Resource Management**
   - Stream large files instead of loading into memory
   - Clean up temporary files after processing
   - Monitor memory usage for long-running processes

---

## 📞 Support & Contribution

### Issues & Bugs
Report issues with detailed:
- Error message
- Steps to reproduce
- Your configuration (without API keys)

### Contributing
1. Fork/clone repository
2. Create feature branch
3. Make changes
4. Test thoroughly
5. Submit pull request

---

## 📜 License

MIT License - Feel free to use for personal and commercial projects

---

## 🎉 Thank You!

Built with ❤️ for researchers and students

**Questions?** Check the configuration files, enable debug logging, and review the API docs above.

Happy researching! 📚✨
