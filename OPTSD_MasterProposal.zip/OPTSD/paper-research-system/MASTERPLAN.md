# KẾ HOẠCH HÀNH ĐỘNG CHI TIẾT — LUẬN VĂN THẠC SĨ
## "Phân tích và Cải tiến các Chiến lược Tối ưu hóa Hiệu năng cho Mô hình Diffusion"
### *(Analyzing and Improving Efficiency Optimization Strategies for Diffusion Models)*

**Giả định lập kế hoạch:** thời lượng ~8 tháng (08/2026 – 03/2027). Vai trò: **HV** = Học viên (chủ trì toàn bộ), **GVHD** = Giảng viên hướng dẫn (định hướng, duyệt), **Đồng nghiệp/Lab** = hỗ trợ hạ tầng/review. Điều chỉnh mốc thời gian theo lịch thực tế của trường.

**Định vị chủ đề:** "chiến lược tối ưu hiệu năng cho diffusion" bao trùm 6 nhóm kỹ thuật chính — (1) *distillation* (consistency/sCM, DMD2, rCM), (2) *fast solvers* (DPM-Solver, DEIS), (3) *quantization/pruning*, (4) *caching & tái sử dụng đặc trưng*, (5) *kiến trúc hiệu quả* (latent diffusion, efficient/linear attention), (6) *tối ưu tầng hệ thống/kernel* (FlashAttention & hậu duệ, quantized/sparse attention kernels — tầng hạ tầng, cross-cutting, hỗ trợ 5 nhóm trên). Nhóm (1)–(5) là tối ưu **thuật toán/mô hình**; nhóm (6) là tối ưu **triển khai/phần cứng** (exact, không đổi chất lượng). Kế hoạch xoay quanh: **khảo sát → tái lập → phân tích → cải tiến**.

---

## Tổng quan các giai đoạn

| GĐ | Tên giai đoạn | Thời gian | Ưu tiên | Kết quả bàn giao (Deliverable) |
|---|---|---|---|---|
| 0 | Khởi động & định hướng | Tuần 1–2 (08/2026) | Cao | Đề cương chi tiết được duyệt |
| 1 | Khảo sát tài liệu (SOTA) | Tuần 3–8 (08–09/2026) | Cao | Survey + bảng phân loại kỹ thuật |
| 2 | Thiết lập hạ tầng & tái lập baseline | Tuần 7–12 (09–10/2026) | Cao | Codebase + baseline tái lập được |
| 3 | Phân tích chuyên sâu chiến lược hiện có | Tuần 11–18 (10–11/2026) | Cao | Báo cáo phân tích + phát hiện điểm yếu |
| 4 | Đề xuất & cải tiến | Tuần 17–24 (11/2026–01/2027) | Rất cao | Phương pháp cải tiến + prototype |
| 5 | Thực nghiệm & đánh giá | Tuần 23–30 (01–02/2027) | Rất cao | Bảng kết quả + ablation đầy đủ |
| 6 | Viết luận văn & bảo vệ | Tuần 29–34 (02–03/2027) | Cao | Luận văn hoàn chỉnh + slide bảo vệ |

*(Các giai đoạn cố ý gối đầu nhau — overlap — để không lãng phí thời gian chờ.)*

---

## GIAI ĐOẠN 0 — Khởi động & định hướng
**Mục tiêu:** Chốt phạm vi, câu hỏi nghiên cứu, và tiêu chí đánh giá trước khi lao vào kỹ thuật.

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Xác định 2–3 câu hỏi nghiên cứu (RQ) rõ ràng | HV + GVHD | Tuần 1 | Rất cao | ≥2 RQ được GVHD duyệt |
| Chốt phạm vi (chọn 2–3/5 nhóm kỹ thuật để đào sâu) | HV + GVHD | Tuần 1 | Cao | Phạm vi ký duyệt |
| Xác định bộ dataset & metric chuẩn | HV | Tuần 2 | Cao | Danh mục dataset/metric hoàn tất |
| Viết đề cương chi tiết (proposal) | HV | Tuần 2 | Cao | Đề cương được duyệt 100% |
| Lập kế hoạch tài nguyên tính toán (GPU) | HV + Lab | Tuần 2 | Cao | Cam kết ≥X GPU-giờ |

---

## GIAI ĐOẠN 1 — Khảo sát tài liệu (SOTA)
**Mục tiêu:** Nắm toàn cảnh và xây khung phân loại các chiến lược tối ưu; xác định "khoảng trống nghiên cứu".

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Thu thập & đọc ≥40 paper cốt lõi (DDPM, LDM, DPM-Solver, sCM, DMD2, **rCM 2510.08431**, quantization…) | HV | Tuần 3–6 | Rất cao | ≥40 paper, ghi chú có cấu trúc |
| Xây bảng phân loại (taxonomy) 6 nhóm kỹ thuật | HV | Tuần 5–6 | Cao | Bảng taxonomy hoàn chỉnh |
| Lập ma trận so sánh (tốc độ/chất lượng/chi phí train) | HV | Tuần 6–7 | Cao | Ma trận ≥15 phương pháp |
| Xác định 2–3 "gap" nghiên cứu cụ thể | HV + GVHD | Tuần 7–8 | Rất cao | Gap được GVHD xác nhận |
| Viết chương Related Work (bản nháp) | HV | Tuần 8 | Trung bình | Draft ~15 trang |

---

## GIAI ĐOẠN 2 — Thiết lập hạ tầng & tái lập baseline
**Mục tiêu:** Có môi trường thực nghiệm ổn định và tái lập được ít nhất 2–3 baseline làm mốc so sánh.

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Dựng môi trường (PyTorch, diffusers, GPU, logging W&B) | HV + Lab | Tuần 7–8 | Cao | Pipeline chạy end-to-end |
| Chọn & tải mô hình nền (vd. SD/latent diffusion cỡ vừa) | HV | Tuần 8–9 | Cao | ≥1 model chạy inference |
| Tái lập baseline #1: fast solver (DPM-Solver++) | HV | Tuần 9–10 | Cao | Sai số FID ≤±5% so với paper |
| Tái lập baseline #2: distillation (sCM hoặc DMD) | HV | Tuần 10–12 | Rất cao | Tái lập trong ngưỡng chấp nhận |
| Xây bộ script đánh giá tự động (FID, CLIP, tốc độ, VRAM) | HV | Tuần 11–12 | Cao | Đo lặp lại được, sai số <2% |

---

## GIAI ĐOẠN 3 — Phân tích chuyên sâu chiến lược hiện có
**Mục tiêu:** Đo lường và phân tích điểm mạnh/yếu thực tế của từng chiến lược → lộ ra cơ hội cải tiến.

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Benchmark đồng nhất các baseline (cùng dataset/metric) | HV | Tuần 11–14 | Rất cao | Bảng benchmark ≥4 phương pháp |
| Phân tích trade-off tốc độ ↔ chất lượng ↔ đa dạng | HV | Tuần 13–15 | Cao | Biểu đồ Pareto |
| Phân tích failure case (mờ chi tiết của sCM, mode collapse của DMD) | HV | Tuần 14–16 | Cao | ≥3 failure mode có minh chứng |
| Đo chi phí ẩn (thời gian/bộ nhớ huấn luyện) | HV | Tuần 15–17 | Trung bình | Bảng chi phí train |
| Viết chương Phân tích (draft) + chốt hướng cải tiến | HV + GVHD | Tuần 17–18 | Rất cao | Hướng cải tiến được duyệt |

---

## GIAI ĐOẠN 4 — Đề xuất & cải tiến *(giai đoạn cốt lõi)*
**Mục tiêu:** Thiết kế và hiện thực hóa (các) cải tiến — đóng góp khoa học chính của luận văn.

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Đề xuất phương pháp cải tiến (formalize ý tưởng, cơ sở lý thuyết) | HV + GVHD | Tuần 17–19 | Rất cao | Đề xuất được GVHD duyệt |
| Hiện thực prototype phiên bản 1 | HV | Tuần 19–22 | Rất cao | Prototype chạy được |
| Vòng lặp thử-sai & tinh chỉnh | HV | Tuần 21–23 | Cao | ≥3 vòng iteration có log |
| Kiểm chứng ý tưởng ở quy mô nhỏ (proof-of-concept) | HV | Tuần 22–24 | Rất cao | Vượt baseline trên ≥1 metric |
| Ghi chép nhật ký thí nghiệm đầy đủ | HV | Liên tục | Cao | 100% thí nghiệm có log tái lập |

---

## GIAI ĐOẠN 5 — Thực nghiệm & đánh giá
**Mục tiêu:** Chứng minh cải tiến bằng thực nghiệm nghiêm ngặt, có ablation và (nếu được) đánh giá con người.

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Thí nghiệm chính so với baseline (đồng nhất điều kiện) | HV | Tuần 23–26 | Rất cao | Bảng kết quả đầy đủ |
| Ablation study (tách vai trò từng thành phần) | HV | Tuần 25–27 | Rất cao | ≥3 cấu hình ablation |
| Đánh giá đa dạng + human eval (nếu khả thi) | HV + Đồng nghiệp | Tuần 26–28 | Cao | ≥30 mẫu/đánh giá viên |
| Kiểm định thống kê (seed khác nhau, khoảng tin cậy) | HV | Tuần 27–29 | Cao | Kết quả có CI, ≥3 seed |
| Tổng hợp kết quả thành bảng/biểu đồ luận văn | HV | Tuần 29–30 | Cao | Bộ hình/bảng hoàn chỉnh |

**Chỉ tiêu thành công tổng thể (gợi ý — điều chỉnh theo phạm vi):**

| Tiêu chí | Mục tiêu định lượng |
|---|---|
| Tăng tốc suy luận | ≥ mốc baseline (vd. đạt/vượt few-step 1–4 bước) |
| Chất lượng (FID/CLIP) | Không tệ hơn baseline quá ngưỡng đã định |
| Đa dạng / mode coverage | Cải thiện đo được so với baseline distillation |
| Chi phí huấn luyện | Định lượng rõ, chấp nhận được |

---

## GIAI ĐOẠN 6 — Viết luận văn & bảo vệ
**Mục tiêu:** Hoàn thiện luận văn đạt chuẩn và bảo vệ thành công.

| Công việc | Người phụ trách | Timeline | Ưu tiên | KPI đánh giá |
|---|---|---|---|---|
| Hoàn thiện toàn bộ các chương | HV | Tuần 29–32 | Rất cao | Bản đầy đủ 100% |
| GVHD review & chỉnh sửa (≥2 vòng) | HV + GVHD | Tuần 31–33 | Cao | ≥2 vòng feedback đã xử lý |
| Rà format, tài liệu tham khảo, đạo văn | HV | Tuần 33 | Cao | Tỉ lệ trùng lặp dưới ngưỡng trường |
| Chuẩn bị slide & tập bảo vệ thử | HV | Tuần 33–34 | Cao | ≥2 lần rehearsal |
| Bảo vệ chính thức | HV | Tuần 34 | Rất cao | Hội đồng thông qua |
| *(Tùy chọn)* Viết bài báo hội nghị/workshop | HV + GVHD | Sau bảo vệ | Trung bình | ≥1 bản nộp |

---

## Rủi ro & phương án dự phòng

| Rủi ro | Mức độ | Phương án dự phòng |
|---|---|---|
| Thiếu GPU / hạ tầng chậm | Cao | Chọn mô hình cỡ vừa, dùng LoRA, thuê cloud |
| Không tái lập được baseline | Cao | Ưu tiên baseline có code chính thức; dự phòng baseline thứ 2 |
| Cải tiến không vượt SOTA | Trung bình | Định vị đóng góp ở phân tích/đánh giá, không chỉ ở SOTA số |
| Trượt tiến độ ở GĐ 4–5 | Cao | Buffer 2 tuần đã gối đầu; cắt giảm phạm vi ablation |
