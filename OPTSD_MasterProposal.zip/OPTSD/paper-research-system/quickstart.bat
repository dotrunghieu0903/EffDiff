@echo off
REM Quick Start Script for Paper Research System (Windows)

setlocal enabledelayedexpansion
cls

echo.
echo 🚀 Paper Research System - Quick Start
echo ======================================
echo.

REM Check Python
echo Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python not found. Please install Python 3.10+
    echo Download from: https://www.python.org/downloads/
    pause
    exit /b 1
)
python --version
echo ✅ Python found
echo.

REM Check FFmpeg
echo Checking FFmpeg installation...
ffmpeg -version >nul 2>&1
if errorlevel 1 (
    echo ⚠️  FFmpeg not found. Install with: choco install ffmpeg
    echo Or download from: https://ffmpeg.org/download.html
) else (
    echo ✅ FFmpeg found
)
echo.

REM Setup Backend
echo Setting up Backend...
cd paper-research-backend

REM Create virtual environment
echo Creating virtual environment...
python -m venv venv

REM Activate virtual environment
call venv\Scripts\activate.bat

REM Install dependencies
echo Installing Python dependencies...
pip install -r requirements.txt

REM Create .env file if not exists
if not exist ".env" (
    echo Creating .env file...
    copy .env.example .env
    echo ⚠️  Please edit .env with your API keys!
)

REM Create config file if not exists
if not exist "config\config.json" (
    echo Creating config.json...
    copy config\config.example.json config\config.json
)

echo ✅ Backend setup complete!
echo.

REM Create outputs directory
if not exist outputs mkdir outputs
if not exist logs mkdir logs

echo.
echo ✅ All setup complete!
echo.
echo Next steps:
echo 1. Edit .env with your API keys (OPENAI_API_KEY, ELEVEN_LABS_API_KEY, etc.)
echo 2. Edit config\config.json if needed
echo 3. Run: python main.py
echo 4. In another terminal: cd ..\paper-research-app ^&^& python -m http.server 3000
echo 5. Open http://localhost:3000
echo.
echo For detailed setup, see SETUP.md
echo.
pause
