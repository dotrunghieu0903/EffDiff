# 📖 Setup Guide - Paper Research System

Complete step-by-step guide to set up and run the Paper Research System on your machine.

## 🔍 Prerequisites Check

Before starting, ensure you have:

- [ ] **Python 3.10 or higher** - Check: `python --version`
- [ ] **pip package manager** - Check: `pip --version`
- [ ] **FFmpeg** (for video generation) - Check: `ffmpeg -version`
- [ ] **Git** (optional) - Check: `git --version`
- [ ] Text editor or IDE (VS Code recommended)

### Installing Missing Prerequisites

#### Python

**Windows:**
- Download from https://www.python.org/downloads/
- During installation: ✅ Check "Add Python to PATH"

**macOS:**
```bash
brew install python3
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install python3 python3-pip
```

#### FFmpeg

**Windows:**
```powershell
# Using Chocolatey (https://chocolatey.org/)
choco install ffmpeg

# Or manual: Download from https://ffmpeg.org/download.html
```

**macOS:**
```bash
brew install ffmpeg
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install ffmpeg
```

---

## 🚀 Step-by-Step Setup

### Step 1: Navigate to Project Directory

```bash
cd d:\Documents\OPTSD\paper-research-system
```

### Step 2: Set Up Backend (Python)

#### 2.1 Create Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

You should see `(venv)` in your terminal prompt.

#### 2.2 Install Python Dependencies

```bash
cd paper-research-backend
pip install -r requirements.txt
```

This installs:
- Flask & CORS support
- Web scraping tools (BeautifulSoup, Selenium)
- LLM integrations (OpenAI, Anthropic)
- Google APIs
- PowerPoint generation (python-pptx)
- Video processing (moviepy, ffmpeg-python)

**Installation may take 2-5 minutes.**

#### 2.3 Create Environment Configuration

```bash
# Copy example to actual file
cp .env.example .env

# (On Windows: copy .env.example .env)
```

#### 2.4 Add Your API Keys

Open `.env` file in your editor and fill in your API keys:

```
# Get from https://platform.openai.com/api-keys
OPENAI_API_KEY=sk-YOUR_KEY_HERE

# Get from https://elevenlabs.io/api
ELEVEN_LABS_API_KEY=YOUR_KEY_HERE

# Get from https://console.cloud.google.com/
GOOGLE_CLOUD_API_KEY=YOUR_KEY_HERE
```

> **Don't have API keys yet?** See section "Getting API Keys" below.

#### 2.5 Create Configuration File

```bash
cd config
cp config.example.json config.json

# Edit config.json with your settings
```

#### 2.6 Test Backend Setup

```bash
# Still in paper-research-backend directory
python main.py
```

You should see:
```
 * Running on http://0.0.0.0:5000
 * WARNING: This is a development server...
```

Open browser to `http://localhost:5000/api/health` - you should see JSON response:
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:45.123456",
  "version": "1.0.0"
}
```

✅ **Backend is running!**

Keep this terminal open or stop with `Ctrl+C` and continue.

---

### Step 3: Set Up Frontend (Web App)

#### 3.1 Navigate to App Directory

```bash
cd ../paper-research-app
```

#### 3.2 Start Web Server

**Option A: Using Python (simplest)**
```bash
python -m http.server 3000
```

**Option B: Using Node.js (if you have it)**
```bash
npx http-server -p 3000
```

You should see:
```
Serving HTTP on 0.0.0.0 port 3000 ...
```

#### 3.3 Access Web App

Open browser to: **http://localhost:3000**

You should see the Paper Research Generator interface!

---

## 🔑 Getting API Keys

### OpenAI API Key

1. Go to https://platform.openai.com/api-keys
2. Sign in with OpenAI account (create if needed)
3. Click "Create new secret key"
4. Copy the key
5. Paste into `.env` file: `OPENAI_API_KEY=sk-...`

**Cost:** ~$0.01-0.10 per paper analysis

### Eleven Labs API Key

1. Go to https://elevenlabs.io
2. Sign up for free account
3. Go to API section
4. Copy your API key
5. Paste into `.env` file: `ELEVEN_LABS_API_KEY=...`

**Free tier:** 10,000 characters/month

### Google Cloud TTS (Alternative to Eleven Labs)

1. Go to https://console.cloud.google.com/
2. Create new project
3. Enable Text-to-Speech API
4. Create service account
5. Download JSON key file
6. Place in `config/google_service_account.json`

**Free tier:** 1 million characters/month

### Google Slides API

For automatic Google Slides generation:

1. Go to https://console.cloud.google.com/
2. Create new project
3. Enable Google Slides API
4. Create service account
5. Download JSON credentials
6. Save to `config/google_service_account.json`
7. Update `.env`: `GOOGLE_SLIDES_CREDENTIALS=/path/to/file.json`

---

## 🧪 Testing the System

### Test 1: Backend Health Check

```bash
curl http://localhost:5000/api/health
```

### Test 2: Web App Loads

Open http://localhost:3000 in browser

### Test 3: Test Mode (Mock Data)

1. Open web app
2. Click "⚡ Test Mode (Mock Data)"
3. You should see 5 sample papers loaded
4. Try clicking on a paper to view details

### Test 4: Generate Sample Content

1. From test mode, click "🚀 Generate" on a paper
2. Watch progress bar
3. Check for output links

---

## 🎯 First Real Run

### Step 1: Set Up API Keys (If You Haven't)

Ensure `.env` has at least one LLM key:
- OPENAI_API_KEY, OR
- CLAUDE_API_KEY

### Step 2: Make Sure Both Servers Running

**Terminal 1 (Backend):**
```bash
cd paper-research-system/paper-research-backend
python main.py
```

**Terminal 2 (Frontend):**
```bash
cd paper-research-system/paper-research-app
python -m http.server 3000
```

### Step 3: Search for Papers

1. Open http://localhost:3000
2. Select search criteria:
   - Citation Growth: "Weekly"
   - Number of Papers: "5"
   - Data Source: "Web Scraping"
3. Click "🚀 Find Top Papers"
4. Wait 15-30 seconds
5. Papers should appear!

### Step 4: Generate Content for a Paper

1. Click "🚀 Generate" on first paper
2. Watch progress:
   - Analyzing paper (30-45 sec)
   - Generating slides (20-30 sec)
   - Creating video (2-3 min)
3. Check outputs folder for results

---

## 📁 Output Structure

After running, you'll have:

```
paper-research-system/
└── paper-research-backend/
    └── outputs/
        └── paper_id/
            ├── analysis.json         # Detailed analysis
            ├── paper_id_slides.pptx  # PowerPoint presentation
            ├── paper_id_video.mp4    # Video with narration
            ├── paper_id_audio.mp3    # Audio file
            └── summary.json          # Summary data
```

---

## 🐛 Troubleshooting

### Issue: "FFmpeg not found"

**Solution:**
1. Install FFmpeg (see Prerequisites)
2. Or set path in `.env`:
```
FFMPEG_PATH=C:\path\to\ffmpeg.exe
```

### Issue: "API Key Invalid"

**Solution:**
1. Double-check the key in `.env`
2. Make sure there are no extra spaces or quotes
3. Verify key hasn't expired on provider's dashboard
4. Try generating a new key

### Issue: "Port Already in Use"

**Solution:**
Use different port:
```bash
# Backend on different port
PORT=5001 python main.py

# Frontend on different port
python -m http.server 4000
```

Then update `config.js` to point to new backend URL.

### Issue: "CORS Error" in Browser

**Solution:**
1. Make sure backend is running
2. Check `CORS_ORIGINS` in `.env`
3. Update to include your frontend URL

### Issue: "Timeout Errors"

**Solution:**
1. Increase timeout in `config.json`
2. Check internet connection
3. Some APIs are slow - be patient on first run

### Issue: "Out of Memory" with Video

**Solution:**
1. Reduce video duration (2 minutes instead of 5)
2. Process fewer papers at once
3. Close other applications
4. Restart Python process

---

## 📊 Performance Tips

### Speed Up Paper Analysis

- Use OpenAI GPT-4 (faster than Claude)
- Reduce LLM max_tokens in config
- Cache results to avoid re-analysis

### Speed Up Video Generation

- Use faster codec in FFmpeg config
- Reduce resolution
- Shorter videos (2 min vs 5 min)

### Speed Up Scraping

- Use API instead of scraping (if available)
- Cache paper list locally
- Use manual input file

---

## 🔄 Running in Production

### Important Changes for Production

1. **Security:**
   - Change `DEBUG=False` in `.env`
   - Use strong SECRET_KEY
   - Add authentication
   - Use HTTPS

2. **Deployment:**
   - Use proper web server (Gunicorn, Nginx)
   - Run as service/daemon
   - Set up logging
   - Monitor resource usage

3. **Database:**
   - Add SQLite/PostgreSQL for caching
   - Store paper analysis results
   - Track usage/quotas

---

## 📞 Troubleshooting Commands

```bash
# Check Python version
python --version

# Check if pip is working
pip list

# Check FFmpeg
ffmpeg -version

# Test backend connection
curl http://localhost:5000/api/health

# Check if ports are in use
netstat -ano | findstr :5000      # Windows
lsof -i :5000                      # macOS/Linux

# View Flask logs in real-time
export FLASK_ENV=development       # Linux/macOS
set FLASK_ENV=development          # Windows

# Test requirements installation
pip install -r requirements.txt --verbose
```

---

## ✅ Checklist - Ready to Go!

- [ ] Python 3.10+ installed
- [ ] FFmpeg installed
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] `.env` file created and filled with API keys
- [ ] `config.json` created
- [ ] Backend runs without errors
- [ ] Frontend loads in browser
- [ ] Test mode shows papers
- [ ] At least one API key configured
- [ ] First paper generation succeeded

**🎉 You're all set! Start discovering amazing research papers!**

---

## 📞 Need Help?

1. Check the main README.md for API documentation
2. Review error messages carefully - they often indicate the problem
3. Check `logs/paper_research.log` for detailed logs
4. Verify all API keys are valid on their provider dashboards
5. Make sure internet connection is working

---

## 📚 Next Steps

1. **Customize Configuration**
   - Edit `config.json` to your preferences
   - Adjust timeouts for your internet speed
   - Configure preferred LLM and TTS providers

2. **Integrate with VS Code**
   - Install VS Code
   - Load the Agent/Skill
   - Run searches directly from editor

3. **Add Your Own Papers**
   - Edit `config/manual_papers.json`
   - Add papers to analyze manually
   - Use custom data sources

4. **Batch Processing**
   - Create scripts to process multiple papers
   - Schedule automated runs
   - Generate weekly/monthly reports

---

Happy researching! 🚀📚✨

🚀 Cách Chạy
Option 1: Quick Start (3 câu lệnh)
cd d:\Documents\OPTSD\paper-research-system
quickstart.bat                           # Setup tự động (Windows)
# Edit .env với API keys
python paper-research-backend/main.py   # Chạy backend
# Ở terminal khác: cd paper-research-app && python -m http.server 3000
Then open: http://localhost:3000

Option 2: Manual Setup
1.Create venv & install dependencies
2.Copy .env.example → .env & add API keys
3.Run python main.py
4.Serve web app on port 3000
5.Access web UI

1.Tóm tắt tài liệu trúng đích và đầy đủ:
Prompt: 
"Hãy đọc toàn bộ file tôi vừa tải lên và tóm tắt theo các mục
Mục đích của tài liệu
Nội dung chính từng phần
các kết luận quan trọng
số liệu nổi bật và những việc cần làm.
Cuối cùng, viết thêm một đoạn tóm tắt ngắn dưới 300 từ để tôi nắm được toàn bộ nội dung cốt lõi chỉ trong 2 phút."
Dùng khi: Bạn tải về một xấp tài liệu, đề cương hay báo cáo dài ngoằng mà không có thời gian cày cuốc từng chữ

2. Phản biện tài liệu dưới góc nhìn chuyên gia
Prompt:
"Hãy đánh giá tài liệu này dưới góc độ chuyên gia thay vì chỉ tóm tắt. 
Phân tích rõ: điểm mạnh, điểm hạn chế, những giả định chưa được chứng minh, rủi ro có thể phát sinh và cơ hội đáng chú ý." 
Kết thúc bằng một vài đề xuất cụ thể để tối ưu nội dung này."
Dùng khi: Bạn cần "soi" lỗi logic của một bản dự thảo, tìm khoảng trống nghiên cứu (research gap) hoặc chuẩn bị đánh giá một đề án. 

3. Đóng gói tài liệu thô thành báo cáo chuyên nghiệp
Prompt:
"Biến nội dung file này thành một báo cáo hoàn chỉnh, bao gồm: tóm tắt tổng quan, đánh giá hiện trạng, các phát hiện quan trọng, đề xuất hành động theo thứ tự ưu tiên và kết luận. Trình bày mạch lạc, chuyên nghiệp. Nếu có số liệu, hãy trực quan hóa bằng bảng biểu"
Dùng khi: Bạn có một đống bản nháp, ghi chép thô nhưng cần ráp lại thành một bản báo cáo chỉn chu, có hệ thống để nộp hoặc trình bày.

4. Bóc tách dữ liệu và số liệu siêu tốc
Prompt:
"Đọc tài liệu và tổng hợp tất cả thông tin định lượng quan trọng: biến số, số liệu, tên tác giả/tổ chức, mốc thời gian, chỉ tiêu, chi phí, doanh thu, tỷ lệ phần trăm. Xuất kết quả dưới dạng bảng trình bày rõ ràng để tôi có thể copy ngay sang Excel."
Dùng khi: Bạn cần gom nhanh các chỉ số, mốc thời gian hoặc dữ liệu thô từ một văn bản dài để đưa vào phần mềm phân tích mà không muốn dò tay từng dòng

5. Ma trận so sánh nhiều tài liệu cùng lúc
Prompt:
"Tôi tải lên nhiều file.
Hãy đọc tất cả và lập bảng so sánh theo các tiêu chí: mục tiêu, nội dung chính, điểm tương đồng, điểm khác biệt, ưu điểm và hạn chế. Sau đó, đánh giá xem tài liệu nào đáng tin cậy nhất và gợi ý cách kết hợp chúng thành một bản tóm tắt tối ưu."

6. Chuyển văn bản thành kế hoạch thực chiến:
Prompt:
"Dựa trên nội dung file này, hãy xây dựng một kế hoạch hành động chi tiết. Chia nhỏ thành từng giai đoạn với: mục tiêu cụ thể, danh sách công việc, người phụ trách, timeline hoàn thành, mức độ ưu tiên và các chỉ tiêu (KPI) đánh giá. Trình bày dạng bảng để tôi có thể áp dụng triển khai ngay"
Dùng khi: đọc xong một đề án, một phương pháp luận và cần biến nó thành các bước (step-by-step) việc cần làm cụ thể để bắt tay vào thực hiện ngay

Vietnamese version: PHÂN TÍCH VÀ CẢI TIẾN CÁC CHIẾN LƯỢC 
TỐI ƯU HÓA HIỆU NĂNG CHO MÔ HÌNH DIFFUSION
English version: ANALYZING AND IMPROVING EFFICIENCY OPTIMIZATION
STRATEGIES FOR DIFFUSION MODELS
