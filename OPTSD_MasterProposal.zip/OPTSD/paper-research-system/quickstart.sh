#!/bin/bash
# Quick Start Script for Paper Research System (macOS/Linux)

set -e  # Exit on error

echo "🚀 Paper Research System - Quick Start"
echo "======================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python
echo -e "\n${YELLOW}Checking Python installation...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 not found. Please install Python 3.10+${NC}"
    exit 1
fi
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo -e "${GREEN}✅ Python ${PYTHON_VERSION} found${NC}"

# Check FFmpeg
echo -e "\n${YELLOW}Checking FFmpeg installation...${NC}"
if ! command -v ffmpeg &> /dev/null; then
    echo -e "${YELLOW}⚠️  FFmpeg not found. Install with: brew install ffmpeg${NC}"
else
    echo -e "${GREEN}✅ FFmpeg found${NC}"
fi

# Setup Backend
echo -e "\n${YELLOW}Setting up Backend...${NC}"
cd paper-research-backend

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Create .env file if not exists
if [ ! -f ".env" ]; then
    echo "Creating .env file..."
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env with your API keys!${NC}"
fi

# Create config file if not exists
if [ ! -f "config/config.json" ]; then
    echo "Creating config.json..."
    cp config/config.example.json config/config.json
fi

echo -e "${GREEN}✅ Backend setup complete!${NC}"

# Create outputs directory
mkdir -p outputs logs

echo -e "\n${GREEN}✅ All setup complete!${NC}"
echo -e "\n${YELLOW}Next steps:${NC}"
echo "1. Edit .env with your API keys (OPENAI_API_KEY, ELEVEN_LABS_API_KEY, etc.)"
echo "2. Edit config/config.json if needed"
echo "3. Run: python main.py"
echo "4. In another terminal: cd ../paper-research-app && python -m http.server 3000"
echo "5. Open http://localhost:3000"
echo ""
echo "For detailed setup, see SETUP.md"
