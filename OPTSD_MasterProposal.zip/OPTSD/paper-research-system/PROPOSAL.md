# ĐỀ CƯƠNG NGHIÊN CỨU (PROPOSAL)
## Pruning bất đối xứng học được + Hợp nhất có nhận-biết-sai-số các trục tăng tốc cho Diffusion Transformer
### *Learned Asymmetric Pruning + An Error-Aware Unified Acceleration Stack for Diffusion Transformers*

**Ngày:** 18/07/2026 · **Cập nhật 24/07/2026** (thêm Đóng góp 1; đồng bộ SOTA-2026 với SURVEY.md đã cập nhật). · **Dựa trên:** SURVEY.md (6 nhóm, **77 SOTA** sau rà soát Paper-Notes 24/07) + readpaper/critique các bài trụ cột.

> ⚠️ **Ghi chú xác minh:** Các số "headline" trích dưới đây là số đã đối chiếu abstract của từng bài (chi tiết trong các file `<Paper>.md`). Một số bài dùng làm bằng chứng "gap đã bị lấp" có arXiv 2025-08→2026 **ngoài mốc kiến thức 01/2026** (DisCa, FoCa, SpeCa, HyCa, LoRaQ, QuantCache…) — đã fetch xác nhận tồn tại nhưng **cần tự đọc lại trước khi trích dẫn chính thức**.

> 🎯 **HAI ĐÓNG GÓP SONG SONG (chốt 24/07/2026):**
> - **Đóng góp 1 — Thuật toán:** phương pháp pruning mới, cắt **attention và MLP độc lập** theo **recoverability *học được*** (khả vi), mở rộng TinyFusion từ mức *depth (drop cả block)* xuống mức *trong-block*. Xem • 2★.
> - **Đóng góp 2 — Hệ thống:** **Error-Aware Unified Stack** — ghép 4 trục trực giao + phân tích tương tác sai số + bộ điều phối. Xem • 3 trở đi.
> - **Khớp nối:** Đóng góp 1 **chính là trục chiều-sâu/cấu-trúc (#1)** mà Đóng góp 2 tiêu thụ — không phải hai đề tài rời. Stack là *khung đánh giá & ứng dụng* chứng minh phương pháp pruning mới composable với quantization/forecast/đa-GPU.

---

## 1. Vấn đề & động lực
Mỗi nhóm kỹ thuật tăng tốc diffusion đã chạm **trần riêng**: pruning độ sâu ~2×, lượng tử W4A4 ~3.5×, caching/forecast ~5×, distillation few-step. Luận văn đặt **hai câu hỏi bổ trợ nhau**:

- **(Đóng góp 1)** Trong nhánh pruning, các phương pháp SOTA vẫn cắt theo **tiêu chí cố định hoặc mức thô (drop cả block)**. TinyFusion đã chuyển sang recoverability *học được* nhưng chỉ ở mức **độ sâu**. Câu hỏi: liệu **attention và MLP có "khả năng phục hồi" khác nhau** và nên bị cắt **độc lập** theo tín hiệu recoverability học được, thay vì một tiêu chí/ngưỡng chung? Đây là chỗ đẩy tiếp mô-típ *"cố định → học được/thích ứng, tương thích bước phục hồi"* — mô-típ này nay hiện trên **cả 4 trục đang dùng**: caching (TaylorSeer→HiCache, DisCa, Learning-to-Cache), pruning (TinyFusion, DiffSparse), distillation (DMD2→Phased DMD) và đa-GPU (DistriFusion→Otil) — đều cho thấy là hướng thắng (xem SURVEY.md • "Lập luận cho hướng cải tiến").
- **(Đóng góp 2)** Các trục này có cộng dồn *nhân* được không, hay tương tác/xung đột — và nếu xung đột thì phối hợp thế nào? Đây không phải bài toán ghép nối kỹ thuật, mà là bài toán **tương tác sai số** giữa các phép xấp xỉ.

## 2. Bảy bài trụ cột đã chọn (mỗi nhóm 1 SOTA)

| Nhóm | Bài chọn (đầu-trục) | Venue | Trục tấn công | **Cập nhật 2026** | Vai trò trong stack | **NOTE — concern còn lại** |
|---|---|---|---|---|---|---|
| 1 Distillation | **DMD2** (2405.14867) | NeurIPS 2024 **Oral** | số bước (train) | ❌ **BỔ TRỢ** (+Phased DMD) | Chế độ NFE-cực-thấp *thay thế* (KHÔNG bật caching) | ⚠️ Phased DMD mới test **20B/28B** (Qwen/Wan2.2), *chưa* FLUX/SDXL; cần **re-distill MoE-theo-pha** → khó tái lập trên 3090/4090; là *few-step* không 1-bước. **Chỉ thăng "THAY" nếu tái lập được ở scale nhỏ.** |
| 2 Solvers | **RF-Solver** (2411.04746) | ICML 2025 | số bước (ODE) | ✅ Giữ nguyên | Bổ trợ ở bước full-compute | STORK / AC-Sampler (ICLR 26) chỉ để đối chiếu, chưa cần thay. |
| 3 Pruning | **TinyFusion** (2412.01199) | CVPR 2025 **Highlight** | **chiều sâu** | ✅ Giữ (baseline để vượt) | **Trục trực giao #1** — *baseline để VƯỢT ở Đóng góp 1* | DiffSparse (token-level → **phải phân biệt kỹ**) + 2ndMatch (baseline khâu phục hồi) là related/baseline phụ, **không thay**. |
| 3 Quant | **SVDQuant** (2411.05007) | ICLR 2025 **Spotlight** | **độ chính xác (W4A4)** | ✅ Giữ nguyên | **Trục trực giao #2** | AccuQuant / Sampling-Aware / TWEO chỉ *nuôi phân tích RQ1* (nhiễu × forecast, outlier hai tầng), **không thay**. Cần verify khâu accepted. |
| 4 Caching | **HiCache** (2508.16984) *← TaylorSeer (2503.06923)* | ICLR 2026 | **thời gian (forecast)** | ✅ **THAY** (đầu-trục) | **Trục trực giao #3** | ✅ Rủi ro thấp: **plug-in 0 FLOPs chồng lên TaylorSeer**, test FLUX, có code. ⚠️ Số head-to-head vs TaylorSeer (từ note) **chưa đối chiếu PDF**. 💡 Giả định "đạo hàm ~Gaussian" có thể gãy dưới W4A4 → **chính là RQ1 (điểm lợi)**. Giữ TaylorSeer làm base-engine + ablation. |
| 5 Arch | **SANA** (2410.10629) | ICLR 2025 **Oral** | backbone | ✅ Giữ nguyên | **Nền/substrate** (không phải trục) | Đổi backbone co ROI mọi trục (• 3d) — là quyết định thiết kế, không copy số gốc. |
| 6 System | **Otil** (CVPR 26) *← DistriFusion (2402.19481)* | CVPR 2026 | đa-GPU/thực thi | 🔶 **THAY** (định vị) — *ưu tiên thấp, có điều kiện* | **Trục trực giao #4** (tùy chọn, có ma sát) | ⚠️ **Số gốc chưa verify** (CVF không truy cập, không arXiv); ⚠️ Otil **CHƯA xử lý GPU dị chủng** (3090≠4090 — đúng dàn này) → cần cân-tải kiểu STADI; chỉ test SD1.5/SDXL. **Chỉ bật nếu verify số + giải dị chủng — đừng để thành đường tới hạn.** |

**Phán quyết thay-vs-bổ-trợ (trả lời trực tiếp):** chỉ **2/3 nâng cấp là "THAY"** — Caching (HiCache thay TaylorSeer, ca chắc nhất vì plug-in 0-FLOPs + test FLUX + sắc hóa RQ1) và Đa-GPU (Otil thay DistriFusion cho PCIe, nhưng **chỉ ở mức định vị SOTA-trục, ưu tiên thấp, có điều kiện** verify+dị chủng). **Distillation là "BỔ TRỢ", KHÔNG thay:** Phased DMD nâng cấp khái niệm DMD2 nhưng *few-step* (không 1-bước), mới test 20B/28B (chưa FLUX/SDXL), và cần re-distill tốn kém khó tái lập trên GPU tiêu dùng ⇒ giữ DMD2 làm baseline khả-chuyển, Phased DMD làm SOTA-tham-chiếu cho chế độ diversity/motion + thảo luận k\* (RQ4). Ba trục còn lại (Solver/Pruning/Quant/Arch) **giữ nguyên**.

*Số headline đã xác minh:* TinyFusion 2× @FID 2.86; SVDQuant W4A4 ~3.5× bộ nhớ / ~3× tốc độ, FLUX FID 19.9 vs 20.3; TaylorSeer 4.99× (FLUX) / 5.00× (HunyuanVideo) & HiCache 5.55× (FLUX, chất lượng ≥ gốc); DMD2 FID 1.28 (IN-64, 1 bước) & ~500× rẻ hơn teacher; DistriFusion tới 6.1× trên 8×A100 & Otil SDXL 2-GPU 1.88× vs 1.50× (PCIe, *chưa verify gốc*); SANA <1s ảnh 1024² trên laptop 16GB.

## 2b. CẬP NHẬT SOTA-trục 2026 (từ rà soát Paper-Notes, xem [SURVEY-PaperNotes-2024-2026.md](output/survey/SURVEY-PaperNotes-2024-2026.md))

Rà soát các hội nghị mới nhất (ICLR/CVPR/ICML 2026, NeurIPS/ICCV 2025) cho **3 bản nâng cấp trực tiếp** cho các bài trụ cột — nên cập nhật SOTA-hiện-hành của từng trục:

| Trục | SOTA cũ (giữ làm gốc) | **SOTA 2026 mới → nâng cấp/thay** | Lý do khớp | Nguồn đã đọc |
|---|---|---|---|---|
| Caching/forecast | TaylorSeer (ICCV 25) | **HiCache** (ICLR 26, arXiv 2508.16984) — Taylor→Hermite, plug-and-play 0 FLOPs, ImageReward vượt gốc @5.55× FLUX; *cùng nhóm tác giả TaylorSeer* | Nâng cấp không phá vai trò "1 trục thời gian"; giả định Gaussian của nó biến RQ1 (nhiễu lượng tử × forecast) thành khe hở mở | [HiCache.md](output/readpaper/HiCache.md) · [critique](output/critiquepaper/HiCache-critique.md) |
| Distillation | DMD2 (NeurIPS 24 Oral) | **Phased DMD** (CVPR 26, arXiv 2510.27684) — MoE-theo-pha trên khoảng SNR, khôi phục diversity/motion mà DMD2 mất, *không thêm chi phí inference* | Củng cố "chế độ NFE-cực-thấp riêng, KHÔNG bật caching" (• 3b) — chính nó là model-distilled mà DisCa cảnh báo | [Phased-DMD.md](output/readpaper/Phased-DMD.md) · [critique](output/critiquepaper/Phased-DMD-critique.md) |
| Đa-GPU/hệ thống | DistriFusion (CVPR 24) | **Otil** (CVPR 26) — chỉ truyền ~25% sub-block đổi nhiều nhất, **−75% giao tiếp**, **nhắm PCIe không-NVLink** (SDXL 2-GPU 1.88× vs 1.50×) | **Khớp đúng cảnh 3090+4090 qua PCIe** (• 3e/• 6); DistriFusion lùi về tham chiếu lịch sử | [Otil.md](output/readpaper/Otil.md) · [critique](output/critiquepaper/Otil-critique.md) |

*Ba trục còn lại giữ nguyên:* TinyFusion (nay là **baseline để vượt** ở Đóng góp 1), SVDQuant (W4A4), RF-Solver (solver). **Cảnh báo bão hòa:** trục caching có ≥15 bài 2025-26 → tuyệt đối không đặt caching làm đóng góp thuật toán, chỉ tiêu thụ HiCache/TaylorSeer làm 1 trục.

## 2★. ĐÓNG GÓP 1 — Pruning attention/MLP theo recoverability *học được* (thuật toán)

**Khe hở (đã kiểm prior-art, xem [[thesis-pruning-direction]]):** TinyFusion học một mask **độ sâu** (giữ/bỏ *cả block* DiT) qua tối ưu khả vi (Gumbel-Softmax) với LoRA làm proxy cho khả năng phục hồi sau finetune. Nhưng nó **coi block là đơn vị nguyên khối** — trong khi một block DiT gồm hai khối con có bản chất rất khác: **self-attention** (trộn token, chi phí bậc hai) và **MLP/feed-forward** (biến đổi theo kênh). Chưa có bài nào tách **recoverability riêng cho attention vs MLP** ở mức trong-block cho diffusion.

**Ý tưởng cốt lõi:** thay vì một quyết định giữ/bỏ chung cho cả block theo tiêu chí cố định, **học hai tín hiệu recoverability độc lập** — một cho nhánh attention, một cho nhánh MLP của mỗi block — rồi cắt bất đối xứng (ví dụ giữ attention nhưng bỏ MLP ở block này, và ngược lại ở block khác), tối ưu **cho** bước phục hồi (LoRA/finetune) chứ không cho sai số tức thời.

**Cơ chế đề xuất (kế thừa & mở rộng TinyFusion):**
1. **Mask kép khả vi:** mỗi block có hai biến Gumbel-Softmax $(m^{attn}_\ell, m^{mlp}_\ell)$ thay vì một $m_\ell$ → không gian cấu hình mịn hơn nhiều.
2. **Recoverability-proxy tách nhánh:** ước lượng tổn thất-sau-phục-hồi riêng cho từng nhánh bằng LoRA-proxy nhẹ (đúng tinh thần "tương thích bước phục hồi" của TinyFusion, và "học được > heuristic" mà DisCa xác nhận ở caching).
3. **Ngân sách bất đối xứng theo độ sâu:** cho phép **mật độ prune biến thiên** (attention-heavy ở tầng nông, MLP-heavy ở tầng sâu — hoặc để dữ liệu quyết định) thay vì tỉ lệ N:M cứng.

**Vì sao có cơ sở (đòn bẩy lập luận từ survey):** mô-típ *"tiêu chí cố định → tiêu chí học được/thích ứng, tương thích phục hồi"* liên tục thắng trên **cả 4 trục đang dùng** (caching, pruning, distillation, đa-GPU — xem bảng meta trong SURVEY.md, bản 24/07 đã thêm cột Distillation + Đa-GPU); DisCa (CVPR 2026) là bằng chứng mới nhất rằng thành phần *học được* trụ được cả ở chế độ nén khắc nghiệt nơi heuristic sụp đổ. Đóng góp 1 đưa nguyên lý đó **xuống mức trong-block, tách attention/MLP** — bước mở rộng tự nhiên, chưa bị chiếm.

**Câu hỏi nghiên cứu riêng (bổ sung vào • 4):**
- **RQ0a:** Attention và MLP trong DiT có profile recoverability khác nhau đủ để cắt bất đối xứng có lợi so với cắt block nguyên khối (TinyFusion) không?
- **RQ0b:** Tín hiệu recoverability *học được* (LoRA-proxy tách nhánh) có vượt tiêu chí cố định (magnitude/Taylor/Hessian kiểu Diff-Pruning, OBS-Diff) ở cùng mức FLOPs không?

> **Mở rộng phụ thuộc (tùy chọn, KHÔNG phải đóng góp thứ ba) — hệ quả của RQ0a:** *nếu* attention và MLP thật sự bất đối xứng về recoverability, một hệ quả tự nhiên là **phân bổ bit-width bất đối xứng attn-vs-MLP** (mixed-precision phản chiếu chính mask pruning) — thống nhất Đóng góp 1 với trục lượng tử. Bằng chứng meta hai chiều: **Spark Transformer** (NeurIPS 25) hợp nhất FFN & attn *đối xứng* (phản đề), còn **Homogeneous-Keys-Heterogeneous-Values** (NeurIPS 25) khai thác *bất đối xứng* hai thành phần (tiền lệ). ⇒ Chỉ đưa vào dưới dạng **ablation/hệ quả** nếu RQ0a xác nhận, giữ khung 2 đóng góp không đổi (xem SURVEY • "Rà soát SOTA-2026" — cơ hội mở rộng #1).

**Related work cần phân biệt (rà soát 24/07/2026, xem [SURVEY-PaperNotes-2024-2026.md](output/survey/SURVEY-PaperNotes-2024-2026.md) • A — khe hở xác nhận CÒN TRỐNG 🟢):**
- **DiffSparse** (ICLR 2026) — *họ hàng gần nhất về tinh thần*: cũng dùng mask khả vi + học được + ngân sách (STE + DP), nhưng ở mức **token-caching**, KHÔNG tách attention/MLP structural. Phải phân biệt kỹ nhất: của họ là *bước/token nào tính lại*, của ta là *khối con attn/MLP nào giữ*.
- **2ndMatch** (CVPR 2026, arXiv 2506.05398) — chỉ *finetune phục hồi* model đã prune (khớp J⊤J). Dùng làm **baseline cho khâu phục hồi** (so với LoRA-proxy).
- **Spark Transformer** (NeurIPS 2025, arXiv 2506.06644) — xử lý FFN & attention **ĐỐI XỨNG** (cùng khung KV-lookup), activation-sparsity cho LLM. **Phản đề trực tiếp cho RQ0a:** họ giả định đối xứng; ta kiểm định cắt *bất đối xứng* attn/MLP có lợi hơn.
- Tham chiếu phụ: **PermLLM** (N:M học được ↔ luận điểm mật độ biến thiên • 2★.3), **What Layers When** / **ReplaceMe** (learned layer-skip/depth-prune ngoài diffusion).

---

# ĐÓNG GÓP 2 — Error-Aware Unified Acceleration Stack (hệ thống)

*(Đóng góp 1 ở trên cung cấp **trục chiều-sâu/cấu-trúc #1** cho stack dưới đây; các mục • 3–• 9 là nội dung Đóng góp 2, giữ nguyên từ bản 18/07 và bổ sung khớp nối.)*

## 3. Đóng góp cốt lõi — **Bản đồ trực giao vs xung đột**
Đây là phát hiện trung tâm (tổng hợp từ 7 critique):

**(a) Bốn trục THỰC SỰ trực giao → cộng dồn nhân được:**
- Chiều sâu/cấu trúc (**Đóng góp 1** — pruning attention/MLP học được; TinyFusion là baseline) × Độ chính xác (SVDQuant) × Thời gian/forecast (**HiCache**/TaylorSeer) × Đa-GPU (**Otil**/DistriFusion). *(SOTA-trục cập nhật 2026 — xem • 2b.)*
- Kỳ vọng tăng tốc *nhân* → **mục tiêu >10× end-to-end** ở chất lượng gần gốc.

**(b) Trục "SỐ BƯỚC" bị tranh chấp → KHÔNG được ghép ngây thơ:**
- Ba kỹ thuật cùng đánh trục này: **Solvers (RF-Solver)**, **Distillation (DMD2)**, **Caching (TaylorSeer)**.
- Bằng chứng xung đột: **DisCa** (CVPR 2026, *ngoài mốc kiến thức*) cho thấy áp caching lên model đã step-distilled làm chất lượng **suy giảm nặng hơn** model nhiều bước. RF-Solver và TaylorSeer đều dùng Taylor nhưng trên đối tượng khác (velocity 1 bước vs feature nhiều bước) → cộng dồn sai số nếu không phân vùng.
- ⇒ **Chọn MỘT bộ giảm-bước làm chính**: giữ TaylorSeer (forecast) làm trục thời gian composable; RF-Solver chỉ áp ở các **bước full-compute** mà TaylorSeer đã đánh dấu; DMD2 tách ra thành **chế độ vận hành riêng** (few-step, không bật caching).

**(c) Điểm ma sát cần ĐO, không giả định:**
- SVDQuant × TaylorSeer: nhiễu lượng tử 4-bit có thể **khuếch đại** sai phân Taylor (đạo hàm ước lượng trên feature nhiễu).
- TinyFusion × TaylorSeer: bỏ lớp có thể làm **quỹ đạo feature kém trơn** → phá giả định "forecastable".
- DistriFusion × TaylorSeer: cả hai "vay mượn" feature (không gian-GPU vs thời gian) → cần **lịch anchor-step** chung.
- DistriFusion × SVDQuant: Async GroupNorm xấp xỉ thống kê từ activation cũ; nếu activation đã 4-bit, sai số cộng dồn.
- **Kernel-attention lượng tử × SVDQuant (W4A4-weight):** cả hai đều *quản outlier* nhưng ở hai tầng/cơ chế khác nhau — kernel attention (SageAttention2 trên 4090, hoặc incoherent-processing của FA-3 trên Hopper) quản outlier *activation attention*, SVDQuant dùng *nhánh low-rank* hút outlier *trọng số*. Bật đồng thời (SageAttention2 INT4/FP8 + SVDQuant W4A4) cần **phối hợp lịch quản outlier hai tầng** để không cộng dồn/khử lẫn nhau — chưa ai đo. **TWEO** (CVPR 2026 — *Transformers Without Extreme Outliers*, khử outlier để FP8 dễ) cấp một điểm tựa phương pháp để *đo & tách* outlier hai tầng này (RQ1b). *(Cầu nối tự nhiên giữa trục kernel Nhóm 6 và trục lượng tử Nhóm 3; trên 3090 không có FP8 nên chỉ còn SageAttention v1 INT8.)*

**(d) SANA là "nền": đổi backbone làm co ROI mọi trục** (ít token → pruning bớt lợi; linear-attention mượt → tiền đề outlier của SVDQuant yếu đi; chỉ 14–20 bước → ngân sách caching co lại). ⇒ Chọn substrate là **quyết định thiết kế**, không copy số tăng tốc từ báo cáo gốc.

> **Hệ quả — tránh backbone ĐÃ distilled làm substrate chính (SANA-Sprint, FLUX.2 [klein]):** một model đã tự tăng tốc sẵn *triệt tiêu chính headroom* mà luận văn cần để đo tương tác. **SANA-Sprint** (arXiv 2503.09641 — SANA distilled 1–4 bước bằng continuous-time consistency, 0.31s/ảnh trên 4090, 1-bước FID 7.59) là ví dụ cực đoan: **1–4 bước ⇒ trục caching/forecast ≈0 headroom** (không còn gì để forecast) và **trục distillation dư thừa** (đã là consistency-distilled), cộng linear-attention làm yếu tiền đề pruning/outlier. ⇒ Tiêu chí substrate đúng là **"nhiều dư địa nén"**, KHÔNG phải "nhanh sẵn": **FLUX.1-dev (full-step, softmax MMDiT) là substrate chính**, SANA/SANA-1.5 làm nền ablation. SANA-Sprint (và FLUX.2 [klein], cũng distilled) **không làm substrate — mà làm baseline cận-trên** (xem §6).

**(e) Nhóm 6 — CHỐT phạm vi phần cứng: 1-GPU tiêu dùng (RTX 3090 Ampere + 4090 Ada).** Hệ quả:
- **FlashAttention-3 bị LOẠI** — async/FP8 của nó gắn Hopper (H100), không áp được lên 3090/4090.
- **Kernel đại diện Nhóm 6 = SageAttention (dòng thu):**
  - **4090 (Ada, GPU chính):** **SageAttention2** (INT4-QK + FP8-PV), ~3× so FlashAttention-2, có FP8.
  - **3090 (Ampere, phụ):** **SageAttention v1** (INT8), ~2.1× so FA-2 — Ampere **không có FP8** nên đây là fallback.
- **Đa-GPU = Otil (CVPR 2026) thay DistriFusion** cho đúng cảnh này → **tùy chọn, ưu tiên thấp**: card tiêu dùng không NVLink (giao tiếp qua PCIe) và 3090≠4090 (dị chủng). Otil giảm 75% giao tiếp **đúng trên PCIe** (nơi DistriFusion yếu) nên là lựa chọn hợp lý hơn; **nhưng Otil chưa xử lý GPU dị chủng** → nếu ghép 2 card, cần bổ sung cân-tải kiểu STADI (arXiv 2509.04719). Chỉ bật nếu thực sự ghép 2 card.
- Kernel attention vẫn là **substrate thực thi nền** (nằm dưới cả stack), là cầu nối sang trục lượng tử (Mục 3c) — nhưng là **SageAttention2**, không phải FA-3.

## 4. Giả thuyết & câu hỏi nghiên cứu
- **H1:** Bốn trục (b) trực giao về FLOPs nhưng **tương tác về sai số**; tồn tại một bộ điều phối *error-aware* đạt >10× ở chất lượng gần gốc mà ghép tuần tự ngây thơ không đạt.
- **RQ1:** Nhiễu lượng tử W4A4 làm hỏng tính "forecastable" của forecast-caching tới mức nào, và **cơ sở dự báo có nên thích ứng theo mức nhiễu**? *(Cụ thể hóa với SOTA-2026, xem SURVEY • "Rà soát SOTA-2026":* HiCache giả định **đạo hàm feature ~Gaussian** để chọn cơ sở Hermite — nhiễu W4A4 có thể phá giả định này ⇒ hỏi *bậc/cơ sở thích ứng*. **AccuQuant** (NeurIPS 25, mô phỏng nhiều bước khi calibrate) và **Sampling-Aware Quantization** (CVPR 26) là bằng chứng rằng *sai số lượng tử tích lũy qua nhiều bước* — vật liệu trực tiếp cho phân tích "nhiễu × nhiều bước × forecast".)*
  - **RQ1b (outlier hai tầng):** khi bật đồng thời kernel-attn lượng tử (SageAttention2) + SVDQuant (W4A4-weight), hai cơ chế quản outlier ở hai tầng có cộng dồn/khử nhau? **TWEO** (CVPR 26, khử extreme-outlier cho FP8) là điểm tựa phương pháp để tách/phân tích outlier hai tầng — xem • 3c.
- **RQ2:** Pruning recoverability-aware có thể được *điều kiện hóa theo lịch cache* để giữ độ trơn quỹ đạo feature không?
- **RQ3:** Thứ tự áp dụng tối ưu (prune→quant→forecast vs joint) và lịch anchor-step phối hợp với DistriFusion là gì?
- **RQ4:** Ranh giới NFE k* nơi distillation (DMD2) vượt trội chế độ nhiều-bước-có-caching nằm ở đâu?

## 5. Phương pháp đề xuất
1. **Pipeline hợp nhất** trên T2I DiT (FLUX/SDXL, và biến thể trên nền SANA): **Pruning bất đối xứng học được (Đóng góp 1, thay TinyFusion nguyên trạng)** → SVDQuant (W4A4) → **HiCache/TaylorSeer** (forecast) → **Otil/DistriFusion** (đa-GPU tùy chọn), điều phối bởi một **Error-Aware Orchestrator**.
2. **Orchestrator** gồm: (i) bậc Taylor thích ứng theo mức nhiễu lượng tử per-layer; (ii) pruning nhận-biết-lịch-cache (recoverability có điều kiện); (iii) lịch anchor-step chung cho forecast + displaced-reuse.
3. **Phân tích tương tác sai số** (đóng góp khoa học chính): đo riêng từng cặp trục, lập ma trận tương tác, xác định điểm cộng dồn phi tuyến — điều **QuantCache (2503.06545) chưa làm** (nó ghép 3 kỹ thuật cho *video* nhưng không phân tích tương tác, không dùng đúng bộ SOTA này).

## 6. Kế hoạch đánh giá
- **Phần cứng (CHỐT):** **RTX 4090 (Ada)** = GPU chính (FP8+INT4 → SageAttention2 + SVDQuant INT4); **RTX 3090 (Ampere)** = kiểm tra tính khả chuyển (INT8 → SageAttention v1). Báo cáo latency/bộ nhớ **đo lại trên 3090/4090** (và 5090 nếu dùng), KHÔNG copy số gốc (vốn đo trên GPU datacenter).
  - **Tiêu chí chọn GPU (đây là luận văn *optimize-resource* → chỉ dùng GPU tiêu dùng/1-card):** (1) NVIDIA/CUDA bắt buộc (SageAttention, Nunchaku/SVDQuant là kernel CUDA); (2) **FP8 tensor cần Ada trở lên** = lằn ranh chạy SageAttention2 (FP8) hay tụt về v1 (INT8); (3) VRAM ≥ 16GB (24GB thoải mái) cho FLUX.1-dev đã lượng tử. **Loại các GPU datacenter cao cấp (A100/H100/H200)** — đi ngược tinh thần optimize-resource; H100 chỉ nhắc như *mốc hardware bật FA-3* mà §3e đã loại, KHÔNG dùng.

  | Tầng | GPU | Arch / VRAM | Vai trò | **NOTE — concern** |
  |---|---|---|---|---|
  | **Chính (CHỐT)** | **RTX 4090** | Ada / 24GB | GPU chính: FP8+INT4 → SageAttention2 + SVDQuant INT4 | ✅ Điểm ngọt giá/khả dụng bậc master. ⚠️ Bật đồng thời 4 trục trên 24GB cần theo dõi VRAM (FLUX-dev ~12B) |
  | **Fallback (CHỐT)** | **RTX 3090** | Ampere / 24GB | Node kiểm khả-chuyển: INT8 → SageAttention **v1** | ⚠️ **Không có FP8** → chỉ v1 INT8. ⚠️ Cần **verify SVDQuant INT4 chạy trên Ampere** (Nunchaku nhắm Ada). Không phải môi trường đo chính |
  | **Nâng cấp tùy chọn** | **RTX 5090** | Blackwell / 32GB | Thay 4090 + mở **NVFP4** làm trục lượng tử *bonus* | ⚠️ Bật NVFP4 = **đổi phạm vi** (phải bỏ dòng "NVFP4 loại" + thêm biến thể trục). ⚠️ Blackwell mới → **verify kernel SageAttention/Nunchaku hỗ trợ SM Blackwell** trước khi cam kết |
  | **Khả-chuyển VRAM thấp** | **RTX 4080 / 4070 Ti Super** | Ada / 16GB | Cùng công thức Ada (FP8+INT4), kiểm giới hạn VRAM | ⚠️ 16GB → FLUX-dev đã lượng tử **vừa khít**, có thể phải offload / giảm batch. Không đổi phạm vi |

  - **KHÔNG thích hợp (tránh):** Turing (2080Ti)/Pascal (1080Ti) — không FP8/không BF16-tensor; VRAM < 16GB (4060 8GB, 3060 12GB — 3060 còn là Ampere); AMD/Intel/Apple — không có kernel CUDA của SageAttention/Nunchaku (phải port, ngoài phạm vi). **NVFP4 & FA-3 vẫn loại ở khung Ada/Ampere** (cần Blackwell/Hopper) — chỉ mở lại nếu chọn 5090.
- **Model (substrate):** **FLUX.1-dev** (full-step, softmax MMDiT) = **substrate chính** vì còn headroom cả 4 trục; SDXL đối chiếu; **SANA/SANA-1.5** làm nền ablation. ⚠️ **Backbone đã distilled KHÔNG dùng làm substrate** (co headroom — xem §3d): FLUX.2 [klein] (4B distilled, ~13GB) và SANA-Sprint chỉ là **model đích phụ / baseline cận-trên**, không phải nền đo tương tác.
- **Chỉ số:** FID, ImageReward, CLIP, LPIPS/PSNR; latency & bộ nhớ **thực đo** (tách rõ compression vs wall-clock).
- **Baseline:** *(Đóng góp 1)* **TinyFusion** (depth pruning học được) + Diff-Pruning/OBS-Diff (tiêu chí cố định) ở cùng mức FLOPs — chứng minh cắt bất đối xứng attention/MLP vượt trội; thêm **DiffSparse** (learned token-sparsity, để phân biệt phạm vi) và **2ndMatch** (baseline khâu phục hồi). *(Đóng góp 2)* từng trục đơn lẻ (nay dùng **HiCache** cho caching, **Otil** cho đa-GPU); ghép tuần tự không điều phối; **QuantCache** (port từ video sang ảnh) làm SOTA-kết-hợp gần nhất. **Baseline cận-trên (upper-bound competitor) trên 4090: SANA-Sprint** (arXiv 2503.09641 — SANA distilled 1–4 bước, 0.31s/ảnh & 1-bước FID 7.59 trên 4090) — mốc "đối thủ đã tối ưu tận cùng theo hướng distill-everything"; câu hỏi định vị: *stack error-aware trên FLUX-dev có match/vượt được tốc độ-chất lượng của một model distilled-sẵn như SANA-Sprint không?*
- **Mục tiêu:** >10× end-to-end **trên 4090** ở suy giảm chất lượng tối thiểu; công bố **bản đồ "trục nào ghép được"** có kèm số liệu tương tác.
- **Tính khả thi phần cứng (dàn có sẵn: 3090 + 4090, 2×24GB — ĐÃ CHỐT là ĐỦ):** đây đúng là cấu hình proposal nhắm tới; 2×24GB *rộng hơn* mức tối thiểu cho luận văn optimize-resource. Ba lưu ý bắt buộc quản lý:
  1. **Verify SVDQuant-INT4 trên Ampere (3090) ngay tuần đầu** — Nunchaku nhắm Ada; nếu INT4 không chạy trên Ampere thì 3090 chỉ còn vai trò đo INT8/khả-chuyển (SageAttention v1). Đây là rủi ro cần *đóng sớm*, không để tới cuối.
  2. **Thứ tự substrate: SDXL (2.6B) trước → FLUX-dev (12B) sau.** Train pruner (Đóng góp 1) trên SDXL rất thoải mái trong 24GB; FLUX-dev chỉ chạy ở chế độ **LoRA-proxy/mask** (không full-finetune — full-finetune 12B không vừa 24GB). Đo tương tác (Đóng góp 2) là *suy luận* nên vừa 24GB cả trên FLUX-dev.
  3. **2 GPU là DỊ CHỦNG (3090≠4090) + PCIe:** đúng kịch bản Otil nhưng Otil *chưa xử lý dị chủng*. ⇒ Trục đa-GPU giữ **tùy chọn/ưu tiên thấp**; trong lúc chờ, dùng **2 card độc lập chạy song song nhiều cấu hình** (tăng throughput thí nghiệm) thay vì ép thành 1 pipeline Otil dị chủng.
  - *Đường tới hạn = train pruner + đo ma trận tương tác — cả hai nằm trong 24GB → không phải nút thắt phần cứng.* Việc bất-khả-thi (re-distill kiểu Phased DMD, NVFP4/FA-3) đều đã được thiết kế tránh từ trước.

## 7. Rủi ro & điểm mở
- Nhiễu lượng tử có thể phá forecast tới mức không cứu được → dự phòng: chỉ forecast trên nhánh low-rank 16-bit của SVDQuant.
- Phần lớn bằng chứng "gap đã lấp" nằm ngoài mốc kiến thức → cần snowballing xác minh (Semantic Scholar/Connected Papers).
- Chi phí kỹ thuật ghép 4 hệ (mỗi hệ engine riêng: Nunchaku, DistriFusion, TaylorSeer).
- **[ĐÃ CHỐT] Phạm vi phần cứng = 1-GPU tiêu dùng (3090/4090).** ⇒ Nhóm 6: kernel = SageAttention2 (4090) / SageAttention v1 (3090); FA-3 loại (Hopper); DistriFusion tùy chọn ưu tiên thấp. Baseline tốc độ đo lại trên 3090/4090 (Mục 6).

## 8. Đính chính cần đưa vào SURVEY.md
- **RF-Solver (2411.04746):** venue thực tế **ICML 2025**, SURVEY đang ghi "arXiv" → cập nhật.
- **SANA (2410.10629):** claim "LLM decoder-only làm text encoder" **không phải đầu tiên** — Lumina-Next (2406.18583) trước ~4 tháng; ghi công cẩn thận.
- Bổ sung tham chiếu **DisCa** (xung đột distillation×caching) và **QuantCache** (baseline kết hợp) vào phần Related Work — sau khi tự xác minh.
- **[24/07/2026] Cập nhật SOTA-trục 2026 (• 2b):** thêm **HiCache** (ICLR 26, arXiv 2508.16984) nâng cấp caching; **Phased DMD** (CVPR 26, arXiv 2510.27684) nâng cấp distillation; **Otil** (CVPR 26) thay DistriFusion cho đa-GPU PCIe. Đã có readpaper + critique riêng (thư mục output/). *Số của Otil chưa xác minh gốc (CVF không truy cập được) — cần verify trước khi trích.*
- **[24/07/2026] Related Work Đóng góp 1 (• 2★):** thêm **DiffSparse / 2ndMatch / Spark Transformer** để phân biệt & làm baseline; khe hở pruning attn/MLP học được đã tái xác nhận CÒN TRỐNG (🟢).
- **[24/07/2026] SURVEY.md đã cập nhật xong** (không còn là "cần đưa vào" mà đã thực hiện): (i) thêm • "⭐ Cập nhật SOTA 2026" ánh xạ pillar-cũ→SOTA-mới (HiCache←TaylorSeer, Phased DMD←DMD2, Otil←DistriFusion); (ii) thêm Phased DMD (Nhóm 1), DiffSparse/2ndMatch/AccuQuant/Sampling-Aware Quant/TWEO + 3 tham chiếu LLM (Nhóm 3), Otil (Nhóm 6B); (iii) thêm • "Rà soát SOTA-2026: có khe hở mới ngoài pruning attn/MLP không?" — **phán quyết: không có khe hở thuật toán độc lập mới; giữ khung 2 đóng góp**; RQ1 được làm giàu (AccuQuant/Sampling-Aware/TWEO — • 4); một cơ hội mở rộng phụ thuộc (bit-width bất đối xứng) ghi ở • 2★.

## 9. Phân pha (tóm tắt)
1. **P0a (mở khóa rủi ro phần cứng — tuần đầu):** verify **SVDQuant-INT4 chạy trên 3090/Ampere**; chốt vai trò thực của 3090 (INT4 hay chỉ INT8/khả-chuyển).
2. **P0b (Đóng góp 1):** Xây & huấn luyện pruning bất đối xứng attention/MLP học được — **prototype trên SDXL (2.6B) trước, rồi port sang FLUX-dev (LoRA-proxy/mask)**; so TinyFusion + tiêu chí cố định (RQ0a/RQ0b).
3. **P1:** Đo baseline từng trục + tái lập các bài trụ cột (SDXL → FLUX-dev).
3. **P2:** Đo tương tác từng cặp trục (ma trận sai số) — trọng tâm RQ1–RQ3.
4. **P3:** Xây Error-Aware Orchestrator + lịch anchor-step.
5. **P4:** Pipeline hợp nhất 4 trục (dùng pruner của P0 làm trục #1), so QuantCache; xác định ranh giới k* (RQ4).
6. **P5:** Ablation trên nền SANA + viết bài.

---
*Nguồn chi tiết mỗi bài: TinyFusion.md, SVDQuant.md, TaylorSeer.md, DMD2.md, RF-Solver.md, SANA.md, DistriFusion.md và các file `-critique.md` tương ứng (mỗi file có Mục "Kết hợp & mầm proposal").*
