"""
Paper Research System - Main Backend Application
Flask API server with endpoints for paper discovery, analysis, slide generation, and video creation
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import logging
from datetime import datetime
import json

# Import services
from services.paper_scraper import PaperScraper
from services.paper_analyzer import PaperAnalyzer
from services.slides_generator import SlidesGenerator
from services.video_generator import VideoGenerator
from services.tts_service import TTSService

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Initialize services
paper_scraper = PaperScraper()
paper_analyzer = PaperAnalyzer()
slides_generator = SlidesGenerator()
video_generator = VideoGenerator()
tts_service = TTSService()

# ============================================
# HEALTH CHECK
# ============================================
@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

# ============================================
# PAPER SEARCH ENDPOINTS
# ============================================
@app.route('/api/papers/search', methods=['POST'])
def search_papers():
    """
    Search for papers with specific citation growth criteria
    
    Request body:
    {
        "citation_growth": "daily|weekly|monthly|quarterly|yearly",
        "count": 1-10,
        "topic_filter": "optional topic",
        "data_source": "scraping|api|manual"
    }
    """
    try:
        data = request.get_json()
        
        citation_growth = data.get('citation_growth', 'weekly')
        count = int(data.get('count', 5))
        topic_filter = data.get('topic_filter', '')
        data_source = data.get('data_source', 'scraping')
        
        logger.info(f"Searching papers: growth={citation_growth}, count={count}, source={data_source}")
        
        # Fetch papers based on source
        if data_source == 'scraping':
            papers = paper_scraper.scrape_top_papers(
                citation_growth=citation_growth,
                count=count,
                topic_filter=topic_filter
            )
        elif data_source == 'api':
            papers = paper_scraper.fetch_via_api(
                citation_growth=citation_growth,
                count=count,
                topic_filter=topic_filter
            )
        else:
            papers = paper_scraper.get_from_manual_input(count=count)
        
        return jsonify({
            'success': True,
            'data': papers,
            'count': len(papers),
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        logger.error(f"Search failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============================================
# PAPER ANALYSIS ENDPOINTS
# ============================================
@app.route('/api/papers/<paper_id>/analyze', methods=['POST'])
def analyze_paper(paper_id):
    """
    Analyze a paper and extract key insights
    
    Request body:
    {
        "llm_provider": "openai|claude|local",
        "abstract": "paper abstract",
        "title": "paper title"
    }
    """
    try:
        data = request.get_json()
        
        llm_provider = data.get('llm_provider', 'openai')
        abstract = data.get('abstract', '')
        title = data.get('title', '')
        
        logger.info(f"Analyzing paper {paper_id} with {llm_provider}")
        
        # Analyze paper
        analysis = paper_analyzer.analyze(
            paper_id=paper_id,
            title=title,
            abstract=abstract,
            llm_provider=llm_provider
        )
        
        return jsonify({
            'success': True,
            'data': analysis
        })
    
    except Exception as e:
        logger.error(f"Analysis failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============================================
# SLIDES GENERATION ENDPOINTS
# ============================================
@app.route('/api/papers/<paper_id>/generate-slides', methods=['POST'])
def generate_slides(paper_id):
    """
    Generate Google Slides or PowerPoint presentation
    
    Request body:
    {
        "analysis": {...},
        "title": "paper title",
        "format": "google-slides|pptx|pdf"
    }
    """
    try:
        data = request.get_json()
        
        analysis = data.get('analysis', {})
        title = data.get('title', '')
        format_type = data.get('format', 'google-slides')
        
        logger.info(f"Generating slides for {paper_id} in {format_type} format")
        
        # Generate slides
        slides_output = slides_generator.generate(
            paper_id=paper_id,
            title=title,
            analysis=analysis,
            format_type=format_type
        )
        
        return jsonify({
            'success': True,
            'data': slides_output
        })
    
    except Exception as e:
        logger.error(f"Slides generation failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============================================
# VIDEO GENERATION ENDPOINTS
# ============================================
@app.route('/api/papers/<paper_id>/generate-video', methods=['POST'])
def generate_video(paper_id):
    """
    Generate video with AI narration
    
    Request body:
    {
        "script": "narration script",
        "voice": "male-english|female-english|...",
        "duration": 2|3|5
    }
    """
    try:
        data = request.get_json()
        
        script = data.get('script', '')
        voice = data.get('voice', 'male-english')
        duration = int(data.get('duration', 3))
        
        logger.info(f"Generating video for {paper_id}")
        
        # Generate TTS audio
        logger.info("Generating audio from script...")
        audio_file = tts_service.generate_speech(
            text=script,
            voice=voice,
            paper_id=paper_id
        )
        
        # Generate video
        logger.info("Creating video with slides and audio...")
        video_output = video_generator.generate(
            paper_id=paper_id,
            audio_file=audio_file,
            duration=duration
        )
        
        return jsonify({
            'success': True,
            'data': video_output
        })
    
    except Exception as e:
        logger.error(f"Video generation failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============================================
# BATCH PROCESSING ENDPOINTS
# ============================================
@app.route('/api/papers/batch-process', methods=['POST'])
def batch_process():
    """
    Process multiple papers in batch
    
    Request body:
    {
        "paper_ids": ["id1", "id2", ...],
        "generate_slides": true,
        "generate_video": true,
        "llm_provider": "openai"
    }
    """
    try:
        data = request.get_json()
        
        paper_ids = data.get('paper_ids', [])
        generate_slides = data.get('generate_slides', True)
        generate_video = data.get('generate_video', True)
        llm_provider = data.get('llm_provider', 'openai')
        
        logger.info(f"Batch processing {len(paper_ids)} papers")
        
        results = []
        for idx, paper_id in enumerate(paper_ids):
            try:
                result = {
                    'paper_id': paper_id,
                    'progress': f"{idx + 1}/{len(paper_ids)}",
                    'status': 'processing'
                }
                
                # TODO: Implement batch processing logic
                
                results.append(result)
            except Exception as e:
                results.append({
                    'paper_id': paper_id,
                    'status': 'failed',
                    'error': str(e)
                })
        
        return jsonify({
            'success': True,
            'data': results
        })
    
    except Exception as e:
        logger.error(f"Batch processing failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============================================
# CONFIG ENDPOINTS
# ============================================
@app.route('/api/config/validate', methods=['POST'])
def validate_config():
    """Validate API keys and credentials"""
    try:
        data = request.get_json()
        
        openai_key = data.get('openai_key', '')
        eleven_labs_key = data.get('eleven_labs_key', '')
        google_credentials = data.get('google_credentials', {})
        
        results = {
            'openai': bool(openai_key),
            'eleven_labs': bool(eleven_labs_key),
            'google_slides': bool(google_credentials)
        }
        
        return jsonify({
            'success': True,
            'data': results
        })
    
    except Exception as e:
        logger.error(f"Config validation failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============================================
# ERROR HANDLERS
# ============================================
@app.errorhandler(404)
def not_found(error):
    return jsonify({'success': False, 'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({'success': False, 'error': 'Internal server error'}), 500

# ============================================
# RUN APPLICATION
# ============================================
if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting Paper Research System on port {port}")
    app.run(
        host='0.0.0.0',
        port=port,
        debug=debug
    )
