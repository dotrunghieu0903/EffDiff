"""
Video Generator Service
Creates videos from slides and audio narration
"""

import logging
import os
import json
from typing import Dict
from datetime import datetime

logger = logging.getLogger(__name__)

class VideoGenerator:
    """Generate videos from slides and audio"""
    
    def __init__(self):
        self.output_dir = os.getenv('OUTPUT_DIR', './outputs')
        self.ffmpeg_path = os.getenv('FFMPEG_PATH', 'ffmpeg')
    
    def generate(self, paper_id: str, audio_file: str, duration: int = 3) -> Dict:
        """
        Generate video from slides and audio
        
        Args:
            paper_id: Paper identifier
            audio_file: Path to audio file
            duration: Video duration in minutes
        
        Returns:
            Dictionary with video output details
        """
        try:
            logger.info(f"Generating video for {paper_id}")
            
            # Check if FFmpeg is available
            if self._check_ffmpeg():
                return self._generate_with_ffmpeg(paper_id, audio_file, duration)
            else:
                logger.warning("FFmpeg not found, using mock video")
                return self._create_mock_video(paper_id)
        
        except Exception as e:
            logger.error(f"Video generation failed: {str(e)}")
            raise
    
    def _check_ffmpeg(self) -> bool:
        """Check if FFmpeg is installed"""
        try:
            import subprocess
            result = subprocess.run(
                [self.ffmpeg_path, '-version'],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    def _generate_with_ffmpeg(self, paper_id: str, audio_file: str, duration: int) -> Dict:
        """Generate video using FFmpeg"""
        try:
            import subprocess
            from pathlib import Path
            
            output_dir = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_dir, exist_ok=True)
            
            video_file = os.path.join(output_dir, f'{paper_id}_video.mp4')
            
            # Build FFmpeg command
            # This is a basic implementation - in production, would be more sophisticated
            cmd = [
                self.ffmpeg_path,
                '-loop', '1',
                '-i', os.path.join(output_dir, 'slides.png'),  # Placeholder image
                '-i', audio_file,
                '-c:v', 'libx264',
                '-tune', 'stillimage',
                '-c:a', 'aac',
                '-b:a', '192k',
                '-pix_fmt', 'yuv420p',
                '-t', str(duration * 60),  # Convert minutes to seconds
                '-shortest',
                video_file
            ]
            
            logger.info(f"Running FFmpeg: {' '.join(cmd)}")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode != 0:
                logger.warning(f"FFmpeg warning: {result.stderr}")
                # Video might still be generated despite warnings
            
            if os.path.exists(video_file):
                logger.info(f"Video generated: {video_file}")
                
                return {
                    'format': 'mp4',
                    'filename': f'{paper_id}_video.mp4',
                    'path': video_file,
                    'url': video_file,
                    'duration': f'{duration} minutes',
                    'file_size': self._format_size(os.path.getsize(video_file)),
                    'status': 'success'
                }
            else:
                raise ValueError("Video file not created")
        
        except Exception as e:
            logger.error(f"FFmpeg video generation failed: {str(e)}")
            raise
    
    def _create_mock_video(self, paper_id: str) -> Dict:
        """Create mock video file for testing"""
        try:
            output_dir = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_dir, exist_ok=True)
            
            video_file = os.path.join(output_dir, f'{paper_id}_video_mock.mp4')
            
            # Create a minimal MP4 file (empty video)
            # This is just for testing - a real MP4 would need proper structure
            with open(video_file, 'wb') as f:
                # MP4 signature
                f.write(b'\x00\x00\x00\x20ftypisom')
                f.write(b'\x00' * 1000)  # Placeholder data
            
            logger.info(f"Mock video created: {video_file}")
            
            return {
                'format': 'mp4',
                'filename': f'{paper_id}_video_mock.mp4',
                'path': video_file,
                'url': video_file,
                'duration': '3 minutes',
                'file_size': '1.5 MB',
                'status': 'mock'
            }
        
        except Exception as e:
            logger.error(f"Mock video creation failed: {str(e)}")
            raise
    
    def _format_size(self, size_bytes: int) -> str:
        """Format file size to human-readable format"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} TB"
