"""
Paper Analyzer Service
Analyzes papers using LLM (OpenAI, Claude, or local model)
"""

import logging
import os
import json
from typing import Dict
from datetime import datetime

logger = logging.getLogger(__name__)

class PaperAnalyzer:
    """Analyze papers using LLM"""
    
    def __init__(self):
        self.openai_key = os.getenv('OPENAI_API_KEY', '')
        self.claude_key = os.getenv('CLAUDE_API_KEY', '')
        self.output_dir = os.getenv('OUTPUT_DIR', './outputs')
    
    def analyze(self, paper_id: str, title: str, abstract: str, 
                llm_provider: str = 'openai') -> Dict:
        """
        Analyze a paper and extract key insights
        
        Args:
            paper_id: Unique paper identifier
            title: Paper title
            abstract: Paper abstract
            llm_provider: 'openai', 'claude', or 'local'
        
        Returns:
            Dictionary with analysis results
        """
        try:
            logger.info(f"Analyzing paper {paper_id} with {llm_provider}")
            
            # Generate analysis prompt
            prompt = self._generate_analysis_prompt(title, abstract)
            
            # Get LLM response
            if llm_provider == 'openai':
                response = self._analyze_with_openai(prompt)
            elif llm_provider == 'claude':
                response = self._analyze_with_claude(prompt)
            else:
                response = self._analyze_with_local(prompt)
            
            # Parse and structure response
            analysis = {
                'paper_id': paper_id,
                'title': title,
                'timestamp': datetime.now().isoformat(),
                'llm_provider': llm_provider,
                'problem_statement': self._extract_section(response, 'problem'),
                'key_contributions': self._extract_section(response, 'contributions'),
                'technical_approach': self._extract_section(response, 'approach'),
                'experimental_results': self._extract_section(response, 'results'),
                'outstanding_highlights': self._extract_section(response, 'highlights'),
                'comparison_with_baselines': self._extract_section(response, 'comparison'),
                'summary_script': self._generate_script(response),
                'summary_url': f"{self.output_dir}/{paper_id}/summary.json"
            }
            
            # Save analysis
            self._save_analysis(paper_id, analysis)
            
            logger.info(f"Analysis completed for {paper_id}")
            return analysis
        
        except Exception as e:
            logger.error(f"Analysis failed: {str(e)}")
            raise
    
    def _generate_analysis_prompt(self, title: str, abstract: str) -> str:
        """Generate analysis prompt for LLM"""
        prompt = f"""
Analyze the following research paper and provide structured insights:

TITLE: {title}

ABSTRACT:
{abstract}

Please provide analysis in the following sections:

1. PROBLEM STATEMENT
   - What is the core problem being addressed?
   - Why is this problem important?

2. KEY CONTRIBUTIONS
   - List 3-5 main contributions of this paper
   - How does it advance the field?

3. TECHNICAL APPROACH
   - Explain the technical methodology
   - What algorithms or techniques are used?

4. EXPERIMENTAL RESULTS
   - What are the main experimental findings?
   - How significant are the results?

5. OUTSTANDING HIGHLIGHTS
   - What makes this paper stand out?
   - What are the most impressive results?

6. COMPARISON WITH BASELINES
   - How does this compare to existing methods?
   - What improvements does it show?

Please be concise and academic in tone. Structure your response with clear headers.
"""
        return prompt
    
    def _analyze_with_openai(self, prompt: str) -> str:
        """Analyze using OpenAI API"""
        try:
            if not self.openai_key:
                logger.warning("OpenAI key not found, using mock response")
                return self._get_mock_analysis()
            
            import openai
            openai.api_key = self.openai_key
            
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert researcher analyzing academic papers."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2000
            )
            
            return response.choices[0].message.content
        
        except Exception as e:
            logger.error(f"OpenAI analysis failed: {str(e)}")
            return self._get_mock_analysis()
    
    def _analyze_with_claude(self, prompt: str) -> str:
        """Analyze using Claude API"""
        try:
            if not self.claude_key:
                logger.warning("Claude key not found, using mock response")
                return self._get_mock_analysis()
            
            import anthropic
            client = anthropic.Anthropic(api_key=self.claude_key)
            
            response = client.messages.create(
                model="claude-3-opus-20240229",
                max_tokens=2000,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            return response.content[0].text
        
        except Exception as e:
            logger.error(f"Claude analysis failed: {str(e)}")
            return self._get_mock_analysis()
    
    def _analyze_with_local(self, prompt: str) -> str:
        """Analyze using local model (placeholder)"""
        logger.info("Using local model for analysis")
        return self._get_mock_analysis()
    
    def _extract_section(self, response: str, section_name: str) -> str:
        """Extract specific section from LLM response"""
        section_map = {
            'problem': 'PROBLEM STATEMENT',
            'contributions': 'KEY CONTRIBUTIONS',
            'approach': 'TECHNICAL APPROACH',
            'results': 'EXPERIMENTAL RESULTS',
            'highlights': 'OUTSTANDING HIGHLIGHTS',
            'comparison': 'COMPARISON WITH BASELINES'
        }
        
        section_header = section_map.get(section_name, '')
        
        try:
            # Find section in response
            start_idx = response.find(section_header)
            if start_idx == -1:
                return f"[{section_header} information available]"
            
            # Find next section or end of response
            start_idx = response.find('\n', start_idx) + 1
            end_idx = len(response)
            
            # Look for next section header
            for header in section_map.values():
                idx = response.find(header, start_idx)
                if idx > start_idx and idx < end_idx:
                    end_idx = idx
            
            section_text = response[start_idx:end_idx].strip()
            return section_text if section_text else f"[{section_header} not clearly provided]"
        
        except Exception as e:
            logger.warning(f"Error extracting {section_name}: {str(e)}")
            return f"[{section_header} extraction error]"
    
    def _generate_script(self, analysis: str) -> str:
        """Generate narration script from analysis"""
        script = f"""
Welcome to this research paper summary.

Today we'll explore the key findings and contributions of this groundbreaking work.

{analysis[:500]}...

This paper makes significant contributions to the field by introducing novel approaches
and achieving impressive results compared to existing methods.

We hope this summary has provided you with valuable insights into this research.

Thank you for watching!
"""
        return script
    
    def _save_analysis(self, paper_id: str, analysis: Dict) -> None:
        """Save analysis to file"""
        try:
            output_path = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_path, exist_ok=True)
            
            analysis_file = os.path.join(output_path, 'analysis.json')
            with open(analysis_file, 'w', encoding='utf-8') as f:
                json.dump(analysis, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Analysis saved to {analysis_file}")
        
        except Exception as e:
            logger.error(f"Failed to save analysis: {str(e)}")
    
    def _get_mock_analysis(self) -> str:
        """Return mock analysis response"""
        return """
PROBLEM STATEMENT
The paper addresses a fundamental challenge in modern machine learning: how to efficiently
scale models while maintaining or improving performance. Existing approaches often suffer
from quadratic complexity and memory constraints.

KEY CONTRIBUTIONS
1. Novel architecture design that achieves linear time complexity
2. Efficient training procedure reducing memory footprint by 60%
3. Comprehensive benchmarking showing state-of-the-art results
4. Open-source implementation for reproducibility

TECHNICAL APPROACH
The authors introduce a selective state space mechanism that enables efficient sequence processing.
Using matrix transformations and hardware-optimized kernels, they achieve near-optimal performance.

EXPERIMENTAL RESULTS
- 2x speedup on long sequences compared to Transformers
- Superior performance on language modeling benchmarks
- Scalable to sequences of 1M+ tokens
- Reduced training time by 40%

OUTSTANDING HIGHLIGHTS
The breakthrough is the discovery that selective gating mechanisms can maintain model expressiveness
while drastically reducing computational complexity. This opens new possibilities for long-context
understanding in language models and other domains.

COMPARISON WITH BASELINES
Compared to Transformer variants, this method shows:
- 10x better scaling efficiency
- 2x faster inference
- 30% less memory usage
- Competitive accuracy on standard benchmarks
"""
