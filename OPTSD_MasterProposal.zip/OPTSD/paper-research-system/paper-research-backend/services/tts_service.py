"""
Text-to-Speech (TTS) Service
Generates audio from text using Eleven Labs, Google Cloud TTS, or other providers
"""

import logging
import os
import json
from typing import Dict
from datetime import datetime

logger = logging.getLogger(__name__)

class TTSService:
    """Generate speech from text"""
    
    def __init__(self):
        self.eleven_labs_key = os.getenv('ELEVEN_LABS_API_KEY', '')
        self.google_cloud_key = os.getenv('GOOGLE_CLOUD_API_KEY', '')
        self.output_dir = os.getenv('OUTPUT_DIR', './outputs')
        
        # Voice mapping for different providers
        self.voice_map = {
            'male-english': {'eleven-labs': 'Adam', 'google': 'en-US-Studio-B'},
            'female-english': {'eleven-labs': 'Sarah', 'google': 'en-US-Studio-C'},
            'male-vietnamese': {'eleven-labs': 'Onyx', 'google': 'vi-VN-Studio-A'},
            'female-vietnamese': {'eleven-labs': 'Shimmer', 'google': 'vi-VN-Studio-B'}
        }
    
    def generate_speech(self, text: str, voice: str = 'male-english', 
                       paper_id: str = 'default') -> str:
        """
        Generate speech audio from text
        
        Args:
            text: Text to convert to speech
            voice: Voice identifier
            paper_id: Paper identifier for file naming
        
        Returns:
            Path to generated audio file
        """
        try:
            logger.info(f"Generating speech with voice: {voice}")
            
            # Try different TTS providers in order
            if self.eleven_labs_key:
                return self._generate_with_eleven_labs(text, voice, paper_id)
            elif self.google_cloud_key:
                return self._generate_with_google_cloud(text, voice, paper_id)
            else:
                logger.warning("No TTS provider configured, using mock audio")
                return self._create_mock_audio(paper_id)
        
        except Exception as e:
            logger.error(f"Speech generation failed: {str(e)}")
            return self._create_mock_audio(paper_id)
    
    def _generate_with_eleven_labs(self, text: str, voice: str, paper_id: str) -> str:
        """Generate speech using Eleven Labs API"""
        try:
            import requests
            
            voice_name = self.voice_map.get(voice, {}).get('eleven-labs', 'Adam')
            
            # Get voice ID
            headers = {'xi-api-key': self.eleven_labs_key}
            
            voices_url = 'https://api.elevenlabs.io/v1/voices'
            voices_response = requests.get(voices_url, headers=headers, timeout=10)
            voices_data = voices_response.json()
            
            voice_id = None
            for v in voices_data.get('voices', []):
                if voice_name.lower() in v.get('name', '').lower():
                    voice_id = v.get('voice_id')
                    break
            
            if not voice_id:
                voice_id = voices_data['voices'][0]['voice_id'] if voices_data['voices'] else None
            
            if not voice_id:
                raise ValueError("No voice available")
            
            # Generate speech
            tts_url = f'https://api.elevenlabs.io/v1/text-to-speech/{voice_id}'
            
            payload = {
                'text': text,
                'model_id': 'eleven_monolingual_v1',
                'voice_settings': {
                    'stability': 0.5,
                    'similarity_boost': 0.75
                }
            }
            
            response = requests.post(
                tts_url,
                json=payload,
                headers=headers,
                timeout=30
            )
            
            if response.status_code != 200:
                raise ValueError(f"Eleven Labs API error: {response.status_code}")
            
            # Save audio file
            output_dir = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_dir, exist_ok=True)
            
            audio_file = os.path.join(output_dir, f'{paper_id}_audio.mp3')
            with open(audio_file, 'wb') as f:
                f.write(response.content)
            
            logger.info(f"Audio generated: {audio_file}")
            return audio_file
        
        except Exception as e:
            logger.error(f"Eleven Labs TTS failed: {str(e)}")
            raise
    
    def _generate_with_google_cloud(self, text: str, voice: str, paper_id: str) -> str:
        """Generate speech using Google Cloud TTS"""
        try:
            from google.cloud import texttospeech
            
            voice_name = self.voice_map.get(voice, {}).get('google', 'en-US-Studio-B')
            
            client = texttospeech.TextToSpeechClient()
            
            synthesis_input = texttospeech.SynthesisInput(text=text)
            
            voice_params = texttospeech.VoiceSelectionParams(
                language_code='en-US' if 'english' in voice else 'vi-VN',
                name=voice_name
            )
            
            audio_config = texttospeech.AudioConfig(
                audio_encoding=texttospeech.AudioEncoding.MP3
            )
            
            response = client.synthesize_speech(
                input=synthesis_input,
                voice=voice_params,
                audio_config=audio_config
            )
            
            # Save audio file
            output_dir = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_dir, exist_ok=True)
            
            audio_file = os.path.join(output_dir, f'{paper_id}_audio.mp3')
            with open(audio_file, 'wb') as f:
                f.write(response.audio_content)
            
            logger.info(f"Audio generated: {audio_file}")
            return audio_file
        
        except Exception as e:
            logger.error(f"Google Cloud TTS failed: {str(e)}")
            raise
    
    def _create_mock_audio(self, paper_id: str) -> str:
        """Create mock audio file for testing"""
        try:
            # Create a silent MP3 file for testing
            output_dir = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_dir, exist_ok=True)
            
            audio_file = os.path.join(output_dir, f'{paper_id}_audio_mock.mp3')
            
            # Create a minimal MP3 file header (silent audio)
            mp3_header = bytes.fromhex('fffb1000')  # MP3 sync word
            
            with open(audio_file, 'wb') as f:
                f.write(mp3_header)
                # Add some silent frames to make it a valid (but very short) MP3
                f.write(b'\x00' * 100)
            
            logger.info(f"Mock audio created: {audio_file}")
            return audio_file
        
        except Exception as e:
            logger.error(f"Mock audio creation failed: {str(e)}")
            raise
    
    def validate_tts_config(self) -> Dict[str, bool]:
        """Validate TTS configuration"""
        return {
            'eleven_labs': bool(self.eleven_labs_key),
            'google_cloud': bool(self.google_cloud_key),
            'has_provider': bool(self.eleven_labs_key or self.google_cloud_key)
        }
