"""
Google Slides Generator Service
Creates Google Slides presentations with paper analysis
"""

import logging
import os
import json
from typing import Dict
from datetime import datetime

logger = logging.getLogger(__name__)

class SlidesGenerator:
    """Generate Google Slides presentations"""
    
    def __init__(self):
        self.google_credentials = os.getenv('GOOGLE_SLIDES_CREDENTIALS', '')
        self.output_dir = os.getenv('OUTPUT_DIR', './outputs')
    
    def generate(self, paper_id: str, title: str, analysis: Dict, 
                format_type: str = 'google-slides') -> Dict:
        """
        Generate slides presentation
        
        Args:
            paper_id: Paper identifier
            title: Paper title
            analysis: Paper analysis data
            format_type: 'google-slides', 'pptx', or 'pdf'
        
        Returns:
            Dictionary with slides output details
        """
        try:
            logger.info(f"Generating slides for {paper_id} in {format_type} format")
            
            if format_type == 'google-slides':
                return self._generate_google_slides(paper_id, title, analysis)
            elif format_type == 'pptx':
                return self._generate_pptx(paper_id, title, analysis)
            elif format_type == 'pdf':
                return self._generate_pdf(paper_id, title, analysis)
            else:
                raise ValueError(f"Unknown format: {format_type}")
        
        except Exception as e:
            logger.error(f"Slides generation failed: {str(e)}")
            raise
    
    def _generate_google_slides(self, paper_id: str, title: str, analysis: Dict) -> Dict:
        """Generate Google Slides presentation"""
        try:
            # Try to use Google Slides API
            try:
                from google.oauth2 import service_account
                from google.auth.transport.requests import Request
                from googleapiclient.discovery import build
                
                # Load credentials
                if self.google_credentials:
                    credentials = service_account.Credentials.from_service_account_info(
                        json.loads(self.google_credentials)
                    )
                    
                    service = build('slides', 'v1', credentials=credentials)
                    
                    # Create presentation
                    presentation = service.presentations().create(
                        body={
                            'title': f'{title} - Academic Analysis'
                        }
                    ).execute()
                    
                    presentation_id = presentation.get('presentationId')
                    logger.info(f"Created Google Slides: {presentation_id}")
                    
                    # Add slides
                    self._add_slides_content(service, presentation_id, title, analysis)
                    
                    # Build share link
                    slides_url = f"https://docs.google.com/presentation/d/{presentation_id}/edit"
                    
                    return {
                        'format': 'google-slides',
                        'presentation_id': presentation_id,
                        'url': slides_url,
                        'title': f'{title} - Academic Analysis',
                        'slides_count': 8,
                        'status': 'success'
                    }
            
            except Exception as e:
                logger.warning(f"Google Slides API error: {str(e)}, falling back to PPTX")
                return self._generate_pptx(paper_id, title, analysis)
        
        except Exception as e:
            logger.error(f"Google Slides generation failed: {str(e)}")
            raise
    
    def _add_slides_content(self, service, presentation_id: str, title: str, analysis: Dict) -> None:
        """Add content to Google Slides"""
        try:
            requests = []
            
            # Slide 1: Title slide
            requests.append(self._create_title_slide(title))
            
            # Slide 2-3: Problem & Motivation
            requests.append(self._create_content_slide(
                'Problem & Motivation',
                analysis.get('problem_statement', '')
            ))
            
            # Slide 4-5: Technical Approach
            requests.append(self._create_content_slide(
                'Technical Approach',
                analysis.get('technical_approach', '')
            ))
            
            # Slide 6-7: Results
            requests.append(self._create_content_slide(
                'Experimental Results',
                analysis.get('experimental_results', '')
            ))
            
            # Slide 8: Highlights
            requests.append(self._create_content_slide(
                'Outstanding Contributions',
                analysis.get('outstanding_highlights', '')
            ))
            
            # Batch update
            if requests:
                service.presentations().batchUpdate(
                    presentationId=presentation_id,
                    body={'requests': requests}
                ).execute()
        
        except Exception as e:
            logger.warning(f"Error adding slides content: {str(e)}")
    
    def _generate_pptx(self, paper_id: str, title: str, analysis: Dict) -> Dict:
        """Generate PowerPoint presentation using python-pptx"""
        try:
            from pptx import Presentation
            from pptx.util import Inches, Pt
            from pptx.enum.text import PP_ALIGN
            from pptx.dml.color import RGBColor
            
            # Create presentation
            prs = Presentation()
            prs.slide_width = Inches(10)
            prs.slide_height = Inches(7.5)
            
            # Define color scheme
            title_color = RGBColor(37, 99, 235)      # Primary blue
            accent_color = RGBColor(124, 58, 237)    # Secondary purple
            
            # Slide 1: Title Slide
            self._add_title_slide_pptx(prs, title, analysis, title_color, accent_color)
            
            # Slide 2: Problem Statement
            self._add_content_slide_pptx(
                prs, 'Problem & Motivation',
                analysis.get('problem_statement', ''),
                title_color
            )
            
            # Slide 3: Technical Approach
            self._add_content_slide_pptx(
                prs, 'Technical Approach',
                analysis.get('technical_approach', ''),
                title_color
            )
            
            # Slide 4: Key Contributions
            self._add_bullet_slide_pptx(
                prs, 'Key Contributions',
                analysis.get('key_contributions', '').split('\n'),
                title_color
            )
            
            # Slide 5: Experimental Results
            self._add_content_slide_pptx(
                prs, 'Experimental Results',
                analysis.get('experimental_results', ''),
                title_color
            )
            
            # Slide 6: Outstanding Highlights
            self._add_content_slide_pptx(
                prs, 'Outstanding Highlights',
                analysis.get('outstanding_highlights', ''),
                accent_color
            )
            
            # Slide 7: Comparison with Baselines
            self._add_content_slide_pptx(
                prs, 'Comparison with Baselines',
                analysis.get('comparison_with_baselines', ''),
                title_color
            )
            
            # Save
            output_dir = os.path.join(self.output_dir, paper_id)
            os.makedirs(output_dir, exist_ok=True)
            
            output_file = os.path.join(output_dir, f'{paper_id}_slides.pptx')
            prs.save(output_file)
            
            logger.info(f"PowerPoint saved: {output_file}")
            
            return {
                'format': 'pptx',
                'filename': f'{paper_id}_slides.pptx',
                'path': output_file,
                'url': output_file,
                'title': f'{title} - Academic Analysis',
                'slides_count': 7,
                'status': 'success'
            }
        
        except ImportError:
            logger.error("python-pptx not installed")
            raise
        except Exception as e:
            logger.error(f"PPTX generation failed: {str(e)}")
            raise
    
    def _add_title_slide_pptx(self, prs, title: str, analysis: Dict, 
                             title_color, accent_color) -> None:
        """Add title slide to PowerPoint"""
        from pptx.util import Inches, Pt
        
        slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(248, 250, 252)  # Light background
        
        # Add title
        title_box = slide.shapes.add_textbox(Inches(0.5), Inches(2), Inches(9), Inches(1))
        title_frame = title_box.text_frame
        title_frame.text = title
        title_frame.paragraphs[0].font.size = Pt(54)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = title_color
        
        # Add subtitle
        subtitle_box = slide.shapes.add_textbox(Inches(0.5), Inches(3.5), Inches(9), Inches(1))
        subtitle_frame = subtitle_box.text_frame
        subtitle_frame.text = "Academic Paper Analysis & Summary"
        subtitle_frame.paragraphs[0].font.size = Pt(24)
        subtitle_frame.paragraphs[0].font.color.rgb = RGBColor(100, 116, 139)
    
    def _add_content_slide_pptx(self, prs, title: str, content: str, title_color) -> None:
        """Add content slide to PowerPoint"""
        from pptx.util import Inches, Pt
        from pptx.enum.text import PP_ALIGN
        
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(255, 255, 255)
        
        # Add title
        title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(0.8))
        title_frame = title_box.text_frame
        title_frame.text = title
        title_frame.paragraphs[0].font.size = Pt(36)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = title_color
        
        # Add content
        content_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.5), Inches(9), Inches(5.5))
        content_frame = content_box.text_frame
        content_frame.word_wrap = True
        content_frame.text = content[:300] if len(content) > 300 else content
        content_frame.paragraphs[0].font.size = Pt(14)
        content_frame.paragraphs[0].font.color.rgb = RGBColor(30, 41, 59)
    
    def _add_bullet_slide_pptx(self, prs, title: str, bullets: list, title_color) -> None:
        """Add bullet point slide to PowerPoint"""
        from pptx.util import Inches, Pt
        
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(255, 255, 255)
        
        # Add title
        title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(0.8))
        title_frame = title_box.text_frame
        title_frame.text = title
        title_frame.paragraphs[0].font.size = Pt(36)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = title_color
        
        # Add bullets
        content_box = slide.shapes.add_textbox(Inches(1), Inches(1.5), Inches(8.5), Inches(5.5))
        content_frame = content_box.text_frame
        content_frame.word_wrap = True
        
        for idx, bullet in enumerate([b for b in bullets if b.strip()][:5]):
            if idx == 0:
                p = content_frame.paragraphs[0]
            else:
                p = content_frame.add_paragraph()
            
            p.text = bullet.strip()
            p.level = 0
            p.font.size = Pt(14)
            p.font.color.rgb = RGBColor(30, 41, 59)
    
    def _generate_pdf(self, paper_id: str, title: str, analysis: Dict) -> Dict:
        """Generate PDF presentation"""
        logger.info("PDF generation not yet implemented, using PPTX instead")
        # For now, generate PPTX instead
        return self._generate_pptx(paper_id, title, analysis)
    
    def _create_title_slide(self, title: str) -> Dict:
        """Create title slide request for Google Slides API"""
        return {
            'createSlide': {
                'objectId': 'title_slide',
                'slideLayout': {
                    'layoutId': 'BLANK_LAYOUT'
                }
            }
        }
    
    def _create_content_slide(self, title: str, content: str) -> Dict:
        """Create content slide request for Google Slides API"""
        return {
            'createSlide': {
                'objectId': f'content_slide_{hash(title) % 10000}',
                'slideLayout': {
                    'layoutId': 'BLANK_LAYOUT'
                }
            }
        }
