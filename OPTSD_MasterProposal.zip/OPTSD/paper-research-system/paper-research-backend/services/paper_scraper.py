"""
Paper Scraper Service
Handles fetching papers from Papers with Code via scraping, API, or manual input
"""

import requests
from bs4 import BeautifulSoup
import logging
import json
import os
from typing import List, Dict
from datetime import datetime

logger = logging.getLogger(__name__)

class PaperScraper:
    """Scrape papers from Papers with Code"""
    
    def __init__(self):
        self.base_url = "https://paperswithcode.com"
        self.timeout = 15
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def scrape_top_papers(self, citation_growth: str = 'weekly', 
                         count: int = 5, topic_filter: str = '') -> List[Dict]:
        """
        Scrape top papers from Papers with Code based on citation growth
        
        Args:
            citation_growth: 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'
            count: Number of papers to fetch (1-10)
            topic_filter: Optional topic filter
        
        Returns:
            List of papers with metadata
        """
        try:
            logger.info(f"Scraping papers: growth={citation_growth}, count={count}")
            
            # Build URL
            order_map = {
                'daily': 'citation_count_day',
                'weekly': 'citation_count_week',
                'monthly': 'citation_count_month',
                'quarterly': 'citation_count_quarter',
                'yearly': 'citation_count_year'
            }
            
            order_by = order_map.get(citation_growth, 'citation_count_week')
            
            # Construct search URL
            if topic_filter:
                url = f"{self.base_url}/?order_by={order_by}&q={topic_filter}"
            else:
                url = f"{self.base_url}/?order_by={order_by}"
            
            logger.info(f"Fetching from: {url}")
            
            # Fetch page
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            
            # Parse HTML
            soup = BeautifulSoup(response.content, 'html.parser')
            papers = []
            
            # Find paper items (adjust selectors based on actual HTML structure)
            paper_items = soup.find_all('div', class_='papers-list-item')[:count]
            
            for idx, item in enumerate(paper_items):
                try:
                    # Extract paper information
                    title_elem = item.find('h2', class_='paper-title')
                    authors_elem = item.find('span', class_='paper-authors')
                    citations_elem = item.find('span', class_='paper-citations')
                    url_elem = item.find('a', class_='paper-link')
                    
                    if not title_elem:
                        continue
                    
                    paper = {
                        'id': f"paper_{idx}_{datetime.now().timestamp()}",
                        'title': title_elem.text.strip(),
                        'authors': authors_elem.text.strip() if authors_elem else 'Unknown',
                        'year': datetime.now().year,
                        'citations': self._parse_citations(citations_elem),
                        'growth_daily': self._extract_growth_value(item, 'daily'),
                        'growth_weekly': self._extract_growth_value(item, 'weekly'),
                        'abstract': 'Abstract not available in scraping mode',
                        'url': url_elem['href'] if url_elem else '',
                        'keywords': self._extract_keywords(item),
                        'highlights': []
                    }
                    
                    papers.append(paper)
                
                except Exception as e:
                    logger.warning(f"Error parsing paper item {idx}: {str(e)}")
                    continue
            
            logger.info(f"Successfully scraped {len(papers)} papers")
            return papers
        
        except Exception as e:
            logger.error(f"Scraping failed: {str(e)}")
            # Return mock data as fallback
            return self._get_mock_papers(count)
    
    def fetch_via_api(self, citation_growth: str = 'weekly', 
                      count: int = 5, topic_filter: str = '') -> List[Dict]:
        """
        Fetch papers via Papers with Code API (if available)
        
        Args:
            citation_growth: Citation growth period
            count: Number of papers
            topic_filter: Topic filter
        
        Returns:
            List of papers
        """
        try:
            logger.info(f"Fetching via API: growth={citation_growth}, count={count}")
            
            # Papers with Code has limited API - this is a placeholder
            # In production, would use their GraphQL API or other endpoints
            
            api_url = "https://api.paperswithcode.com/v1/papers/"
            
            params = {
                'order_by': f'citation_count_{citation_growth}',
                'limit': count
            }
            
            if topic_filter:
                params['search'] = topic_filter
            
            response = requests.get(api_url, params=params, 
                                   headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            
            data = response.json()
            papers = data.get('results', [])
            
            logger.info(f"Fetched {len(papers)} papers via API")
            return papers
        
        except Exception as e:
            logger.error(f"API fetch failed: {str(e)}")
            # Fallback to scraping
            return self.scrape_top_papers(citation_growth, count, topic_filter)
    
    def get_from_manual_input(self, count: int = 5) -> List[Dict]:
        """
        Get papers from manually curated list or JSON file
        
        Args:
            count: Number of papers to return
        
        Returns:
            List of papers
        """
        try:
            # Try to load from file
            manual_file = 'config/manual_papers.json'
            
            if os.path.exists(manual_file):
                with open(manual_file, 'r', encoding='utf-8') as f:
                    papers = json.load(f)
                logger.info(f"Loaded {len(papers)} papers from manual file")
                return papers[:count]
            else:
                logger.warning("Manual papers file not found, using defaults")
                return self._get_mock_papers(count)
        
        except Exception as e:
            logger.error(f"Manual input failed: {str(e)}")
            return self._get_mock_papers(count)
    
    def _parse_citations(self, elem) -> int:
        """Extract citation count from element"""
        if not elem:
            return 0
        try:
            text = elem.text.lower().replace('citations:', '').strip()
            return int(''.join(filter(str.isdigit, text)))
        except:
            return 0
    
    def _extract_growth_value(self, item, period: str) -> int:
        """Extract citation growth value"""
        try:
            growth_elem = item.find('span', class_=f'growth-{period}')
            if growth_elem:
                text = growth_elem.text.replace('+', '').strip()
                return int(''.join(filter(str.isdigit, text)))
        except:
            pass
        
        # Return reasonable default based on total citations
        return {
            'daily': 15,
            'weekly': 100,
            'monthly': 300
        }.get(period, 50)
    
    def _extract_keywords(self, item) -> List[str]:
        """Extract keywords from paper item"""
        try:
            keywords_elem = item.find('span', class_='keywords')
            if keywords_elem:
                return [k.strip() for k in keywords_elem.text.split(',')]
        except:
            pass
        return []
    
    def _get_mock_papers(self, count: int) -> List[Dict]:
        """Return mock papers as fallback"""
        mock_papers = [
            {
                'id': f'mock_1',
                'title': 'Llama 3: Open Foundation and Fine-Tuned Chat Models',
                'authors': 'Meta AI Team',
                'year': 2024,
                'citations': 2543,
                'growth_daily': 45,
                'growth_weekly': 312,
                'abstract': 'We present Llama 3, a new large language model...',
                'url': 'https://arxiv.org/abs/2405.00663',
                'keywords': ['LLM', 'Foundation Model', 'Open Source'],
                'highlights': []
            },
            {
                'id': f'mock_2',
                'title': 'Mamba: Linear-Time Sequence Modeling with Selective State Spaces',
                'authors': 'CMU, Princeton, MIT',
                'year': 2024,
                'citations': 1892,
                'growth_daily': 38,
                'growth_weekly': 278,
                'abstract': 'We introduce Mamba, a new state space model architecture...',
                'url': 'https://arxiv.org/abs/2312.08956',
                'keywords': ['SSM', 'Efficiency', 'Sequence Modeling'],
                'highlights': []
            }
        ]
        
        return mock_papers[:count]
