"""
Enhanced Paper Scraper Service with Multi-Source Support
Handles multiple data sources with intelligent fallback and aggregation
"""

import requests
from bs4 import BeautifulSoup
import logging
import json
import os
from typing import List, Dict, Tuple
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)

class PaperSource(Enum):
    """Supported paper data sources"""
    PAPERS_WITH_CODE = "papers-with-code"
    SEMANTIC_SCHOLAR = "semantic-scholar"
    ARXIV = "arxiv"
    HUGGING_FACE = "hugging-face"
    OPENREVIEW = "openreview"
    MANUAL = "manual"

class EnhancedPaperScraper:
    """Multi-source paper scraper with intelligent fallback"""
    
    def __init__(self):
        self.timeout = 15
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        # Source priority order
        self.source_priority = {
            'daily': [PaperSource.PAPERS_WITH_CODE, PaperSource.ARXIV, PaperSource.HUGGING_FACE],
            'weekly': [PaperSource.PAPERS_WITH_CODE, PaperSource.SEMANTIC_SCHOLAR, PaperSource.HUGGING_FACE],
            'monthly': [PaperSource.PAPERS_WITH_CODE, PaperSource.SEMANTIC_SCHOLAR, PaperSource.HUGGING_FACE],
            'quarterly': [PaperSource.PAPERS_WITH_CODE, PaperSource.SEMANTIC_SCHOLAR],
            'yearly': [PaperSource.PAPERS_WITH_CODE, PaperSource.SEMANTIC_SCHOLAR, PaperSource.OPENREVIEW]
        }
    
    def fetch_papers(self, 
                    period: str = 'weekly',
                    count: int = 5,
                    topic_filter: str = '',
                    source: str = 'auto',
                    retry_count: int = 3) -> Tuple[List[Dict], str]:
        """
        Fetch papers from specified or best-available source
        
        Args:
            period: daily/weekly/monthly/quarterly/yearly
            count: Number of papers to fetch
            topic_filter: Optional topic filter
            source: 'auto' (smart selection), 'combined' (all sources), or specific source name
            retry_count: Number of retries for each source
        
        Returns:
            Tuple of (papers list, source used)
        """
        try:
            logger.info(f"Fetching papers: period={period}, count={count}, source={source}")
            
            if source.lower() == 'combined':
                return self._fetch_combined(period, count, topic_filter)
            elif source.lower() == 'auto':
                return self._fetch_with_fallback(period, count, topic_filter, retry_count)
            else:
                return self._fetch_specific(source, period, count, topic_filter, retry_count)
        
        except Exception as e:
            logger.error(f"Paper fetching failed: {str(e)}")
            # Return mock data as last resort
            return self._get_mock_papers(count), 'mock'
    
    def _fetch_with_fallback(self, period: str, count: int, 
                            topic_filter: str, retry_count: int) -> Tuple[List[Dict], str]:
        """Try sources in priority order until one succeeds"""
        
        sources = self.source_priority.get(period, self.source_priority['weekly'])
        
        for source in sources:
            try:
                logger.info(f"Trying source: {source.value}")
                
                papers = self._fetch_from_source(source, period, count, topic_filter)
                
                if papers and len(papers) > 0:
                    logger.info(f"Successfully fetched {len(papers)} papers from {source.value}")
                    return papers, source.value
            
            except Exception as e:
                logger.warning(f"Source {source.value} failed: {str(e)}, trying next...")
                continue
        
        # All sources failed
        logger.error("All sources failed, returning mock data")
        return self._get_mock_papers(count), 'mock'
    
    def _fetch_specific(self, source: str, period: str, count: int, 
                       topic_filter: str, retry_count: int) -> Tuple[List[Dict], str]:
        """Fetch from specific source with retries"""
        
        try:
            source_enum = PaperSource[source.upper().replace('-', '_')]
        except KeyError:
            logger.error(f"Unknown source: {source}")
            return self._fetch_with_fallback(period, count, topic_filter, retry_count)
        
        for attempt in range(retry_count):
            try:
                papers = self._fetch_from_source(source_enum, period, count, topic_filter)
                if papers:
                    return papers, source
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} for {source} failed: {str(e)}")
                if attempt < retry_count - 1:
                    import time
                    time.sleep(2 ** attempt)  # Exponential backoff
        
        # Fallback to auto mode
        logger.warning(f"Source {source} exhausted retries, falling back to auto mode")
        return self._fetch_with_fallback(period, count, topic_filter, retry_count)
    
    def _fetch_from_source(self, source: PaperSource, period: str, 
                          count: int, topic_filter: str) -> List[Dict]:
        """Dispatch to appropriate source fetcher"""
        
        if source == PaperSource.PAPERS_WITH_CODE:
            return self._fetch_papers_with_code(period, count, topic_filter)
        elif source == PaperSource.SEMANTIC_SCHOLAR:
            return self._fetch_semantic_scholar(period, count, topic_filter)
        elif source == PaperSource.ARXIV:
            return self._fetch_arxiv(period, count, topic_filter)
        elif source == PaperSource.HUGGING_FACE:
            return self._fetch_hugging_face(period, count, topic_filter)
        elif source == PaperSource.OPENREVIEW:
            return self._fetch_openreview(period, count, topic_filter)
        else:
            raise ValueError(f"Unknown source: {source}")
    
    def _fetch_combined(self, period: str, count: int, topic_filter: str) -> Tuple[List[Dict], str]:
        """Fetch from all available sources and aggregate"""
        
        all_papers = []
        sources_used = []
        
        for source in [PaperSource.PAPERS_WITH_CODE, 
                      PaperSource.SEMANTIC_SCHOLAR, 
                      PaperSource.HUGGING_FACE,
                      PaperSource.ARXIV]:
            try:
                papers = self._fetch_from_source(source, period, count, topic_filter)
                if papers:
                    all_papers.extend(papers)
                    sources_used.append(source.value)
            except Exception as e:
                logger.warning(f"Error fetching from {source.value}: {str(e)}")
                continue
        
        # Deduplicate
        unique_papers = {}
        for paper in all_papers:
            paper_key = f"{paper['title']}_{paper['authors']}"
            if paper_key not in unique_papers:
                unique_papers[paper_key] = paper
        
        # Sort by citation growth
        papers = list(unique_papers.values())
        papers.sort(key=lambda p: p.get('growth_daily', 0) + p.get('growth_weekly', 0), 
                   reverse=True)
        
        logger.info(f"Combined fetch: {len(papers)} unique papers from sources: {sources_used}")
        return papers[:count], f"combined ({', '.join(sources_used)})"
    
    # ============================================
    # SOURCE-SPECIFIC FETCHERS
    # ============================================
    
    def _fetch_papers_with_code(self, period: str, count: int, topic_filter: str) -> List[Dict]:
        """Fetch from Papers with Code (scraping)"""
        logger.info(f"Fetching from Papers with Code: period={period}, count={count}")
        
        order_map = {
            'daily': 'citation_count_day',
            'weekly': 'citation_count_week',
            'monthly': 'citation_count_month',
            'quarterly': 'citation_count_quarter',
            'yearly': 'citation_count_year'
        }
        
        order_by = order_map.get(period, 'citation_count_week')
        url = f"https://paperswithcode.com/?order_by={order_by}"
        
        if topic_filter:
            url += f"&q={topic_filter}"
        
        try:
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            
            # Parse papers (adjust selectors based on actual HTML)
            papers = self._parse_pwc_papers(response.content, count)
            logger.info(f"Fetched {len(papers)} papers from Papers with Code")
            return papers
        
        except Exception as e:
            logger.error(f"Papers with Code fetch failed: {str(e)}")
            raise
    
    def _fetch_semantic_scholar(self, period: str, count: int, topic_filter: str) -> List[Dict]:
        """Fetch from Semantic Scholar API"""
        logger.info(f"Fetching from Semantic Scholar: period={period}, count={count}")
        
        try:
            api_url = "https://api.semanticscholar.org/graph/v1/paper/search"
            
            query = topic_filter if topic_filter else "neural networks"
            
            params = {
                'query': query,
                'limit': count,
                'fields': 'title,authors,year,citationCount,abstract,url'
            }
            
            response = requests.get(api_url, params=params, 
                                   headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            
            data = response.json()
            papers = self._parse_semantic_scholar_response(data.get('data', []))
            logger.info(f"Fetched {len(papers)} papers from Semantic Scholar")
            return papers
        
        except Exception as e:
            logger.error(f"Semantic Scholar fetch failed: {str(e)}")
            raise
    
    def _fetch_arxiv(self, period: str, count: int, topic_filter: str) -> List[Dict]:
        """Fetch from arXiv API (latest papers)"""
        logger.info(f"Fetching from arXiv: period={period}, count={count}")
        
        try:
            # arXiv best for daily/recent
            categories = 'cs.LG,cs.AI,cs.CL,stat.ML'  # ML categories
            
            # Build date range for period
            if period == 'daily':
                submitted_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d0000')
            elif period == 'weekly':
                submitted_date = (datetime.now() - timedelta(days=7)).strftime('%Y%m%d0000')
            else:
                submitted_date = (datetime.now() - timedelta(days=30)).strftime('%Y%m%d0000')
            
            search_query = f'cat:({categories}) AND submittedDate:[{submitted_date} TO 9999]'
            
            if topic_filter:
                search_query += f' AND ({topic_filter})'
            
            url = 'http://export.arxiv.org/api/query'
            params = {
                'search_query': search_query,
                'start': 0,
                'max_results': count,
                'sortBy': 'submittedDate',
                'sortOrder': 'descending'
            }
            
            response = requests.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            
            papers = self._parse_arxiv_response(response.content)
            logger.info(f"Fetched {len(papers)} papers from arXiv")
            return papers
        
        except Exception as e:
            logger.error(f"arXiv fetch failed: {str(e)}")
            raise
    
    def _fetch_hugging_face(self, period: str, count: int, topic_filter: str) -> List[Dict]:
        """Fetch from Hugging Face Papers (scraping)"""
        logger.info(f"Fetching from Hugging Face: period={period}, count={count}")
        
        try:
            # Hugging Face has different trending periods
            if period in ['daily', 'today']:
                url = "https://huggingface.co/papers?date=today"
            elif period in ['weekly', 'week']:
                url = "https://huggingface.co/papers/trending?range=week"
            elif period in ['monthly', 'month']:
                url = "https://huggingface.co/papers/trending?range=month"
            else:
                url = "https://huggingface.co/papers/trending?range=month"
            
            response = requests.get(url, headers=self.headers, timeout=self.timeout)
            response.raise_for_status()
            
            papers = self._parse_hugging_face_papers(response.content, count)
            logger.info(f"Fetched {len(papers)} papers from Hugging Face")
            return papers
        
        except Exception as e:
            logger.error(f"Hugging Face fetch failed: {str(e)}")
            raise
    
    def _fetch_openreview(self, period: str, count: int, topic_filter: str) -> List[Dict]:
        """Fetch from OpenReview API (conference papers)"""
        logger.info(f"Fetching from OpenReview: period={period}, count={count}")
        
        try:
            # OpenReview for conferences (best for yearly/all-time)
            url = "https://api.openreview.net/notes"
            
            # Fetch recent conference papers
            params = {
                'venueid': 'ICLR.cc/2024/Conference',
                'limit': count,
                'details': 'all'
            }
            
            response = requests.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            
            papers = self._parse_openreview_response(response.json())
            logger.info(f"Fetched {len(papers)} papers from OpenReview")
            return papers
        
        except Exception as e:
            logger.error(f"OpenReview fetch failed: {str(e)}")
            raise
    
    # ============================================
    # PARSING FUNCTIONS
    # ============================================
    
    def _parse_pwc_papers(self, content, count: int) -> List[Dict]:
        """Parse Papers with Code HTML"""
        soup = BeautifulSoup(content, 'html.parser')
        papers = []
        
        # This is a placeholder - actual selectors depend on current HTML structure
        # You'd need to inspect the actual website and update selectors
        
        return papers[:count]
    
    def _parse_semantic_scholar_response(self, data: List[Dict]) -> List[Dict]:
        """Parse Semantic Scholar API response"""
        papers = []
        
        for item in data:
            paper = {
                'id': item.get('paperId', f"s2_{item['title']}"),
                'title': item.get('title', 'Unknown'),
                'authors': ', '.join([a['name'] for a in item.get('authors', [])[:3]]),
                'year': item.get('year', datetime.now().year),
                'citations': item.get('citationCount', 0),
                'growth_daily': 0,
                'growth_weekly': 0,
                'abstract': item.get('abstract', ''),
                'url': item.get('url', ''),
                'keywords': [],
                'highlights': [],
                'source': 'semantic-scholar'
            }
            papers.append(paper)
        
        return papers
    
    def _parse_arxiv_response(self, content) -> List[Dict]:
        """Parse arXiv API XML response"""
        # This would parse arXiv's Atom feed
        # Placeholder for actual implementation
        return []
    
    def _parse_hugging_face_papers(self, content, count: int) -> List[Dict]:
        """Parse Hugging Face Papers HTML"""
        # Placeholder for BeautifulSoup parsing
        return []
    
    def _parse_openreview_response(self, data: Dict) -> List[Dict]:
        """Parse OpenReview API response"""
        papers = []
        
        for note in data.get('notes', [])[:5]:
            paper = {
                'id': note.get('id', f"or_{note['title']}"),
                'title': note.get('content', {}).get('title', 'Unknown'),
                'authors': ', '.join(note.get('content', {}).get('authors', [])[:3]),
                'year': datetime.now().year,
                'citations': 0,  # OpenReview doesn't provide citation counts
                'growth_daily': 0,
                'growth_weekly': 0,
                'abstract': note.get('content', {}).get('abstract', ''),
                'url': f"https://openreview.net/forum?id={note['id']}",
                'keywords': [],
                'highlights': [],
                'source': 'openreview'
            }
            papers.append(paper)
        
        return papers
    
    def _get_mock_papers(self, count: int) -> List[Dict]:
        """Return mock papers as fallback"""
        mock_papers = [
            {
                'id': f'mock_{i}',
                'title': f'Sample Paper {i+1}: Advanced Techniques in Machine Learning',
                'authors': f'Author {i+1}, Co-author {i+1}',
                'year': 2024,
                'citations': 1000 + (i * 200),
                'growth_daily': 45 - (i * 5),
                'growth_weekly': 312 - (i * 20),
                'abstract': 'This is a sample paper abstract for testing purposes.',
                'url': 'https://arxiv.org/abs/2024.00000',
                'keywords': ['ML', 'AI', 'Deep Learning'],
                'highlights': ['Innovation A', 'Innovation B'],
                'source': 'mock'
            }
            for i in range(count)
        ]
        return mock_papers
