# KHẢO SÁT TÀI LIỆU SOTA — Tối ưu hóa Hiệu năng cho Mô hình Diffusion
## *State-of-the-Art Survey — Efficiency Optimization Strategies for Diffusion Models*

**Ngày khảo sát:** 17/07/2026 · **Cập nhật:** 24/07/2026 (rà soát Paper-Notes 2024–2026 — xem [SURVEY-PaperNotes-2024-2026.md](SURVEY-PaperNotes-2024-2026.md)). · **Cửa sổ SOTA:** 2024–2026 · **Nguồn:** arXiv & hội nghị uy tín (CVPR, ICCV, ECCV, NeurIPS, ICML, ICLR/OpenReview, SIGGRAPH, ACM MM).

> **Quy ước đếm:** Mỗi nhóm tách 2 cụm:
> - 🆕 **SOTA (2024–2026)** — đánh số 1…N, **là số lượng được tính**.
> - 📌 **Paper gốc / nền tảng / tiền thân** — gom riêng ở cuối mỗi nhóm (đa số 2021–2023), đánh dấu A1…, **KHÔNG tính vào hạn mức** (giữ lại để truy nguồn phương pháp). *(Cập nhật 24/07: một vài pillar 2024–2025 đã bị bản 2026 vượt qua nay được ghi chú "tiền thân trực tiếp / cơ sở" — vẫn giữ ở cụm SOTA để truy vết, nhưng vai trò-trục lùi về nền — xem • "Cập nhật SOTA 2026" dưới.)*
>
> **Xác minh:** Mọi paper đều được fetch trang arXiv `/abs/` (hoặc OpenReview/CVF) khớp tiêu đề + tác giả + năm. Các arXiv ID bịa (tiền tố năm 2602–2607…) đã bị loại. **Tổng (bản 17/07): 53 SOTA + 19 gốc.** **Bổ sung 24/07: +9 SOTA 2026 đã đọc-note/xác minh** (Phased DMD, DiffSparse, 2ndMatch, AccuQuant, Sampling-Aware Quant, TWEO, Otil + HiCache/DisCa đã có) và **+3 tham chiếu chéo-miền LLM** (Spark Transformer, PermLLM, Homogeneous-Keys-Heterogeneous-Values — không tính vào hạn mức diffusion).

---

## ⭐ Cập nhật SOTA 2026 (rà soát Paper-Notes, 24/07/2026) — nâng cấp SOTA-trục, hạ pillar cũ xuống "cơ sở"

> Rà soát các hội nghị mới nhất (**ICLR 2026, CVPR 2026, ICML 2026, NeurIPS 2025, ICCV 2025**) cho **3 bản nâng cấp trực tiếp** các pillar-trục đang dùng trong [PROPOSAL.md](../../PROPOSAL.md). Nguyên tắc: **SOTA-hiện-hành = bản 2026; pillar 2024–2025 lùi về "tiền thân / cơ sở-hàm" của chính nó** (giữ trong bảng để truy vết, nhưng vai trò-trục do bản mới đảm nhiệm).

| Trục | Pillar cũ → **lùi về cơ sở** | **SOTA 2026 mới (đầu trục)** | Quan hệ | Nguồn đã đọc-note |
|---|---|---|---|---|
| **Caching / forecast** (Nhóm 4) | TaylorSeer (#7, ICCV 25) → *cơ sở-hàm* | **HiCache** (#9, ICLR 26, arXiv 2508.16984) | Đổi cơ sở đơn thức Taylor → **Hermite** (đạo hàm feature ~Gaussian); plug-and-play 0 FLOPs, **cùng nhóm tác giả** TaylorSeer | [HiCache.md](../readpaper/HiCache.md) |
| **Distillation** (Nhóm 1) | DMD2 (#6, NeurIPS 24 Oral) → *cơ sở* | **Phased DMD** (#12, CVPR 26, arXiv 2510.27684) | MoE-theo-pha trên khoảng SNR; **khôi phục diversity/motion** mà SGTS của DMD2 làm sập; *không thêm chi phí suy luận* | [Phased-DMD.md](../readpaper/Phased-DMD.md) |
| **Đa-GPU / hệ thống** (Nhóm 6B) | DistriFusion (#8, CVPR 24) → *tham chiếu lịch sử* | **Otil** (#14, CVPR 26) | Chỉ truyền ~25% sub-block đổi nhiều nhất, **−75% giao tiếp**, **nhắm PCIe không-NVLink** (SDXL 2-GPU 1.88× vs 1.50×) | [Otil.md](../readpaper/Otil.md) |

**Bổ sung liên quan Đóng góp 1 (pruning attn/MLP học được) — thêm vào Nhóm 3:** DiffSparse (#12, learned token-sparsity khả vi), 2ndMatch (#13, finetune-phục-hồi model đã prune), AccuQuant (#14, mô phỏng đa-bước khi calibrate), Sampling-Aware Quantization (#15), TWEO (#16, khử outlier cho FP8). **Tham chiếu chéo-miền LLM (KHÔNG tính hạn mức diffusion):** Spark Transformer (FFN & attn *đối xứng* — phản đề RQ0a), PermLLM (N:M *học được*), Homogeneous-Keys-Heterogeneous-Values (tiền lệ *bất đối xứng* hai thành phần).

> **Cảnh báo bão hòa (trục caching):** rà soát bắt được **≥15 bài caching/forecast 2025–2026** (HiCache, DiCache, DPCache, ResCa, ScalingCache, ERTACache, D2Cache, Evolutionary Caching, MeanCache, Budget-Step Caching, Adaptive Spectral Forecasting, TAP, LESA, RAPID³, TimeRipples…). ⇒ Caching **chỉ là trục tiêu thụ**, tuyệt đối không đặt làm đóng góp thuật toán.

---

## Nhóm 1 — Distillation (chưng cất)

### 🆕 SOTA 2024–2026 *(tính hạn mức: 12 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| 1 | SDXL-Lightning: Progressive Adversarial Diffusion Distillation | Shanchuan Lin, 2024 | arXiv (ByteDance) | https://arxiv.org/abs/2402.13929 | Kết hợp progressive + adversarial → SOTA 1/few-step ở 1024px, phát hành LoRA & full UNet. | ✅ |
| 2 | Trajectory Consistency Distillation (TCD) | Jianbin Zheng, 2024 | arXiv | https://arxiv.org/abs/2402.19159 | Hàm consistency theo quỹ đạo (semi-linear) + stochastic sampling → giảm sai số distillation, tốt ở NFE thấp. | ✅ |
| 3 | Latent Adversarial Diffusion Distillation (LADD / SD3-Turbo) | Axel Sauer, 2024 | SIGGRAPH Asia 2024 | https://arxiv.org/abs/2403.12015 | Đưa ADD vào latent space dùng generative features của LDM → huấn luyện đơn giản, đa tỉ lệ. | ✅ |
| 4 | Score identity Distillation (SiD) | Mingyuan Zhou, 2024 | ICML 2024 | https://arxiv.org/abs/2404.04057 | Data-free, dùng 3 score identity chưng cất generator 1 bước, giảm FID nhanh theo hàm mũ, sánh/vượt teacher. | ✅ |
| 5 | Hyper-SD: Trajectory Segmented Consistency Model | Yuxi Ren, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2404.13686 | Trajectory Segmented Consistency Distillation + human feedback + score distillation → SOTA 1–8 bước qua LoRA. | ✅ |
| 6 | Improved DMD (DMD2) | Tianwei Yin, 2024 | NeurIPS 2024 (Oral) | https://arxiv.org/abs/2405.14867 | Bỏ dataset hồi quy tốn kém + two-time-scale + adversarial → SOTA few-step (~500× rẻ hơn). **⤵ 24/07: lùi về *cơ sở* — bị Phased DMD (#12) vượt ở diversity/motion.** | ✅ |
| 7 | Phased Consistency Models (PCM) | Fu-Yun Wang, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2405.18407 | Chia quỹ đạo ODE thành đoạn con + adversarial consistency loss, sửa 3 lỗi LCM, vượt LCM ở 1–16 bước. | ✅ |
| 8 | SwiftBrush v2 | Trung Dao, 2024 | ECCV 2024 | https://arxiv.org/abs/2408.14176 | Cải tiến one-step qua khởi tạo SD-Turbo + LoRA + clamped CLIP loss → vượt teacher nhiều bước (FID 8.14). | ✅ |
| 9 | Simplifying, Stabilizing & Scaling Continuous-Time CM (sCM) | Cheng Lu, 2024 | arXiv (OpenAI) | https://arxiv.org/abs/2410.11081 | Ổn định hóa CM thời gian liên tục, scale tới 1.5B tham số, đạt chất lượng diffusion trong 2 bước. | ✅ |
| 10 | Mean Flows for One-step Generative Modeling (MeanFlow) | Zhengyang Geng, 2025 | NeurIPS 2025 (Oral) | https://arxiv.org/abs/2505.13447 | Mô hình hóa vận tốc trung bình → sinh 1 bước từ đầu (không distillation), FID 3.43 (1-NFE) ImageNet 256. | ✅ |
| 11 | Score-Regularized Continuous-Time Consistency (rCM) | Kaiwen Zheng, 2025 | arXiv (NVIDIA) | https://arxiv.org/abs/2510.08431 | Score distillation làm regularizer "mode-seeking" + kernel FlashAttention-2 JVP → scale CM 14B, 1–4 bước, 15–50×. | ✅ |
| 12 ⭐ | **Phased DMD** — Few-step DMD via Score Matching within Subintervals | Xiangyu Fan, 2025 | CVPR 2026 | https://arxiv.org/abs/2510.27684 | **Nâng cấp trực tiếp DMD2 (#6):** chia dải SNR thành khoảng con + MoE-theo-pha (không thêm chi phí suy luận) → khôi phục diversity (T2I) & motion (T2V) mà SGTS của DMD2 làm sập; distill Qwen-Image-20B / Wan2.2-28B. | ✅ (đã đọc-note; số bảng chưa) |

### 📌 Paper gốc — KHÔNG tính hạn mức *(4 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| A1 | Consistency Models | Yang Song, 2023 | ICML 2023 | https://arxiv.org/abs/2303.01469 | Gốc của consistency model: ánh xạ trực tiếp noise→data, sinh 1 bước không adversarial. | ✅ |
| A2 | Latent Consistency Models (LCM) | Simian Luo, 2023 | arXiv | https://arxiv.org/abs/2310.04378 | Đưa consistency distillation vào latent space → sinh 2–4 bước từ LDM. | ✅ |
| A3 | Distribution Matching Distillation (DMD) | Tianwei Yin, 2023 | CVPR 2024 | https://arxiv.org/abs/2311.18828 | Gốc của DMD: chưng cất 1 bước bằng khớp phân phối qua gradient hiệu score. | ✅ |
| A4 | Adversarial Diffusion Distillation (ADD / SDXL-Turbo) | Axel Sauer, 2023 | ICML 2024 | https://arxiv.org/abs/2311.17042 | Gốc của ADD: score distillation + adversarial loss → sinh 1–4 bước. | ✅ |

---

## Nhóm 2 — Fast Solvers / Samplers (tăng tốc không cần huấn luyện)

### 🆕 SOTA 2024–2026 *(tính hạn mức: 10 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| 1 | Bespoke Non-Stationary Solvers | Neta Shaul, 2024 | arXiv | https://arxiv.org/abs/2403.01329 | Solver-distillation: fit tham số solver non-stationary (~1% chi phí train) theo mô hình cho sẵn. | ✅ |
| 2 | On the Trajectory Regularity of ODE-based Sampling (GITS) | Defang Chen, 2024 | ICML 2024 | https://arxiv.org/abs/2405.11326 | Khai thác tính đều của quỹ đạo ODE + quy hoạch động tối ưu lịch thời gian cho few-step. | ✅ |
| 3 | Accelerating Diffusion with Parallel Sampling (PIADM) | Haoxuan Chen, 2024 | NeurIPS 2024 (Spotlight) | https://arxiv.org/abs/2405.15986 | Chia sampling thành O(1) block giải bằng lặp Picard song song → độ phức tạp dưới tuyến tính có chứng minh. | ✅ |
| 4 | PFDiff: Combining Past and Future Scores | Guangyi Wang, 2024 | arXiv | https://arxiv.org/abs/2408.08822 | Bỏ bước dựa score quá khứ + cập nhật "foresight" tương lai sửa sai số rời rạc, giảm NFE cho solver sẵn có. | ✅ |
| 5 | DC-Solver: Dynamic Compensation Predictor-Corrector | Wenliang Zhao, 2024 | ECCV 2024 | https://arxiv.org/abs/2409.03755 | Bù động thích ứng từng bước (tối ưu trên ~10 điểm) sửa lệch predictor-corrector khi CFG cao → ~5 bước. | ✅ |
| 6 | BELM: Bidirectional Explicit Linear Multi-step Sampler | Fangyikang Wang, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2410.07273 | Multistep tuyến tính bước biến thiên + ràng buộc hai chiều → inversion chính xác toán học + sampling chất lượng cao. | ✅ |
| 7 | Taming Rectified Flow (RF-Solver) | Jiangshan Wang, 2024 | ICML 2025 | https://arxiv.org/abs/2411.04746 | ODE solver cho rectified flow dùng Taylor bậc cao giảm sai số (inversion/editing). | ✅ |
| 8 | Leveraging Previous Steps (flow solver) | Kaiyu Song, 2024 | arXiv | https://arxiv.org/abs/2411.07627 | Tái dùng output các bước trước qua nội suy đa thức/Taylor để giảm NFE. | ✅ |
| 9 | Differentiable Solver Search | Shuai Wang, 2025 | arXiv | https://arxiv.org/abs/2505.21114 | Tìm kiếm khả vi hệ số/timestep solver tối ưu cho chất lượng cao ở rất ít bước. | ✅ |
| 10 | A-FloPS: Adaptive Flow Path Sampler | Cheng Jin, 2025 | arXiv | https://arxiv.org/abs/2509.00036 | Reparameterize sang flow-matching + phân rã vận tốc thích ứng, tích phân bậc cao ~5 NFE. | ✅ |

### 📌 Paper gốc — KHÔNG tính hạn mức *(5 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| A1 | DPM-Solver | Cheng Lu, 2022 | NeurIPS 2022 (Oral) | https://arxiv.org/abs/2206.00927 | Gốc solver exponential-integrator, ~10–20 NFE. | ✅ |
| A2 | DPM-Solver++ | Cheng Lu, 2022 | arXiv | https://arxiv.org/abs/2211.01095 | Multistep data-prediction bậc cao + thresholding, ổn định guided sampling. | ✅ |
| A3 | DEIS | Qinsheng Zhang, 2022 | ICLR 2023 | https://arxiv.org/abs/2204.13902 | Exponential integrator khai thác cấu trúc ODE bán tuyến tính → 10 bước. | ✅ |
| A4 | UniPC | Wenliang Zhao, 2023 | NeurIPS 2023 | https://arxiv.org/abs/2302.04867 | Predictor + corrector bậc tùy ý; corrector tăng độ chính xác không tốn NFE. | ✅ |
| A5 | SA-Solver | Shuchen Xue, 2023 | NeurIPS 2023 | https://arxiv.org/abs/2309.05019 | SDE multistep Adams solver với phương sai giải tích cho sampling ngẫu nhiên few-step. | ✅ |

---

## Nhóm 3 — Quantization & Pruning

### 🆕 SOTA 2024–2026 *(tính hạn mức: 16 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| 1 | PTQ4DiT: Post-training Quantization for DiT | Junyi Wu, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2405.16005 | PTQ cho DiT với Channel-wise Salience Balancing + hiệu chỉnh theo Spearman ρ (kênh nổi trội & khó theo timestep). | ✅ |
| 2 | ViDiT-Q: Quantization for Image & Video DiT | Tianchen Zhao, 2024 | ICLR 2025 | https://arxiv.org/abs/2406.02540 | PTQ nhận biết token/timestep + mixed precision → W8A8 không mất mát, W4A8 gần như không mất mát. | ✅ |
| 3 | Q-DiT (PTQ cho DiT) | Lei Chen, 2024 | arXiv | https://arxiv.org/abs/2406.17343 | PTQ riêng cho DiT: tự phân bổ granularity + dynamic activation quantization theo mẫu. | ✅ |
| 4 | DilateQuant (QAT via Weight Dilation) | Xuewen Liu, 2024 | ACM MM 2025 | https://arxiv.org/abs/2409.14307 | QAT dùng Weight Dilation thu hẹp dải activation giữ weight + Temporal Parallel Quantizer + distillation block. | ✅ |
| 5 | SVDQuant (4-bit) | Muyang Li, 2024 | arXiv | https://arxiv.org/abs/2411.05007 | Hấp thụ outlier vào nhánh low-rank độ chính xác cao → suy luận W4A4. | ✅ |
| 6 | TinyFusion (depth pruning DiT) | Gongfan Fang, 2024 | CVPR 2025 (Highlight) | https://arxiv.org/abs/2412.01199 | Pruning độ sâu học được, khả vi, nhận biết khả năng phục hồi; 2× tốc độ, <7% chi phí pre-train. | ✅ |
| 7 | MPQ-DM (mixed precision extreme low-bit) | Weilun Feng, 2024 | arXiv | https://arxiv.org/abs/2412.11549 | Phân bổ bit-width theo outlier + distillation quan hệ làm mượt theo thời gian. | ✅ |
| 8 | QVGen (video quantization) | Yushi Huang, 2025 | arXiv | https://arxiv.org/abs/2505.11497 | QAT với phân tích gradient-norm + module phụ suy giảm, lần đầu lượng tử 3/4-bit hiệu quả cho video diffusion. | ✅ |
| 9 | PQCAD-DM | Beomseok Ko, 2025 | arXiv | https://arxiv.org/abs/2506.16776 | Progressive quantization + calibration-assisted distillation, giảm nửa thời gian suy luận. | ✅ |
| 10 | OBS-Diff (one-shot pruning) | Junhan Zhu, 2025 | arXiv | https://arxiv.org/abs/2510.06751 | Optimal Brain Surgeon cho T2I diffusion với Hessian theo timestep, pruning one-shot theo nhóm. | ✅ |
| 11 | MosaicDiff (training-free pruning) | Bowei Guo, 2025 | ICCV 2025 | https://arxiv.org/abs/2510.11962 | Pruning cấu trúc training-free khớp mức prune với các pha tốc độ học pretraining → tăng tốc DiT/SDXL. | ✅ |
| 12 ⭐ | **DiffSparse** — Accelerating DiT with **Learned** Token Sparsity | (ICLR 2026) | ICLR 2026 | [OpenReview V3eUas3VCL](https://openreview.net/forum?id=V3eUas3VCL) | **Họ hàng gần nhất về *tinh thần* Đóng góp 1:** mask *khả vi + học được* + ngân sách (STE + DP) — nhưng ở mức **token-caching/recompute**, KHÔNG tách attn/MLP cấu trúc. Phải phân biệt kỹ. | ✅ (đã đọc-note) |
| 13 ⭐ | **2ndMatch** — Finetuning Pruned Diffusion via 2nd-Order Jacobian Matching | (CVPR 2026) | CVPR 2026 | https://arxiv.org/abs/2506.05398 | *Không prune* — chỉ **finetune phục hồi** model đã prune (khớp J⊤J). **Baseline cho khâu phục hồi** của Đóng góp 1 (so với LoRA-proxy). | ✅ (đã đọc-note) |
| 14 | **AccuQuant** — Simulating Multiple Denoising Steps for Quantizing | (NeurIPS 2025) | NeurIPS 2025 | [note](https://en.papernotes.org/NeurIPS2025/image_generation/accuquant_simulating_multiple_denoising_steps_for_quantizing/) | Mô phỏng nhiều bước khử nhiễu khi calibrate → giảm **tích lũy sai số lượng tử qua nhiều bước**. Vật liệu trực tiếp cho RQ1 (nhiễu × forecast). | ⏳ (verify arXiv/accepted) |
| 15 | **Sampling-Aware Quantization for Diffusion** | (CVPR 2026) | CVPR 2026 | [note](https://en.papernotes.org/CVPR2026/model_compression/sampling-aware_quantization_for_diffusion_models/) | Lượng tử **nhận-biết-lấy-mẫu** (đa bước) — bổ trợ/đối thủ SVDQuant; nuôi RQ1. | ⏳ (verify) |
| 16 | **TWEO** — Transformers Without Extreme Outliers (FP8) | (CVPR 2026) | CVPR 2026 | [note](https://en.papernotes.org/CVPR2026/model_compression/tweo_transformers_without_extreme_outliers_enables_fp8_training_and_quantization/) | Khử outlier để FP8 dễ — **liên quan phân tích outlier hai tầng** (kernel attn × SVDQuant, PROPOSAL • 3c). | ⏳ (verify) |

> **Tham chiếu chéo-miền LLM cho Đóng góp 1 (KHÔNG tính hạn mức diffusion — dùng ở Related Work):**
> - **Spark Transformer** (NeurIPS 2025, arXiv 2506.06644) — activation-sparsity xử lý **FFN & attention ĐỐI XỨNG** (cùng khung KV-lookup, LLM). **Phản đề trực tiếp cho RQ0a:** họ giả định đối xứng; luận án kiểm định *bất đối xứng* attn/MLP có lợi hơn.
> - **PermLLM** (NeurIPS 2025) — hoán vị kênh *học được* cho **N:M** sparsity → tựa luận điểm "**mật độ prune biến thiên thay N:M cứng**".
> - **Homogeneous Keys, Heterogeneous Values** (NeurIPS 2025) — khai thác *bất đối xứng* K vs V trong KV-cache → **tiền lệ khái niệm** "hai thành phần trong một khối có bản chất khác → xử lý khác".
> - Phụ: **LEAP** (ICML 2026, learnable end-to-end pruning), **What Layers When** / **ReplaceMe** (learned layer-skip / depth-prune ngoài diffusion).

### 📌 Paper gốc — KHÔNG tính hạn mức *(4 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| A1 | Q-Diffusion | Xiuyu Li, 2023 | ICCV 2023 | https://arxiv.org/abs/2302.04304 | Gốc PTQ data-free cho diffusion: hiệu chỉnh theo timestep + split shortcut quantization → 4-bit. | ✅ |
| A2 | PTQD | Yefei He, 2023 | NeurIPS 2023 | https://arxiv.org/abs/2305.10657 | Tách nhiễu lượng tử tương quan/không tương quan và hiệu chỉnh từng phần. | ✅ |
| A3 | Diff-Pruning (Structural Pruning) | Gongfan Fang, 2023 | NeurIPS 2023 | https://arxiv.org/abs/2305.10924 | Gốc pruning cấu trúc cho diffusion dựa Taylor qua timestep, cắt ~50% FLOPs. | ✅ |
| A4 | EfficientDM (QAT low-bit) | Yefei He, 2023 | ICLR 2024 (Spotlight) | https://arxiv.org/abs/2310.03270 | QAT data-free qua QALoRA + distillation, độ chính xác QAT ở chi phí gần PTQ. | ✅ |

---

## Nhóm 4 — Caching & Feature Reuse

### 🆕 SOTA 2024–2026 *(tính hạn mức: 11 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| 1 | Δ-DiT: Training-Free Acceleration for DiT | Pengtao Chen, 2024 | arXiv | https://arxiv.org/abs/2406.01125 | Δ-Cache thích ứng theo giai đoạn, cache độ lệch giữa feature map (thay vì bản thân map), riêng cho DiT. | ✅ |
| 2 | Learning-to-Cache (DiT) | Xinyin Ma, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2406.01733 | Học lịch cache theo lớp, khả vi, cho DiT — bỏ tới 93.68% tính toán bước cache. | ✅ |
| 3 | FORA: Fast-Forward Caching for DiT | Pratheba Selvaraju, 2024 | arXiv | https://arxiv.org/abs/2407.01425 | Cache lịch tĩnh, lưu & tái dùng output attention/MLP qua các bước dựa độ tương đồng cao giữa timestep. | ✅ |
| 4 | ToCa (Token-wise Feature Caching) | Chang Zou, 2024 | ICLR 2025 | https://arxiv.org/abs/2410.05317 | Cache đặc trưng theo token thích ứng cho DiT, chọn token dễ cache + tỉ lệ khác nhau theo lớp. | ✅ |
| 5 | FasterCache (video) | Zhengyao Lv, 2024 | ICLR 2025 | https://arxiv.org/abs/2410.19355 | Tái dùng attention-feature động + CFG-Cache cho video, giữ chi tiết thời gian. | ✅ |
| 6 | TeaCache (video) | Feng Liu, 2024 | CVPR 2025 | https://arxiv.org/abs/2411.19108 | Ước lượng thay đổi output không đều theo timestep để quyết định khi nào cache — tới 4.41× video. | ✅ |
| 7 | TaylorSeer (forecast caching) | Jiacheng Liu, 2025 | ICCV 2025 | https://arxiv.org/abs/2503.06923 | Chuyển "tái dùng" sang "dự báo" đặc trưng bước tương lai bằng Taylor (~5× FLUX/HunyuanVideo). **⤵ 24/07: lùi về *cơ sở-hàm* — HiCache (#9) đổi đơn thức→Hermite làm đầu-trục.** | ✅ |
| 8 | EasyCache: Runtime-Adaptive Caching (video) | Xin Zhou, 2025 | arXiv | https://arxiv.org/abs/2507.02860 | Cache thích ứng runtime, quyết định tái dùng online từ động lực bậc một nhẹ, không cần profiling offline. | ✅ |
| 9 ⭐ | **HiCache** (Scaled-Hermite forecasting) — *đầu-trục caching* | Liang Feng, 2025 | **ICLR 2026** · arXiv | https://arxiv.org/abs/2508.16984 | **Nâng cấp cơ-sở-hàm của TaylorSeer (#7):** đạo hàm feature DiT ~Gaussian → đa thức **Hermite** (Karhunen–Loève) tối ưu hơn đơn thức; dual-scaling, **0 FLOPs, training-free, plug-in lên cả họ caching**; 5.55× FLUX chất lượng ≥ gốc. *Cùng nhóm tác giả TaylorSeer.* | ✅ (abs xác minh) |
| 10 | SpeCa: Speculative Feature Caching | Jiacheng Liu, 2025 | ACM MM 2025 | https://arxiv.org/abs/2509.11628 | Khung "forecast-then-verify" dùng speculative sampling dự báo feature + cơ chế verify accept/reject không tham số. | ✅ |
| 11 | DisCa: Distillation-Compatible **Learnable** Feature Caching (video) | Chang Zou, 2026 | CVPR 2026 | https://arxiv.org/abs/2602.05449 | Lần đầu caching *học được* + tương thích distillation: **predictor nơ-ron nhẹ (~4% mô hình) thay heuristic** + Restricted MeanFlow (giới hạn khoảng flow) + GAN → 11.8× trên HunyuanVideo, gần như không mất chất lượng. | ✅ (abs xác minh; số bảng chưa) |

> **Định vị:** DisCa **không cùng nhóm** với 10 bài trên. Bài 1–10 (kể cả TeaCache #6, TaylorSeer #7) là caching **training-free / heuristic**; DisCa là **caching học được + tương thích distillation** — một *danh mục con mới* mà nó mở màn. So sánh trực tiếp speedup với training-free là **không cùng điều kiện** (DisCa cần huấn luyện predictor trên mô hình đã distill). Cùng tác giả Chang Zou với ToCa (#4). Số liệu bảng (11.8×, VBench) đọc tự động từ HTML → **đối chiếu PDF trước khi trích**.

### 📌 Paper gốc — KHÔNG tính hạn mức *(3 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| A1 | DeepCache | Xinyin Ma, 2023 | CVPR 2024 | https://arxiv.org/abs/2312.00858 | Gốc caching cho diffusion: cache & tái dùng đặc trưng U-Net bậc cao qua các bước. | ✅ |
| A2 | Cache Me if You Can (Block Caching) | Felix Wimbauer, 2023 | CVPR 2024 | https://arxiv.org/abs/2312.03209 | Tái dùng output từng block U-Net theo lịch cache tự động dựa độ thay đổi. | ✅ |
| A3 | Token Merging for Fast SD (ToMe) | Daniel Bolya, 2023 | CVPR-W 2023 | https://arxiv.org/abs/2303.17604 | Gộp token dư thừa trong transformer block của SD (giảm tới 60% token) → ~2×. | ✅ |

---

## Nhóm 5 — Efficient Architectures

### 🆕 SOTA 2024–2026 *(tính hạn mức: 11 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| 1 | U-DiTs: Downsample Tokens in U-Shaped DiT | Yuchuan Tian, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2405.02730 | DiT hình chữ U + downsample token trên QKV trong self-attention, vượt DiT đẳng hướng ở chi phí thấp hơn nhiều. | ✅ |
| 2 | DiG (Gated Linear Attention) | Lianghui Zhu, 2024 | CVPR 2025 | https://arxiv.org/abs/2405.18428 | Đưa Gated Linear Attention dưới bậc hai vào backbone diffusion 2D → hiệu quả cao res tốt hơn DiT. | ✅ |
| 3 | LinFusion: 1 GPU, 1 Minute, 16K Image | Songhua Liu, 2024 | arXiv | https://arxiv.org/abs/2409.02097 | Linear-attention tổng quát (xấp xỉ low-rank) thay self-attention → độ phức tạp tuyến tính, sinh 16K. | ✅ |
| 4 | SANA (Linear Diffusion Transformers) | Enze Xie, 2024 | ICLR 2025 (Oral) | https://arxiv.org/abs/2410.10629 | Linear-attention DiT + AE nén sâu 32× + text encoder decoder-only → 4096² dưới 1 giây trên laptop GPU. | ✅ |
| 5 | DC-AE (Deep Compression Autoencoder) | Junyu Chen, 2024 | ICLR 2025 | https://arxiv.org/abs/2410.10733 | Residual Autoencoding + Decoupled HR Adaptation → nén không gian 128× vẫn giữ tái tạo tốt. | ✅ |
| 6 | LightningDiT / VA-VAE | Jingfeng Yao, 2025 | CVPR 2025 (Oral) | https://arxiv.org/abs/2501.01423 | Căn chỉnh latent tokenizer chiều cao với vision foundation model + LightningDiT → hội tụ ~21× nhanh, SOTA ImageNet-256. | ✅ |
| 7 | SANA 1.5 | Enze Xie, 2025 | ICML 2025 | https://arxiv.org/abs/2501.18427 | Scale linear DiT qua depth-growth + pruning độ sâu theo tầm quan trọng block + trao đổi compute lúc suy luận. | ✅ |
| 8 | DiT-Air | Chen Chen, 2025 | arXiv | https://arxiv.org/abs/2503.10618 | DiT thuần sánh kiến trúc T2I chuyên biệt + chia sẻ tham số theo lớp → mô hình nhỏ hơn ~66%. | ✅ |
| 9 | EDiT (Linear Compressed Attention) | Philipp Becker, 2025 | arXiv | https://arxiv.org/abs/2503.16726 | Attention lai (linear cho token ảnh, softmax cho prompt) → tới 2.2× trên PixArt-Σ/SD3.5-Medium. | ✅ |
| 10 | DyDiT++ (Timestep & Spatial Dynamics) | Wangbo Zhao, 2025 | arXiv | https://arxiv.org/abs/2504.06803 | Phân bổ tính toán động theo timestep & không gian, loại bỏ tính toán dư thừa trong DiT. | ✅ |
| 11 | Taming DiT for Mobile Video Generation | Yushu Wu, 2025 | arXiv | https://arxiv.org/abs/2507.13343 | VAE nén + pruning ba tầng + adversarial step distillation → ~15 fps video on-device (iPhone 16 Pro Max). | ✅ |

*Ghi chú Nhóm 5 (đính chính 18/07/2026): claim "text encoder decoder-only" của SANA (#4) **không phải đầu tiên** — Lumina-Next (https://arxiv.org/abs/2406.18583, 06/2024) đã dùng Gemma-2B làm text encoder T2I trước SANA ~4 tháng; ghi công cẩn thận khi trích SANA làm mốc "đầu tiên".*

### 📌 Paper gốc — KHÔNG tính hạn mức *(3 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | TT |
|---|-------|------------------|-------|-------------------|------------------|----|
| A1 | Latent Diffusion Models (LDM) | Robin Rombach, 2021 | CVPR 2022 | https://arxiv.org/abs/2112.10752 | Gốc latent diffusion: chạy diffusion trong latent space của autoencoder → giảm mạnh chi phí. | ✅ |
| A2 | Scalable Diffusion Models with Transformers (DiT) | William Peebles, 2022 | ICCV 2023 | https://arxiv.org/abs/2212.09748 | Gốc DiT: thay U-Net bằng transformer trên latent patch, scaling sạch. | ✅ |
| A3 | MobileDiffusion | Yang Zhao, 2023 | arXiv | https://arxiv.org/abs/2311.16567 | Gốc diffusion trên di động: tối ưu kiến trúc + sampling → T2I 512² dưới 1 giây trên điện thoại. | ✅ |

---

## Nhóm 6 — System / Kernel-level Optimization *(tối ưu tầng hệ thống / kernel)*

> Tầng **hạ tầng/phần cứng** — tăng tốc thực thi mà **không đổi công thức thuật toán** (khác Nhóm 5 dùng attention xấp xỉ, khác Nhóm 4 caching). Chia 3 nhánh con: **6A** attention kernel · **6B** distributed/parallel inference · **6C** compilation/serving/low-precision execution. Cột **"Đặc thù diffusion?"**: *yes* = làm riêng cho (video) diffusion; *general* = primitive tổng quát nhưng benchmark/áp dụng trên diffusion.

### 🆕 6A — Attention kernels (exact / quantized / sparse) *(7 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | Đặc thù diffusion? | TT |
|---|-------|------------------|-------|-------------------|------------------|--------------------|----|
| 1 | FlashAttention-3 | Jay Shah, 2024 | NeurIPS 2025 | https://arxiv.org/abs/2407.08608 | Tăng tốc exact attention trên GPU Hopper qua bất đồng bộ Tensor-Core/TMA, xen kẽ matmul–softmax, FP8 block quantization. | general | ✅ |
| 2 | SageAttention (8-bit) | Jintao Zhang, 2024 | ICLR 2025 | https://arxiv.org/abs/2410.02367 | Kernel attention lượng tử INT8 training-free, ~2× FlashAttention2, gần như không mất mát end-to-end. | general (benchmark diffusion) | ✅ |
| 3 | SageAttention2 (per-thread INT4) | Jintao Zhang, 2024 | ICML 2025 | https://arxiv.org/abs/2411.10958 | Attention lượng tử per-thread INT4 QK + FP8 PV + outlier smoothing, ~3× FlashAttention2. | general (benchmark diffusion) | ✅ |
| 4 | Sparse VideoGen | Haocheng Xi, 2025 | ICML 2025 | https://arxiv.org/abs/2502.01776 | Training-free: phân loại head thành pattern sparse Spatial/Temporal + kernel & profiler online cho DiT video. | yes (video DiT) | ✅ |
| 5 | Sliding Tile Attention (STA) | Peiyuan Zhang, 2025 | ICML 2025 | https://arxiv.org/abs/2502.04507 | Kernel sliding-window theo tile nhận biết phần cứng, khai thác attention 3D cục bộ trong video DiT (58.79% MFU). | yes (video DiT) | ✅ |
| 6 | SpargeAttention (sparse + quantized) | Jintao Zhang, 2025 | ICML 2025 | https://arxiv.org/abs/2502.18137 | Sparse + quantized attention training-free, lọc 2 giai đoạn nhận biết softmax bỏ matmul; 4–7×. | general (benchmark diffusion) | ✅ |
| 7 | Radial Attention (O(n log n) sparse) | Xingyang Li, 2025 | NeurIPS 2025 | https://arxiv.org/abs/2506.19852 | Mask sparse tĩnh O(n log n) khai thác suy giảm năng lượng không-thời gian; video dài 4×, nhanh 3.7×. | yes (long video diffusion) | ✅ |

### 🆕 6B — Distributed / Parallel Inference (đa GPU) *(7 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | Đặc thù diffusion? | TT |
|---|-------|------------------|-------|-------------------|------------------|--------------------|----|
| 8 | DistriFusion (Displaced Patch Parallelism) | Muyang Li, 2024 | CVPR 2024 | https://arxiv.org/abs/2402.19481 | Chia ảnh thành patch trên nhiều GPU, tái dùng feature map "cũ" của bước trước để giấu giao tiếp cross-patch (tới 6.1× trên 8×A100). **⤵ 24/07: lùi về *tham chiếu lịch sử* — Otil (#14) thay cho cảnh PCIe/tiêu dùng.** | yes | ✅ |
| 9 | PipeFusion (Patch-level Pipeline Parallelism) | Jiarui Fang, 2024 | NeurIPS 2025 | https://arxiv.org/abs/2405.14430 | Pipeline parallelism mức patch, chia cả ảnh lẫn lớp qua GPU, tái dùng feature map cũ 1 bước để giảm giao tiếp. | yes | ✅ |
| 10 | USP (Unified Sequence Parallelism) | Jiarui Fang, 2024 | arXiv | https://arxiv.org/abs/2405.07719 | Thống nhất DeepSpeed-Ulysses (all-to-all) + Ring-Attention thành scheme sequence-parallel lai, bền với kiến trúc & topology. | general (backbone SP cho DiT) | ✅ |
| 11 | AsyncDiff (Asynchronous Denoising) | Zigeng Chen, 2024 | NeurIPS 2024 | https://arxiv.org/abs/2406.06911 | Chia mạng noise-prediction ra nhiều thiết bị, biến denoising tuần tự thành pipeline bất đồng bộ dựa tương đồng hidden-state. | yes | ✅ |
| 12 | xDiT (Inference Engine for DiT) | Jiarui Fang, 2024 | arXiv | https://arxiv.org/abs/2411.01738 | Engine suy luận DiT thống nhất, lai Sequence Parallel + PipeFusion + CFG parallel; >10× scale đa GPU/đa node. | yes | ✅ |
| 13 | SwiftFusion (Scalable Sequence Parallelism) | Jiacheng Yang, 2026 | arXiv | https://arxiv.org/abs/2601.20273 | Engine serving DiT nhận biết topology + attention mới + giao tiếp one-sided cho sequence parallelism mở rộng (1.35× trung bình vs SOTA). | yes | ✅ |
| 14 ⭐ | **Otil** — Communication-Efficient Multi-GPU Diffusion Inference — *đầu-trục đa-GPU* | Li et al., 2025 | **CVPR 2026** | [CVF PDF](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_Otil_Accelerating_Diffusion_Model_Inference_via_Communication-Efficient_Multi-GPU_Parallelism_CVPR_2026_paper.pdf) · [code](https://github.com/uplaoli/OTIL-PROJECT) | **Thay DistriFusion (#8) cho PCIe/tiêu dùng:** chỉ truyền ~25% sub-block đổi nhiều nhất (cosine + round-robin), **−75% giao tiếp**, **nhắm PCIe không-NVLink** (SDXL 2-GPU 1.88× vs 1.50×). *Chưa xử lý GPU dị chủng (3090≠4090) → cần cân-tải kiểu STADI.* | yes | ⏳ (CVF chưa fetch được — verify số gốc) |

### 🆕 6C — Compilation / Serving / Low-precision Execution *(3 bài)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | Đặc thù diffusion? | TT |
|---|-------|------------------|-------|-------------------|------------------|--------------------|----|
| 14 | SwiftDiffusion (Efficient Serving) | Suyi Li, 2024 | arXiv | https://arxiv.org/abs/2407.02031 | Hệ thống serving end-to-end: ControlNet-as-a-Service caching, overlap LoRA bất đồng bộ, latent parallelism → giảm tới 7.8× latency trên SDXL. | yes | ✅ |
| 15 | Low-Bitwidth Floating Point Quantization | Cheng Chen, 2024 | arXiv | https://arxiv.org/abs/2408.06995 | Thực thi FP8/FP4 độ chính xác thấp cho diffusion (học làm tròn weight), vượt INT quantization ở cùng bit-width. *(cross-cutting với Nhóm 3)* | yes | ✅ |
| 16 | ML Drift (On-Device GPU Inference) | Jiuqiang Tang, 2025 | arXiv | https://arxiv.org/abs/2505.00232 | Engine suy luận GPU on-device đa nền tảng với operator fusion, chạy model sinh lớn hơn 10–100× on-device (gồm Stable Diffusion). | general (nhắm SD) | ✅ |

### 📌 Paper gốc Nhóm 6 — KHÔNG tính hạn mức *(4 bài, gom chung)*

| # | Title | Tác giả đầu, Năm | Venue | URL (đã xác minh) | Đóng góp cốt lõi | Đặc thù diffusion? | TT |
|---|-------|------------------|-------|-------------------|------------------|--------------------|----|
| A1 | Self-attention Does Not Need O(n²) Memory | Markus N. Rabe, 2021 | arXiv | https://arxiv.org/abs/2112.05682 | Chứng minh attention chỉ cần O(1) bộ nhớ — ý tưởng nền cho các fused kernel sau này. | general | ✅ |
| A2 | **FlashAttention** (Tri Dao) | Tri Dao, 2022 | NeurIPS 2022 | https://arxiv.org/abs/2205.14135 | **Gốc của cả nhóm:** thuật toán exact attention IO-aware, tiled/fused, giảm đọc/ghi HBM↔SRAM. | general | ✅ |
| A3 | FlashAttention-2 | Tri Dao, 2023 | ICLR 2024 | https://arxiv.org/abs/2307.08691 | Cải tiến phân chia công việc/song song (~2×), đạt 50–73% peak GEMM FLOPs/s. | general | ✅ |
| A4 | SnapFusion (edge runtime) | Yanyu Li, 2023 | NeurIPS 2023 | https://arxiv.org/abs/2306.00980 | UNet hiệu quả + step distillation → T2I on-device dưới 2 giây (8 bước thay vì 50). | yes | ✅ |

*Ghi chú:*
- *Pyramid Attention Broadcast (2408.12588) đã xác minh nhưng broadcast attention qua timestep → thuộc **Nhóm 4 (caching)**, không xếp ở đây.*
- *MobileDiffusion (2311.16567) là một bài serving/edge phù hợp Nhóm 6 nhưng **đã nằm ở Nhóm 5 (A3)** → không liệt kê trùng.*
- *Low-Bitwidth FP (mục 15) là **cross-cutting** với Nhóm 3 (quantization) — xếp ở đây vì nhấn mạnh thực thi phần cứng FP8/FP4.*

---

## Tổng kết độ phủ

| Nhóm | 🆕 SOTA (tính) | 📌 Gốc / tham chiếu (không tính) | Tổng xác minh |
|---|---|---|---|
| 1. Distillation | **12** *(+Phased DMD)* | 4 | 16 |
| 2. Fast solvers | **10** | 5 | 15 |
| 3. Quantization & Pruning | **16** *(+DiffSparse, 2ndMatch, AccuQuant, Sampling-Aware Q, TWEO)* | 4 + 3 tham chiếu LLM | 23 |
| 4. Caching & feature reuse | **11** | 3 | 14 |
| 5. Efficient architectures | **11** | 3 | 14 |
| 6. System / Kernel-level optimization | **17** *(+Otil)* | 4 | 21 |
| **Tổng** | **77 🆕** | **23 📌 + 3 tham chiếu LLM** | **103** |

Trong đó Nhóm 6 gồm 3 nhánh: **6A** attention kernel (7) · **6B** distributed/parallel inference (**7**, +Otil) · **6C** compilation/serving/execution (3).

**Cập nhật 24/07/2026 (rà soát Paper-Notes):** +9 SOTA 2026 (Phased DMD, DiffSparse, 2ndMatch, AccuQuant, Sampling-Aware Quant, TWEO, Otil — cùng HiCache/DisCa đã có từ bản 17/07) + 3 tham chiếu chéo-miền LLM. Ba trục có **bản 2026 vượt pillar** (caching, distillation, đa-GPU) — xem • "Cập nhật SOTA 2026" ở đầu tài liệu. Các mục đánh dấu ⏳ cần verify khâu accepted + link gốc trước khi trích dẫn luận văn.

**Ghi chú:** hạn mức SOTA/nhóm đều **≥10 bài (2024–2026)**. 23 paper gốc giữ nguyên nhưng gom riêng, dùng cho phần "Background" của Related Work.

**Về Nhóm 6 (nơi FlashAttention thuộc về):** đây là tầng **hạ tầng/kernel**, cross-cutting — hỗ trợ cả 5 nhóm còn lại. FlashAttention (Tri Dao) là **paper gốc (A2)**, không phải đề xuất SOTA mới trong cửa sổ. Trong luận văn nên định vị nhóm này là *enabler triển khai* (exact/không đổi chất lượng), tách khỏi các đóng góp thuật toán đặc thù diffusion. Đáng chú ý: nhánh SOTA của nhóm (SageAttention/SpargeAttention của Jintao Zhang — đồng tác giả rCM) cho thấy kernel tối ưu và distillation quy mô lớn đang hội tụ.

## Lập luận cho hướng cải tiến luận văn — "tiêu chí cố định → tiêu chí *học được*, tương thích phục hồi"

*(Mạch lập luận này rút ra từ toàn survey, dùng để biện minh cho hướng: cắt attention/MLP độc lập theo **recoverability học được** thay vì tiêu chí cố định — xem [[thesis-pruning-direction]].)*

**Quan sát meta xuyên các nhóm nén.** Ở mọi nhóm, ranh giới SOTA dịch theo cùng một hướng: **thay quy tắc tĩnh/heuristic bằng một thành phần *học được, khả vi, và tương thích với bước phục hồi***.

| Trục nén | Thế hệ "tiêu chí **cố định** / heuristic" | Thế hệ "tiêu chí **học được** / tương thích phục hồi" | Điều thắng thêm được |
|---|---|---|---|
| **Caching** (Nhóm 4) | TeaCache #6, TaylorSeer #7 — công thức tái dùng/ dự báo thủ công theo timestep | Learning-to-Cache #2 (lịch cache khả vi), **DisCa #11 (predictor nơ-ron thay heuristic, huấn luyện *trên* mô hình đã distill)** | Giữ chất lượng ở mức nén cao hơn hẳn; DisCa trụ được cả khi quỹ đạo bị làm thưa bởi distillation — chỗ heuristic sụp đổ |
| **Pruning** (Nhóm 3) | Diff-Pruning A3, OBS-Diff #10, MosaicDiff #11 — tiêu chí cố định (Taylor / Hessian / training-free) | **TinyFusion #6 — depth pruning học được, khả vi, *nhận biết khả năng phục hồi (recoverability-aware)***; **DiffSparse #12 (token-sparsity *học được*, khả vi STE+DP)** | Chọn cấu trúc cắt tối ưu *cho* bước finetune sau đó, không phải tối ưu sai số tức thời |
| **Distillation** (Nhóm 1) | DMD/DMD2 — một-bước + SGTS *cố định* (kéo về 1-bước) | **Phased DMD #12 — experts *học được* theo pha SNR** | Khôi phục diversity/motion mà lịch một-bước cố định làm sập |
| **Đa-GPU** (Nhóm 6B) | DistriFusion #8 — phát *toàn bộ* feature map (lịch giao tiếp cố định) | **Otil #14 — chọn *thích ứng* ~25% sub-block đổi nhiều nhất** | Bám đúng cái thực sự thay đổi → −75% giao tiếp trên PCIe |

*(Cập nhật 24/07: cùng mô-típ "cố định → thích ứng/học được" nay hiện ở **cả 4 trục** đang dùng, không chỉ caching + pruning.)*

**Suy ra cho luận văn.** DisCa là bằng chứng mới nhất (CVPR 2026) rằng mô-típ "**heuristic cố định → dự đoán học được + tương thích với kỹ thuật nén/phục hồi kèm theo**" *đẩy được biên giới nén ngay ở chế độ khắc nghiệt nhất* (đã distilled + few-step, nơi mọi giả định tĩnh gãy). Đây chính là đòn bẩy lập luận cho đề xuất của luận văn:

1. **Vấn đề của tiêu chí cố định.** Cắt attention/MLP theo magnitude/Taylor tĩnh giả định "tầm quan trọng đo *trước* finetune ≈ tổn thất *sau* finetune" — giả định này sai đúng như "adjacent-step similarity" sai sau distillation trong DisCa.
2. **Đề xuất.** Cắt **độc lập attention vs. MLP** theo một tín hiệu **recoverability học được** (khả vi, tối ưu *cho* bước phục hồi), thay vì một ngưỡng cố định chung — kế thừa trực tiếp tinh thần TinyFusion (recoverability-aware, differentiable) và tính "tương thích với bước huấn luyện kèm theo" của DisCa.
3. **Khoảng trống được biện minh.** TinyFusion mới làm ở mức *độ sâu (drop cả block)*; chưa ai tách **recoverability riêng cho attention và MLP** ở mức trong-block. Survey cho thấy hướng "học được + tương thích phục hồi" liên tục thắng heuristic ⇒ mở rộng nó xuống mức attention/MLP là bước đi tự nhiên, có cơ sở SOTA, chưa bị chiếm.

> **Một câu để trích trong Related Work:** *"Xu hướng nhất quán từ caching (DisCa, Learning-to-Cache) đến pruning (TinyFusion) là thay tiêu chí nén **cố định** bằng tiêu chí **học được, khả vi và tương thích với bước phục hồi**; luận văn này đưa nguyên lý đó xuống mức trong-block, cắt attention và MLP độc lập theo recoverability học được."*

## Rà soát SOTA-2026: có khe hở/cải tiến mới NGOÀI pruning attn/MLP không?

*(Trả lời câu hỏi rà soát: quét 6 trục với SOTA 2026 mới, ngoài khe hở pruning attn/MLP có thể đề nghị cải tiến mới nào?)*

**Phán quyết ngắn: KHÔNG có khe hở thuật toán *độc lập* mới nào mạnh hơn hoặc trống hơn khe hở pruning attn/MLP.** SOTA 2026 *củng cố* khung 2-đóng-góp chứ không mở đề tài thứ ba. Chi tiết theo trục:

| Trục (SOTA 2026) | Còn khe hở độc lập? | Vì sao / vai trò với luận văn |
|---|---|---|
| **Caching/forecast** (HiCache) | ❌ **Đã bão hòa** (≥15 bài 25-26) | Tuyệt đối không làm đóng góp thuật toán. HiCache giả định *đạo hàm feature ~Gaussian* — giả định này **có thể gãy dưới nhiễu W4A4** ⇒ nuôi **RQ1** (không phải khe hở riêng). |
| **Distillation** (Phased DMD) | ❌ Nhiều bài 25-26 | Cấu trúc "experts theo pha SNR" ⇒ dùng để định **ranh giới k\*** (RQ4) và cảnh báo *không bật caching trên model đã distill* (DisCa). |
| **Quantization** (AccuQuant, Sampling-Aware, TWEO) | ⚠️ Chỉ khe hở *tương tác*, không độc lập | Vật liệu tốt cho **RQ1** (nhiễu lượng tử × nhiều bước × forecast) và **phân tích outlier hai tầng** (kernel-attn × SVDQuant, • 3c). |
| **Solver** (STORK, AC-Sampler) | ❌ | Đông đúc; RF-Solver vẫn đủ cho bước full-compute. |
| **Đa-GPU** (Otil) | ⚠️ Khe hở *kỹ thuật* (GPU dị chủng) | Otil chưa xử lý 3090≠4090 → khoảng trống *engineering* (cân-tải kiểu STADI), không phải đóng góp khoa học chính. |
| **Kernel/sparse-linear** (SLA, Trainable log-linear, SparseDiT) | ❌ | Substrate thực thi; nền cho cả stack. |

**Hai cơ hội mở rộng *nằm trong khung*, đáng ghi nhưng phải giữ phụ thuộc (không thành đóng góp thứ ba):**

1. **Bất đối xứng attn/MLP mở rộng sang *độ chính xác* (bit-width), không chỉ pruning.** Bằng chứng meta mạnh lên: **Spark Transformer** hợp nhất FFN & attn *đối xứng*, còn **Homogeneous-Keys-Heterogeneous-Values** khai thác *bất đối xứng* hai thành phần — hai bằng chứng đối nghịch làm giả thuyết "attn và MLP có bản chất/recoverability khác nhau" (RQ0a) trở nên đáng kiểm định hơn. ⇒ *Nếu* RQ0a đúng, một hệ quả tự nhiên là **phân bổ bit-width bất đối xứng attn-vs-MLP** (mixed-precision phản chiếu chính mask pruning) — thống nhất Đóng góp 1 với trục lượng tử. Đây là **góc mở rộng khả dĩ** (stretch), nên để dưới dạng *ablation/hệ quả*, không phải trục mới.
2. **Basis-adaptivity của forecast dưới nhiễu nén.** Giả định Gaussian của HiCache × nhiễu W4A4 của SVDQuant ⇒ câu hỏi "bậc/cơ sở dự báo có nên *thích ứng theo mức nhiễu lượng tử*?" — nhưng đây là **RQ1 của Đóng góp 2**, không phải đóng góp caching riêng (bão hòa).

**Kết luận cho luận văn:** giữ nguyên khung 2 đóng góp; SOTA-2026 *chỉ* (i) tái xác nhận khe hở pruning attn/MLP còn trống, (ii) cấp thêm baseline/phản đề (DiffSparse, 2ndMatch, Spark Transformer, PermLLM), (iii) làm giàu RQ1 (AccuQuant/Sampling-Aware/TWEO) và (iv) gợi *một* hệ quả mở rộng phụ thuộc (bit-width bất đối xứng) để cân nhắc nếu còn dư địa.

## Phương pháp (tái lập được)
- Vòng 1: mỗi nhóm chạy nhiều truy vấn WebSearch + **WebFetch trang arXiv `/abs/`** khớp tiêu đề/tác giả/năm.
- Vòng 2 (mở rộng): loại trừ các bài đã có, tìm thêm bài 2024–2026, tiếp tục xác minh từng URL.
- Các arXiv ID tiền tố năm tương lai (2602–2607…) do bộ tóm tắt tìm kiếm bịa → **loại bỏ**.

## Ứng viên overflow (chưa xác minh — cần fetch trước khi trích dẫn)
- Caching: ClusCa (2509.10312). Solvers: AMED-Solver (2312.00094, 2023), DPM-Solver-v3 (2310.13268, 2023), ParaTAA (2402.09970). Quantization: MPQ-DMv2 (2507.04290), TFMQ-DM (2311.16503). Distillation: Improved Techniques for Training CM (2310.14189, 2023). Architectures: SnapFusion (2306.00980, 2023), PixArt-Σ.

## Gợi ý mở rộng
- **Citation snowballing** qua Semantic Scholar / Connected Papers từ các paper trụ cột (đòn bẩy recall lớn nhất) để tiến gần "đủ toàn bộ".
- Với luận văn: áp dụng giao thức PRISMA rút gọn (nguồn/truy vấn/tiêu chí nhận-loại/số lượng từng bước) để Related Work bảo vệ được.
