# SURVEY BỔ SUNG — Rà soát Paper-Notes (2024–2026) cho Proposal luận văn

**Ngày:** 24/07/2026 · **Nguồn:** [zhaoyang97/Paper-Notes-en](https://github.com/zhaoyang97/Paper-Notes-en) → portal [en.papernotes.org](https://en.papernotes.org/) (23.000+ ghi chú, tổ chức theo `docs/<Hội nghị>/<lĩnh vực>/`).
**Đối chiếu với:** [PROPOSAL.md](../../PROPOSAL.md) (2 đóng góp), [SURVEY.md](SURVEY.md) (6 nhóm), [[thesis-pruning-direction]].
**Phạm vi quét:** các lĩnh vực `model_compression/`, `image_generation/`, `video_generation/` × các hội nghị mới nhất **ICLR 2026, CVPR 2026, ICML 2026, NeurIPS 2025, ICCV 2025, CVPR 2025**. Chỉ giữ paper về **tăng tốc / nén diffusion & DiT** (pruning, quantization, caching/forecast, distillation few-step, solver, sparse/linear attention, đa-GPU).

> ⚠️ **GHI CHÚ XÁC MINH.** Repo nguồn là *tổng hợp ghi chú do AI sinh*, không phải paper gốc. Mọi URL `en.papernotes.org` dưới đây **đã được lấy trực tiếp từ trang index** (tồn tại thật). Venue suy ra từ đường dẫn thư mục. Các bài đánh dấu **[đã đọc note]** tôi đã mở ghi chú và trích nội dung + arXiv/OpenReview thật; các bài **[chỉ liệt kê]** mới lấy tiêu đề+URL, **cần tự mở note + xác minh arXiv/CVF/OpenReview trước khi trích dẫn chính thức**. Nhiều bài 2026 nằm **ngoài mốc kiến thức 01/2026** → bắt buộc verify khâu chấp nhận (accepted) trước khi đưa vào Related Work.

---

## 0. TL;DR — 4 kết luận cho người bận

1. **Khe hở Đóng góp 1 VẪN TRỐNG (🟢).** Không có bài nào làm đúng thứ luận văn định làm: *pruning cấu trúc tách attention-vs-MLP theo recoverability **học được, khả vi** cho DiT*. Các bài gần nhất chỉ chạm biên: token-sparsity học được (DiffSparse), recovery sau prune (2ndMatch), hay sparsity FFN+attention nhưng **đối xứng** và **activation-level** cho LLM (Spark Transformer). ⇒ Hướng vững, nhưng phải **trích dẫn & phân biệt rõ 3 bài này** trong Related Work.
2. **Có 3 ứng viên "SOTA mới" đáng NÂNG CẤP trục của Đóng góp 2 (đều đã đọc note, đều 2026):**
   - **HiCache (ICLR 2026)** — *cải tiến trực tiếp TaylorSeer* (đổi cơ sở Taylor→Hermite), plug-and-play, ImageReward vượt cả bản gốc ở 5.55× trên FLUX. ⇒ Ứng viên thay/kèm TaylorSeer làm SOTA trục **caching/forecast**.
   - **Phased DMD (CVPR 2026)** — *cải tiến trực tiếp DMD2*, sửa lỗi sụp diversity/động lực chuyển động khi few-step. ⇒ Ứng viên nâng cấp trục **distillation**.
   - **Otil (CVPR 2026)** — *cải tiến trực tiếp DistriFusion*, **nhắm đúng PCIe / đa-GPU tiêu dùng không NVLink** (giảm 75% giao tiếp, 1.88× vs 1.50× của DistriFusion trên SDXL 2-GPU). ⇒ **Khớp hoàn hảo cảnh phần cứng 3090+4090** đã chốt; ứng viên thay DistriFusion cho trục **đa-GPU tùy chọn**.
3. **Trục CACHING đã QUÁ BÃO HÒA** (củng cố nhận định cũ trong SURVEY/TaylorSeer-critique): quét được **≥15 bài caching/forecast 2025-2026** (HiCache, DiCache, DPCache, ResCa, ScalingCache, ERTACache, D2Cache, Evolutionary Caching, MeanCache, Budget-Step Caching, Adaptive Spectral Forecasting, TAP, LESA, RAPID³, "Let Features Decide Their Own Solvers"…). ⇒ **KHÔNG chọn caching làm đóng góp thuật toán**; chỉ tiêu thụ 1 bài (HiCache/TaylorSeer) làm trục.
4. **Bằng chứng "gap đã lấp" cho DisCa được xác nhận** (DisCa có trang note riêng ở CVPR 2026 video_generation) → dùng an toàn làm đòn bẩy lập luận "cố định→học được, tương thích distill" như PROPOSAL • 2★ đã viết.

---

## A. Ảnh hưởng tới ĐÓNG GÓP 1 (pruning attention/MLP học được) — kiểm khe hở & baseline

**Kết luận: khe hở còn trống.** Bảng dưới là các bài gần nhất về mặt ý tưởng — dùng làm **related work để phân biệt** hoặc **baseline để vượt**.

| Bài | Venue | Cắt/nén gì | Học được? | Tách attn/MLP? | Vai trò với Đóng góp 1 | Trạng thái |
|---|---|---|---|---|---|---|
| **OBS-Diff** — Accurate Pruning for Diffusion in One-Shot | ICLR 2026 | trọng số (Hessian/OBS, one-shot) | ❌ tiêu chí cố định | ❌ | **Baseline tiêu chí-cố định** (đã có trong PROPOSAL • 6) | [note](https://en.papernotes.org/ICLR2026/model_compression/obs-diff_accurate_pruning_for_diffusion_models_in_one-shot/) |
| **2ndMatch** — Finetuning Pruned Diffusion via 2nd-Order Jacobian Matching | CVPR 2026 | *không prune* — chỉ **finetune phục hồi** model đã prune (Diff-Pruning/BK-SDM); khớp J⊤J | — | ❌ | **Baseline/kỹ thuật phục hồi bổ trợ** cho bước LoRA-recovery; so trực tiếp với LoRA-proxy | **[đã đọc note]** arXiv 2506.05398 |
| **DiffSparse** — Accelerating DiT with **Learned** Token Sparsity | ICLR 2026 | **token** (cache/recompute), khả vi qua STE + DP dưới ngân sách | ✅ học được | ❌ (không tách attn/MLP) | **Họ hàng gần nhất về *tinh thần*** (differentiable + learned mask + budget) — phải phân biệt: của họ là *token-level caching*, của mình là *structural attn/MLP*. Trích để định vị. | **[đã đọc note]** OpenReview V3eUas3VCL |
| **Spark Transformer** — Reactivating Sparsity in FFN **and** Attention | NeurIPS 2025 | **activation sparsity** (Statistical Top-k), LLM Gemma-2 | ✅ (ngưỡng học) | ⚠️ xử lý FFN & attn **ĐỐI XỨNG** (cùng khung KV-lookup) | **Phản đề hữu ích:** họ hợp nhất *đối xứng*; luận án lập luận *bất đối xứng*. Trích để làm nổi giả thuyết RQ0a. | **[đã đọc note]** arXiv 2506.06644 |
| **LEAP** — Learnable End-to-End Adaptive Pruning of LLMs | ICML 2026 | cấu trúc LLM, học end-to-end | ✅ | ❌ | Tham chiếu "learnable structural pruning" (miền LLM) — đối chiếu phương pháp | [chỉ liệt kê](https://en.papernotes.org/ICML2026/model_compression/leap_learnable_end-to-end_adaptive_pruning_of_large_language_models/) |
| **PermLLM** — Learnable Channel Permutation for **N:M** Sparse LLMs | NeurIPS 2025 | N:M sparsity + hoán vị kênh học được | ✅ | ❌ | Liên quan luận điểm "**mật độ biến thiên thay N:M cứng**" (PROPOSAL • 2★.3) | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/model_compression/permllm_learnable_channel_permutation_for_nm_sparse_large_language_models/) |
| **ReplaceMe** — Depth Pruning + Transformer Block **Linearization** | NeurIPS 2025 | độ sâu (bỏ block) + thay bằng ánh xạ tuyến tính | ❌ | ❌ | Đối chiếu "depth pruning" ngoài diffusion; ý tưởng thay block bằng xấp xỉ rẻ | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/model_compression/replaceme_network_simplification_via_depth_pruning_and_transformer_block_lineari/) |
| **What Layers When** — Learning to Skip Compute via Residual Gates | ICLR 2026 | bỏ-tính-động theo lớp (learned gates) | ✅ | ❌ | Tham chiếu "learned layer skipping" — gần depth-mask của TinyFusion | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/model_compression/what_layers_when_learning_to_skip_compute_in_llms_with_residual_gates/) |
| **Homogeneous Keys, Heterogeneous Values** — khai thác **bất đối xứng** KV | NeurIPS 2025 | KV-cache LLM | — | ⚠️ luận điểm *bất đối xứng giữa hai thành phần* | **Tiền lệ khái niệm** cho "hai thành phần trong 1 khối có bản chất khác → xử lý khác" | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/model_compression/homogeneous_keys_heterogeneous_values_exploiting_local_kv_cache_asymmetry_for_lo/) |

**Hành động đề xuất cho Đóng góp 1:**
- Thêm **DiffSparse, 2ndMatch, Spark Transformer** vào Related Work + tuyến baseline (đã có TinyFusion/Diff-Pruning/OBS-Diff). DiffSparse là bài **phải phân biệt kỹ nhất** (cùng dùng khả-vi + mask học được + ngân sách; khác trục: token vs structural attn/MLP).
- Cân nhắc **2ndMatch làm baseline cho khâu phục hồi** (thay/so với LoRA-proxy): "recoverability *ước lượng* (của mình) vs *finetune phục hồi thực* (2ndMatch)".
- Dùng **Spark Transformer** làm điểm tựa lập luận cho **RQ0a** (họ giả định đối xứng; ta kiểm định bất đối xứng attn/MLP có lợi hơn).

---

## B. Ứng viên "SOTA mới" theo từng TRỤC của Đóng góp 2

### B1. Trục CACHING / FORECAST — hiện SOTA = TaylorSeer (ICCV 2025)
**Phán quyết: trục này bão hòa. Nâng cấp SOTA lên HiCache, giữ nguyên vai trò "1 trục thời gian".**

| Ứng viên | Venue | Điểm mấu chốt | Với proposal | Trạng thái |
|---|---|---|---|---|
| **HiCache** ⭐ | ICLR 2026 | Cơ sở **Hermite** thay đơn thức Taylor; plug-and-play 0 FLOPs; **ImageReward 0.998 > TaylorSeer 0.957** @5.55× FLUX | **THAY/KÈM TaylorSeer** làm SOTA trục caching (nâng cấp không mất tính "1 trục") | **[đã đọc note]** OpenReview faYbbo1KsQ, [code](https://github.com/fenglang918/HiCache) |
| **DiCache** | ICLR 2026 | model tự quyết lịch cache (online) | Đối thủ TaylorSeer khác; đối chiếu | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/model_compression/dicache_let_diffusion_model_determine_its_own_cache/) |
| **"Let Features Decide Their Own Solvers"** — Hybrid Feature Caching | ICLR 2026 | mỗi feature chọn solver riêng | Ý tưởng per-feature — liên quan RQ2 (điều kiện hóa) | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/image_generation/let_features_decide_their_own_solvers_hybrid_feature_caching_for_diffusion_trans/) |
| ScalingCache · ERTACache · DPCache · ResCa · Evolutionary Caching · MeanCache · Budget-Step Caching · Adaptive Spectral Forecasting · TAP · LESA · RAPID³ · D2Cache · TimeRipples | ICLR/CVPR/ICML 2026, NeurIPS 2025 | biến thể error-rectify / adaptive-interval / residual / spectral / RL-policy | **Bằng chứng bão hòa** — không chọn; trích 2-3 bài để chứng minh "gap nội tại đã kín" | [chỉ liệt kê] (xem Phụ lục) |

### B2. Trục QUANTIZATION — hiện SOTA = SVDQuant (ICLR 2025, W4A4 + low-rank)
**Phán quyết: giữ SVDQuant làm SOTA ảnh-DiT; bổ sung ứng viên cho phân tích tương-tác-sai-số & mở rộng video.**

| Ứng viên | Venue | Điểm mấu chốt | Với proposal | Trạng thái |
|---|---|---|---|---|
| **Sampling-Aware Quantization for Diffusion** | CVPR 2026 | lượng tử **nhận-biết-lấy-mẫu** (đa bước) | Đối thủ/bổ trợ SVDQuant; liên quan RQ1 (nhiễu × forecast) | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/model_compression/sampling-aware_quantization_for_diffusion_models/) |
| **AccuQuant** — Simulating Multiple Denoising Steps for Quantizing | NeurIPS 2025 | mô phỏng nhiều bước khi calibrate → giảm tích lũy sai số lượng tử | **Trực tiếp phục vụ RQ1** (nhiễu lượng tử qua nhiều bước) | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/image_generation/accuquant_simulating_multiple_denoising_steps_for_quantizing/) |
| **DeltaQuant** — 4-bit **Video** Diffusion, Spatiotemporal Delta Smoothing | CVPR 2026 | W4 cho video DiT | Mở rộng video (nếu nới phạm vi sang video) | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/model_compression/deltaquant_4-bit_video_diffusion_models_with_spatiotemporal_delta_smoothing/) |
| **DVD-Quant** — Data-free Video DiT Quantization | ICLR 2026 | PTQ data-free video | Đối chiếu | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/model_compression/dvd-quant_data-free_video_diffusion_transformers_quantization/) |
| **TWEO** — Transformers Without Extreme Outliers (FP8) | CVPR 2026 | loại outlier để FP8 dễ | **Liên quan phân tích outlier hai tầng** (PROPOSAL • 3c: kernel × SVDQuant) | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/model_compression/tweo_transformers_without_extreme_outliers_enables_fp8_training_and_quantization/) |
| **Q-DiT** (baseline gốc) · **Q-DiT4SR** · Gradient-Aligned Calibration · Beyond Uniformity PTQ | CVPR 2025 / ICML 2026 / ICLR 2026 | PTQ DiT W4A8, per-SR, calib | Baseline PTQ đối chiếu SVDQuant | [chỉ liệt kê] (Phụ lục) |
| **BinaryAttention** — One-Bit QK-Attention for Vision/Diffusion | CVPR 2026 | 1-bit QK | Cực đoan; đối chiếu trục kernel-lượng-tử | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/model_compression/binaryattention_one-bit_qk-attention_for_vision_and_diffusion_transformers/) |

### B3. Trục DISTILLATION / FEW-STEP — hiện SOTA = DMD2 (NeurIPS 2024 Oral)
**Phán quyết: Phased DMD là nâng cấp trực tiếp DMD2, đáng đưa vào (nhất là nếu chạm video/diversity).**

| Ứng viên | Venue | Điểm mấu chốt | Với proposal | Trạng thái |
|---|---|---|---|---|
| **Phased DMD** ⭐ | CVPR 2026 | Chia SNR-subinterval, MoE experts; **sửa sụp diversity/motion của DMD2** (OF 3.23→9.30) | **Nâng cấp SOTA trục distillation**; củng cố "chế độ NFE-cực-thấp riêng" (• 3b) | **[đã đọc note]** [project](https://x-niper.github.io/projects/Phased-DMD/) |
| **Transition Matching Distillation** | CVPR 2026 | distill few-step video | Đối thủ DMD2 (video) | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/video_generation/transition_matching_distillation_for_fast_video_generation/) |
| **CMT** — Mid-Training cho Consistency/MeanFlow/FlowMap | ICLR 2026 | huấn luyện hiệu quả họ flow-map | Nền few-step thay thế | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/image_generation/cmt_mid-training_for_efficient_learning_of_consistency_mean_flow_and_flow_map_mo/) |
| **FastLightGen** — few steps **+** fewer params | CVPR 2026 | ghép step-distill × param-distill | **Gần tinh thần "prune × distill"** — đối chiếu Đóng góp 1×1 | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/video_generation/fastlightgen_fast_and_light_video_generation_with_fewer_steps_and_parameters/) |
| Causal Forcing · DistillKac · Adaptive Video Distillation · Shortcutting Flow Matching · Distilled Decoding 2 | ICML/CVPR/NeurIPS 25-26 | biến thể few-step | Đối chiếu; xác định ranh giới k* (RQ4) | [chỉ liệt kê] (Phụ lục) |

### B4. Trục SOLVER (ODE/SDE) — hiện SOTA = RF-Solver (ICML 2025)
| Ứng viên | Venue | Điểm mấu chốt | Với proposal | Trạng thái |
|---|---|---|---|---|
| **STORK** | ICLR 2026 | giải đồng thời stiffness + phụ thuộc cấu trúc, cho diffusion & flow-matching | Đối thủ/nâng cấp RF-Solver | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/image_generation/stork_faster_diffusion_and_flow_matching_sampling_by_resolving_both_stiffness_an/) |
| **AC-Sampler** | ICLR 2026 | sửa sampling bằng Metropolis-Hastings | Đối chiếu | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/image_generation/ac-sampler_accelerate_and_correct_diffusion_sampling_with_metropolis-hastings_al/) |
| **Tortoise and Hare Guidance** | NeurIPS 2025 | multirate integration cho CFG | Rẻ, ghép guidance | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/image_generation/tortoise_and_hare_guidance_accelerating_diffusion_model_inference_with_multirate/) |

### B5. Trục ĐA-GPU / HỆ THỐNG — hiện SOTA = DistriFusion (CVPR 2024)
**Phán quyết: Otil khớp cảnh phần cứng tiêu dùng hơn hẳn → ứng viên thay DistriFusion cho trục đa-GPU tùy chọn.**

| Ứng viên | Venue | Điểm mấu chốt | Với proposal | Trạng thái |
|---|---|---|---|---|
| **Otil** ⭐ | CVPR 2026 | Chỉ truyền ~25% sub-block đổi nhiều nhất; **giảm 75% giao tiếp vs DistriFusion**; **nhắm PCIe (không NVLink)** — SDXL 2-GPU **1.88× vs 1.50×** | **THAY DistriFusion** cho cảnh **3090+4090 qua PCIe** đã chốt (PROPOSAL • 3e/• 6). Đây là ứng viên khớp phần cứng nhất toàn khảo sát. | **[đã đọc note]** [code](https://github.com/uplaoli/OTIL-PROJECT) |
| **Accelerating Parallel Diffusion Serving w/ Residual Compression** | NeurIPS 2025 | nén residual khi truyền | Cùng hướng giảm giao tiếp; đối chiếu Otil | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/image_generation/accelerating_parallel_diffusion_model_serving_with_residual_compression/) |
| **Hybrid Data-Pipeline Parallelism (CFG scheduling)** | CVPR 2026 | song song data+pipeline theo lịch CFG | Đối chiếu cho serving | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/image_generation/accelerating_diffusion_via_hybrid_data-pipeline_parallelism_based_on_conditional/) |

### B6. Trục KERNEL / SPARSE-LINEAR ATTENTION — substrate = SageAttention2 (4090)
*(Không phải trục "cộng dồn" mà là nền thực thi + cầu sang lượng tử — PROPOSAL • 3c/• 3e.)*

| Ứng viên | Venue | Điểm mấu chốt | Với proposal | Trạng thái |
|---|---|---|---|---|
| **SLA** — Sparse–Linear Attention cho DiT (fine-tunable) | ICLR 2026 | vượt sparsity thuần bằng lai sparse+linear, **fine-tune được** | Ứng viên substrate attention cho DiT (đối chiếu SageAttention2) | [chỉ liệt kê](https://en.papernotes.org/ICLR2026/model_compression/sla_beyond_sparsity_in_diffusion_transformers_via_fine-tunable_sparselinear_atte/) |
| **Trainable Log-linear Sparse Attention for Efficient DiT** | CVPR 2026 | attention log-tuyến tính học được | Substrate/đối chiếu | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/model_compression/trainable_log-linear_sparse_attention_for_efficient_diffusion_transformers/) |
| **SparseDiT** — Token Sparsification cho DiT | NeurIPS 2025 | token-sparse | Đối chiếu với DiffSparse & Đóng góp 1 | [chỉ liệt kê](https://en.papernotes.org/NeurIPS2025/image_generation/sparsedit_token_sparsification_for_efficient_diffusion_transformer/) |
| **DDiT** — Dynamic Patch Scheduling | CVPR 2026 | lập lịch patch động | Trục token khác; đối chiếu | [chỉ liệt kê](https://en.papernotes.org/CVPR2026/image_generation/ddit_dynamic_patch_scheduling_for_efficient_diffusion_transformers/) |
| Attention Surgery · LinVideo · AdaCluster · RAPID · M4V (Mamba) · RT-Lynx · SPRINT · Representation Shift · FastVAR · ViT-Linearizer | CVPR/ICLR/ICML 26, ICCV 25 | linearize / cluster / GEMM-sparsity / token-compress | Chủ yếu **video**; kho tham chiếu substrate | [chỉ liệt kê] (Phụ lục) |

---

## C. Khuyến nghị cụ thể chỉnh Proposal

1. **Không đổi khung 2 đóng góp.** Rà soát này *củng cố* chứ không lật hướng: khe hở pruning attn/MLP học được vẫn trống.
2. **Cập nhật bảng SOTA-trục (PROPOSAL • 2 / • 3a):**
   - Trục caching: TaylorSeer → **thêm HiCache** làm SOTA-hiện-hành (hoặc thay, nếu tái lập được). Ghi rõ HiCache là nâng cấp cơ-sở-hàm của chính TaylorSeer.
   - Trục distillation: DMD2 → **kèm Phased DMD** cho chế độ few-step/diversity.
   - Trục đa-GPU: DistriFusion → **thay bằng Otil** cho cảnh PCIe/tiêu dùng (khớp • 3e/• 6). DistriFusion lùi về "tham chiếu lịch sử".
3. **Bổ sung Related Work + baseline Đóng góp 1:** DiffSparse (phân biệt kỹ), 2ndMatch (baseline phục hồi), Spark Transformer (phản đề đối xứng), PermLLM ("N:M học được" ↔ luận điểm mật độ biến thiên).
4. **Nuôi RQ1 bằng bằng chứng mới:** AccuQuant + Sampling-Aware Quantization + TWEO là vật liệu tốt cho phân tích *nhiễu lượng tử qua nhiều bước × forecast* và *outlier hai tầng*.
5. **Cảnh báo bão hòa:** tuyệt đối không đặt caching làm đóng góp thuật toán — ≥15 bài 2025-26 đã cày nát. Dùng làm trục tiêu thụ thôi.

---

## Phụ lục — Danh mục dài đầy đủ theo hội nghị (tiêu đề + URL note)

> Tất cả URL lấy từ trang index đã fetch. `⭐` = đã đọc note & xác minh nội dung. Còn lại **[chỉ liệt kê]** — cần verify trước khi trích.

### CVPR 2026 — `model_compression/`
- ⭐ Phased DMD — Few-step DMD via Score Matching within Subintervals · [note](https://en.papernotes.org/CVPR2026/model_compression/phased_dmd_few-step_distribution_matching_distillation_via_score_matching_within/)
- ⭐ Otil — Communication-Efficient Multi-GPU Diffusion Inference · [note](https://en.papernotes.org/CVPR2026/model_compression/otil_accelerating_diffusion_model_inference_via_communication-efficient_multi-gp/)
- DeltaQuant — 4-bit Video Diffusion, Spatiotemporal Delta Smoothing · [note](https://en.papernotes.org/CVPR2026/model_compression/deltaquant_4-bit_video_diffusion_models_with_spatiotemporal_delta_smoothing/)
- Sampling-Aware Quantization for Diffusion Models · [note](https://en.papernotes.org/CVPR2026/model_compression/sampling-aware_quantization_for_diffusion_models/)
- TWEO — Transformers Without Extreme Outliers (FP8) · [note](https://en.papernotes.org/CVPR2026/model_compression/tweo_transformers_without_extreme_outliers_enables_fp8_training_and_quantization/)
- BinaryAttention — One-Bit QK-Attention for Vision & Diffusion Transformers · [note](https://en.papernotes.org/CVPR2026/model_compression/binaryattention_one-bit_qk-attention_for_vision_and_diffusion_transformers/)
- Trainable Log-linear Sparse Attention for Efficient DiT · [note](https://en.papernotes.org/CVPR2026/model_compression/trainable_log-linear_sparse_attention_for_efficient_diffusion_transformers/)
- TimeRipples — Accelerating vDiTs via Spatio-Temporal Correlations · [note](https://en.papernotes.org/CVPR2026/model_compression/timeripples_accelerating_vdits_by_understanding_the_spatio-temporal_correlations/)
- PyramidalWan — Pretrained Video Model Pyramidal for Efficient Inference · [note](https://en.papernotes.org/CVPR2026/model_compression/pyramidalwan_on_making_pretrained_video_model_pyramidal_for_efficient_inference/)
- Adaptive Video Distillation — Mitigating Oversaturation/Temporal Collapse · [note](https://en.papernotes.org/CVPR2026/model_compression/adaptive_video_distillation_mitigating_oversaturation_and_temporal_collapse_in_f/)
- Test-time Sparsity for Extreme Fast Action Diffusion · [note](https://en.papernotes.org/CVPR2026/model_compression/test-time_sparsity_for_extreme_fast_action_diffusion/)
- AdaSVD — SVD with Adaptive Mechanisms for Large Multimodal Models · [note](https://en.papernotes.org/CVPR2026/model_compression/adasvd_singular_value_decomposition_with_adaptive_mechanisms_for_large_multimoda/)

### CVPR 2026 — `image_generation/`
- ⭐ 2ndMatch — Finetuning Pruned Diffusion via 2nd-Order Jacobian Matching (arXiv 2506.05398) · [note](https://en.papernotes.org/CVPR2026/image_generation/2ndmatch_finetuning_pruned_diffusion_models_via_second-order_jacobian_matching/)
- Adaptive Spectral Feature Forecasting for Diffusion Sampling Acceleration · [note](https://en.papernotes.org/CVPR2026/image_generation/adaptive_spectral_feature_forecasting_for_diffusion_sampling_acceleration/)
- Accelerating Diffusion via Hybrid Data-Pipeline Parallelism (CFG scheduling) · [note](https://en.papernotes.org/CVPR2026/image_generation/accelerating_diffusion_via_hybrid_data-pipeline_parallelism_based_on_conditional/)
- DDiT — Dynamic Patch Scheduling for Efficient DiT · [note](https://en.papernotes.org/CVPR2026/image_generation/ddit_dynamic_patch_scheduling_for_efficient_diffusion_transformers/)
- DPCache — Denoising as Path Planning for Diffusion Acceleration · [note](https://en.papernotes.org/CVPR2026/image_generation/dpcache_denoising_path_planning_diffusion_accel/)
- Just-in-Time — Training-Free Spatial Acceleration for DiT · [note](https://en.papernotes.org/CVPR2026/image_generation/just-in-time_training-free_spatial_acceleration_for_diffusion_transformers/)
- ResCa — Residual Caching for DiT Acceleration · [note](https://en.papernotes.org/CVPR2026/image_generation/resca_residual_caching_for_diffusion_transformers_acceleration/)
- Memory-Efficient Fine-Tuning DiT via Dynamic Patch Sampling & Block Skipping · [note](https://en.papernotes.org/CVPR2026/image_generation/memory-efficient_fine-tuning_diffusion_transformers_via_dynamic_patch_sampling_a/)
- LESA — Learnable Stage-Aware Predictors for Diffusion Acceleration · [note](https://en.papernotes.org/CVPR2026/image_generation/lesa_learnable_stage_aware_predictors_for_diffusion_model_acceleration/)
- TAP — Token-Adaptive Predictor for Training-Free Diffusion Acceleration · [note](https://en.papernotes.org/CVPR2026/image_generation/tap_a_token-adaptive_predictor_framework_for_training-free_diffusion_acceleratio/)

### CVPR 2026 — `video_generation/`
- DisCa — Distillation-Compatible Learnable Feature Caching (đòn bẩy lập luận) · [note](https://en.papernotes.org/CVPR2026/video_generation/disca_accelerating_video_diffusion_transformers_wi/)
- Transition Matching Distillation for Fast Video Generation · [note](https://en.papernotes.org/CVPR2026/video_generation/transition_matching_distillation_for_fast_video_generation/)
- FastLightGen — Fewer Steps and Parameters · [note](https://en.papernotes.org/CVPR2026/video_generation/fastlightgen_fast_and_light_video_generation_with_fewer_steps_and_parameters/)
- D2Cache — Second-Order Delta Caching · [note](https://en.papernotes.org/CVPR2026/video_generation/d2cache_second-order_delta_caching_for_higher_video_diffusion_acceleration/)
- AdaCluster — Adaptive Query-Key Clustering for Sparse Attention · [note](https://en.papernotes.org/CVPR2026/video_generation/adacluster_adaptive_query-key_clustering_for_sparse_attention_in_video_generatio/)
- Attention Surgery — Linearize Your Video DiT · [note](https://en.papernotes.org/CVPR2026/video_generation/attention_surgery_an_efficient_recipe_to_linearize_your_video_diffusion_transfor/)
- LinVideo — Post-Training O(n) Attention · [note](https://en.papernotes.org/CVPR2026/video_generation/linvideo_a_post-training_framework_towards_on_attention_in_efficient_video_gener/)
- M4V — Multimodal Mamba for Efficient T2V · [note](https://en.papernotes.org/CVPR2026/video_generation/m4v_multimodal_mamba_for_efficient_text-to-video_generation/)
- RAPID — Reusing Attention Sparsity with Inter-step Adaptation · [note](https://en.papernotes.org/CVPR2026/video_generation/rapid_reusing_attention_sparsity_with_inter-step_adaptation_for_efficient_video_/)
- Accelerating Autoregressive Video Diffusion via History-Guided Cache · [note](https://en.papernotes.org/CVPR2026/video_generation/accelerating_autoregressive_video_diffusion_via_history-guided_cache_and_residua/)

### ICLR 2026 — `model_compression/`
- OBS-Diff — Accurate Pruning for Diffusion in One-Shot (baseline) · [note](https://en.papernotes.org/ICLR2026/model_compression/obs-diff_accurate_pruning_for_diffusion_models_in_one-shot/)
- SLA — Sparse–Linear Attention for DiT (fine-tunable) · [note](https://en.papernotes.org/ICLR2026/model_compression/sla_beyond_sparsity_in_diffusion_transformers_via_fine-tunable_sparselinear_atte/)
- DiCache — Diffusion Model Determines Its Own Cache · [note](https://en.papernotes.org/ICLR2026/model_compression/dicache_let_diffusion_model_determine_its_own_cache/)
- DVD-Quant — Data-free Video DiT Quantization · [note](https://en.papernotes.org/ICLR2026/model_compression/dvd-quant_data-free_video_diffusion_transformers_quantization/)
- Gradient-Aligned Calibration for PTQ of Diffusion · [note](https://en.papernotes.org/ICLR2026/model_compression/gradient-aligned_calibration_for_post-training_quantization_of_diffusion_models/)
- Beyond Uniformity — Sample/Frequency Meta Weighting for PTQ of Diffusion · [note](https://en.papernotes.org/ICLR2026/model_compression/beyond_uniformity_sample_and_frequency_meta_weighting_for_post-training_quantiza/)
- ERTACache — Error Rectification & Timesteps Adjustment · [note](https://en.papernotes.org/ICLR2026/model_compression/ertacache_error_rectification_and_timesteps_adjustment_for_efficient_diffusion/)
- ScalingCache — Difference Scaling & Dynamic Interval Caching · [note](https://en.papernotes.org/ICLR2026/model_compression/scalingcache_extreme_acceleration_of_dits_through_difference_scaling_and_dynamic/)
- Plug-and-Play Fidelity Optimization for DiT Acceleration · [note](https://en.papernotes.org/ICLR2026/model_compression/plug-and-play_fidelity_optimization_for_diffusion_transformer_acceleration_via_c/)
- RAPID³ — Tri-Level Reinforced Acceleration Policies for DiT · [note](https://en.papernotes.org/ICLR2026/model_compression/rapid3_tri-level_reinforced_acceleration_policies_for_diffusion_transformer/)
- What Layers When — Learning to Skip Compute (Residual Gates) · [note](https://en.papernotes.org/ICLR2026/model_compression/what_layers_when_learning_to_skip_compute_in_llms_with_residual_gates/)

### ICLR 2026 — `image_generation/`
- ⭐ HiCache — Scaled-Hermite Upgrade for Taylor-Style Cache-then-Forecast (OpenReview faYbbo1KsQ) · [note](https://en.papernotes.org/ICLR2026/image_generation/hicache_a_plug-in_scaled-hermite_upgrade_for_taylor-style_cache-then-forecast_di/)
- ⭐ DiffSparse — Accelerating DiT with Learned Token Sparsity (OpenReview V3eUas3VCL) · [note](https://en.papernotes.org/ICLR2026/image_generation/diffsparse_accelerating_diffusion_transformers_with_learned_token_sparsity/)
- STORK — Faster Diffusion & Flow-Matching Sampling (stiffness + structure) · [note](https://en.papernotes.org/ICLR2026/image_generation/stork_faster_diffusion_and_flow_matching_sampling_by_resolving_both_stiffness_an/)
- AC-Sampler — Accelerate & Correct Sampling (Metropolis-Hastings) · [note](https://en.papernotes.org/ICLR2026/image_generation/ac-sampler_accelerate_and_correct_diffusion_sampling_with_metropolis-hastings_al/)
- CMT — Mid-Training for Consistency/MeanFlow/FlowMap · [note](https://en.papernotes.org/ICLR2026/image_generation/cmt_mid-training_for_efficient_learning_of_consistency_mean_flow_and_flow_map_mo/)
- Evolutionary Caching to Accelerate Off-the-Shelf Diffusion · [note](https://en.papernotes.org/ICLR2026/image_generation/evolutionary_caching_to_accelerate_your_off-the-shelf_diffusion_model/)
- Let Features Decide Their Own Solvers — Hybrid Feature Caching · [note](https://en.papernotes.org/ICLR2026/image_generation/let_features_decide_their_own_solvers_hybrid_feature_caching_for_diffusion_trans/)
- MeanCache — Instantaneous→Average Velocity for Flow Matching · [note](https://en.papernotes.org/ICLR2026/image_generation/meancache_from_instantaneous_to_average_velocity_for_accelerating_flow_matching_/)
- SPRINT — Sparse-Dense Residual Fusion for Efficient DiT · [note](https://en.papernotes.org/ICLR2026/image_generation/sprint_sparse-dense_residual_fusion_for_efficient_diffusion_transformers/)
- DistillKac — Few-Step via Damped Wave Equations · [note](https://en.papernotes.org/ICLR2026/image_generation/distillkac_few-step_image_generation_via_damped_wave_equations/)
- FastFlow — Flow Matching via Bandit Inference · [note](https://en.papernotes.org/ICLR2026/image_generation/fastflow_accelerating_the_generative_flow_matching_models_with_bandit_inference/)

### ICML 2026 — `model_compression/` & `image_generation/`
- LEAP — Learnable End-to-End Adaptive Pruning of LLMs · [note](https://en.papernotes.org/ICML2026/model_compression/leap_learnable_end-to-end_adaptive_pruning_of_large_language_models/)
- FlattenGPT — Depth Compression via Layer Flattening · [note](https://en.papernotes.org/ICML2026/model_compression/flattengpt_depth_compression_for_transformer_with_layer_flattening/)
- RT-Lynx — GEMM Sparsity for Diffusion Models · [note](https://en.papernotes.org/ICML2026/image_generation/rt-lynx_putting_the_gemm_sparsity_in_a_right_way_for_diffusion_models/)
- Budget-Constrained Step-Level Diffusion Caching · [note](https://en.papernotes.org/ICML2026/image_generation/budget-constrained_step-level_diffusion_caching/)
- Q-DiT4SR — Detail-Preserving DiT Quantization for Real-World SR · [note](https://en.papernotes.org/ICML2026/image_generation/q-dit4sr_exploration_of_detail-preserving_diffusion_transformer_quantization_for/)
- Causal Forcing — Autoregressive Diffusion Distillation (real-time video) · [note](https://en.papernotes.org/ICML2026/image_generation/causal_forcing_autoregressive_diffusion_distillation_done_right_for_high-quality/)
- LiftQuant — Continuous Bit-Width LLM · [note](https://en.papernotes.org/ICML2026/model_compression/liftquant_continuous_bit-width_llm_via_dimensional_lifting_and_projection/)

### NeurIPS 2025 — `model_compression/` & `image_generation/`
- ⭐ Spark Transformer — Reactivating Sparsity in FFN & Attention (arXiv 2506.06644) · [note](https://en.papernotes.org/NeurIPS2025/model_compression/spark_transformer_reactivating_sparsity_in_ffn_and_attention/)
- ReplaceMe — Depth Pruning + Block Linearization · [note](https://en.papernotes.org/NeurIPS2025/model_compression/replaceme_network_simplification_via_depth_pruning_and_transformer_block_lineari/)
- Homogeneous Keys, Heterogeneous Values — KV Asymmetry · [note](https://en.papernotes.org/NeurIPS2025/model_compression/homogeneous_keys_heterogeneous_values_exploiting_local_kv_cache_asymmetry_for_lo/)
- PermLLM — Learnable Channel Permutation for N:M Sparse LLMs · [note](https://en.papernotes.org/NeurIPS2025/model_compression/permllm_learnable_channel_permutation_for_nm_sparse_large_language_models/)
- LittleBit — Ultra Low-Bit Quantization via Latent Factorization · [note](https://en.papernotes.org/NeurIPS2025/model_compression/littlebit_ultra_low-bit_quantization_via_latent_factorization/)
- ParetoQ — Scaling Laws in Extremely Low-bit LLM Quantization · [note](https://en.papernotes.org/NeurIPS2025/model_compression/paretoq_improving_scaling_laws_in_extremely_low-bit_llm_quantization/)
- AccuQuant — Simulating Multiple Denoising Steps for Quantizing Diffusion · [note](https://en.papernotes.org/NeurIPS2025/image_generation/accuquant_simulating_multiple_denoising_steps_for_quantizing/)
- Accelerating Parallel Diffusion Serving with Residual Compression · [note](https://en.papernotes.org/NeurIPS2025/image_generation/accelerating_parallel_diffusion_model_serving_with_residual_compression/)
- SparseDiT — Token Sparsification for Efficient DiT · [note](https://en.papernotes.org/NeurIPS2025/image_generation/sparsedit_token_sparsification_for_efficient_diffusion_transformer/)
- Tortoise and Hare Guidance — Multirate Integration · [note](https://en.papernotes.org/NeurIPS2025/image_generation/tortoise_and_hare_guidance_accelerating_diffusion_model_inference_with_multirate/)
- Shortcutting Pre-trained Flow Matching Diffusion · [note](https://en.papernotes.org/NeurIPS2025/image_generation/shortcutting_pre-trained_flow_matching_diffusion_models_is_almost_free_lunch/)
- Distilled Decoding 2 — One-step Sampling of Image AR Models · [note](https://en.papernotes.org/NeurIPS2025/image_generation/distilled_decoding_2_onestep_sampling_of_image_autoregressiv/)
- Fast Solvers for Discrete Diffusion Models (high-order) · [note](https://en.papernotes.org/NeurIPS2025/image_generation/fast_solvers_for_discrete_diffusion_models_theory_and_applications_of_high-order/)

### ICCV 2025 & CVPR 2025 — `model_compression/`
- FastVAR — Linear Visual AR via Cached Token Pruning (2.7×) · [note](https://en.papernotes.org/ICCV2025/model_compression/fastvar_linear_visual_autoregressive_modeling_via_cached_token_pruning/)
- Representation Shift — Unifying Token Compression with FlashAttention (5.5×) · [note](https://en.papernotes.org/ICCV2025/model_compression/representation_shift_unifying_token_compression_with_flashattention/)
- ViT-Linearizer — Distilling Quadratic Knowledge into Linear-Time (4.2×) · [note](https://en.papernotes.org/ICCV2025/model_compression/vit-linearizer_distilling_quadratic_knowledge_into_linear-time_vision_models/)
- Q-DiT — Accurate PTQ for Diffusion Transformers (W4A8) · [note](https://en.papernotes.org/CVPR2025/model_compression/q-dit_accurate_post-training_quantization_for_diffusion_transformers/)
- DKDM — Data-Free KD for Diffusion (any architecture) · [note](https://en.papernotes.org/CVPR2025/model_compression/dkdm_data-free_knowledge_distillation_for_diffusion_models_with_any_architecture/)
- DyCoke — Dynamic Token Compression for Fast Video LLMs · [note](https://en.papernotes.org/CVPR2025/model_compression/dycoke_dynamic_compression_of_tokens_for_fast_video_large_language_models/)

---
*Phương pháp: quét index `en.papernotes.org` theo (hội nghị × lĩnh vực), lọc thủ công theo tiêu chí tăng-tốc-diffusion, đọc sâu 6 note trọng yếu (⭐) để xác minh nội dung + arXiv/OpenReview. Không hallucination tiêu đề/URL. Các mục [chỉ liệt kê] cần verify khâu accepted + link gốc trước khi trích dẫn luận văn.*
