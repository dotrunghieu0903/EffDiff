> **Ghi chú xác minh (18/07/2026):** Định vị và khe hở prior-art dưới đây dựa trên các nguồn đã fetch qua WebFetch/WebSearch cùng ngày: `arxiv.org/abs/2411.04746` (v3, ICML 2025), `arxiv.org/html/2411.04746v3`, `arxiv.org/abs/2410.10792` (RF-Inversion), `arxiv.org/abs/2412.07517` (FireFlow), `arxiv.org/abs/2210.05475` (GENIE), `arxiv.org/abs/2206.00927` + `arxiv.org/abs/2211.01095` (DPM-Solver / DPM-Solver++, đã có trong SURVEY.md Nhóm 2 mục A1/A2). Không có arXiv ID nào thuộc tiền tố 2026 trong nhóm này nên không cần cảnh báo "đọc lại".

# RF-Solver (2411.04746) — Đánh giá chuyên gia

## Định vị

RF-Solver thuộc Nhóm 2 — Fast Solvers/Samplers (training-free) — nhưng thu hẹp phạm vi vào **riêng họ mô hình rectified-flow** (FLUX, OpenSora, HunyuanVideo) chứ không phải diffusion score-based nói chung như DPM-Solver/DEIS/UniPC. Đóng góp là một bước nâng cấp *số học* (Euler bậc một → Taylor bậc hai) cho chính phép giải ODE, rồi dùng độ chính xác đó làm bệ đỡ cho một framework editing (RF-Edit) dựa trên chia sẻ đặc trưng self-attention. Về bản chất, đây là bài toán "làm cho inversion đúng hơn để editing tốt hơn", không phải bài toán "giảm số bước sampling tới mức tối thiểu" như GITS, DC-Solver, hay Differentiable Solver Search trong cùng nhóm.

## Điểm mạnh

- **Công thức hóa sạch:** đi từ nghiệm tích phân chính xác (biến thiên hằng số) rồi khai triển Taylor số hạng phi tuyến — không phải heuristic, có bậc lỗi chứng minh được (O(h²)→O(h³)).
- **Training-free, plug-and-play:** không cần fine-tune, tương thích mọi backbone RF pretrain — hạ rào cản áp dụng thực tế, lý do chính khiến nó lan rộng nhanh (repo GitHub, dùng làm baseline cho FireFlow và nhiều bài editing sau).
- **Giao thức so sánh công bằng theo NFE:** cho RF gốc gấp đôi số bước để so cùng ngân sách compute — mức độ nghiêm túc khoa học cao hơn nhiều bài "so sánh cùng số bước" dễ gây hiểu nhầm.
- **Phủ rộng 4 nhóm tác vụ** (sinh ảnh, inversion ảnh/video, editing ảnh/video) trên 3 backbone khác nhau (FLUX, OpenSora, HunyuanVideo) — không chỉ là kết quả cục bộ trên một model.
- **Venue mạnh + tác động thực tế xác nhận:** ICML 2025, code công khai, đã sinh follow-up trực tiếp trong cùng ngách (FireFlow, ICML 2025) chỉ trong vòng 1 tháng.

## Hạn chế

- Bậc hai đòi thêm **một lần forward/timestep** để ước lượng đạo hàm bằng sai phân hữu hạn — bài không báo cáo số liệu latency/wall-clock nào (đã kiểm tra kỹ phần abstract + HTML, không tìm thấy), nên "lợi ích thực" về tốc độ triển khai (so với chỉ tăng số bước Euler thường) chưa được định lượng minh bạch, chỉ có lợi ích *chất lượng-trên-NFE*.
- Số bước chia sẻ đặc trưng (M, mặc định 5) là siêu tham số cần tinh chỉnh gần như theo từng ảnh — tác giả tự nhận điều này, chưa có cơ chế tự động.
- Không có mục "Limitations" tường minh trong bản đã fetch; các giới hạn phải suy luận gián tiếp từ nội dung phương pháp.
- Ablation dừng ở bậc Taylor n=1..3 trên cùng một cấu hình full-precision, không có phân tích lý thuyết sâu giải thích *vì sao* n=3 lại kém hơn n=2 ngoài khung "ngân sách NFE cố định" — có thể còn nguyên nhân khác (sai số khuếch đại từ sai phân hữu hạn ở bậc cao) chưa được kiểm chứng.
- Chưa test dưới điều kiện guidance-scale cực trị, dưới backbone đã bị pruning/quantize — đúng là khoảng trống liên quan trực tiếp tới stack luận văn (xem mục Kết hợp).

## Giả định chưa chứng minh (giả định TRUNG TÂM)

**Giả định trung tâm:** trường vận tốc học được v_θ đủ **trơn (smooth)/khả vi liên tục** ở lân cận cục bộ mỗi timestep, để một khai triển Taylor bậc 2–3 quanh điểm đó là xấp xỉ tốt cho quỹ đạo ODE thật. Cả lý luận giảm bậc lỗi (O(h²)→O(h³)) và việc ước lượng đạo hàm bằng sai phân hữu hạn Δt=0.01 đều dựa ngầm vào giả định này. Bài không đo trực tiếp độ cong/độ trơn của v_θ (ví dụ qua Lipschitz constant hay norm đạo hàm bậc hai thực nghiệm) — họ chỉ suy luận gián tiếp qua metric đầu ra (MSE, LPIPS…). Với mạng transformer lớn, có classifier-free guidance, hoặc (liên quan luận văn) đã bị lượng tử hóa/pruning, giả định trơn này có thể bị vi phạm cục bộ (bước nhảy tại vùng CFG mạnh, nhiễu lượng tử hóa phá vỡ tính liên tục cục bộ) mà không được kiểm tra trong bài.

## Rủi ro

- **Rủi ro chi phí:** double forward/step có thể "ăn" hết lợi ích giảm NFE khi ghép với các phương pháp giảm bước cực mạnh khác (distillation few-step) — biên lợi nhuận biên tế sẽ khác hẳn so với sampling nhiều bước gốc.
- **Rủi ro khuếch đại nhiễu số:** sai phân hữu hạn Δt=0.01 trên một mạng đã lượng tử hóa (nhiễu round-off cỡ lớn hơn) có thể làm ước lượng đạo hàm sai lệch nghiêm trọng, khiến hiệu chỉnh bậc hai phản tác dụng.
- **Rủi ro siêu tham số:** M (số bước chia sẻ đặc trưng) và Δt cần tinh chỉnh, khó tổng quát hóa tự động cho pipeline production đa dạng ảnh/video.
- **Rủi ro "cửa sổ độc quyền hẹp":** FireFlow xuất hiện chỉ ~1 tháng sau với mục tiêu và hiệu năng tương tự — cho thấy ý tưởng nằm trong một "vùng chín" mà nhiều nhóm cùng chạm tới gần như đồng thời, nên độ khác biệt bền vững của RF-Solver về lâu dài có thể mỏng.

## Cơ hội

- **Hợp nhất hai tầng Taylor:** RF-Solver khai triển Taylor cho *velocity field theo thời gian tại một bước*; TaylorSeer (Nhóm 4, đã có trong luận văn) khai triển Taylor cho *đặc trưng cache theo timestep để dự báo/bỏ qua bước*. Đây là cơ hội hợp nhất khung Taylor ở hai tầng (solver-level và feature-level) — xem chi tiết mục Kết hợp bên dưới.
- **Tự động hóa bậc Taylor & M:** kết hợp ý tưởng của Differentiable Solver Search (2505.21114, cùng Nhóm 2) để học bậc/tham số tối ưu theo ảnh/video thay vì cố định tay.
- **Kiểm tra khả năng tương thích với nén mô hình** (chính là câu hỏi luận văn cần trả lời): liệu ước lượng đạo hàm bằng sai phân hữu hạn còn ổn định dưới TinyFusion (pruning độ sâu) và SVDQuant (W4A4) hay không — đây là khoảng trống thực nghiệm chưa ai lấp, và là cơ hội đóng góp mới cụ thể cho luận văn.

## KIỂM TRA KHE HỞ prior-art

| # | Prior-art | Mức độ | Ghi chú |
|---|---|---|---|
| 1 | **RF-Inversion** (Rout et al., arXiv 2410.10792, nộp 14/10/2024) | 🟢 | Công trình cạnh tranh/ra trước ~3 tuần, **đã được RF-Solver tự thừa nhận và so sánh trực tiếp** trong Table 3 của chính bài (LPIPS 0.318 vs RF-Edit 0.149) — không phải khe hở ẩn, minh bạch. Xác minh 18/07/2026: https://arxiv.org/abs/2410.10792 |
| 2 | **DPM-Solver / DPM-Solver++** (Cheng Lu, 2206.00927 / 2211.01095, đã có trong SURVEY.md Nhóm 2 A1/A2) | 🟡 | Cùng công thức toán học lõi: nghiệm tích phân chính xác (exponential integrator) + khai triển Taylor số hạng phi tuyến của mạng — chỉ khác đối tượng (score function của DDPM vs velocity field của rectified flow). RF-Solver về cơ bản là **chuyển nhượng (transplant)** một kỹ thuật đã có sang tham số hóa flow-matching, không phải phát minh khai triển Taylor-cho-ODE-diffusion từ đầu. Bài không nhấn mạnh rõ dòng dõi này trong phần đã fetch. Xác minh 18/07/2026: https://arxiv.org/abs/2206.00927, https://arxiv.org/abs/2211.01095 |
| 3 | **GENIE — Higher-Order Denoising Diffusion Solvers** (Dockhorn et al., arXiv 2210.05475, 2022) | 🟡 | Tiền lệ "solver bậc cao hơn cho diffusion" từ 2022, nhưng theo hướng chưng cất/học số hạng hiệu chỉnh (Jacobian-vector-product) thay vì ước lượng bằng sai phân hữu hạn như RF-Solver. Một hướng thiết kế thay thế đáng đối chiếu nhưng không thấy được thảo luận/so sánh trong phần đã fetch. Xác minh 18/07/2026: https://arxiv.org/abs/2210.05475 |
| 4 | **FireFlow** (Deng et al., arXiv 2412.07517, nộp 09/12/2024, ICML 2025) | 🔴 | Ra đời chỉ ~1 tháng SAU RF-Solver, giải đúng cùng bài toán (inversion/editing RF nhanh & chính xác cho FLUX) và tuyên bố đạt độ chính xác bậc-hai với **chi phí cỡ bậc-một** (nhanh hơn ~3× so với baseline RF-inversion trước đó) — tức là đã có một lời giải hiệu quả hơn về chi phí xuất hiện gần như ngay sau RF-Solver. Không phải "khe hở của RF-Solver" theo nghĩa cổ điển (vì ra sau) nhưng là dấu hiệu 🔴 cần lưu ý khi định vị luận văn: ngách "numerical solver chính xác cho RF inversion" chín rất nhanh, độ mới độc quyền của RF-Solver có cửa sổ hẹp. Xác minh 18/07/2026: https://arxiv.org/abs/2412.07517 |

## Ba câu phản biện & đáp án

**Q1: Nếu mỗi bước cần forward thêm một lần để ước lượng đạo hàm, thì "giảm NFE hiệu dụng" có còn thực chất hay chỉ là đổi tên chi phí?**
Đáp: Bài dùng giao thức so sánh công bằng (Table 1: cho RF gốc gấp đôi số bước để cùng tổng NFE) và RF-Solver vẫn thắng trên cơ sở đó — nên lợi ích không đơn thuần đổi tên chi phí, mà là lợi ích chất lượng-trên-compute thật. **Điểm còn để ngỏ:** không tìm thấy bảng latency/wall-clock nào trong nguồn đã fetch — lợi ích "chất lượng/NFE" đã được xác minh nhưng lợi ích "thời gian thực tế mỗi ảnh" so với các giải pháp một-lần-forward (như FireFlow) thì chưa kiểm chứng được từ nguồn này, cần đọc thêm PDF đầy đủ/phụ lục.

**Q2: Giả định độ trơn của velocity field có còn đúng dưới classifier-free guidance mạnh hoặc dưới backbone đã bị lượng tử hóa/pruning (đúng bối cảnh luận văn TinyFusion+SVDQuant) không?**
Đáp: Bài không kiểm tra ở các điều kiện guidance cực trị hay trên backbone đã nén; ablation chỉ đổi bậc Taylor (n=1,2,3) trên mô hình full-precision gốc. **Điểm còn để ngỏ:** chưa có bằng chứng nào (trong hay ngoài bài) về việc ước lượng đạo hàm sai phân hữu hạn (Δt=0.01) có ổn định khi mạng bị lượng tử hóa W4A4 hoặc pruning độ sâu — đây chính là câu hỏi thực nghiệm mà luận văn cần tự trả lời, không phải điều RF-Solver đã giải quyết sẵn.

**Q3: So với FireFlow ra đời gần như đồng thời với hiệu năng tương đương/tốt hơn ở chi phí thấp hơn, RF-Solver còn giữ được vị trí "đóng góp SOTA" không?**
Đáp: RF-Solver vẫn là đóng góp tổng quát hơn về mặt lý thuyết (họ nghiệm bậc-n tùy ý, tổng quát cho cả ảnh và video trên 3 backbone khác nhau — FLUX, OpenSora, HunyuanVideo), trong khi FireFlow theo tìm kiếm chỉ báo cáo phạm vi ảnh (FLUX-dev). **Điểm còn để ngỏ:** không tìm được bảng so sánh trực tiếp đối đầu (head-to-head) giữa hai bài trong bất kỳ nguồn đã fetch — cần tự đọc thêm để kết luận chắc chắn ai thắng ai về hiệu năng/chi phí thực tế.

## Kết hợp & mầm proposal

**Câu hỏi:** Solver nhanh training-free (giảm NFE, ở đây là RF-Solver) có trực giao hay CHỒNG LẤN với TaylorSeer trong stack luận văn (TinyFusion × SVDQuant × TaylorSeer)?

**Phân tích theo trục tài nguyên:**
- **TinyFusion** tác động lên trục **độ sâu mạng** (số block transformer mỗi lần forward) — hoàn toàn trực giao với cả RF-Solver và TaylorSeer, vì cả hai không đổi kiến trúc, chỉ đổi *cách dùng* các lần forward.
- **SVDQuant** tác động lên trục **độ chính xác số học** (bit-width weight/activation) mỗi phép tính trong một lần forward — về nguyên tắc cũng trực giao với trục timestep, NHƯNG có một điểm giao cắt rủi ro cụ thể: RF-Solver cần ước lượng đạo hàm v_θ^(1) bằng **sai phân hữu hạn** (Δt=0.01) — một hiệu số của hai giá trị network output rất gần nhau. Dưới W4A4, nhiễu lượng tử hóa (round-off) có thể lớn hơn hoặc cùng cỡ với chính hiệu số hữu ích đó → hiệu chỉnh bậc hai của RF-Solver có thể bị **nhiễu lượng tử hóa nhấn chìm hoặc khuếch đại**, phản tác dụng. Đây là **xung đột thật, cụ thể, đáng kiểm chứng thực nghiệm** giữa RF-Solver và SVDQuant.
- **TaylorSeer** tác động lên đúng **trục timestep/số lần forward thật** — cùng trục mà RF-Solver đang tối ưu (RF-Solver giảm *số bước ODE cần* để đạt chất lượng mục tiêu bằng cách làm mỗi bước chính xác hơn; TaylorSeer giảm *số lần forward thật* bằng cách dự báo/bỏ qua một số bước và thay bằng ngoại suy Taylor rẻ). Hai phương pháp dùng **CÙNG công cụ toán học** (khai triển Taylor) nhưng áp lên **hai đối tượng khác nhau**: RF-Solver khai triển Taylor của *trường vận tốc theo thời gian trong một bước ODE*; TaylorSeer khai triển Taylor của *đặc trưng đã cache theo lịch sử nhiều timestep* để dự báo bước tương lai. Vì vậy đây **không hoàn toàn trực giao — có CHỒNG LẤN về mục tiêu tài nguyên (giảm số lần forward thật) nhưng khác cơ chế**.

**Xung đột cụ thể khi ghép:**
1. RF-Solver đã tự "nhìn trước" một chút (forward tại t+Δt) để lấy đạo hàm — nếu TaylorSeer cũng đang dự báo/bỏ qua đúng bước đó bằng ngoại suy riêng của nó, hai lớp xấp xỉ Taylor độc lập sẽ **cộng dồn sai số** theo cách không được phân tích lý thuyết ở cả hai bài — rủi ro sai số nhân đôi kiểu "Taylor xấp xỉ trên Taylor xấp xỉ" thay vì cộng lợi ích.
2. TaylorSeer chỉ có ý nghĩa khi có bước "cache/full-compute" xen với bước "forecast" — RF-Solver cần *chính xác* các bước full-compute đó phải sạch (network output thật, không bị forecast) để đạo hàm sai phân hữu hạn còn ý nghĩa. Nếu lịch trình TaylorSeer đặt bước forecast ngay sau bước RF-Solver cần lấy đạo hàm (t+Δt), sai phân sẽ được tính trên một giá trị *dự báo* chứ không phải giá trị thật — làm hỏng đúng giả định trung tâm của RF-Solver.

**Đề xuất kết hợp (mầm proposal cho luận văn):**
- **Phân vùng vai trò theo lịch trình:** chỉ dùng bước cập nhật bậc hai của RF-Solver tại các timestep mà TaylorSeer đã đánh dấu là "full-compute/cache step" (không phải "forecast step"), giữ hai lớp Taylor tách biệt về không gian áp dụng, tránh chồng chất sai số trên cùng một bước.
- **Kiểm định thực nghiệm bắt buộc trước khi ghép:** đo độ ổn định của ước lượng đạo hàm sai phân hữu hạn (Δt=0.01) khi backbone đã qua TinyFusion (pruning) + SVDQuant (W4A4) — nếu nhiễu lượng tử hóa làm sai phân hữu hạn không ổn định, cần tăng Δt hoặc chuyển sang ước lượng đạo hàm bậc thấp/robust hơn (ví dụ trung bình nhiều mẫu) khi chạy trên nhánh đã nén.
- **Góc đóng góp mới khả thi cho luận văn:** "Lịch trình hợp nhất nhận biết độ chính xác số học cho Taylor hai tầng (solver-level RF-Solver + feature-level TaylorSeer) trên backbone đã pruning+quantize" — trực tiếp lấp khoảng trống 🟡/🟢 đã chỉ ra ở trên (RF-Solver chưa test dưới nén; TaylorSeer benchmark trong SURVEY.md cũng không test cùng RF-Solver).

**Kết luận ngắn:** RF-Solver **trực giao** với TinyFusion (khác trục: độ sâu vs. timestep), có **xung đột số học cụ thể cần kiểm chứng** với SVDQuant (sai phân hữu hạn dưới nhiễu lượng tử hóa W4A4), và **chồng lấn một phần về mục tiêu** (cùng nhằm giảm số lần forward thật) nhưng **khác cơ chế** với TaylorSeer (Taylor-trên-ODE-một-bước vs. Taylor-trên-lịch-sử-đa-bước) — ghép được nhưng phải phân vùng lịch trình rõ ràng để tránh cộng dồn sai số, và đây chính là mầm cho một đề xuất thực nghiệm cụ thể của luận văn.

## Verdict

RF-Solver là một bước ngoặt **thực dụng và có ảnh hưởng thật** (ICML 2025, sinh follow-up trực tiếp như FireFlow chỉ trong một tháng) nhờ chuyển thành công công thức "nghiệm ODE chính xác + Taylor bậc cao" đã được chứng minh hiệu quả ở diffusion score-based (DPM-Solver) sang tham số hóa rectified-flow/velocity cho FLUX/OpenSora/HunyuanVideo, nhưng đây là một **adaptation thông minh và hiệu quả cao hơn là một đột phá lý thuyết hoàn toàn nguyên bản**, và độ mới độc quyền của nó có cửa sổ khá hẹp trên thực tế.
