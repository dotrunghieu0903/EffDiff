# Đánh giá chuyên gia — TinyFusion: Diffusion Transformers Learned Shallow

**Paper:** Gongfan Fang, Kunjun Li, Xinyin Ma, Xinchao Wang · CVPR 2025 (Highlight) · https://arxiv.org/abs/2412.01199
**Ngày đánh giá:** 18/07/2026

> **Ghi chú xác minh:** Nội dung method/kết quả lấy từ abstract `/abs/` + HTML `/html/`. Phần "kiểm tra khe hở nghiên cứu" dưới đây mỗi link đều được fetch trang `/abs/` để xác nhận tồn tại. **Cảnh báo:** một vài bài có tiền tố arXiv năm 2026 (vd 2607.00927) nằm **ngoài mốc kiến thức của tôi (01/2026)** — tôi xác nhận trang trả về nội dung khớp, nhưng bạn nên tự đọc lại trước khi trích dẫn chính thức.

---

## Định vị trong lĩnh vực
TinyFusion thuộc dòng **structural depth pruning** cho Diffusion Transformer — cạnh tranh trực tiếp với hai trường phái cũ: (a) *importance-based* (ShortGPT, sensitivity) và (b) *error/loss-based* (Diff-Pruning). Trade-off nó điều hướng: giữ chất lượng *sau fine-tune* trong khi giảm số lớp. Điểm bản lề là **đổi hàm mục tiêu** từ "lỗi tức thời sau cắt" sang "khả năng phục hồi sau tinh chỉnh" (recoverability), và biến việc chọn lớp thành bài toán **khả vi** học được.

## 1. Điểm mạnh
- **Đóng góp khái niệm rõ ràng và được chứng minh phản trực giác:** lấy mẫu 100k mô hình cho thấy loss thấp nhất sau cắt lại cho FID *tệ nhất* (20.69 vs 6.45). Đây là bằng chứng thuyết phục bác bỏ nguyên tắc loss-minimization.
- **Cơ chế khả vi gọn:** Gumbel-Softmax + Straight-Through trên block N:M, kèm LoRA (~0.9%) "giả lập" fine-tune — chi phí thấp mà tối ưu đúng đại lượng quan tâm.
- **Hiệu quả thực tế mạnh:** DiT-XL 28→14 lớp, FID 2.86, 2× speedup, <7% chi phí pre-train; vượt xa ShortGPT (22.28).
- **Tổng quát hóa tốt** across DiT/MAR/SiT — hiếm có ở paper pruning.

## 2. Điểm hạn chế
- **Granularity thô:** chỉ cắt *nguyên lớp transformer*; không tách attention vs MLP → bỏ lỡ dư thừa không đối xứng (thực tế attention thường dư nhiều hơn MLP).
- **Ràng buộc scheme N:M cứng:** 1:2 tốt nhất nhưng áp một tỉ lệ giữ đều toàn mạng, không cho mật độ prune biến thiên theo độ sâu.
- **Recoverability đo bằng LoRA là *proxy*:** giả định thứ hạng cấu hình theo LoRA-adapter trùng với thứ hạng theo full fine-tune — chưa chứng minh chặt.
- **Phạm vi đánh giá hẹp:** chủ yếu class-conditional ImageNet 256; thiếu text-to-image, độ phân giải cao, video.
- **"2× speedup" phụ thuộc phần cứng song song** — cắt độ sâu lợi nhất khi tính tuần tự theo lớp; cần nêu rõ điều kiện.

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *thứ hạng recoverability ước lượng bằng LoRA đồng biến với hiệu năng sau full fine-tune*. Toàn bộ giá trị phương pháp dựa vào đây; paper cho bằng chứng gián tiếp (ablation LoRA > full FT ở giai đoạn ước lượng) chứ chưa bảo chứng lý thuyết.
- Giả định block N:M không cắt mất "cụm lớp" phải đi cùng nhau.
- Giả định recoverability học trên ImageNet chuyển được sang phân phối dữ liệu khác (T2I).

## 4. Rủi ro có thể phát sinh
- **Tái lập:** kết quả FID 2.86 cần KD 500K bước — chi phí "<7%" vẫn không nhỏ tuyệt đối; người ít GPU khó lặp lại.
- **Hiệu lực đánh giá:** FID/IS trên ImageNet không phản ánh chất lượng T2I (prompt adherence).
- **Massive-activation KD mong manh:** RepKD chuẩn thất bại, phải cắt ngưỡng 2σ/4σ — dấu hiệu phương pháp nhạy với chi tiết kỹ thuật.
- **Tốc độ thực tế:** speedup lý thuyết theo lớp có thể không hiện thực hoá trên GPU bộ nhớ-giới hạn.

## 5. Cơ hội đáng chú ý
- **Pruning độ sâu bất đối xứng attention/MLP** trong khung recoverability khả vi (chính TinyFusion để ngỏ).
- **Mật độ prune biến thiên theo độ sâu** (thay N:M cứng) — học luôn tỉ lệ giữ mỗi tầng.
- **Mở rộng sang T2I / video DiT (FLUX, SD3, HunyuanVideo).**
- **Kết hợp với quantization/caching** (orthogonal) → compression stack.
- **Chứng minh/kiểm định lý thuyết** cho tương quan LoRA-proxy ↔ full-FT.

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa? *(tìm ngày 18/07/2026)*

### Gap A — "Tách attention/MLP, cắt độc lập" (gap TinyFusion tự nêu)
- 🟡 **DyDiT / Dynamic Diffusion Transformer** (Wangbo Zhao, ICLR 2025, [2410.03456](https://arxiv.org/abs/2410.03456)) — prune **head attention + kênh MLP** nhưng theo **width động theo timestep**, không phải static structural depth pruning và **không** theo tiêu chí recoverability. → *Lân cận, khác bản chất.*
- 🟡 **Taming DiT for Mobile Video** (Yushu Wu, 2025, [2507.13343](https://arxiv.org/abs/2507.13343), đã có trong SURVEY Nhóm 5) — có **pruning ba tầng block/head/FFN**, nhưng gắn với adversarial step-distillation cho video mobile, không phải khung học-được-khả-vi kiểu TinyFusion.
- 🟡 **Pluggable Pruning w/ Contiguous Layer Distillation** (Jian Ma, 2025→CVPR 2026, [2511.16156](https://arxiv.org/abs/2511.16156)) — kết hợp **depth + width** nhưng theo cách **hợp nhất (unified)**, *không* cắt attention/MLP độc lập.
- 🟡 **What Matters in Transformers** ([2406.15786](https://arxiv.org/abs/2406.15786)) — cắt riêng attention vs MLP, nhưng cho **LLM**, không phải diffusion.
- **Kết luận:** 🟢 **Chưa thấy ai làm đúng phần giao thoa** = *"đưa lựa chọn cắt độc lập attention-vs-MLP vào khung recoverability khả vi (Gumbel-Softmax + LoRA-proxy) của TinyFusion"*. Các bài trên chạm tới "fine-grained DiT pruning" nhưng qua cơ chế khác (động, hợp nhất, hoặc miền LLM). **Đây vẫn là khe hở khai thác được** — đóng góp mới nên nhấn: *static structural, learnable, recoverability-aware, attention/MLP-asymmetric*.

### Gap B — "Mở rộng text-to-image"
- 🔴/🟡 **Đã khá đông đúc.** Post-Training Pruning for DiT ([2607.00927](https://arxiv.org/abs/2607.00927) — *ngoài mốc kiến thức, cần tự xác nhận*), NanoFLUX (T2I mobile), Efficient Pruning of Stable Diffusion ([2411.15113](https://arxiv.org/abs/2411.15113)), và Pluggable Pruning (chạy trên DiT tổng quát). → Nếu bạn định đóng góp ở đây, phải phân biệt rất rõ với các bài này; **kém "trống" hơn Gap A.**

**Khuyến nghị chọn hướng:** ưu tiên **Gap A** (attention/MLP-asymmetric recoverability pruning) — còn trống nhất và nối mạch trực tiếp với TinyFusion + Diff-Pruning. Có thể ghép thêm **mật độ prune biến thiên theo độ sâu** làm đóng góp phụ.

## 7. Ba câu hỏi phản biện & đáp án gợi ý

**Q1. LoRA-proxy có thực sự dự báo đúng hiệu năng full fine-tune, hay chỉ là trùng hợp trên DiT-XL/ImageNet?**
*Đáp án mạnh nhất của tác giả:* ablation cho thấy chọn mask bằng LoRA-proxy cho kết quả cuối tốt hơn cả full-FT trong vòng ước lượng, và lặp lại nhất quán trên DiT/MAR/SiT.
*Điểm còn để ngỏ:* không có bảo chứng lý thuyết cho tính đồng biến; rủi ro proxy lệch khi đổi phân phối dữ liệu (T2I) hoặc rank LoRA khác.

**Q2. So sánh với baseline có công bằng không, khi TinyFusion dùng KD 500K bước để đạt FID 2.86 còn ShortGPT chỉ 100K?**
*Đáp án mạnh nhất:* ở cùng 100K bước, TinyFusion vẫn thắng áp đảo (5.73 vs 22.28); KD là phần cộng thêm, có báo cáo tách bạch.
*Điểm còn để ngỏ:* con số "đinh" 2.86 gắn với ngân sách train lớn hơn; cần bảng iso-compute đầy đủ để loại nghi ngờ.

**Q3. "2× speedup" đo trong điều kiện nào, và cắt độ sâu có còn lợi trên phần cứng bộ nhớ-giới hạn / batch nhỏ không?**
*Đáp án mạnh nhất:* giảm nửa số lớp giảm trực tiếp độ trễ tuần tự theo lớp, đo được 2× trên thiết bị song song.
*Điểm còn để ngỏ:* chưa khảo sát chế độ memory-bound / on-device, nơi lợi ích có thể co lại.

---

## Kết luận
TinyFusion là một đóng góp phương pháp luận vững (đổi mục tiêu sang recoverability, khả vi hoá pruning) và là lựa chọn SOTA-pruning tốt cho luận văn — với khe hở **"cắt độc lập attention/MLP trong khung recoverability"** hiện vẫn còn trống (tính đến 18/07/2026) và đáng để bạn khai thác làm đóng góp mới.
