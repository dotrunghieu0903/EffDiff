# Đánh giá chuyên gia — HiCache: Scaled-Hermite Upgrade for Taylor-Style Cache-then-Forecast

**Paper:** Liang Feng, Shikang Zheng, Jiacheng Liu, Yuqi Lin, Qinming Zhou, Peiliang Cai, Xinyu Wang, Junjie Chen, Chang Zou, Yue Ma, Linfeng Zhang · **ICLR 2026** · https://arxiv.org/abs/2508.16984
**Ngày đánh giá:** 24/07/2026

> **Ghi chú xác minh:** Abstract nguyên văn từ `/abs/`. Số head-to-head vs TaylorSeer (ImageReward 0.998 vs 0.957, LPIPS 0.398 vs 0.452) từ note en.papernotes.org — **chưa đối chiếu bảng PDF**. Nhóm tác giả **trùng đội TaylorSeer** (Jiacheng Liu, Chang Zou, Junjie Chen, Linfeng Zhang) → đây là bản kế nhiệm chính chủ.

---

## Định vị trong lĩnh vực
HiCache thuộc Nhóm 4 (caching/forecast), là **bản nâng cấp toán học của chính TaylorSeer**: giữ nguyên cỗ máy *cache-then-forecast* nhưng đổi **hàm cơ sở ngoại suy** từ đơn thức Taylor sang **đa thức Hermite có scale**, lập luận rằng đạo hàm-đặc-trưng DiT là Gaussian nên Hermite là cơ sở trực giao tối ưu (Karhunen–Loève). Trade-off điều hướng: thêm một chút phức tạp chọn cơ sở/scale, đổi lấy ngoại suy chính xác hơn ở cùng bậc → đẩy trần tốc độ. **Tuyên bố trung tâm:** khớp cơ sở với thống kê thực nghiệm của feature là đòn bẩy chính; **tuyên bố phụ:** plug-and-play lên cả họ caching (ClusCa 0.948→0.984).

## 1. Điểm mạnh
- **Lập luận nguyên lý sạch:** không phải "thử cơ sở khác cho may", mà suy từ tính chất Gaussian của sai phân đặc trưng → Hermite là lựa chọn *có lý thuyết bảo chứng*. Đây là loại đóng góp khó phản bác về mặt động cơ.
- **Chi phí gần như bằng 0:** training-free, không thêm FLOPs, cắm lên phương pháp có sẵn — rào cản áp dụng cực thấp.
- **Tính bổ trợ (không chỉ cạnh tranh):** nâng ClusCa và tích hợp được với TaylorSeer → định vị như "lớp nâng cấp" cho cả nhánh, giá trị thực dụng cao.
- **Đa miền:** T2I / video / super-resolution, khớp mạch đa-tác-vụ.

## 2. Điểm hạn chế
- **Chỉ giải quyết *cơ sở hàm*, không giải quyết *lịch cache thích ứng*:** vẫn kế thừa điểm yếu chọn bậc/khoảng của TaylorSeer; không có verify/sửa-sai online (như SpeCa).
- **Bằng chứng head-to-head mỏng ở abstract:** con số nổi bật của abstract là 5.55× và ClusCa 0.948→0.984; các số vượt TaylorSeer trực tiếp nằm ở bảng (chưa xác minh gốc trong lần đánh giá này).
- **Không định lượng chi phí bộ nhớ** lưu các sai phân bậc cao / hệ số Hermite (kế thừa nguyên si từ TaylorSeer).
- **σ (dual-scaling) là siêu tham số mới:** thêm một nút cần dò, abstract không nói cách chọn tổng quát.

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *sai phân hữu hạn của đạo hàm đặc trưng DiT tuân theo Gaussian đa biến* trên mọi backbone/lịch bước — cơ sở để tuyên bố Hermite "tối ưu". Được nêu là quan sát thực nghiệm; **không có kiểm định phân phối rộng** across model, và tính "tối ưu" chỉ đúng *nếu* giả định Gaussian đúng.
- Giả định σ tối ưu ổn định across prompt/nội dung/tác vụ.
- Giả định tính "tối ưu Gaussian-process" (đúng cho ước lượng tuyến tính) chuyển thẳng thành *chất lượng sinh ảnh tốt hơn* — một bước nhảy cần bằng chứng.

## 4. Rủi ro có thể phát sinh
- **Tương tác với lượng tử hóa (cực kỳ liên quan luận văn):** nếu feature bị nhiễu W4A4, phân phối sai phân có thể **lệch khỏi Gaussian** → nền tảng "Hermite tối ưu" lung lay. Đây vừa là rủi ro của HiCache vừa là **RQ1 của proposal**.
- **Tích lũy sai số** ở video dài / tốc độ rất cao vẫn còn (chưa có sửa-sai online).
- **Hiệu lực đánh giá:** ImageReward/LPIPS có thể không bắt artifact tinh vi; số 0.998 > baseline gốc cần soi kỹ (nghi hiệu ứng regularization như TaylorSeer từng gặp).

## 5. Cơ hội đáng chú ý
- **Bậc Hermite / σ thích ứng** theo lớp-timestep-mức-nhiễu (chưa làm) — trùng RQ1/RQ2 của proposal.
- **Ghép với pruning cấu trúc (Đóng góp 1):** nếu bỏ lớp attn/MLP làm quỹ đạo feature kém trơn, liệu Hermite còn khớp? → vật liệu trực tiếp cho phân tích tương tác sai số.
- **Cơ sở ngoại suy tùy phân-phối-đo-được** (không cứng Gaussian→Hermite) — tổng quát hóa xa hơn.

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa (ngày tìm: 24/07/2026)
- **Khe hở "trục caching một-mình làm đóng góp thuật toán"** → 🔴 **đã kín**. Ngoài HiCache còn DiCache, ScalingCache, ERTACache, DPCache, ResCa, Evolutionary Caching, MeanCache, D2Cache, "Let Features Decide Their Own Solvers", Budget-Step Caching, Adaptive Spectral Forecasting (đều ICLR/CVPR/ICML 2026, xem [SURVEY-PaperNotes-2024-2026.md](../survey/SURVEY-PaperNotes-2024-2026.md) §B1). ⇒ **Không chọn caching làm đóng góp**; chỉ tiêu thụ HiCache/TaylorSeer làm 1 trục.
- **Khe hở "cơ sở forecast thích ứng theo mức nhiễu lượng tử"** → 🟢 **chưa thấy ai làm** (tìm theo "quantization-aware Taylor/Hermite cache diffusion" chưa ra). Đây chính là **RQ1** — cơ hội còn để ngỏ cho luận văn.
- **Khe hở "caching × pruning cấu trúc (quỹ đạo feature kém trơn)"** → 🟡 **lân cận**: DisCa xử lý caching×distillation, chưa ai đo caching×structural-pruning. Cần snowballing thêm.

## 7. Ba câu hỏi phản biện & đáp án gợi ý
**Q1. Giả định Gaussian của sai phân đặc trưng có phổ quát không, hay chỉ đúng trên FLUX/vài model đã test?**
*Đáp:* Bảo vệ mạnh nhất — quan sát Gaussian nhất quán trên các backbone thử nghiệm và cải thiện thực nghiệm rõ (ClusCa 0.948→0.984). **Điểm còn để ngỏ:** không có kiểm định phân phối trên phổ model rộng; nếu Gaussian không đúng (vd feature đã lượng tử/prune), "tối ưu Hermite" mất bảo chứng — tác giả không khoanh vùng điều kiện hiệu lực.

**Q2. "Tối ưu cho quá trình Gaussian" là tối ưu về *ước lượng tuyến tính*; vì sao điều đó kéo theo *chất lượng sinh tốt hơn*?**
*Đáp:* Vì sai số ngoại suy feature nhỏ hơn thường dẫn tới output gần teacher hơn, và thực nghiệm ImageReward/LPIPS ủng hộ. **Điểm còn để ngỏ:** mối nối "sai số feature ↓ ⇒ chất lượng cảm nhận ↑" không tuyến tính; một số trường hợp vượt cả baseline gốc gợi ý yếu tố regularization chưa được giải thích.

**Q3. So với TaylorSeer, phần *đắt* (chọn bậc/khoảng/σ, bộ nhớ sai phân) có bị giấu trong "zero extra FLOPs" không?**
*Đáp:* FLOPs ngoại suy Hermite thực sự tương đương Taylor nên tuyên bố hợp lý. **Điểm còn để ngỏ:** chi phí bộ nhớ lưu sai phân và công dò σ không được định lượng; trên phần cứng bộ-nhớ-giới-hạn (4090 24GB) đây có thể là ràng buộc thực.

**Kết luận:** HiCache là bản nâng cấp có-nền-toán, gần-miễn-phí và chính chủ của TaylorSeer — nên **thay TaylorSeer làm SOTA trục caching** trong proposal, nhưng chính giả định Gaussian của nó lại biến câu hỏi "nhiễu lượng tử/pruning có phá tính forecastable không" thành khe hở RQ1/RQ2 còn để ngỏ mà luận văn nên khai thác.
