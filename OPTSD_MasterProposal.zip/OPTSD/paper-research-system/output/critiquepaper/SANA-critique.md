# Đánh giá chuyên gia — SANA: Efficient High-Resolution Text-to-Image Synthesis with Linear Diffusion Transformers

**Paper:** Enze Xie, Junsong Chen, Junyu Chen, Han Cai, et al. (NVIDIA/MIT/Tsinghua/Playground) · ICLR 2025 (Oral) · https://arxiv.org/abs/2410.10629
**Ngày đánh giá:** 18/07/2026

> **Ghi chú xác minh:** Nội dung method/kết quả lấy từ abstract `/abs/` + HTML `/html/` (xem SANA.md). Phần "kiểm tra khe hở nghiên cứu" dưới đây mỗi link liên quan đều đã được fetch trang `/abs/` để xác nhận abstract/ngày nộp thật (Lumina-Next 2406.18583, Agent Attention 2312.08874, LightningDiT 2501.01423). Không có arXiv id tiền tố 2026 nào trong phần này — toàn bộ nằm trong mốc kiến thức 01/2026 của tôi, không cần cảnh báo "tự đọc lại".

---

## Định vị trong lĩnh vực
SANA thuộc dòng **kiến trúc T2I hiệu quả tái thiết kế toàn hệ thống** (không chỉ một module) — cạnh tranh trực tiếp với PixArt-Σ (cùng lineage tác giả), SDXL, SD3, FLUX. Điểm bản lề: chuyển "ngân sách nén" từ backbone diffusion (nơi đắt vì chạy nhiều bước × nhiều lớp) sang autoencoder và text-encoder (nơi chạy một lần). Ba trục thay đổi đồng thời: **AE nén 32×**, **attention tuyến tính thay softmax**, **LLM decoder-only thay T5**. Đây không phải một kỹ thuật nén hậu-huấn-luyện (post-hoc) như TinyFusion/SVDQuant/TaylorSeer, mà là một **lựa chọn kiến trúc từ-đầu (from-scratch)**.

## 1. Điểm mạnh
- **Luận điểm hệ thống rõ ràng và có bằng chứng thực nghiệm:** ablation Fig.3 cho thấy AE với rFID tái tạo *tốt nhất* (F8C16) không cho FID sinh ảnh tốt nhất — F32C32 thắng dù tái tạo kém hơn. Đây là phản trực giác và được đo, không chỉ là giả thuyết.
- **Hiệu quả thực đo trên nhiều trục cùng lúc:** Sana-0.6B ≈ 39.5× nhanh hơn FLUX-dev ở 1024² (Bảng 7), text encoder nhanh ~6× (Bảng 9), on-device W8A8 thêm 2.4× (Bảng 5) — không phải một con số marketing đơn lẻ mà một hệ số liệu nhất quán.
- **Venue mạnh + tác động thực tế đo được:** ICLR 2025 Oral; sinh trực tiếp dòng follow-up trong cùng nhóm khảo sát (SANA 1.5, DC-AE tách thành paper riêng, EDiT, DiT-Air, LiT).
- **Ablation có kỷ luật:** tách bạch được đóng góp của AE, attention, text-encoder, CHI, solver — không gộp mờ thành một con số duy nhất.

## 2. Điểm hạn chế
- **Tự nhận yếu ở chi tiết tinh:** "text rendering và generation of faces and hands" vẫn khó — đúng những vùng cần độ phân giải/attention cục bộ cao, nghi ngờ trực tiếp vào giả định trung tâm (xem mục 3).
- **Không đảm bảo an toàn/kiểm soát nội dung** — tác giả tự thừa nhận, chưa có cơ chế giảm thiểu.
- **So sánh chủ yếu trên benchmark chuẩn (FID/CLIP/GenEval/DPG)** — không có đánh giá con người quy mô lớn hay stress-test OOD (phong cách hiếm, văn bản dài phức tạp) để kiểm định độ bền của attention tuyến tính.
- **NoPE "lần đầu"** là tuyên bố khó kiểm chứng phủ định — không có benchmark dài-hạn (length/resolution generalization) đo trực tiếp trong bài, chỉ lập luận định tính.
- **Ghép 3 thay đổi lớn cùng lúc** khiến khó tách bạch đóng góp biên của từng trục trong kết quả cuối (dù có ablation riêng, hiệu ứng tương tác 3 chiều không được đo).

## 3. Giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *ReLU linear attention + Mix-FFN (bù cục bộ bằng depthwise conv) có thể thay thế hoàn toàn năng lực mô hình hóa ngữ cảnh toàn cục/chi tiết mịn của softmax attention, ở mọi nội dung và độ phân giải — không chỉ trên phân phối benchmark đã test.* Toàn bộ lợi ích tốc độ của SANA phụ thuộc giả định này đúng; chính điểm yếu tự nhận (chữ, mặt, tay — đều cần chi tiết mịn/tương tác token xa) là dấu hiệu giả định này **không hoàn toàn giữ vững**, và là lý do các bài follow-up (EDiT) quay lại dùng **attention lai** (softmax cho token quan trọng, linear cho phần còn lại) thay vì linear thuần.
- Giả định phụ: "AE nên gánh toàn bộ việc nén, diffusion chỉ khử nhiễu" — đúng ở phạm vi test (rFID 0.34, PSNR 29.29) nhưng chưa rõ giới hạn khi đẩy nén xa hơn 32× (paper không thử 64×/128× — DC-AE của cùng nhóm tác giả sau đó thử tới 128× nhưng là bài khác).
- Giả định CHI (Complex Human Instruction) tổng quát hóa sang ngôn ngữ/văn hóa khác ngoài tiếng Anh — chỉ có bằng chứng zero-shot định tính (Fig.14 tiếng Trung/emoji), chưa có số liệu định lượng đa ngôn ngữ.

## 4. Rủi ro có thể phát sinh
- **Rủi ro tái lập:** ghép 3 thay đổi kiến trúc lớn cùng huấn luyện từ đầu — chi phí thử nghiệm cao, khó cho nhóm ít tài nguyên lặp lại đầy đủ ablation.
- **Rủi ro suy giảm chất lượng ở use-case chuyên biệt:** text rendering/faces/hands đã yếu sẵn — ứng dụng cần độ chính xác cao ở các vùng này (thiết kế UI, avatar) có thể không phù hợp trực tiếp.
- **Rủi ro "tự-so-sánh có lợi":** SANA-0.6B so với FLUX-12B khác biệt cả kiến trúc, dữ liệu huấn luyện, ngân sách compute — khó tách bạch phần lợi ích do kiến trúc thuần túy vs. do khác biệt công thức huấn luyện/dữ liệu.
- **Rủi ro claim ưu tiên (priority claim) bị lung lay:** tuyên bố ngầm về tính mới của "decoder-only LLM text encoder" có thể bị phản biện bởi Lumina-Next đã làm trước ~4 tháng (xem Gap A) — nếu người đọc/luận văn dùng SANA làm mốc "người đầu tiên" sẽ sai.

## 5. Cơ hội đáng chú ý
- **Attention lai (hybrid) thích ứng theo vùng ảnh** — dùng softmax cho vùng chi tiết mịn (mặt/tay/chữ), linear cho vùng nền — đúng hướng EDiT đã đi, còn nhiều biến thể chưa khai thác.
- **Kết hợp SANA với pruning/quantization/caching hậu-huấn-luyện** (chính là Bước 4 dưới đây) — SANA là backbone hiệu quả, không loại trừ nén thêm.
- **Mở rộng video** (tác giả tự nêu là hướng tương lai) — chưa có bài nào trong nhóm khảo sát ghép đúng công thức AE-32×+Linear-DiT+decoder-LLM cho video.
- **Rank/độ nén AE thích ứng theo nội dung** (thay 32× cố định) — vùng nhiều chi tiết giữ token dày hơn.

---

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa? *(tìm ngày 18/07/2026)*

### Gap A — "LLM decoder-only làm text encoder cho T2I diffusion" (SANA ngầm định vị là điểm mới)
- 🟢 **Lumina-Next: Making Lumina-T2X Stronger and Faster with Next-DiT** (Alpha-VLLM, nộp 05/06/2024, [2406.18583](https://arxiv.org/abs/2406.18583)) — abstract xác nhận nguyên văn: *"multilingual generation using decoder-based LLMs as the text encoder"*, cụ thể dùng **Gemma-2B** — **trước SANA (14/10/2024) khoảng 4 tháng**, cùng chọn Gemma làm text encoder.
- 🟢 **Lumina-T2X** (họ trước Lumina-Next, dùng LLaMA-7B làm text encoder) — đã xác nhận qua abstract Lumina-Next mô tả "Lumina-T2X ... nascent family", tức decoder-only-LLM-as-text-encoder trong dòng Lumina còn sớm hơn nữa.
- **Kết luận:** 🟢 **Gap đã đóng theo hướng ngược** — đây không phải khe hở để khai thác, mà là **điểm cần tự sửa trong cách trình bày luận văn**: nếu dùng SANA làm ví dụ "người đầu tiên dùng LLM decoder-only làm text encoder T2I", đó là **sai** — Lumina-Next/Lumina-T2X đã làm trước. Đóng góp thật của SANA ở mục này là kỹ thuật ổn định hóa (RMSNorm + scale nhỏ) và **Complex Human Instruction**, không phải ý tưởng "dùng LLM decoder-only".

### Gap B — "Attention tuyến tính/hybrid cho diffusion image generation"
- 🟡 **Agent Attention: On the Integration of Softmax and Linear Attention** (Han et al., nộp 14/12/2023, ECCV 2024, [2312.08874](https://arxiv.org/abs/2312.08874)) — abstract xác nhận: áp dụng cho Stable Diffusion, *"accelerates generation and substantially enhances image generation quality without any additional training"* — khoảng **10 tháng trước SANA**. Tuy nhiên khác bản chất: (a) retrofit **training-free** trên U-Net Stable Diffusion đã có sẵn, không phải kiến trúc DiT huấn luyện từ đầu; (b) là attention **lai** (softmax+linear qua agent-token) chứ không phải linear thuần như SANA.
- **Kết luận:** 🟡 **Chồng lấn ý tưởng nền tảng** (softmax→linear cho diffusion đã có từ cuối 2023) nhưng **không trùng phạm vi** (retrofit U-Net vs. from-scratch DiT). SANA vẫn giữ được đóng góp riêng ở việc *huấn luyện từ đầu một DiT thuần linear attention ở quy mô lớn*, nhưng không nên trình bày "linear attention cho diffusion" như ý tưởng hoàn toàn mới của SANA.

### Gap C — "NoPE — DiT đầu tiên bỏ hoàn toàn positional embedding"
- 🟡 **Chưa tìm được phản chứng trực tiếp** (chưa xác nhận DiT nào khác bỏ PE hoàn toàn trước SANA) nhưng cũng **chưa có xác nhận độc lập** ngoài tự-tuyên-bố của tác giả — NoPE cho *ngôn ngữ* (causal LM) đã có từ trước (khái niệm NoPE gốc là cho LLM, không phải vision). Xếp 🟡 vì đây là tuyên bố plausible nhưng chưa kiểm chứng chặt, không nên trích dẫn như sự thật đã xác nhận.

**Khuyến nghị:** nếu luận văn trích SANA, nên **tránh dùng khung "SANA là người đầu tiên..."** cho cả 3 mục A/B/C; đóng góp đáng trích dẫn chính xác nhất của SANA là **tổ hợp hệ thống + kỹ thuật ổn định hóa cụ thể (CHI, RMSNorm+scale, Flow-DPM-Solver)**, không phải các ý tưởng thành phần đơn lẻ.

## Ba câu hỏi phản biện & đáp án gợi ý

**Q1. Linear attention có thực sự đủ mạnh, hay lợi ích tốc độ đang được "mua" bằng chất lượng ở chi tiết mịn mà benchmark FID/CLIP/GenEval không bắt được?**
*Đáp án mạnh nhất của tác giả:* điểm số FID/CLIP/GenEval/DPG của Sana-0.6B/1.6B đều cạnh tranh hoặc vượt FLUX-dev ở cùng độ phân giải (Bảng 7), tức linear attention không làm giảm chất lượng đo được trên benchmark chuẩn.
*Điểm còn để ngỏ:* chính tác giả thừa nhận text rendering và mặt/tay còn yếu — đây là loại lỗi mà FID/CLIP (chỉ số phân phối/toàn cục) thường không nhạy; benchmark định lượng không đủ để bác bỏ nghi ngờ này, cần đánh giá con người có mục tiêu (targeted human eval) trên đúng các trường hợp khó.

**Q2. So sánh Sana-0.6B vs FLUX-12B có công bằng không, khi khác biệt cả kiến trúc, dữ liệu, và ngân sách huấn luyện?**
*Đáp án mạnh nhất:* bài báo báo cáo throughput/latency đo trực tiếp trên phần cứng thật (không phải ước tính lý thuyết), và so sánh ở cùng điều kiện suy luận (cùng độ phân giải, cùng số bước hợp lý cho mỗi mô hình).
*Điểm còn để ngỏ:* không có bảng "iso-data" hoặc "iso-compute" tách riêng đóng góp của kiến trúc khỏi đóng góp của lượng dữ liệu/caption curation — phần "efficient training/data curation" (mục 3) cũng góp vào chất lượng, nên con số "20× nhỏ hơn, 100+× nhanh hơn" phản ánh gói giải pháp tổng thể, không tách bạch được đâu là do *chỉ riêng* kiến trúc.

**Q3. SANA có thực sự là "người đầu tiên" ở các claim decoder-only-LLM-as-text-encoder và NoPE, hay đây là claim quá rộng so với thực tế?**
*Đáp án mạnh nhất:* SANA đóng góp kỹ thuật cụ thể mới (CHI, RMSNorm+scale ổn định huấn luyện, NoPE tích hợp trong một DiT thuần linear-attention huấn luyện ở quy mô/tốc độ này) chứ không tuyên bố "phát minh ra decoder-only text encoder" một cách tường minh trong câu abstract chính (chỉ nói "chúng tôi thay T5 bằng LLM decoder-only").
*Điểm còn để ngỏ:* Lumina-Next (06/2024) đã dùng chính Gemma-2B làm text encoder T2I ~4 tháng trước SANA (10/2024) — xác minh 🟢 qua `/abs/`. Nếu luận văn định dùng SANA như mốc mở đầu cho hướng "LLM text encoder cho diffusion", cần trích cả Lumina-T2X/Lumina-Next để tránh lỗi ghi công.

---

## Kết hợp & mầm proposal

**Câu hỏi:** kiến trúc hiệu quả kiểu SANA (linear attention + deep-compression AE) trực giao hay chồng lấn với stack 3 trục của luận văn — **TinyFusion (pruning độ sâu) × SVDQuant (W4A4) × TaylorSeer (dự báo đặc trưng/skip bước)**? SANA là **nền** cho cả stack hay là **lựa chọn thay thế**?

**Trả lời ngắn:** SANA vừa là **nền thay backbone** (không phải kỹ thuật hậu-huấn-luyện cạnh tranh trực tiếp với 3 trục), vừa **chồng lấn ngân sách hiệu quả** với cả ba trục — nghĩa là có thể xếp lớp lên trên, nhưng lợi ích *biên* của việc xếp thêm sẽ nhỏ hơn khi áp trên một mô hình đã hiệu quả (SANA) so với áp trên một DiT/FLUX softmax-attention tiêu chuẩn, và một giả định kỹ thuật của SVDQuant cần kiểm lại.

| Trục | Hoạt động trên | Tương thích với backbone kiểu SANA? |
|---|---|---|
| **TinyFusion** (pruning độ sâu, học được) | Bỏ *nguyên lớp* transformer | **Về cấu trúc: có** — SANA vẫn là chồng block tuần tự, mask Gumbel-Softmax + LoRA-proxy áp được như cũ. **Về hiệu năng biên: giảm**. TinyFusion được tinh chỉnh trên DiT-XL/2 675M, 28 lớp *softmax attention*; Sana-0.6B đã giảm gần hết dư thừa "dễ thấy" qua AE 32× + linear attention (ít token, ít FLOPs/lớp hơn nhiều). Không gian dư thừa còn lại để pruning khai thác co lại — cần đo lại đường cong recoverability trên backbone linear-attention, không thể giả định giống DiT chuẩn.
| **SVDQuant** (W4A4, hấp thụ outlier low-rank) | Các lớp **linear** (QKV, MLP) | **Chồng lấn giả định, không tự động drop-in.** SVDQuant nhắm outlier hoạt hóa cực trị — hiện tượng gắn liền với **softmax attention** (nhạy hàm exponential ở logit lớn). ReLU linear attention của SANA có phân phối hoạt hóa mượt hơn nhiều (không qua softmax) → **có thể có ít outlier hơn để "hấp thụ"**, tức tiền đề "outlier lớn cần nhánh low-rank" của SVDQuant *yếu đi* trên backbone linear-attention. Kỹ thuật vẫn chạy được (áp cho mọi lớp linear) nhưng **giá trị gia tăng của nhánh low-rank cần đo lại thực nghiệm**, không nên giả định giữ nguyên mức nén 3.5×/tăng tốc 3.0× đã báo cáo trên DiT/FLUX gốc.
| **TaylorSeer** (Taylor-forecast đặc trưng theo timestep, skip bước) | Trục thời gian (số bước denoising) | **Trực giao về nguyên tắc** (không phụ thuộc loại attention trong từng bước) nhưng **chồng lấn ngân sách**: SANA đã giảm số bước cần thiết xuống 14–20 bước qua Flow-DPM-Solver (so với 28–50 bước Flow-Euler) — **ngân sách còn lại để TaylorSeer "bỏ qua/dự báo" nhỏ hơn nhiều**. Cache interval / bậc Taylor mà TaylorSeer tinh chỉnh trên lịch trình 28–50 bước cần retuning cho lịch trình rút gọn của SANA; lợi ích tuyệt đối (số bước tiết kiệm được) giảm theo tỉ lệ.

**Kết luận về vị trí của SANA trong stack:**
- **KHÔNG phải trực giao thuần túy** như cách TinyFusion/SVDQuant/TaylorSeer trực giao với nhau (3 trục *khác nhau*: sâu / độ chính xác / thời gian). SANA thay đổi **chính bề mặt (substrate)** mà cả ba trục vận hành trên — đổi backbone từ softmax-DiT sang linear-DiT + AE siêu nén làm thay đổi (a) số token mỗi lớp phải xử lý (ảnh hưởng ROI của pruning), (b) phân phối hoạt hóa từng lớp linear (ảnh hưởng tiền đề outlier của SVDQuant), (c) số bước denoising cần thiết (ảnh hưởng ROI của caching).
- Vì vậy SANA đóng vai **"nền" (base) hợp lý hơn là "trực giao"**: có thể coi là lựa chọn backbone hiệu quả để áp thêm TinyFusion×SVDQuant×TaylorSeer lên trên, kỳ vọng tăng tốc *nhân* — nhưng ba giả định của ba kỹ thuật đó (đường cong recoverability, tiền đề outlier softmax, lịch trình cache) đều cần **hiệu chỉnh lại trên substrate linear-attention/AE-32×**, không thể copy nguyên số liệu từ báo cáo gốc (đo trên DiT/FLUX softmax-attention chuẩn).
- **Mầm proposal (nếu mở rộng luận văn ra ngoài 3 trục hiện có):** *"Nén trên nền đã nén: kiểm định lại 3 trục pruning/quantization/caching khi backbone đã là kiến trúc hiệu quả (linear-attention DiT + deep-compression AE)"* — câu hỏi khoa học cốt lõi là liệu độ dư thừa "còn lại" sau khi kiến trúc đã hấp thụ phần dễ, có còn đủ lớn và đủ *có cấu trúc* (structured) để TinyFusion/SVDQuant/TaylorSeer khai thác hiệu quả, hay lợi ích biên giảm nhanh (diminishing returns) khi các trục compete cho cùng một "khoảng dư thừa" đã bị kiến trúc ăn bớt trước.
- Đây **không thay thế** đề xuất trọng tâm hiện tại của luận văn (stack TinyFusion×SVDQuant×TaylorSeer trên backbone chuẩn) mà là một **thí nghiệm robustness/generalization** đáng thêm vào phần thảo luận hoặc hướng mở rộng: chứng minh (hoặc phản biện) rằng stack 3 trục không chỉ hoạt động trên DiT/FLUX chuẩn mà còn giữ được lợi ích tương đối trên một backbone đã tối ưu kiến trúc từ đầu như SANA.

---

## Kết luận
SANA là một hệ thống T2I hiệu quả có luận điểm rõ ràng và kết quả đo được mạnh (venue ICLR Oral, tác động follow-up thực), nhưng **hai trong ba trục đổi mới kiến trúc mà bài ngầm định vị là mới (decoder-only-LLM-text-encoder, linear-attention-cho-diffusion) đã có tiền lệ xác minh được trước đó** (Lumina-Next 06/2024, Agent Attention 12/2023) — nên trích dẫn SANA cho **đóng góp hệ thống + kỹ thuật ổn định hóa cụ thể**, không cho "ý tưởng đầu tiên"; và khi kết hợp với stack TinyFusion×SVDQuant×TaylorSeer của luận văn, SANA đóng vai **nền thay backbone làm co lại dư địa hiệu quả còn lại cho cả ba trục** hơn là một lựa chọn trực giao hoàn toàn — cần hiệu chỉnh lại giả định của cả ba kỹ thuật trên substrate linear-attention/AE-siêu-nén trước khi kỳ vọng tăng tốc nhân như trên backbone chuẩn.
