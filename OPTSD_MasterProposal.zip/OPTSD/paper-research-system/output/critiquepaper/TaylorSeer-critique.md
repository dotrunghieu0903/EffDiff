# Đánh giá chuyên gia — TaylorSeer: From Reusing to Forecasting

**Paper:** Jiacheng Liu, Chang Zou, Yuanhuiyi Lyu, Junjie Chen, Linfeng Zhang · **ICCV 2025** · https://arxiv.org/abs/2503.06923
**Ngày đánh giá:** 18/07/2026

> **Ghi chú xác minh:** Method/kết quả từ abstract `/abs/` + HTML `/html/`. Phần "kiểm tra khe hở" mỗi link chính đã fetch `/abs/`. ⚠️ **Cảnh báo mạnh:** nhánh caching/forecasting cực kỳ nóng — nhiều follow-up có arXiv **2025-08 → 2026-03, ngoài mốc kiến thức của tôi (01/2026)**; đã xác nhận tồn tại nhưng bạn phải tự đọc lại.

---

## Định vị trong lĩnh vực
TaylorSeer thuộc Nhóm 4 (caching/feature-reuse), nhưng **định nghĩa lại paradigm**: từ *cache-then-reuse* (Δ-DiT, FORA, ToCa, TeaCache) sang *cache-then-forecast*. Trade-off điều hướng: chấp nhận lưu thêm các bậc sai phân + tính ngoại suy Taylor, đổi lấy việc **phá trần ~3–4×** của reuse. Tuyên bố trung tâm: *đặc trưng diffusion dự báo được* nên forecast > reuse ở tỉ lệ tăng tốc cao.

## 1. Điểm mạnh
- **Đóng góp khái niệm sắc, dễ tổng quát:** chuyển reuse→forecast là ý tưởng gọn, có nền toán (chuỗi Taylor + sai phân hữu hạn), training-free, cắm được vào model/solver sẵn có.
- **Bằng chứng ablation thuyết phục:** bậc khai triển quyết định chất lượng — O=0 (reuse thuần) FID 9.24 → O=1 còn 3.59 → O=2–3 bão hòa; chứng minh trực tiếp "forecast đánh bại reuse".
- **Kết quả mạnh, đa miền:** 4.99× (FLUX) & 5.00× (HunyuanVideo) gần như không mất mát; DiT FID thấp hơn SOTA 3.41 ở 4.53×.
- **Ảnh + video** cùng một khung — tính khái quát cao.
- **Sinh ra cả một dòng nghiên cứu** (HiCache, SpeCa, FoCa) → dấu hiệu công trình nền.

## 2. Điểm hạn chế
- **Ngoại suy dễ phân kỳ ở "vùng cứng" (stiff):** Taylor bậc cao ngoại suy xa dễ nổ sai số — chính các bài sau (FoCa) chỉ ra điểm này.
- **Bậc m và khoảng N chọn thủ công:** không tự thích ứng theo lớp/timestep/nội dung.
- **Chi phí bộ nhớ cache các bậc sai phân** tăng theo m; paper ít định lượng đánh đổi bộ nhớ.
- **Speedup lý thuyết vs latency thực lệch nhau:** một số nguồn báo 4.99× compression nhưng latency ~3.53× (overhead ngoại suy) — cần đọc kỹ con số nào là "thực đo".
- **Không có cơ chế verify/sửa sai online** (SpeCa bổ sung sau) → rủi ro tích lũy sai ở tỉ lệ cực cao.

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *quỹ đạo đặc trưng đủ trơn và "đa thức-hoá" được* để Taylor bậc thấp ngoại suy chính xác qua khoảng bước lớn. Đúng thực nghiệm trên các model đã test; **không có ranh giới sai số lý thuyết** — và vùng stiff là phản ví dụ.
- Giả định sai phân hữu hạn từ vài bước cache là ước lượng đạo hàm đủ tốt (nhạy nhiễu).
- Giả định m/N tối ưu ổn định across prompt/nội dung.

## 4. Rủi ro có thể phát sinh
- **Tích lũy sai số** ở tỉ lệ tăng tốc rất cao / video dài (ngoại suy nhiều bước).
- **Hiệu lực đánh giá:** VBench/ImageReward/FID có thể không bắt artifact chuyển động tinh vi.
- **Overhead thực tế** của lưu-và-tính sai phân có thể ăn bớt speedup trên phần cứng bộ nhớ-giới hạn.
- **Tương tác với nén khác** (quantization) chưa khảo sát — đặc trưng lượng tử-nhiễu có thể phá tính "forecastable".

## 5. Cơ hội đáng chú ý
- **Bậc/khoảng thích ứng** (theo lớp, timestep, tốc độ đổi feature).
- **Cơ sở ngoại suy tốt hơn** (Hermite, ODE-solver) — đã có HiCache/FoCa.
- **Forecast + verify** nhẹ — đã có SpeCa.
- **Ghép stack nén trực giao: TaylorSeer × SVDQuant × TinyFusion** (xem Mục 7).

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa? *(tìm 18/07/2026)*

> ⚠️ Đây là nhánh **đông đúc nhất** trong 3 bài đã xét. Hầu hết ngoài mốc kiến thức của tôi.

### Gap A — Sửa lỗi ngoại suy / kiểm soát tích lũy sai
- 🔴 **FoCa: Forecast then Calibrate** (Shikang Zheng, 2025, [2508.16211](https://arxiv.org/abs/2508.16211)) — coi caching là ODE, predictor BDF2 + hiệu chỉnh Heun, chặn sai số vùng stiff. **Đã lấp.**
- 🔴 **SpeCa** ([2509.11628](https://arxiv.org/abs/2509.11628), đã có trong SURVEY) — forecast-then-verify, verify chỉ ~1.7–3.5% forward. **Đã lấp.**
- 🔴 **HiCache** ([2508.16984](https://arxiv.org/abs/2508.16984)) — đổi cơ sở sang Hermite. **Đã lấp.**

### Gap B — Bậc/khoảng thích ứng, per-dimension
- 🔴 **HyCa** ([2510.04188](https://arxiv.org/abs/2510.04188)) — mỗi chiều feature chọn "solver" riêng, 5–6×. **Đã lấp phần lớn.**
- 🟡 PrediT (adaptive interval), FreqCa ([2510.08669](https://arxiv.org/abs/2510.08669)), LearniBridge ([2606.26778](https://arxiv.org/abs/2606.26778)) — thích ứng interval / calibrate học được. **Đông.**

### Gap C — Ghép caching × quantization × pruning
- 🔴 **QuantCache** (Junyi Wu, 2025, [2503.06545](https://arxiv.org/abs/2503.06545)) — **đã kết hợp cả ba** (latent caching + importance-guided quantization + structural pruning), 6.72× trên Open-Sora. Nhưng: **(a) cho video (Open-Sora), (b) dùng caching theo *latent/layer* chứ không phải forecasting kiểu TaylorSeer, (c) quantization/pruning là biến thể riêng, không phải SVDQuant/TinyFusion.**
- 🟢 **Còn trống:** *ghép đúng bộ SOTA hiện đại — TaylorSeer (forecast) × SVDQuant (W4A4) × TinyFusion (learnable depth pruning) — cho T2I image DiT (FLUX), kèm nghiên cứu tương tác sai số* (liệu nhiễu lượng tử có phá tính forecastable của Taylor? pruning có làm quỹ đạo feature bớt trơn?). **Đây là khe hở hợp mạch luận văn nhất.**

**Khuyến nghị:** đừng chọn Gap A/B (đã bão hòa). Nếu bám riêng TaylorSeer → gần như hết chỗ. Giá trị thực nằm ở **Gap C phiên bản "SOTA-trio cho image DiT + phân tích tương tác"** (Mục 7).

## 7. Có thể kết hợp với TinyFusion / SVDQuant không? → **CÓ (trực giao 3 trục), và đây là mầm proposal.**

Ba phương pháp tấn công **ba trục chi phí khác nhau**, nên composable, tăng tốc *nhân*:

| Phương pháp | Trục cắt giảm | Đơn vị |
|---|---|---|
| **TinyFusion** | Chiều sâu (bỏ lớp) | cấu trúc / spatial |
| **SVDQuant** | Độ chính xác (W4A4) | per-op |
| **TaylorSeer** | Số bước tính (skip qua forecast) | thời gian / temporal |

**Vì sao chưa "giải quyết xong":** QuantCache chứng minh *ý tưởng ghép ba* khả thi (video), nhưng chưa ai (1) dùng đúng bộ SOTA forecast+W4A4+learnable-depth-pruning, (2) trên **image T2I DiT (FLUX/SANA)**, và (3) trả lời **câu hỏi tương tác** — điểm khoa học cốt lõi:

> *Nhiễu lượng tử 4-bit và việc bỏ lớp có phá vỡ giả định "quỹ đạo đặc trưng trơn, dự báo được" mà TaylorSeer dựa vào không? Nếu có, thứ tự áp dụng (prune→quant→forecast vs joint) và bù sai số nào là tối ưu?*

### Vài dòng mầm proposal (để ghép sau khi xong các nhóm)
- **Tiêu đề (nháp):** *"Trục nào cũng cắt: Hợp nhất pruning độ sâu, lượng tử 4-bit và dự báo đặc trưng cho Diffusion Transformer"*.
- **Vấn đề:** Mỗi kỹ thuật đã chạm trần riêng (~2× pruning, ~3.5× quant, ~5× caching); ghép ngây thơ dễ **cộng dồn sai số** (quant-noise → sai phân Taylor phóng đại; pruning → quỹ đạo feature kém trơn).
- **Giả thuyết:** ba trục trực giao *về FLOPs* nhưng *tương tác về sai số*; cần một cơ chế **error-aware** điều phối (vd forecast bậc thích ứng theo mức nhiễu lượng tử; recoverability-aware pruning nhận biết lịch cache).
- **Đóng góp dự kiến:** (1) pipeline hợp nhất TinyFusion×SVDQuant×TaylorSeer cho FLUX; (2) phân tích tương tác sai số 3 trục (cái QuantCache không làm); (3) bộ điều phối error-aware; (4) mục tiêu tăng tốc *nhân* (kỳ vọng >10× end-to-end) ở chất lượng gần gốc.
- **Baseline so sánh:** QuantCache (video→port sang image), từng kỹ thuật đơn lẻ, và ghép tuần tự không điều phối.

## 8. Ba câu hỏi phản biện & đáp án gợi ý

**Q1. Không có ranh giới sai số — làm sao đảm bảo Taylor không phân kỳ ở vùng stiff?**
*Đáp mạnh nhất:* thực nghiệm cho thấy quỹ đạo feature trơn, bậc 2–3 đủ ổn ở N=5–7; kết quả gần lossless.
*Điểm còn để ngỏ:* chính FoCa/SpeCa ra đời để vá đúng chỗ này → thừa nhận ngoại suy thuần chưa đủ an toàn ở tỉ lệ cực cao.

**Q2. "4.99×" là compression hay latency thực?**
*Đáp mạnh nhất:* con số compression phản ánh FLOPs bỏ đi; paper cũng báo latency (một số nguồn: ~3.53× FLUX).
*Điểm còn để ngỏ:* overhead lưu/tính sai phân khiến speedup thực < tỉ lệ nén — cần bảng latency-thực-đo tách bạch.

**Q3. Phương pháp còn ý nghĩa khi model đã bị lượng tử/pruning mạnh không?**
*Đáp mạnh nhất:* caching trực giao với nén per-op/structural nên về nguyên tắc cộng hưởng.
*Điểm còn để ngỏ:* chưa có thí nghiệm; nhiễu lượng tử có thể phá tính forecastable — đúng là câu hỏi mở mà Gap C nhắm tới.

---

## Kết luận
TaylorSeer là công trình nền, đổi paradigm caching (reuse→forecast) với kết quả mạnh và đã sinh ra cả một dòng follow-up — nhưng chính vì thế **không gian gap nội tại của nó gần như đã bão hòa (18/07/2026)**; giá trị nghiên cứu còn lại nằm ở **ghép trực giao TaylorSeer × SVDQuant × TinyFusion cho image DiT kèm phân tích tương tác sai số** (điều QuantCache chưa làm cho bộ SOTA này), và đây chính là mầm proposal hợp nhất ba nhóm của luận văn.
