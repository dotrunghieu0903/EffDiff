# Đánh giá chuyên gia — DMD2: Improved Distribution Matching Distillation for Fast Image Synthesis

**Paper:** Tianwei Yin, Michaël Gharbi, Taesung Park, Richard Zhang, Eli Shechtman, Frédo Durand, William T. Freeman · **NeurIPS 2024 (Oral)** · https://arxiv.org/abs/2405.14867
**Ngày đánh giá:** 18/07/2026

> **Ghi chú xác minh:** Method/kết quả lấy từ abstract `/abs/` + HTML `/html/` (xem chi tiết mục "chưa xác minh" trong DMD2.md). Phần "kiểm tra khe hở" dưới đây: mỗi khe hở đã WebSearch rồi WebFetch trực tiếp trang `/abs/` để xác nhận tồn tại + đọc abstract. ⚠️ **Cảnh báo mạnh:** một số bài liên quan có arXiv tiền tố **2602–2606 (ngoài mốc kiến thức 01/2026 của tôi)** — đã xác nhận tồn tại qua fetch `/abs/` thực tế nhưng bạn phải tự đọc lại toàn văn trước khi trích dẫn chính thức.

---

## Định vị trong lĩnh vực
DMD2 thuộc Nhóm 1 (Distillation), nhánh **giảm SỐ BƯỚC sampling bằng huấn luyện** (khác Nhóm 2 fast-solver là training-free, khác Nhóm 4 caching là tái dùng/dự báo đặc trưng trong lúc suy luận). DMD2 định nghĩa lại "trần chất lượng" của distillation: từ *student bị chặn trên bởi teacher* (DMD, LCM, mọi phương pháp distribution-matching/consistency thuần) sang *student có thể vượt teacher* nhờ thêm tín hiệu từ dữ liệu thật qua GAN loss. Tuyên bố trung tâm: **loại bỏ được nút thắt dataset hồi quy tốn kém mà vẫn ổn định và còn tốt hơn**, đổi lại phải chấp nhận một số đánh đổi có hệ thống của học đối nghịch (GAN) — đa dạng đầu ra, guidance cố định, quỹ đạo feature "bị ép" vào rất ít bước.

## 1. Điểm mạnh
- **Chẩn đoán đúng nguyên nhân gốc của bất ổn:** không phải "bỏ regression loss là sai", mà là critic fake-score không theo kịp phân phối generator đang trôi — TTUR là một sửa lỗi tối thiểu, có cơ sở lý thuyết (mượn từ GAN) và ablation minh chứng rõ (FID 3.48 → 2.61 khi thêm TTUR).
- **Phá "trần cấu trúc" của distillation:** GAN loss trên ảnh thật là cơ chế đầu tiên trong dòng DMD cho phép student **vượt** chất lượng teacher một cách có chủ đích, không phải ngẫu nhiên — mở ra một lớp bài toán mới (distillation không còn là "xấp xỉ tốt nhất có thể của teacher" mà là "cải thiện so với teacher").
- **Giải quyết đúng vấn đề thực dụng nhất:** bỏ hẳn nhu cầu ~700 A100-ngày dữ liệu cặp (theo thân bài) — đây là lý do bài được áp dụng rộng khắp trong công nghiệp (SDXL/SD1.5 few-step production pipelines), chứ không chỉ là cải tiến benchmark.
- **Venue + tác động:** NeurIPS 2024 Oral, tác giả từ nhóm nghiên cứu mạnh (Adobe/MIT), sinh ra hẳn một họ bài follow-up (diversity-fix, quantization-aware scheduling, caching-compatible) — dấu hiệu công trình nền thực sự, đúng tiêu chí SOTA đã dùng cho TinyFusion/SVDQuant/TaylorSeer.
- **Mở rộng đa bước có kiểm soát:** "backward simulation" giải quyết đúng lệch pha train/inference thay vì lờ đi — một chi tiết kỹ thuật nhỏ nhưng chỉ ra tác giả hiểu rõ *tại sao* multi-step distillation ngây thơ thất bại.

## 2. Điểm hạn chế
- **Đánh đổi đa dạng (diversity) do GAN:** paper tự nhận diversity score giảm (0.61 vs 0.64, HTML — chưa xác minh với abstract) — đây là hệ quả cố hữu của adversarial distillation, không phải lỗi riêng của DMD2 nhưng chưa được giải quyết triệt để trong bài (chỉ được các bài follow-up 2025 vá).
- **CFG cố định lúc train:** mất "núm xoay" hướng dẫn linh hoạt của teacher — hạn chế thực dụng khi người dùng cần trade-off alignment/diversity theo prompt.
- **FID ở NFE thấp là proxy yếu:** cải thiện FID vài điểm ở 1–4 bước không luôn tương ứng với đánh giá con người tốt hơn tương đương — user study (128 prompt, HTML) là mẫu nhỏ so với benchmark ảnh triệu mẫu.
- **Phụ thuộc hai mạng phụ trợ (μ_real, μ_fake) + discriminator:** tăng độ phức tạp huấn luyện/số siêu tham số (tỉ lệ TTUR 5×, trọng số GAN loss) — khả năng tái lập ở backbone khác (không phải SD/SDXL/EDM) chưa được paper chứng minh trực tiếp.
- **Quỹ đạo feature bị "ép" cực ngắn:** hệ quả trực tiếp của việc giảm còn 1–4 bước là gần như không còn "không gian thời gian" cho các kỹ thuật suy luận khác (xem Mục 7) — bài không thảo luận tương tác này.

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *tín hiệu GAN trên ảnh thật đủ để sửa đúng hướng sai số ước lượng real-score không hoàn hảo của teacher, mà không đưa vào lỗi mode-collapse/GAN-bias mới.* Đây là giả định cốt lõi cho phép tuyên bố "vượt teacher" — đúng thực nghiệm trên SD/SDXL ở quy mô paper, nhưng **không có ranh giới lý thuyết** đảm bảo GAN loss luôn cải thiện hơn là chỉ "làm ảnh giống thật hơn về texture" (một failure mode kinh điển của GAN, dễ nhầm với "chất lượng cao hơn thật"). Các bài diversity-fix 2025 (Mục 6) gián tiếp xác nhận: cái giá phải trả cho giả định này là **mode collapse có thật**.
- Giả định tỉ lệ cập nhật TTUR = 5× là tối ưu/ổn định phổ quát — chỉ kiểm chứng trên ImageNet-64/SD/SDXL, chưa rõ có cần điều chỉnh theo backbone/độ phân giải khác (video DiT, FLUX-scale).
- Giả định "backward simulation" (dùng sample sinh từ chính student) không tự khuếch đại lỗi qua nhiều vòng huấn luyện — không có chứng minh hội tụ hình thức, chỉ có bằng chứng thực nghiệm (ablation FID 20.66 → 19.32).

## 4. Rủi ro có thể phát sinh
- **Mode collapse ẩn** trong các use-case đòi hỏi đa dạng cao (ví dụ sinh dữ liệu huấn luyện, data augmentation) — rủi ro âm thầm nếu chỉ nhìn FID/CLIP tổng hợp.
- **Thiên lệch phân phối do discriminator** học trên tập ảnh thật cụ thể (LAION-Aesthetics) có thể truyền bias thẩm mỹ của tập đó vào student mạnh hơn cả teacher gốc.
- **Khó tái lập ổn định huấn luyện GAN** ở nhóm không có hạ tầng/kinh nghiệm tinh chỉnh TTUR + trọng số loss — rào cản triển khai thực tế ngoài phòng lab lớn.
- **Tương tác tiêu cực với nén khác (đã có bằng chứng cụ thể, xem Mục 6/7):** model 1-step "thiếu giai đoạn phục hồi (recovery phase)" nên nhạy hơn với nhiễu lượng tử — kết hợp ngây thơ DMD2 với lượng tử 4-bit có thể cộng dồn sai số nghiêm trọng hơn ở model nhiều bước.

## 5. Cơ hội đáng chú ý
- **Sửa diversity mà không mất tốc độ** (đã có: diversity distillation, Zero/Anti-CFG) — hướng tiếp tục hoàn thiện.
- **Lượng tử-nhận-biết-scheduler** cho model few-step (Q-Sched) — hướng bổ sung trực tiếp cho DMD2.
- **Caching tương thích với distillation** (DisCa) — xác nhận đây là bài toán thật, chưa giải cho ảnh T2I.
- **Ghép với stack nén trực giao TinyFusion × SVDQuant × TaylorSeer** — xem Mục 7, đây là mầm proposal chính.

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa? *(tìm 18/07/2026)*

### Gap A — Sửa mode collapse/đa dạng do GAN loss trong distillation few-step
- 🔴 **Distilling Diversity and Control in Diffusion Models** (Rohit Gandikota, David Bau, [2503.10637](https://arxiv.org/abs/2503.10637)) — phát hiện distilled model "chốt" cấu trúc ảnh ngay bước đầu (khác base model rải quyết định cấu trúc qua nhiều bước); đề xuất "diversity distillation": dùng base model chỉ ở bước đầu rồi chuyển sang distilled model → khôi phục đa dạng, giữ tốc độ, **training-free**. Trong mốc kiến thức (03/2025). **Đã lấp.**
- 🔴 **Few-Step Diffusion via Score identity Distillation** (Mingyuan Zhou, Yi Gu, Zhendong Wang, [2505.12674](https://arxiv.org/abs/2505.12674)) — tối ưu SiD cho few-step, thêm "Diffusion GAN-based adversarial loss" + hai chiến lược guidance mới **Zero-CFG**/**Anti-CFG** để giải quyết chính xác "trade-off alignment-diversity" mà GAN loss kiểu DMD2 gây ra. Trong mốc kiến thức (05/2025). **Đã lấp.**
- 🟡 **1.x-Distill: Breaking the Diversity, Quality, and Efficiency Barrier in DMD** ([2604.04018](https://arxiv.org/abs/2604.04018), nộp 05/04/2026) — khung "fractional-step distillation" (1.67–1.74 NFE hiệu quả), tuyên bố giải đồng thời cả 3 rào cản (đa dạng/chất lượng/hiệu quả) của chính họ DMD. **⚠️ Ngoài mốc kiến thức 01/2026 — đã xác nhận tồn tại qua fetch `/abs/` nhưng cần tự đọc lại toàn văn.**

### Gap B — Caching/forecast tương thích với model đã distill few-step (câu hỏi trung tâm của Mục 7)
- 🔴 **DisCa: Distillation-Compatible Learnable Feature Caching** ([2602.05449](https://arxiv.org/abs/2602.05449), CVPR 2026, nộp 05/02/2026) — xác nhận trực tiếp: *"chất lượng suy giảm nghiêm trọng hơn khi áp thẳng training-free feature caching vào model đã step-distilled"*; đề xuất caching học được, tương thích distillation, đạt tới **11.8×** tăng tốc kết hợp. **Đây chính là bằng chứng thực nghiệm cho giả thuyết "distillation làm caching mất ý nghĩa" nêu trong đề bài — đã có người xác nhận VÀ giải một phần, nhưng chỉ cho video DiT, không dùng đúng cơ chế forecast kiểu TaylorSeer, và không kết hợp quantization/pruning.** **⚠️ Ngoài mốc kiến thức 01/2026 — cần tự đọc lại.**
- 🟡 **Denoising as Path Planning (DPCache)** ([2602.22654](https://arxiv.org/abs/2602.22654), nộp 2026) — training-free, đóng khung lại denoising như path-planning để tăng tốc; liên quan lân cận, chưa rõ có nhắm riêng model đã distill hay không — **cần đọc thêm**. **⚠️ Ngoài mốc kiến thức — cần tự đọc lại.**

### Gap C — Lượng tử hoá cho model đã distill few-step (tương tác với SVDQuant)
- 🔴 **Q-Sched** (Natalia Frumkin, Diana Marculescu, [2509.01624](https://arxiv.org/abs/2509.01624), ICML 2026) — PTQ ở mức **scheduler** (không sửa trọng số) cho model few-step, đạt full-precision accuracy với giảm 4× kích thước model; benchmark trực tiếp trên **FLUX.1[schnell] và SDXL-Turbo** (cả hai đều là model distilled few-step) → *"quantization và few-step distillation bổ sung cho nhau"* (nguyên văn ý paper). Trong mốc kiến thức (09/2025, dù venue ghi ICML 2026). **Đã lấp phần lớn cho hướng PTQ-scheduler, nhưng KHÔNG phải kiểu low-rank-branch W4A4 như SVDQuant.**
- 🟡 **MixDQ** (Tianchen Zhao et al., [2405.17873](https://arxiv.org/abs/2405.17873)) — PTQ mixed-precision "metric-decoupled" riêng cho few-step T2I diffusion, thừa nhận (thân bài, chưa xác minh với abstract) rằng model few-step khó lượng tử hơn model nhiều bước vì **thiếu "giai đoạn phục hồi" (recovery phase)** để tự sửa nhiễu lượng tử qua các bước sau — đúng cơ chế cần cân nhắc khi ghép DMD2 (1–4 bước) với SVDQuant (W4A4). **Đã lấp một phần, khác cơ chế SVDQuant (không dùng nhánh low-rank hấp thụ outlier).**

### Gap D — 🟢 Khe hở còn trống thật (khớp mạch luận văn nhất)
**Chưa thấy ai** ghép **đúng bộ SOTA hiện đại của luận văn** — DMD2 (few-step adversarial distillation) × TinyFusion (learnable depth pruning) × SVDQuant (W4A4 low-rank) × TaylorSeer (Taylor-forecast caching) — trong **một pipeline T2I ảnh (FLUX/SDXL)**, kèm phân tích tương tác sai số ba chiều:
1. Nhiễu lượng tử có khuếch đại mạnh hơn trên model *thiếu recovery phase* (DMD2 few-step) so với model nhiều bước — mở rộng đúng phát hiện của MixDQ nhưng cho cơ chế low-rank của SVDQuant cụ thể;
2. Pruning độ sâu (TinyFusion) có làm quỹ đạo feature *kém trơn* hơn, phá điều kiện cần của Taylor-forecast (TaylorSeer);
3. Số bước bị DMD2 rút xuống 1–4 có **xóa sổ không gian tác dụng của caching/forecast** hay không — DisCa đã xác nhận vấn đề này là thật (cho video, caching học được) nhưng chưa ai làm cho đúng cơ chế forecast Taylor + đúng bộ trio nén (prune+quant) trên ảnh.

**Khuyến nghị:** đừng chọn lại Gap A (đã bão hòa 2025) hoặc Gap C thuần (Q-Sched đã đóng phần lớn khoảng trống image T2I). Giá trị lớn nhất nằm ở **Gap B+D hợp nhất** — vì DisCa đã chứng minh *thực nghiệm* rằng distillation và caching xung đột thật, nhưng chưa ai đặt bài toán đó trong bối cảnh **có cả quantization/pruning** để trả lời "khi đã nén 3 trục khác rồi, distillation few-step còn đáng làm nữa không, hay nên nhường không gian đó cho caching/forecast?"

## 7. Kết hợp & mầm proposal — DMD2 có phải trục thứ 4 trực giao, hay chồng lấn với TaylorSeer?

**Câu trả lời ngắn: CHỒNG LẤN một phần thật (đã có bằng chứng thực nghiệm — DisCa), không phải trực giao sạch như TinyFusion/SVDQuant/TaylorSeer với nhau.**

| Trục | Cắt giảm gì | Đơn vị | Khi kết hợp với trục khác |
|---|---|---|---|
| TinyFusion | Chiều sâu mạng (bỏ lớp) | cấu trúc/spatial | Trực giao với quant/caching |
| SVDQuant | Độ chính xác số (W4A4) | per-op | Trực giao với pruning/caching, **nhưng nhạy hơn khi input là model few-step (Gap C)** |
| TaylorSeer | Số **bước tính trong 1 lần suy luận** (skip qua forecast) | thời gian/temporal, hoạt động **trong không gian bước còn lại sau khi đã cố định tổng số bước** | **Cùng trục thời gian với DMD2** |
| **DMD2 (distillation)** | Số **bước sampling tối thiểu cần có** (huấn luyện lại để cần ít bước hơn ngay từ đầu) | thời gian/temporal, quyết định **có bao nhiêu bước để TaylorSeer còn "chơi" trên đó** | **Không trực giao với TaylorSeer** |

**Vì sao chồng lấn, không trực giao:** TinyFusion cắt *chiều sâu mỗi bước*; SVDQuant cắt *độ chính xác mỗi phép toán*; cả hai không đụng đến "có bao nhiêu bước". TaylorSeer và DMD2 **cùng nhắm vào trục số-bước-sampling**, chỉ khác cơ chế: DMD2 giảm số bước *tối thiểu cần thiết* bằng huấn luyện lại (từ ~50–100 bước xuống 1–4 bước "gốc"), còn TaylorSeer giảm số bước *thực tính* bằng cách dự báo (forecast) một phần bước trong một lịch trình đã cho — nhưng TaylorSeer cần **ít nhất m+1 bước tính đầy đủ** để suy ra các bước còn lại bằng khai triển Taylor bậc m. Khi DMD2 đã rút tổng số bước xuống 1–4, **không còn đủ "nguyên liệu" (đủ bước đã tính + đủ khoảng cách N giữa các bước) để TaylorSeer ngoại suy có ý nghĩa** — đúng như giả thuyết đặt ra trong đề bài, và đúng như DisCa đã xác nhận thực nghiệm (2602.05449): áp thẳng caching training-free vào model đã step-distilled làm chất lượng suy giảm nghiêm trọng hơn so với áp vào model gốc nhiều bước.

**Hệ quả cho stack 3 trục của luận văn:**
- TinyFusion × SVDQuant vẫn trực giao sạch với nhau và với TaylorSeer — giữ nguyên "stack 3 trục" như đã định vị.
- DMD2 (đại diện Nhóm 1) **không nên được đề xuất như "trục thứ 4" cộng dồn cùng TaylorSeer** — vì about cùng ngân sách thời gian, dùng cả hai đồng thời ở mức tối đa (DMD2 xuống 1–4 bước RỒI áp TaylorSeer lên trên) là **mâu thuẫn logic**: hoặc chấp nhận model đã distill (ít bước, mỗi bước phải tính đủ, không còn chỗ cho forecast), hoặc giữ model nhiều bước gốc và dùng TaylorSeer để giả lập hiệu ứng "ít bước" một cách rẻ hơn nhưng có thể đảo ngược/điều chỉnh runtime — hai chiến lược này **cạnh tranh cho cùng một ngân sách NFE**, không cộng dồn nhân như TinyFusion×SVDQuant×TaylorSeer.
- Vai trò đúng của DMD2 trong stack: **thay thế TaylorSeer khi ngân sách NFE cực thấp** (1–4 bước, nơi TaylorSeer hết tác dụng) hoặc **là "chế độ vận hành khác"** song song — không phải nhân chồng. Điểm còn mở, đúng như Gap D: liệu có một **vùng trung gian** (ví dụ DMD2 xuống 8–16 bước thay vì 1–4) nơi vẫn còn đủ "khoảng" cho TaylorSeer hoạt động một phần, tạo ra một đường trade-off tốc độ/chất lượng mới chưa ai vẽ ra?

**Mầm proposal đề xuất (nhánh dành cho luận văn, khác với mầm TaylorSeer×SVDQuant×TinyFusion đã có):**
- **Tiêu đề (nháp):** *"Khi nào chưng cất giết chết caching: một nghiên cứu về ranh giới NFE mà tại đó TaylorSeer hết tác dụng, và liệu SVDQuant×TinyFusion có bù được khoảng trống đó."*
- **Câu hỏi khoa học:** Với model đã distill xuống k bước (k=1,2,4,8,16...), tồn tại ngưỡng k* nào mà dưới đó forecast-caching (TaylorSeer/HiCache/SpeCa) không còn mang lại lợi ích (do không đủ bước tham chiếu để ước lượng sai phân) — và trên ngưỡng đó, kết hợp DMD2(k bước) + TinyFusion + SVDQuant + TaylorSeer có tạo ra đường Pareto tốt hơn từng kỹ thuật đơn lẻ không?
- **Baseline so sánh:** DisCa (cho video, learnable caching riêng) — cần làm phiên bản ảnh, đối chiếu forecast Taylor thuần vs caching học được của DisCa, cộng thêm trục quant/prune mà DisCa chưa có.
- **Rủi ro cần lường trước:** nếu k* ≈ 4–8 (rất thấp), giá trị của "kết hợp trục 4" gần như không tồn tại cho các pipeline production hiện đại (đa số đã distill xuống 4 bước) — cần định vị rõ đóng góp là "biết khi nào NÊN/KHÔNG NÊN cộng caching vào model đã distill", không phải tuyên bố cộng dồn luôn có lợi.

## 8. Ba câu hỏi phản biện & đáp án gợi ý

**Q1. "Vượt teacher" nhờ GAN loss có phải là cải thiện chất lượng thật, hay chỉ là hiệu ứng "giống ảnh thật hơn về texture" kinh điển của GAN, dễ đánh lừa FID/CLIP?**
*Đáp mạnh nhất:* user study trên PartiPrompts (128 prompt, HTML) cho thấy con người cũng đánh giá DMD2 thắng ở một tỉ lệ mẫu đáng kể, không chỉ là hiệu ứng metric.
*Điểm còn để ngỏ:* mẫu user study nhỏ; diversity giảm (0.61 vs 0.64) là dấu hiệu cổ điển của GAN-bias — chưa có phân tích tách bạch "chất lượng thật tăng" khỏi "đa dạng giảm khiến mỗi ảnh nhìn 'chỉn chu' hơn nhưng ít biến thể hơn".

**Q2. Tỉ lệ TTUR 5× và trọng số GAN loss có phải siêu tham số nhạy, cần tinh chỉnh riêng cho mỗi backbone (FLUX, SANA, video DiT), hay tổng quát hoá tốt?**
*Đáp mạnh nhất:* paper thử nghiệm nhất quán trên hai quy mô khác nhau (ImageNet-64 nhỏ và SDXL lớn) với cùng cơ chế TTUR, cho thấy tính robust ở mức độ nào đó.
*Điểm còn để ngỏ:* cả hai đều là ảnh tĩnh, kiến trúc UNet/latent tương tự; chưa có bằng chứng trên video DiT hay kiến trúc linear-attention (SANA, LinFusion) — nơi động lực huấn luyện GAN có thể khác hẳn.

**Q3. DMD2 và TaylorSeer có thật sự "cộng dồn nhân" được như tuyên bố ngầm của một stack nén đa trục, hay chúng cạnh tranh trên cùng ngân sách NFE?**
*Đáp mạnh nhất (đã phân tích ở Mục 7):* về nguyên tắc có thể phối hợp ở vùng NFE trung bình (8–16 bước), nơi DMD2 giảm bước tối thiểu cần thiết còn TaylorSeer forecast một phần trong số bước còn lại.
*Điểm còn để ngỏ:* chưa có ai đo ngưỡng k* nơi lợi ích forecast biến mất khi đã distill quá sâu (1–4 bước) — DisCa xác nhận vấn đề tồn tại (cho video) nhưng ngưỡng chính xác và cách khắc phục cho ảnh T2I kèm quant/pruning vẫn là khe hở mở (Gap D).

---

## Kết luận
DMD2 là công trình nền đúng nghĩa của Nhóm 1: giải quyết nút thắt thực dụng nhất của distillation (dataset hồi quy tốn kém), chứng minh được rằng student có thể *vượt* teacher nhờ GAN loss trên dữ liệu thật, và tạo ra một họ bài follow-up sửa đúng các đánh đổi nó để lại (diversity, quantization-aware scheduling, caching tương thích distillation). Nhưng khi đặt cạnh stack nén 3 trục của luận văn (TinyFusion × SVDQuant × TaylorSeer), DMD2 **không phải trục thứ tư trực giao** — nó cạnh tranh trực tiếp với TaylorSeer trên cùng ngân sách số-bước-sampling, một xung đột đã được DisCa (2602.05449) xác nhận thực nghiệm cho video; giá trị nghiên cứu còn lại cho luận văn nằm ở việc **định lượng ranh giới NFE nơi caching hết tác dụng sau distillation, và kiểm tra liệu pruning/quantization có bù lại được khoảng trống đó cho ảnh T2I** — một khe hở (Gap D) thực sự còn trống tính đến 18/07/2026.
