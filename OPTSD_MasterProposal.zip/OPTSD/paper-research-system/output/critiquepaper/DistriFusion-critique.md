# Đánh giá chuyên gia — DistriFusion: Distributed Parallel Inference for High-Resolution Diffusion Models

**Paper:** Muyang Li, Tianle Cai, Jiaxin Cao, Qinsheng Zhang, Han Cai, Junjie Bai, Yangqing Jia, Ming-Yu Liu, Kai Li, Song Han · **CVPR 2024 Highlight** · https://arxiv.org/abs/2402.19481
**Ngày đánh giá:** 18/07/2026

> **Ghi chú xác minh:** Method/kết quả từ abstract `/abs/` + HTML `/html/` (đã fetch 2 lần độc lập, chọn bản nhất quán nội bộ). Phần "kiểm tra khe hở" mỗi link chính đã fetch `/abs/` trực tiếp (không suy đoán từ snippet search). Các paper follow-up dẫn dưới đây đều có ngày nộp **2024–2025**, trong mốc kiến thức 01/2026 của tôi — không cần cảnh báo "ngoài mốc", nhưng nội dung chi tiết (bảng số) vẫn chỉ lấy từ abstract đã fetch, không suy diễn.

---

## Định vị trong lĩnh vực
DistriFusion thuộc **Nhóm 6B (Distributed/Parallel Inference)** — tầng **hạ tầng/kernel-hệ thống**, khác về bản chất với Nhóm 4 (caching đổi kết quả xấp xỉ theo thời gian) và Nhóm 5 (kiến trúc mới): đây là tối ưu **exact**, không đổi công thức thuật toán diffusion, chỉ đổi **cách phân phối tính toán** một lần sinh ảnh ra nhiều GPU. Được chọn làm SOTA đại diện Nhóm 6 vì: (a) venue mạnh — **CVPR 2024 Highlight**; (b) là **bước ngoặt phương pháp luận** — công thức "displaced patch parallelism" (tái dùng activation "lệch một bước" để biến giao tiếp đồng bộ thành bất đồng bộ, xen kẽ tính toán) là ý tưởng gốc cho toàn bộ nhánh song song hoá đặc thù-diffusion sau đó; (c) tác động thực tế mạnh — trực tiếp sinh ra **PipeFusion, xDiT, USP** (đều nằm trong SURVEY.md Nhóm 6B) và loạt follow-up 2024–2025 (STADI, CompactFusion, PCPP). **Á quân:** *Sparse VideoGen* (2502.01776, ICML 2025) — cũng đặc thù diffusion (video DiT), cũng training-free và sinh follow-up (STA, SpargeAttention, Radial Attention đều trích dẫn/tiếp nối hướng phân loại head sparse), nhưng thuộc nhánh 6A (kernel attention) hẹp hơn về phạm vi ảnh hưởng hệ thống so với 6B — DistriFusion định hình cả một *kiến trúc suy luận phân tán* còn Sparse VideoGen định hình một *kernel attention*.

## 1. Điểm mạnh
- **Ý tưởng gọn, đúng chỗ đau:** khai thác đúng đặc thù diffusion (input liên tiếp giống nhau) để giải quyết đúng nút thắt của song song hoá patch (giao tiếp biên) — không phải patch cho patch xong lắp ghép, mà là "mượn ngữ cảnh từ quá khứ gần".
- **Exact về tinh thần, không đổi thuật toán:** không retrain, không xấp xỉ hoá công thức denoising — khác các nhóm caching/quantization phải đánh đổi chất lượng-tốc độ trực tiếp trên đầu ra.
- **Bằng chứng đối chứng rõ (naïve patch parallelism):** cùng hạ tầng, chỉ thiếu cơ chế displaced-reuse, FID vỡ từ 24→252 ở 8 GPU — chứng minh trực tiếp giá trị của đóng góp cốt lõi, không phải chỉ nhờ "nhiều GPU hơn".
- **Corrected Async GroupNorm** là chi tiết kỹ thuật khéo — giải quyết đúng vấn đề chuẩn hoá toàn cục vốn là điểm nghẽn kinh điển của mọi phép chia patch.
- **Sức ảnh hưởng đã được chứng minh theo thời gian** (2024→2026): PipeFusion, xDiT, USP, STADI, CompactFusion, PCPP đều định vị mình *so với* DistriFusion — dấu hiệu công trình nền thực sự, không chỉ tuyên bố suông.

## 2. Điểm hạn chế
- **Phụ thuộc NVLink** — tự paper thừa nhận: không có NVLink thì không giấu hết được giao tiếp; trên cluster PCIe-only lợi ích giảm mạnh (PipeFusion sau đó nhắm chính vào khoảng trống này).
- **Suy giảm ở ảnh có nhiều bước khởi động thấp hoặc few-step samplers:** cảnh báo "may not work for extremely-few-step methods" — nghĩa là *không trực giao hoàn toàn* với các hướng giảm bước (distillation/fast solver, Nhóm 1–2 của luận văn) — cần warm-up đủ dài để tái dùng đặc trưng có ý nghĩa.
- **Lợi ích tỉ lệ với độ phân giải:** ở 1024×1024 chỉ 2.8× (8 GPU) so với 6.1× ở 3840×3840 — với ảnh/video thông thường (không siêu cao) hiệu quả kém hấp dẫn hơn số headline 6.1×.
- **Đánh đổi communication ẩn:** dù ít hơn tensor parallelism, PCPP (2412.02962) đo được có thể giảm thêm ~70% giao tiếp so với DistriFusion — nghĩa là bản gốc chưa phải điểm tối ưu Pareto, còn khoảng trống communication-vs-quality mà chính DistriFusion để lại.
- **Không tự thích ứng phần cứng dị chủng (heterogeneous GPU):** giả định ngầm các GPU đồng tốc — STADI (2509.04719) chỉ ra khoảng trống này khi GPU không đồng nhất/có tải nền.

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *đặc trưng/activation giữa hai bước denoising liên tiếp đủ giống nhau để dùng thay thế mà không tích lũy lỗi qua nhiều bước.* Đúng thực nghiệm trên SDXL/DDIM 50 bước với warm-up đủ; nhưng **không có chặn sai số lý thuyết** cho việc lỗi "lệch một bước" có tích lũy theo số bước hay không — paper chỉ chứng minh bằng thực nghiệm cuối kỳ (FID cuối), không phân tích quỹ đạo sai số theo từng bước.
- Giả định **corrected GroupNorm xấp xỉ đủ tốt** cho mọi kiến trúc/độ phân giải — chỉ kiểm chứng trên SDXL (UNet), chưa rõ với kiến trúc Transformer-based (DiT) có cùng hành vi thống kê không (PipeFasion sau đó mới mở rộng sang DiT).
- Giả định **warm-up length cố định** là đủ cho "mọi" prompt/nội dung — không có tiêu chí chọn số bước warm-up thích ứng theo độ phức tạp ảnh.

## 4. Rủi ro có thể phát sinh
- **Tích lũy sai số activation** qua rất nhiều bước hoặc với sampler bước lớn không đều (non-uniform schedule) — chưa có phân tích lý thuyết, chỉ có "nó hoạt động tốt trên benchmark đã test".
- **Không portable sang few-step/distillation models** (đối lập trực tiếp với Nhóm 1 luận văn) — nếu kết hợp với distillation 1–4 bước, "input liên tiếp giống nhau" có thể không còn đúng vì mỗi bước nhảy xa hơn trong không gian latent.
- **Yêu cầu hạ tầng đặc thù (NVLink, GPU đồng nhất)** hạn chế khả năng ứng dụng ngoài data-center cao cấp — không phù hợp on-device/edge (khác hẳn hướng SnapFusion/MobileDiffusion của Nhóm 5/6 khác).
- **Hiệu lực đo lường:** FID/LPIPS trên COCO 5K là proxy chất lượng phổ biến nhưng không bắt được artefact biên patch tinh vi ở vùng chi tiết cao — cần đánh giá thị giác người dùng bổ sung.

## 5. Cơ hội đáng chú ý
- **Ghép với communication compression** (residual/quantized activation — hướng CompactFusion đã mở) để giảm thêm phụ thuộc NVLink.
- **Mở rộng sang kiến trúc dị chủng / GPU không đồng tốc** (STADI đã làm một phần) — vẫn còn dư địa với edge cluster hỗn hợp.
- **Warm-up thích ứng theo nội dung/độ phức tạp ảnh** — chưa ai làm tường minh.
- **Ghép trực giao với 3 trục nén mô hình của luận văn (TinyFusion × SVDQuant × TaylorSeer)** — xem Mục 7.

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa? *(tìm 18/07/2026)*

### Gap A — Giảm phụ thuộc giao tiếp / NVLink, cải thiện Pareto latency-quality
- 🔴 **PipeFusion** (Jiarui Fang, 2024, [2405.14430](https://arxiv.org/abs/2405.14430)) — thay patch-parallel bằng pipeline-parallel mức patch+layer, giảm giao tiếp mạnh hơn, hoạt động tốt trên PCIe (không cần NVLink), mở rộng sang DiT (Pixart, SD3, Flux.1). **Đã lấp** (trong SURVEY.md #9).
- 🔴 **PCPP — Partially Conditioned Patch Parallelism** (XiuYu Zhang, 12/2024, [2412.02962](https://arxiv.org/abs/2412.02962), đã fetch `/abs/`) — giảm thêm ~70% giao tiếp so với DistriFusion, speedup 2.36–8.02× (4–8 GPU) vs 2.32–6.71× của DistriFusion, đổi lại **có thể giảm chất lượng ảnh** (tự thừa nhận). **Đã lấp một phần** — nhưng mở khoảng trống mới (trade-off quality chưa tối ưu).
- 🔴 **CompactFusion — Residual Compression** (Jiajun Luo, 07/2025, [2507.17511](https://arxiv.org/abs/2507.17511), đã fetch `/abs/`) — nén *residual* activation liên bước (temporal redundancy) để giảm giao tiếp, nén dưới 1% dữ liệu gốc mà vẫn vượt chất lượng DistriFusion, 3.0× trên 4×L20. **Đã lấp** hướng "giấu giao tiếp bằng nén activation".

### Gap B — Phần cứng dị chủng / heterogeneous GPU
- 🔴 **STADI** (Han Liang, 09/2025, [2509.04719](https://arxiv.org/abs/2509.04719), đã fetch `/abs/`) — lịch trình step-patch thích ứng cho cluster GPU không đồng tốc, giảm latency tới 45% so với patch parallelism SOTA. **Đã lấp.**

### Gap C — Ghép patch-parallel/distributed inference × nén mô hình (quantization trọng số W4A4 kiểu SVDQuant, pruning độ sâu kiểu TinyFusion, forecast đặc trưng kiểu TaylorSeer)
- 🟡 CompactFusion/PCPP chỉ nén **activation giao tiếp giữa GPU** (communication-level), **không** nén trọng số mô hình (weight quantization W4A4) hay cắt lớp (structural depth pruning) — khác bản chất với SVDQuant/TinyFusion. Search chung ("quantization can reduce communication workloads for patch parallelism") chỉ là nhận định định hướng chung trong literature, **chưa có paper cụ thể** ghép W4A4-model-weight-quant (kiểu SVDQuant) *cùng lúc* với displaced patch parallelism.
- 🟢 **Còn trống — xác nhận qua nhiều truy vấn WebSearch độc lập (không tìm thấy paper nào khớp):** chưa có công trình nào ghép **đúng bộ**: (1) DistriFusion-style displaced patch/pipeline parallelism (đa GPU, hệ thống), (2) SVDQuant W4A4 (lượng tử trọng số+activation trên từng GPU), (3) TinyFusion depth pruning (giảm số lớp trước khi phân phối qua GPU), và (4) TaylorSeer forecast theo thời gian (bỏ qua tính lại toàn bộ bước) — **cùng một pipeline, kèm phân tích tương tác lỗi giữa 4 trục**. Đây là khe hở rõ nhất, đặc biệt câu hỏi: *warm-up steps của DistriFusion (đồng bộ hoàn toàn, "định hình cấu trúc tần số thấp") có xung đột với các bước bị TaylorSeer "bỏ qua" (forecast) không — vì cả hai đều dựa vào giả định "các bước liên tiếp giống nhau" nhưng khai thác nó theo 2 chiều khác nhau (không gian GPU vs thời gian).*

**Khuyến nghị:** Gap A/B đã bão hòa tương đối (nhiều nhóm cạnh tranh 2024–2025). Gap C — ghép hệ thống-phân tán × nén mô hình 3 trục — vẫn mở và hợp với hướng luận văn (xem Mục 7).

## 7. Kết hợp & mầm proposal

**Vai trò của DistriFusion trong stack:** DistriFusion (và nhánh 6B nói chung) là tầng **hạ tầng/hệ thống trực giao** — nó không đổi trọng số, không đổi số bước, không đổi kiến trúc mạng, chỉ đổi **nơi** tính toán chạy (1 GPU → N GPU) và **khi nào** dữ liệu được đồng bộ. Về nguyên tắc nó cộng hưởng *nhân* với cả 3 trục nén mô hình:

| Trục | Cắt giảm gì | Đơn vị áp dụng | Quan hệ với DistriFusion |
|---|---|---|---|
| **TinyFusion** | Số lớp (depth pruning) | Trên mỗi GPU, trước khi chia patch | **Cộng hưởng thuận:** ít lớp hơn → mỗi patch tính nhanh hơn trên từng GPU, không đổi cơ chế patch/communication. |
| **SVDQuant** | Bit-width trọng số+activation (W4A4) | Trên mỗi GPU, per-op | **Cộng hưởng thuận nhưng có ma sát:** giảm compute/memory mỗi GPU, và nếu quantize luôn activation *trao đổi giữa GPU* thì còn giảm thêm giao tiếp (như CompactFusion gợi ý) — nhưng **corrected Async GroupNorm** của DistriFusion xấp xỉ thống kê từ activation "cũ"; nếu activation đó đã bị lượng tử 4-bit, sai số xấp xỉ chuẩn hoá có thể **cộng dồn** với sai số lượng tử (chưa ai đo). |
| **TaylorSeer** | Số bước tính lại (forecast thay vì tính) | Theo thời gian (toàn cục, trước khi chia GPU) | **Xung đột tiềm ẩn cần kiểm chứng:** cả TaylorSeer và DistriFusion đều dựa trên "hai bước liên tiếp giống nhau" — TaylorSeer **bỏ qua tính toán** ở bước bị forecast (không có activation "thật" mới), còn DistriFusion **cần activation thật của bước trước** để làm ngữ cảnh displaced. Nếu một bước bị TaylorSeer forecast, feature map "cũ" mà DistriFusion tái dùng có thể là **feature đã bị ngoại suy** chứ không phải feature thật đo được — sai số ngoại suy (Taylor) và sai số displaced (lệch 1 bước không gian-thời gian) **chồng lấn theo hướng xấu** (cả hai đều là "xấp xỉ theo thời gian", không độc lập ngẫu nhiên) → cần warm-up/step nào giữ "thật" (không forecast) để DistriFusion neo lại, tránh trôi tích lũy song song trên 2 trục thời gian.

**Kết luận cộng hưởng/xung đột:**
- **Nền tảng/trực giao thật:** DistriFusion × TinyFusion — gần như không ma sát, vì pruning tác động *cấu trúc mạng* còn DistriFusion tác động *phân phối tính toán không gian*, hai trục không chia sẻ giả định.
- **Trực giao có ma sát nhẹ, đáng đo:** DistriFusion × SVDQuant — cộng hưởng tốc độ rõ, nhưng cần kiểm chứng thực nghiệm liệu approx-GroupNorm có khuếch đại sai số lượng tử hay không (câu hỏi mở, chưa ai công bố).
- **Xung đột cấu trúc cần thiết kế lại lịch trình:** DistriFusion × TaylorSeer — cả hai "vay mượn" theo trục thời gian nên **không thể ghép ngây thơ** (chồng 2 lớp xấp xỉ thời gian); cần đồng thiết kế lịch: bước nào là "thật" (đồng bộ, không forecast) để vừa nuôi TaylorSeer vừa nuôi DistriFusion, bước nào được cả hai "ăn theo".

### Vài dòng mầm proposal
- **Câu hỏi nghiên cứu:** Khi ghép displaced patch/pipeline parallelism (đa GPU) với forecast đặc trưng theo thời gian (TaylorSeer) và nén mô hình (SVDQuant + TinyFusion), lịch trình "bước nào tính thật, bước nào forecast, bước nào đồng bộ liên-GPU" nên thiết kế thế nào để tránh cộng dồn 2 lớp xấp xỉ thời gian (spatial-displaced và temporal-forecast) mà vẫn giữ tốc độ nhân?
- **Đóng góp dự kiến:** (1) pipeline hợp nhất 4 trục (depth-pruned, W4A4, forecast-cached, multi-GPU displaced) trên FLUX/SDXL; (2) lịch trình "anchor step" phối hợp — các bước neo (không forecast, đồng bộ đầy đủ) được chọn chung cho cả DistriFusion và TaylorSeer thay vì độc lập; (3) đo tương tác sai số thực nghiệm (câu hỏi mở nêu trên) — hiện chưa ai công bố.
- **Baseline so sánh:** DistriFusion/PipeFusion đơn lẻ + TaylorSeer đơn lẻ ghép tuần tự không điều phối (naïve stacking) vs. lịch trình anchor-step phối hợp.

## 8. Ba câu hỏi phản biện & đáp án gợi ý

**Q1. Không có chặn sai số lý thuyết cho việc tái dùng activation "lệch 1 bước" — sao biết lỗi không tích lũy qua 50 bước?**
*Đáp mạnh nhất:* thực nghiệm cho FID cuối kỳ gần như không đổi (24.0→24.4) qua nhiều số GPU và độ phân giải khác nhau — dấu hiệu thực nghiệm mạnh về ổn định.
*Điểm còn để ngỏ:* đây vẫn là bằng chứng thực nghiệm cuối kỳ, không phải chặn lý thuyết theo từng bước; PCPP/CompactFusion ra đời sau đúng vì nhìn thấy còn dư địa cải thiện chất lượng-giao tiếp, gợi ý DistriFusion chưa ở điểm tối ưu.

**Q2. Yêu cầu NVLink có làm phương pháp mất giá trị thực tế trên cluster phổ biến (PCIe)?**
*Đáp mạnh nhất:* tác giả minh bạch nêu hạn chế này; và chính hạn chế này định hướng đúng cho PipeFusion (pipeline-parallel, ít nhạy NVLink hơn) — nghĩa là dòng nghiên cứu đã tự sửa.
*Điểm còn để ngỏ:* nếu dùng DistriFusion gốc (không phải PipeFusion) trên PCIe-only, lợi ích có thể sụt mạnh — cần benchmark riêng, paper không cung cấp số PCIe.

**Q3. Ghép với TaylorSeer (forecast theo thời gian) có còn đúng giả định "bước liên tiếp giống nhau" mà DistriFusion dựa vào không?**
*Đáp mạnh nhất:* về nguyên tắc hai giả định (spatial-similarity cho DistriFusion, temporal-similarity cho TaylorSeer) không mâu thuẫn logic — cùng dựa trên tính trơn của quỹ đạo denoising.
*Điểm còn để ngỏ:* **chưa có thực nghiệm nào kiểm chứng** liệu feature bị TaylorSeer ngoại suy (không phải "thật") có còn đủ tốt để DistriFusion dùng làm ngữ cảnh liên-patch hay không — đây chính là Gap C/mầm proposal ở Mục 7, câu hỏi mở thật sự chưa ai trả lời.

---

## Kết luận
DistriFusion là công trình nền của song song hoá diffusion đa GPU (CVPR 2024 Highlight), đóng vai "enabler hạ tầng" đúng nghĩa — exact, không đổi chất lượng, và đã chứng minh sức ảnh hưởng qua một chuỗi follow-up dày đặc (PipeFusion, xDiT, USP, STADI, CompactFusion, PCPP) đến tận 2025; nhưng đúng vì phổ biến nên các khe hở "nội tại" (giảm giao tiếp, hỗ trợ GPU dị chủng) đã được lấp gần hết. Giá trị nghiên cứu còn lại nằm ở **lớp ghép trực giao với 3 trục nén mô hình của luận văn** — đặc biệt câu hỏi chưa ai trả lời: liệu forecast theo thời gian (TaylorSeer) và displaced-reuse theo không gian (DistriFusion) có cộng dồn sai số khi ghép ngây thơ, và lịch trình "anchor step" nào giải quyết được xung đột đó.
