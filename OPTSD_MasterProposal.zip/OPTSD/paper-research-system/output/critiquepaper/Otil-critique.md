# Đánh giá chuyên gia — Otil: Communication-Efficient Multi-GPU Diffusion Inference

**Paper:** Li et al. · **CVPR 2026** · [CVF PDF](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_Otil_Accelerating_Diffusion_Model_Inference_via_Communication-Efficient_Multi-GPU_Parallelism_CVPR_2026_paper.pdf) · [code](https://github.com/uplaoli/OTIL-PROJECT)
**Ngày đánh giá:** 24/07/2026

> ⚠️ **Ghi chú xác minh:** **Không lấy được abstract/PDF gốc** — server CVF liên tục từ chối kết nối lúc đánh giá. Toàn bộ nội dung từ note en.papernotes.org + đoạn search web ("Otil sends only variant activations"). **MỌI số liệu là chưa xác minh gốc** — phải mở lại PDF/repo trước khi trích dẫn. Không có bản arXiv.

---

## Định vị trong lĩnh vực
Otil thuộc Nhóm 6 (hệ thống/đa-GPU), cạnh tranh trực tiếp **DistriFusion** và **AsyncDiff** (patch-parallel / async displaced-reuse). Trường phái: song song không-gian trên nhiều GPU. Trade-off điều hướng: chấp nhận sai số của việc *chỉ cập nhật một phần* bản đồ activation, đổi lấy **giảm mạnh giao tiếp trên PCIe băng thông thấp**. **Tuyên bố trung tâm:** suy luận diffusion đa-GPU trên PCIe *bị nghẽn giao tiếp chứ không phải tính toán*, nên nén *cái gửi đi* (top-25% sub-block đổi nhiều nhất) là đòn bẩy đúng; **tuyên bố phụ:** lợi ích co lại trên NVLink.

## 1. Điểm mạnh
- **Chẩn đoán đúng nút thắt phần cứng phổ thông:** trên PCIe (không NVLink), giao tiếp là điểm chết của DistriFusion — Otil đánh trúng. Đây là điểm khiến nó **khớp trực tiếp cảnh 3090+4090 của luận văn** hơn bất kỳ bài đa-GPU nào.
- **Cơ chế đơn giản, có kiểm soát sai số:** xếp hạng cosine + top-k + round-robin đảm bảo mọi vùng cuối cùng được làm mới → chống tích lũy sai một cách tường minh.
- **Cải thiện định lượng rõ so với baseline cùng lớp:** (chưa xác minh) 1.88× vs 1.50× của DistriFusion trên SDXL 2-GPU, giảm 75% giao tiếp.
- **Trung thực về điều kiện hiệu lực:** tự nêu lợi ích nhỏ trên NVLink — tránh over-claim.

## 2. Điểm hạn chế
- **KHÔNG xử lý GPU dị chủng:** note mô tả đa-GPU đồng chủng; cân tải sub-block giữa 3090 (Ampere) và 4090 (Ada) — tốc độ/băng thông khác nhau — là bài toán mở. STADI (arXiv 2509.04719) mới là bài nhắm dị chủng.
- **Chỉ báo cáo SD1.5/SDXL:** chưa có FLUX-scale DiT; chất lượng ở mức nén cao trên model lớn chưa rõ.
- **Không so NVLink:** thiếu điểm tham chiếu để biết mất mát tuyệt đối so với thượng nguồn băng thông cao.
- **Rủi ro chất lượng chỉ mô tả "FID trong khoảng tương đương"** — mơ hồ; cần số cụ thể.

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *giữa hai bước liên tiếp, chỉ một số ít vùng không gian đổi đáng kể, và bỏ cập nhật ~75% vùng còn lại không tích lũy thành sai số nhìn thấy được* — nhờ round-robin. Đúng trực giác + có lịch làm mới, nhưng ở **tăng tốc rất cao / few-step (ít bước để round-robin phủ hết)** giả định này yếu đi (chính Otil báo tới 2.84× khi ghép few-step — nơi mỗi vùng được refresh ít lần nhất).
- Giả định sub-block 8×8 tối ưu across model/độ phân giải.
- Giả định cosine-dissimilarity là tiêu chí chọn vùng "quan trọng" đủ tốt (có thể bỏ sót vùng đổi nhỏ nhưng nhạy cảm perceptual).

## 4. Rủi ro có thể phát sinh
- **Tương tác với lượng tử W4A4 (rất liên quan luận văn):** nếu activation đã 4-bit rồi mới chọn/gửi sub-block, sai số lượng tử + sai số bỏ-cập-nhật **cộng dồn**; và GroupNorm/thống kê async có thể lệch. Trùng điểm ma sát PROPOSAL §3c.
- **Few-step regime:** round-robin cần đủ bước để phủ; ở NFE thấp (kết hợp DMD2/Phased-DMD) có thể để vùng cũ quá lâu.
- **Reproducibility:** phụ thuộc cấu hình PCIe/topology cụ thể; số tăng tốc khó tái lập trên dàn khác.

## 5. Cơ hội đáng chú ý
- **Mở rộng dị chủng 3090+4090** (kết hợp ý tưởng STADI step-patch cho GPU khác loại) — 🟢 khe hở khớp đúng phần cứng luận văn.
- **Lịch anchor-step chung** giữa Otil (bỏ-cập-nhật không gian) và HiCache/TaylorSeer (bỏ-tính thời gian) — cả hai "vay mượn" feature ở hai chiều; đồng bộ lịch là **RQ3** của proposal.
- **Otil × SVDQuant:** đo cộng dồn sai số truyền-một-phần × activation 4-bit — chưa ai làm.

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa (ngày tìm: 24/07/2026)
- **Khe hở "giảm giao tiếp đa-GPU diffusion trên PCIe"** → 🔴 **đã có (Otil + lân cận)**: Otil, "Accelerating Parallel Diffusion Serving with Residual Compression" (NeurIPS 2025, arXiv 2507.17511), Hybrid Data-Pipeline Parallelism (CVPR 2026). ⇒ Trục đa-GPU thuần đã có người; luận văn dùng làm **trục tùy chọn**, không đóng góp.
- **Khe hở "song song diffusion trên GPU DỊ CHỦNG (3090+4090)"** → 🟡 **làm một phần**: STADI (arXiv 2509.04719) nhắm heterogeneous GPUs bằng step-patch; Otil thì không. Còn chỗ ghép Otil-style communication × STADI-style load-balance.
- **Khe hở "truyền-một-phần × activation lượng tử 4-bit (cộng dồn sai số)"** → 🟢 **chưa thấy ai làm** — trùng phân tích tương tác sai số của proposal (§3c). Cơ hội để ngỏ.

## 7. Ba câu hỏi phản biện & đáp án gợi ý
**Q1. Bỏ cập nhật ~75% vùng mỗi bước, round-robin có thực sự chặn tích lũy sai số ở tăng tốc cao/few-step không?**
*Đáp:* Bảo vệ mạnh nhất — round-robin đảm bảo mọi vùng được refresh theo chu kỳ và số FID báo cáo "trong khoảng tương đương". **Điểm còn để ngỏ:** ở NFE thấp, chu kỳ phủ dài hơn số bước còn lại → vùng cũ có thể không kịp refresh; đúng chế độ 2.84× (few-step) là nơi rủi ro cao nhất mà bằng chứng mỏng nhất.

**Q2. Vì sao cosine-dissimilarity là tiêu chí chọn vùng đúng, không phải một tín hiệu perceptual?**
*Đáp:* Cosine rẻ, tương quan tốt với thay đổi feature. **Điểm còn để ngỏ:** vùng đổi *nhỏ về cosine* nhưng *nhạy về cảm nhận* (khuôn mặt, chữ) có thể bị bỏ; chưa có ablation theo loại nội dung.

**Q3. Lợi ích có tổng quát ngoài PCIe đồng chủng SD1.5/SDXL — cụ thể lên 3090+4090 dị chủng và FLUX — không?**
*Đáp:* Nguyên lý "gửi ít hơn" độc lập model/kích thước nên về lý thuyết chuyển được. **Điểm còn để ngỏ:** không có số dị chủng, không có FLUX-scale, không có NVLink-baseline; cân tải giữa card khác tốc độ là vấn đề Otil chưa giải.

**Kết luận:** Otil là bản thay thế DistriFusion đúng-kịch-bản cho đa-GPU PCIe không-NVLink nên **thay DistriFusion làm SOTA trục đa-GPU tùy chọn** trong proposal, nhưng vì nó chưa xử lý GPU dị chủng (3090+4090) lẫn tương tác với activation 4-bit, chính hai chỗ đó là khe hở còn để ngỏ mà luận văn có thể khai thác (ghép ý tưởng STADI + phân tích tương tác sai số §3c).
