# Phản biện chuyên gia — SVDQuant: Absorbing Outliers by Low-Rank Components for 4-Bit Diffusion Models

**Nguồn:** https://arxiv.org/abs/2411.05007 · ICLR 2025 (Spotlight)
**Tác giả:** Muyang Li, Yujun Lin, Zhekai Zhang, Tianle Cai, Xiuyu Li, Junxian Guo, Enze Xie, Chenlin Meng, Jun-Yan Zhu, Song Han (MIT / NVIDIA)

> Lưu ý: bản phản biện dựa trên abstract (đã xác minh) và bản HTML/tóm tắt nội dung từ lần đọc trước. Các số liệu bảng (FID, Image Reward…) là **chưa xác minh độc lập** vì PDF quá lớn không fetch được. Phần "suy luận chuyên gia" được ghi rõ để tách khỏi những gì paper thực sự tuyên bố.
>
> **Cập nhật 18/07/2026:** bổ sung (a) kết luận re-scan "best-in-group" và (b) Mục 6 — kiểm tra khe hở nghiên cứu (prior-art), làm tương tự bản TinyFusion. ⚠️ Nhiều bài follow-up dưới đây có tiền tố arXiv **2025-05 → 2026-07, ngoài mốc kiến thức của tôi (01/2026)** — đã fetch xác nhận tồn tại nhưng bạn phải tự đọc lại trước khi trích dẫn.

## Có phải bài "ok nhất" nhóm Quantization? → **Có.**

So trong SURVEY.md Nhóm 3: **PTQ4DiT** (NeurIPS 2024) / **Q-DiT** dừng ở PTQ không đẩy W4**A4**; **ViDiT-Q** (ICLR 2025) mạnh nhưng activation vẫn 8-bit (W8A8/W4A8); **DilateQuant/MPQ-DM** ít tác động hệ thống thực. **SVDQuant** thắng vì hội đủ 3 yếu tố hiếm: (1) đẩy tới **W4A4** (mốc khó nhất), (2) **thuật toán mới** (hút outlier bằng nhánh low-rank thay vì smoothing), (3) **hiện thực hệ thống** (engine **Nunchaku** — tăng tốc *đo được* 3.0–3.6×, tương thích LoRA không re-quantize). Venue mạnh nhất nhóm (**ICLR 2025 Spotlight**), phủ FLUX.1/PixArt-Σ/SANA/SDXL. → *Thay thế nếu mục tiêu khác:* cần video mà không muốn engine tùy biến → ViDiT-Q; PTQ thuần cho DiT class-conditional → PTQ4DiT.

## Định vị công trình

SVDQuant thuộc dòng **lượng tử hóa hậu-huấn-luyện (PTQ)** cho mô hình sinh ảnh, cạnh tranh trực tiếp với các phương pháp xử lý outlier như smoothing (SmoothQuant/AWQ ở LLM) và các PTQ chuyên cho diffusion (ViDiT-Q, MixDQ, Q-Diffusion). Điểm khác biệt định vị: đa số công trình trước hoặc chỉ lượng tử hóa trọng số (W4A16 — không tăng tốc thật cho diffusion vì nó *compute-bound*), hoặc thử W4A4 nhưng sụp đổ chất lượng. Đánh đổi mà SVDQuant điều hướng là: **thêm một nhánh 16-bit hạng thấp** để "gánh" outlier — hy sinh một chút tính "thuần 4-bit" và thêm chi phí kernel, đổi lấy chất lượng W4A4 dùng được. Tuyên bố trung tâm là *chất lượng W4A4 gần full-precision với tăng tốc thực đo trên phần cứng tiêu dùng*; tuyên bố phụ là các phần kỹ thuật (fusion Nunchaku, tương thích LoRA không cần lượng tử hóa lại).

**Giả định chịu tải (load-bearing):** ma trận trọng số đã làm mượt Ŵ có phổ singular value *tập trung mạnh* — vài chục giá trị đầu lớn vượt trội — nên một nhánh hạng thấp r=16/32 đủ để hút gần hết outlier, để lại phần dư "hiền" cho 4-bit.

---

## 1. Điểm mạnh

- **Phân rã bài toán sắc bén.** Việc tách sai số lượng tử hóa thành 4 thành phần (độ lớn/lượng tử của cả W và A) rồi chỉ ra rằng smoothing một mình chỉ dời outlier chứ không diệt được nó, là một lập luận chẩn đoán tốt, dẫn thẳng tới thiết kế nhánh hạng thấp. Đây là đóng góp khái niệm chứ không chỉ kỹ thuật.
- **Đồng thiết kế thuật toán–hệ thống.** Nhiều paper PTQ dừng ở "giảm bit trên giấy". SVDQuant đi tới cùng: nhận ra nhánh 16-bit ngây thơ thêm ~57% latency và giải quyết bằng kernel fusion (Nunchaku) để chỉ còn ~5–10%. Việc *đo tăng tốc thực* (không chỉ nén lý thuyết) là điểm hiếm và có giá trị thực tiễn cao.
- **Nhắm đúng nút thắt của diffusion.** Chỉ ra diffusion là compute-bound ngay ở batch 1 (khác LLM memory-bound) là lý do chính đáng để lượng tử hóa cả activation — biện minh mạnh cho mục tiêu W4A4 thay vì W4A16 dễ hơn.
- **Tính ứng dụng: LoRA không cần re-quantize.** Nhét LoRA vào nhánh hạng thấp là một tiện ích thực dụng, hạ rào cản triển khai cho cộng đồng (đổi style mà không lượng tử hóa lại).
- **Phổ mô hình rộng.** Kiểm chứng trên cả DiT (FLUX.1, PixArt-Σ, SANA) lẫn UNet (SDXL, SDXL-Turbo), gồm cả mô hình few-step — cho thấy tính khái quát của ý tưởng.

## 2. Điểm hạn chế

- **"Không hoàn toàn 4-bit".** Nhánh hạng thấp chạy 16-bit. Với r=32 trên ma trận lớn, đây là chi phí bộ nhớ/tính toán thật (~0.3 GiB theo paper). So sánh "4-bit vs baseline" cần tính công bằng phần này — nếu tính đủ, mức nén hiệu dụng hơi thấp hơn con số quảng cáo.
- **Suy giảm rõ trên mô hình nhỏ.** Ablation PixArt-Σ đạt Image Reward 0.878 so với FP16 0.944 — khoảng cách không nhỏ. Phương pháp có vẻ hưởng lợi từ độ dư thừa của mô hình lớn (FLUX.1 12B); với mô hình gọn, "phần dư" không còn hiền như giả định.
- **Phụ thuộc phần cứng chặt.** Tăng tốc gắn với kernel INT4 (RTX 4090) và NVFP4 (Blackwell/5090) của NVIDIA. Ngoài hệ sinh thái này, lợi ích tốc độ chưa được chứng minh — một hạn chế về tính khái quát của tuyên bố hệ thống.
- **Chi phí ẩn của quy trình.** Cần hiệu chuẩn offline, chọn λ theo kênh, và tinh chỉnh siêu tham số (rank, group size) theo lớp/mô hình. Paper ít định lượng chi phí engineering này để đạt kết quả tốt.
- **Đánh giá dựa nhiều vào metric tự động.** FID/Image Reward/LPIPS/PSNR có tương quan không hoàn hảo với cảm nhận người dùng, đặc biệt ở artifact tinh vi (text nhỏ, tay, texture). Thiếu (hoặc thiếu nổi bật) một human study quy mô để chốt "gần như không mất chất lượng".

## 3. Những giả định chưa được chứng minh

- **(Trung tâm) Phổ singular value luôn tập trung.** Toàn bộ phương pháp dựa vào việc Ŵ có vài chục singular value trội. Paper minh họa điều này (Figure 5) nhưng đó là *quan sát thực nghiệm trên một số lớp*, không phải bảo đảm. Nếu một họ mô hình/kiến trúc có phổ phẳng hơn, rank cố định sẽ không hút đủ outlier → phần dư vẫn khó lượng tử hóa. Đây là giả định dễ vỡ nhất.
- **Rank nhỏ cố định là đủ.** Việc r=16/32 tốt cho mọi lớp là giả định tiện lợi; các lớp khác nhau có thể cần rank khác nhau — chọn cứng có thể dưới/thừa tối ưu.
- **Outlier chủ yếu là hiện tượng "hạng thấp".** Giả định rằng outlier nằm gọn trong không gian con hạng thấp. Nếu outlier phân tán/đẳng hướng (không cấu trúc thấp), SVD sẽ kém hiệu quả — chưa có bằng chứng phủ định trường hợp này.
- **Sai số PTQ không tích lũy nguy hiểm qua nhiều bước khử nhiễu.** Diffusion chạy hàng chục bước; giả định sai số mỗi bước nhỏ và không cộng dồn thành lệch phân phối cần được kiểm chứng kỹ hơn, nhất là ở lịch trình nhiều bước.

## 4. Rủi ro có thể phát sinh

- **Tính tái lập.** Kết quả tốt phụ thuộc kernel tùy chỉnh + calibration cẩn thận; nhóm không có hạ tầng tương tự có thể khó tái lập đúng cả chất lượng *và* tốc độ.
- **Hiệu lực đánh giá.** Nếu kết luận "gần full-precision" chủ yếu dựa trên metric tổng hợp trên MJHQ/sDCI, có rủi ro over-claim ở các phân phối prompt khác (ví dụ ảnh có chữ, sơ đồ, khuôn mặt) — nơi 4-bit thường lộ artifact.
- **Chi phí ẩn khi mở rộng.** Với mô hình/kiến trúc mới, chi phí tinh chỉnh siêu tham số per-layer có thể lớn hơn kỳ vọng, làm giảm sức hấp dẫn "cắm là chạy".
- **Rủi ro khái quát.** Hiệu quả có thể lệ thuộc vào việc mô hình lớn dư thừa; khi ngành đi theo hướng mô hình nhỏ-hiệu quả, biên lợi ích có thể co lại.
- **An toàn/khử phòng vệ.** Giảm bit có thể ảnh hưởng vi tế tới các cơ chế an toàn (watermark, bộ lọc nội dung) tích hợp trong mô hình — chưa được khảo sát.

## 5. Cơ hội đáng chú ý

- **Nguyên lý "nhánh hạng thấp gánh outlier" có thể tổng quát hóa** sang LLM, VLM, và các lớp attention/MLP khác — một khung tư duy tái sử dụng được, không riêng diffusion.
- **Kết hợp với QAT** để vượt rào 3-bit (paper thừa nhận PTQ thuần thất bại dưới ~3-bit): SVDQuant làm khởi tạo tốt cho fine-tune nhận thức lượng tử.
- **Rank thích ứng theo lớp** (chọn r theo phổ singular value thực tế) là hướng cải tiến rõ ràng, có thể vừa tăng chất lượng vừa giảm chi phí.
- **Nunchaku như hạ tầng dùng chung.** Engine fusion có thể trở thành nền tảng triển khai diffusion 4-bit trên GPU tiêu dùng, mở khóa on-device generation.
- **Tương thích LoRA** mở ra hệ sinh thái adapter cho mô hình đã lượng tử — giá trị sản phẩm rõ rệt.

---

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa? *(tìm ngày 18/07/2026)*

> ⚠️ Không gian này **đông đúc hơn hẳn pruning**. Hầu hết bài dưới đây ngoài mốc kiến thức của tôi — đã fetch `/abs/` xác nhận tồn tại nhưng cần bạn tự đọc kỹ.

### Gap A — Nhánh low-rank / lượng tử *thích ứng theo timestep*
- 🔴 **Timestep-Aware SVDQuant-GPTQ for Wan2.2-I2V** (Junhao Wu, 2026, [2605.27003](https://arxiv.org/abs/2605.27003)) — **trực tiếp** ghép SVDQuant + timestep-bin-wise clipping per-expert, nhưng **chỉ cho video Wan2.2 MoE** và làm qua *tìm clipping-ratio theo bin*, chưa phải "nhánh low-rank tự thích ứng".
- 🟡 **TR-DQ** ([2503.06564](https://arxiv.org/abs/2503.06564)), **DiRotQ** ([2605.16732](https://arxiv.org/abs/2605.16732)), **Hierarchical Timestep Grouping PTQ** ([2503.06930](https://arxiv.org/abs/2503.06930)) — xử lý outlier theo timestep qua **rotation/shift-scale/grouping**, *không* qua nhánh low-rank.
- **Kết luận:** 🟡 khe hẹp còn lại (làm low-rank branch thích ứng timestep cho **image DiT**), nhưng hướng timestep-aware nói chung đã đông → rủi ro trùng cao.

### Gap B — Phân bổ / tối ưu rank thích ứng cho nhánh low-rank
- 🟡 **LoRaQ: Optimized Low Rank Approximation for 4-bit Quantization** (Yann Bouquet, 2026, [2604.18117](https://arxiv.org/abs/2604.18117)) — tối ưu xấp xỉ low-rank cho PTQ 4-bit trên **PixArt-Σ/SANA** (đúng miền); abstract chưa xác nhận per-layer adaptivity nhưng đã lấn thẳng vào ý này → cần đọc kỹ.
- 🟡 **TwinQuant** (learnable subspace decomposition, [2606.01556](https://arxiv.org/abs/2606.01556)) — decomposition học được nhưng cho **LLM**.
- **Kết luận:** 🟡 bị lấn một phần; phải phân biệt rõ với LoRaQ.

### Gap C — Sub-4-bit (W3A3/W2) qua hấp thụ low-rank
- 🟢/🟡 Chưa thấy bài trực diện ghép "low-rank absorption" ở mức <4-bit cho diffusion (**BiDM** [2412.05926](https://arxiv.org/abs/2412.05926) đẩy tới nhị phân nhưng *khác cơ chế*). → **Trống nhất** trong 3 gap thuần-quantization.

### Gap D — Stack nén trực giao: SVDQuant × depth-pruning (TinyFusion)
- 🟢 Chưa thấy bài kết hợp **low-rank-absorption quantization + learnable depth pruning** thành pipeline chung cho DiT. → **Giao điểm với hướng luận văn của bạn** — trống + hợp mạch nhất.

**Khuyến nghị:** bám riêng SVDQuant → **Gap C** trống nhất; xét tổng thể luận văn (đã chọn TinyFusion) → **Gap D (stack SVDQuant × TinyFusion)** giá trị cao và khó bị phủ nhận. **Tránh Gap A** (timestep-aware) vì đã quá đông.

## 7. Ba câu hỏi phản biện & đáp án gợi ý

**Câu 1 — Về giả định phổ hạng thấp:**
*"Phương pháp giả định phổ singular value của trọng số đã làm mượt tập trung ở vài chục giá trị đầu. Điều gì xảy ra khi một lớp (hoặc một kiến trúc) có phổ phẳng hơn, và rank cố định r=16/32 có phải lựa chọn tối ưu cho mọi lớp không?"*

> **Đáp án gợi ý (bảo vệ paper):** Quan sát thực nghiệm (Figure 5) cho thấy trên các lớp linear của DiT/UNet đã khảo sát, phổ đều dốc mạnh sau khi smoothing — vì smoothing chủ động dồn outlier vào một số hướng. Với lớp phổ phẳng, có thể tăng rank cục bộ; chi phí thêm nhỏ vì nhánh đã được fuse gần như miễn phí. **Điểm còn để ngỏ:** paper chưa chứng minh tính phổ quát của phổ dốc, cũng chưa thử rank thích ứng theo lớp — đây đúng là điểm yếu trung tâm, và câu trả lời trung thực là "đúng với các mô hình đã test, chưa bảo đảm cho mọi kiến trúc".

**Câu 2 — Về công bằng của so sánh nén/tăng tốc:**
*"Nhánh hạng thấp chạy 16-bit và tốn thêm bộ nhớ/tính toán. Khi so 'W4A4 của chúng tôi' với baseline, con số nén và tăng tốc đã tính đủ chi phí nhánh 16-bit + overhead kernel chưa, hay chỉ tính phần residual 4-bit?"*

> **Đáp án gợi ý:** Paper *có* tính phần này: mức nén ~3.5× và tăng tốc ~3.0× (so NF4 W4A16) là số đo end-to-end đã bao gồm nhánh hạng thấp (~0.3 GiB) và overhead fusion (~5–10%). Chính việc đo *thực tế trên phần cứng* (không phải nén lý thuyết) là điểm mạnh. **Điểm còn để ngỏ:** so sánh sẽ thuyết phục hơn nếu có bảng tách bạch riêng chi phí nhánh 16-bit và một baseline "W4A4 thuần không nhánh" để thấy rõ đánh đổi chất lượng ↔ chi phí.

**Câu 3 — Về hiệu lực đánh giá chất lượng:**
*"Kết luận 'gần như không mất chất lượng' dựa chủ yếu vào FID/Image Reward/LPIPS/PSNR trên MJHQ-30K và sDCI. Các metric này có bắt được artifact 4-bit tinh vi (chữ nhỏ, khuôn mặt, cấu trúc hình học) không, và có human study nào chốt kết luận này không?"*

> **Đáp án gợi ý:** Bộ metric đa chiều (cả chất lượng lẫn tương đồng theo cặp như LPIPS/PSNR so với ảnh FP16) hạn chế được rủi ro một metric đơn lẻ đánh lừa; khoảng cách với FP16 rất nhỏ trên mô hình lớn. **Điểm còn để ngỏ:** các metric tổng hợp nổi tiếng là kém nhạy với artifact cục bộ (text, tay, hình học); nếu không có human study quy mô trên phân phối prompt "khó", tuyên bố "gần như không mất chất lượng" nên được đọc là *theo metric tự động*, không nhất thiết theo cảm nhận người dùng ở mọi loại ảnh.

---

## Kết luận đánh giá

SVDQuant là một công trình PTQ mạnh và thực dụng: nó biến W4A4 cho diffusion từ "sụp đổ" thành "dùng được" nhờ một hiểu biết sắc bén (dời-rồi-hút outlier bằng nhánh hạng thấp SVD) kết hợp đồng thiết kế hệ thống hiếm thấy — nhưng lợi ích của nó gắn chặt với giả định phổ hạng thấp, mô hình đủ lớn, và kernel NVIDIA, nên nên được xem là bước tiến quan trọng nhưng chưa phải giải pháp phổ quát.
