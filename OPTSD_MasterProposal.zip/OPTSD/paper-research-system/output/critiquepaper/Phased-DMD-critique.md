# Đánh giá chuyên gia — Phased DMD: Few-step DMD via Score Matching within Subintervals

**Paper:** Xiangyu Fan, Zesong Qiu, Zhuguanyu Wu, Fanzhou Wang, Zhiqian Lin, Tianxiang Ren, Dahua Lin, Ruihao Gong, Lei Yang · **CVPR 2026** · https://arxiv.org/abs/2510.27684
**Ngày đánh giá:** 24/07/2026

> **Ghi chú xác minh:** Abstract nguyên văn từ `/abs/`. Số định lượng (Wan2.2: OF 3.23→9.30; Dynamic Degree 65.45%→82.27%; DINOv3 0.828→0.768) từ note en.papernotes.org — **chưa đối chiếu bảng PDF**. Có tác giả Ruihao Gong (nhóm quantization/efficient nổi tiếng).

---

## Định vị trong lĩnh vực
Phased DMD thuộc Nhóm 1 (distillation), là **bản mở rộng few-step của DMD/DMD2**. Trường phái: distribution-matching distillation (không cần khớp 1-1 quỹ đạo teacher, khác consistency/flow-map). Trade-off điều hướng: chấp nhận *một số ít bước* + huấn luyện nhiều expert theo pha, đổi lấy việc **khôi phục diversity (ảnh) và động lực chuyển động (video)** mà 1-bước đánh mất — nhưng **không tăng chi phí suy luận** (MoE chọn expert theo pha). **Tuyên bố trung tâm:** phase-wise + subinterval-score-matching là cách đúng để làm few-step DMD ổn định; **tuyên bố phụ:** SGTS (giải pháp cũ) thực chất kéo đa-bước về chất lượng 1-bước.

## 1. Điểm mạnh
- **Chẩn đoán sắc và có giá trị độc lập:** chỉ ra SGTS âm thầm sập diversity/chuyển động — một phản-bằng-chứng hữu ích cho cả cộng đồng, không chỉ để bán phương pháp của mình.
- **Thiết kế "miễn phí lúc suy luận":** MoE-theo-pha không tăng NFE/độ trễ inference so với few-step thường → đúng tinh thần tăng tốc.
- **Bỏ phụ thuộc ground-truth:** back-simulation dừng ở timestep trung gian + score-matching trong-khoảng có dẫn xuất chặt → sạch về mặt lý thuyết.
- **Kiểm chứng quy mô rất lớn:** Qwen-Image-20B, Wan2.2-28B — hiếm bài distillation dám chạy cỡ này, tăng độ tin cậy thực dụng.

## 2. Điểm hạn chế
- **Chi phí huấn luyện tăng:** nhiều expert theo pha → nhiều lần train / lưu tham số; "free" chỉ đúng ở inference, không ở train (abstract không định lượng).
- **Chưa thử ở quy mô tiêu dùng:** toàn model 20B/28B; **FLUX-dev/SDXL (mục tiêu luận văn) chưa có số** → không rõ lợi ích còn bao nhiêu khi model nhỏ hơn, ít pha hơn.
- **Số/vị trí khoảng SNR là thiết kế thủ công:** chưa học được, chưa ablation ranh giới khoảng.
- **Diversity ảnh báo cáo định tính ở abstract:** con số DINOv3 (chưa xác minh) thực ra cho thấy diversity Phased (0.768) *thấp hơn* DMD2 (0.828) — cần đọc kỹ chiều đo (có thể diversity đo bằng chỉ số khác; mâu thuẫn biểu kiến này phải làm rõ).

## 3. Những giả định chưa được chứng minh
- **Giả định trung tâm (load-bearing):** *chia dải SNR thành khoảng con và huấn luyện expert riêng từng khoảng sẽ giảm độ khó học mà không tạo đường-may (seam) giữa các pha.* Ghép các expert ở ranh giới khoảng có thể gây gián đoạn phân phối — abstract khẳng định "rigorous formulation" nhưng tính liên tục qua ranh giới chưa được chứng minh tường minh.
- Giả định số pha nhỏ đủ để phủ độ phức tạp mà không nổ chi phí train.
- Giả định kết quả 20B/28B tổng quát xuống model nhỏ.

## 4. Rủi ro có thể phát sinh
- **Xung đột với caching (rất liên quan luận văn):** DisCa cho thấy áp caching lên model đã step-distilled bị hỏng nặng hơn. Phased DMD là *few-step distilled* → nếu ghép TaylorSeer/HiCache lên nó, ngân sách caching gần như bằng 0 và rủi ro sập chất lượng cao. Củng cố quyết định **tách DMD2/Phased-DMD thành chế độ vận hành riêng, không bật caching** (PROPOSAL §3b).
- **Reproducibility:** train MoE-theo-pha ở cỡ 20B/28B tốn tài nguyên khổng lồ → khó tái lập trên 3090/4090.
- **Hiệu lực đánh giá chuyển động:** OF/Dynamic Degree có thể không bắt hết artifact chuyển động tinh vi.

## 5. Cơ hội đáng chú ý
- **Ranh giới NFE k\*** nơi few-step-distill (Phased DMD) vượt "nhiều-bước-có-caching" — trùng **RQ4** của proposal.
- **Phased DMD × pruning cấu trúc (Đóng góp 1):** distill một model *đã prune bất đối xứng* — expert theo pha có bù được dung lượng mất do prune không? Khe hở kép chưa ai chạm.
- **Học ranh giới khoảng SNR** thay vì đặt cứng — mở rộng tự nhiên.

## 6. Kiểm tra khe hở nghiên cứu — đã có ai làm chưa (ngày tìm: 24/07/2026)
- **Khe hở "few-step distillation khôi phục diversity/motion"** → 🔴 **đã có (chính bài này + lân cận)**: Phased DMD, Transition Matching Distillation (CVPR 2026), CMT (ICLR 2026), Causal Forcing (ICML 2026). ⇒ Trục distillation *thuần* đông; luận văn dùng làm **chế độ vận hành**, không phải đóng góp.
- **Khe hở "ghép distillation few-step × caching an toàn"** → 🟡 **lân cận, chưa giải quyết**: DisCa (CVPR 2026) mới xử lý caching-tương-thích-distill ở video, chưa ai đo Phased-DMD × HiCache trên ảnh. Còn chỗ.
- **Khe hở "distill model đã pruning bất đối xứng"** → 🟢 **chưa thấy ai làm** (tìm "distillation pruned diffusion transformer attention MLP" chỉ ra 2ndMatch — là *finetune phục hồi*, không phải distill few-step). Cơ hội cho khớp Đóng góp 1 × Nhóm 1.

## 7. Ba câu hỏi phản biện & đáp án gợi ý
**Q1. Chia SNR thành khoảng và train expert riêng có tạo gián đoạn phân phối ở ranh giới không?**
*Đáp:* Bảo vệ mạnh nhất — score-matching trong-khoảng có dẫn xuất chặt và progressive-refinement đảm bảo chuyển tiếp mượt về SNR cao. **Điểm còn để ngỏ:** abstract không đưa bằng chứng định lượng về tính liên tục qua ranh giới; artifact "seam" giữa expert là rủi ro chưa loại trừ.

**Q2. "Không thêm chi phí suy luận" có che chi phí huấn luyện nhiều expert không?**
*Đáp:* Đúng rằng inference chỉ chọn 1 expert/pha nên NFE không đổi. **Điểm còn để ngỏ:** chi phí train (nhiều expert × model 20B/28B) không được định lượng; với nhóm tài nguyên hạn chế đây là rào cản tái lập lớn.

**Q3. Kết quả trên 20B/28B có tổng quát xuống FLUX-dev/SDXL — mục tiêu triển khai tiêu dùng — không?**
*Đáp:* Distribution-matching vốn không phụ thuộc kích thước teacher nên về nguyên tắc chuyển được. **Điểm còn để ngỏ:** không có số ở quy mô nhỏ; lợi ích diversity/motion có thể co lại khi model nhỏ và số pha ít.

**Kết luận:** Phased DMD là hậu duệ đáng giá của DMD2 cho chế độ few-step (khôi phục diversity/motion mà không tăng chi phí inference) nên **đưa vào proposal kèm DMD2 làm SOTA trục distillation**, nhưng vì nó tạo ra chính "model đã distilled" mà DisCa cảnh báo không hợp caching, nó *củng cố* — chứ không phá — quyết định tách distillation thành chế độ vận hành riêng.
