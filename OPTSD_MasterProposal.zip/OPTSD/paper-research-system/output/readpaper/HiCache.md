# HiCache: A Plug-in Scaled-Hermite Upgrade for Taylor-Style Cache-then-Forecast Diffusion Acceleration

**Tác giả:** Liang Feng, Shikang Zheng, Jiacheng Liu, Yuqi Lin, Qinming Zhou, Peiliang Cai, Xinyu Wang, Junjie Chen, Chang Zou, Yue Ma, Linfeng Zhang
**Venue:** ICLR 2026 (Poster) · arXiv 2508.16984
**Nguồn:** https://arxiv.org/abs/2508.16984 · [code](https://github.com/fenglang918/HiCache) · [OpenReview](https://openreview.net/forum?id=faYbbo1KsQ)

> **Ghi chú xác minh (ngày 24/07/2026):** Abstract lấy **nguyên văn** từ trang `/abs/`. **Đã xác minh (khớp abstract):** 5.55× trên FLUX.1-dev (chất lượng bằng/vượt baseline); nâng ClusCa từ ImageReward 0.9480 → 0.9840; áp dụng T2I/video/super-resolution; hoạt động độc-lập hoặc tích-hợp-với-TaylorSeer. **Chưa xác minh (từ note en.papernotes.org — chỉ tham khảo):** ImageReward 0.9979 (HiCache) vs 0.9572 (TaylorSeer) và LPIPS 0.3982 vs 0.4520 ở 5.55× — cần đối chiếu bảng trong PDF trước khi trích chính thức. Danh tính tác giả **Jiacheng Liu, Chang Zou, Junjie Chen, Linfeng Zhang** trùng nhóm TaylorSeer → HiCache là bài **kế nhiệm chính chủ** của TaylorSeer.

---

# English version

## 1. Purpose of the document
Diffusion Transformers are slow because of iterative sampling. **Feature caching** accelerates them by *forecasting* future-step features via temporal extrapolation (the TaylorSeer paradigm), but forecasting quality degrades when the mathematical basis mis-models how features actually evolve. HiCache aims to **push the caching speed–quality frontier further** by replacing the Taylor monomial basis with a basis that provably matches the empirical statistics of DiT feature derivatives — **without any training**, as a plug-in on top of the whole caching family.

## 2. Main content, section by section
**Motivation.** TaylorSeer extrapolates skipped-step features with a Taylor (monomial) series. Monomials are monotonic and diverge quickly, so they poorly fit non-monotonic feature trajectories with inflection points — extrapolation error blows up and caps the achievable speedup.

**Key insight.** The finite-difference approximations of DiT feature derivatives empirically follow a **multivariate Gaussian** distribution. By Karhunen–Loève / Gaussian-process theory, **Hermite polynomials** are the optimal orthogonal basis for Gaussian-correlated processes → they fit the feature trajectory far better than monomials at the same order.

**Method — Scaled-Hermite forecast.**
- Replace the Taylor monomial basis with **scaled Hermite polynomials** for the cache-then-forecast extrapolation.
- A **dual-scaling mechanism** (contraction factor σ acting on both input bounds and coefficient magnitudes) guarantees numerical stability while preserving predictive accuracy.
- **Zero extra FLOPs**, training-free, drop-in: works standalone OR layered on top of TaylorSeer and other caching methods (e.g. ClusCa).

**Experiments.** FLUX.1-dev (T2I), plus video generation and super-resolution. Baselines: TaylorSeer, ClusCa.

## 3. Key conclusions
- Matching the *basis function* to the *empirical feature statistics* (Gaussian → Hermite) is the lever that unlocks more speed at equal quality.
- HiCache is a **plug-in upgrade to the entire caching family**, not a standalone competitor only — it enhances existing methods (ClusCa 0.9480 → 0.9840 ImageReward).
- Reaches **5.55× on FLUX.1-dev while matching or exceeding the un-accelerated baseline quality**, generalizing across image, video, and SR.

## 4. Notable figures & to-dos
**Verified (abstract):**
- **5.55× speedup** on FLUX.1-dev, quality ≥ baseline.
- **ClusCa: ImageReward 0.9480 → 0.9840** when HiCache is added.
- Works standalone and integrated with TaylorSeer; spans T2I / video / super-resolution.

**Unverified (note en.papernotes.org — indicative only):** at 5.55× on FLUX — HiCache ImageReward 0.9979 vs TaylorSeer 0.9572; LPIPS 0.3982 vs 0.4520.

**Limitations / to-dos:** none stated in the abstract. Implicit: the Gaussian-derivative assumption is empirical (may not hold for every backbone/step schedule); choice of Hermite order and σ still needs setting; caching still stores higher-order differences (memory cost, like TaylorSeer). To do: verify the head-to-head vs TaylorSeer numbers against the PDF tables.

## 5. Quick recap (< 300 words)
HiCache is a training-free, plug-in upgrade to feature-caching acceleration of diffusion transformers. The dominant caching paradigm (TaylorSeer) forecasts the features of skipped denoising steps by extrapolating a **Taylor series** — but Taylor uses monomial basis functions that are monotonic and diverge fast, so they badly fit the real, non-monotonic feature trajectories, causing extrapolation error to explode and limiting speedup. HiCache's insight is that the finite-difference approximations of DiT feature derivatives are empirically **multivariate Gaussian**, and for Gaussian-correlated processes the mathematically optimal orthogonal basis is the **Hermite polynomials** (Karhunen–Loève theory). So HiCache simply swaps the monomial basis for **scaled Hermite polynomials**, adds a **dual-scaling mechanism** for numerical stability, and forecasts features with zero extra FLOPs. Crucially it is not just a rival to TaylorSeer — it layers on top of the whole caching family, improving e.g. ClusCa's ImageReward from 0.9480 to 0.9840. On FLUX.1-dev it reaches **5.55× speedup while matching or exceeding the unaccelerated baseline quality**, and it holds up across text-to-image, video generation, and super-resolution. Because the authors overlap with the TaylorSeer team, HiCache reads as the official successor that "fixes the math" of forecast-based caching: same cache-then-forecast machinery, better basis functions. The takeaway for a practitioner: if you already use a Taylor-style cache, dropping in Hermite bases is a near-free quality/speed gain; if you don't, HiCache is the current strongest single-axis caching accelerator for DiT.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈47w):** Taylor-style feature caching forecasts diffusion features with monomials that diverge on non-monotonic trajectories. HiCache shows those feature derivatives are Gaussian, so it swaps in the optimal Hermite basis plus dual-scaling — training-free, zero extra FLOPs — hitting 5.55× on FLUX while matching or beating baseline quality.

**VI (≈46 từ):** Caching kiểu Taylor dự báo đặc trưng bằng đơn thức, phân kỳ trên quỹ đạo phi đơn điệu. HiCache chứng minh các đạo hàm đặc trưng là Gaussian, nên thay bằng cơ sở Hermite tối ưu kèm dual-scaling — không train, không thêm FLOPs — đạt 5.55× trên FLUX mà chất lượng bằng hoặc vượt.

## 7. The essence in plain language
**The problem, plainly:** To speed up an image model, we skip steps and *guess* what the picture-features would have been. TaylorSeer guesses with a formula (Taylor) whose "shape" doesn't match how features really move, so the guess drifts.

**Core idea (one sentence):** Use the *right* set of curve-shapes — ones that mathematically match how the features actually wiggle — to make the guess accurate.

**Everyday analogy — drawing tools:** Guessing a curvy road with only straight rulers (monomials) forces bad approximations; HiCache hands you a set of French curves (Hermite polynomials) shaped exactly like the road, so the same effort traces it far better.

**If you remember only one thing:** Same forecasting idea as TaylorSeer, but with the *mathematically correct ruler* — nearly free extra speed and quality.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Diffusion Transformer chậm vì lấy mẫu lặp nhiều bước. **Feature caching** tăng tốc bằng cách *dự báo* đặc trưng của các bước bị bỏ qua thông qua ngoại suy theo thời gian (paradigm TaylorSeer), nhưng chất lượng dự báo suy giảm khi **cơ sở toán học mô hình sai** cách đặc trưng thực sự biến thiên. HiCache đặt mục tiêu **đẩy xa hơn biên tốc độ–chất lượng của caching** bằng cách thay cơ sở đơn thức Taylor bằng một cơ sở khớp *thống kê thực nghiệm* của đạo hàm đặc trưng DiT — **không cần huấn luyện**, cắm được lên toàn bộ họ caching.

## 2. Nội dung chính từng phần
**Động lực.** TaylorSeer ngoại suy đặc trưng bước bị bỏ bằng chuỗi Taylor (đơn thức). Đơn thức đơn điệu và phân kỳ nhanh → khớp kém với quỹ đạo đặc trưng phi đơn điệu có điểm uốn → sai số ngoại suy bùng nổ, giới hạn tỉ lệ tăng tốc.

**Ý tưởng then chốt.** Các xấp xỉ sai phân hữu hạn của đạo hàm đặc trưng DiT tuân theo phân phối **Gaussian đa biến**. Theo lý thuyết Karhunen–Loève / quá trình Gaussian, **đa thức Hermite** là cơ sở trực giao tối ưu cho quá trình tương quan Gaussian → khớp quỹ đạo tốt hơn hẳn đơn thức ở cùng bậc.

**Phương pháp — dự báo Scaled-Hermite.**
- Thay cơ sở đơn thức Taylor bằng **đa thức Hermite có scale** cho ngoại suy cache-then-forecast.
- **Cơ chế dual-scaling** (hệ số co σ tác động lên cả biên đầu vào lẫn độ lớn hệ số) đảm bảo ổn định số mà vẫn giữ độ chính xác.
- **Không thêm FLOPs**, training-free, cắm-là-chạy: dùng độc lập HOẶC chồng lên TaylorSeer và các bài caching khác (vd ClusCa).

**Thí nghiệm.** FLUX.1-dev (T2I), thêm video generation và super-resolution. Baseline: TaylorSeer, ClusCa.

## 3. Các kết luận quan trọng
- Khớp *hàm cơ sở* với *thống kê đặc trưng thực nghiệm* (Gaussian → Hermite) là đòn bẩy mở thêm tốc độ ở cùng chất lượng.
- HiCache là **bản nâng cấp cắm-thêm cho cả họ caching**, không chỉ là đối thủ độc lập — cải thiện phương pháp có sẵn (ClusCa 0.9480 → 0.9840 ImageReward).
- Đạt **5.55× trên FLUX.1-dev mà chất lượng bằng hoặc vượt baseline gốc**, tổng quát hóa qua ảnh/video/SR.

## 4. Số liệu nổi bật & việc cần làm
**Đã xác minh (abstract):**
- **5.55×** trên FLUX.1-dev, chất lượng ≥ baseline.
- **ClusCa: ImageReward 0.9480 → 0.9840** khi thêm HiCache.
- Chạy độc lập và tích hợp với TaylorSeer; trải T2I / video / super-resolution.

**Chưa xác minh (note en.papernotes.org — chỉ tham khảo):** ở 5.55× trên FLUX — HiCache ImageReward 0.9979 vs TaylorSeer 0.9572; LPIPS 0.3982 vs 0.4520.

**Hạn chế / việc cần làm:** abstract không nêu. Ngầm: giả định Gaussian của đạo hàm là *thực nghiệm* (có thể không đúng mọi backbone/lịch bước); vẫn phải chọn bậc Hermite và σ; vẫn lưu các sai phân bậc cao (tốn bộ nhớ như TaylorSeer). Cần làm: đối chiếu số head-to-head vs TaylorSeer với bảng trong PDF.

## 5. Tóm tắt ngắn (< 300 từ)
HiCache là bản nâng cấp cắm-thêm, không cần huấn luyện, cho hướng tăng tốc feature-caching của diffusion transformer. Paradigm caching thống trị (TaylorSeer) dự báo đặc trưng các bước bị bỏ bằng cách ngoại suy **chuỗi Taylor** — nhưng Taylor dùng hàm cơ sở đơn thức, đơn điệu và phân kỳ nhanh, nên khớp rất tệ với quỹ đạo đặc trưng thật (phi đơn điệu), khiến sai số ngoại suy bùng nổ và giới hạn tăng tốc. Nhận định của HiCache: các xấp xỉ sai phân hữu hạn của đạo hàm đặc trưng DiT có phân phối **Gaussian đa biến**, và với quá trình tương quan Gaussian thì cơ sở trực giao tối ưu là **đa thức Hermite** (lý thuyết Karhunen–Loève). Nên HiCache chỉ đơn giản đổi cơ sở đơn thức sang **đa thức Hermite có scale**, thêm **cơ chế dual-scaling** để ổn định số, và dự báo đặc trưng với **không thêm FLOPs**. Quan trọng: nó không chỉ là đối thủ của TaylorSeer mà **chồng lên cả họ caching**, ví dụ nâng ImageReward của ClusCa từ 0.9480 lên 0.9840. Trên FLUX.1-dev đạt **5.55× mà chất lượng bằng hoặc vượt baseline gốc**, và bền vững qua T2I, video, super-resolution. Do nhóm tác giả trùng đội TaylorSeer, HiCache như bản kế nhiệm chính chủ "sửa lại phần toán" của caching dạng dự báo: vẫn cỗ máy cache-then-forecast, chỉ đổi hàm cơ sở cho đúng. Rút gọn cho người dùng: nếu đã dùng cache kiểu Taylor, cắm Hermite vào là lời gần như miễn phí; nếu chưa, HiCache là bộ tăng tốc caching một-trục mạnh nhất hiện tại cho DiT.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈47w):** Taylor-style feature caching forecasts diffusion features with monomials that diverge on non-monotonic trajectories. HiCache shows those feature derivatives are Gaussian, so it swaps in the optimal Hermite basis plus dual-scaling — training-free, zero extra FLOPs — hitting 5.55× on FLUX while matching or beating baseline quality.

**VI (≈46 từ):** Caching kiểu Taylor dự báo đặc trưng bằng đơn thức, phân kỳ trên quỹ đạo phi đơn điệu. HiCache chứng minh các đạo hàm đặc trưng là Gaussian, nên thay bằng cơ sở Hermite tối ưu kèm dual-scaling — không train, không thêm FLOPs — đạt 5.55× trên FLUX mà chất lượng bằng hoặc vượt.

## 7. Bản chất nói nôm na
**Vấn đề:** Để tăng tốc mô hình vẽ ảnh, ta bỏ bớt bước và *đoán* đặc trưng lẽ ra phải có. TaylorSeer đoán bằng một công thức (Taylor) có "hình dáng" không khớp cách đặc trưng thực sự di chuyển, nên đoán bị lệch.

**Ý tưởng cốt lõi:** Dùng *đúng* bộ hình-dạng-đường-cong — loại khớp về mặt toán học với cách đặc trưng thực sự uốn lượn — để đoán chính xác.

**Ẩn dụ đời thường — bộ dụng cụ vẽ:** Đoán một con đường cong mà chỉ có thước kẻ thẳng (đơn thức) thì buộc phải xấp xỉ dở; HiCache đưa cho bạn bộ thước cong (đa thức Hermite) có hình đúng như con đường, cùng công sức mà vẽ sát hơn nhiều.

**Câu để đời:** Vẫn là ý tưởng dự báo của TaylorSeer, nhưng với *cây thước đúng về toán học* — thêm tốc độ và chất lượng gần như miễn phí.
