# Phased DMD: Few-step Distribution Matching Distillation via Score Matching within Subintervals

**Tác giả:** Xiangyu Fan, Zesong Qiu, Zhuguanyu Wu, Fanzhou Wang, Zhiqian Lin, Tianxiang Ren, Dahua Lin, Ruihao Gong, Lei Yang
**Venue:** CVPR 2026 (Poster) · arXiv 2510.27684
**Nguồn:** https://arxiv.org/abs/2510.27684 · [project](https://x-niper.github.io/projects/Phased-DMD/) · [OpenReview](https://openreview.net/forum?id=zzJTo7ujql)

> **Ghi chú xác minh (ngày 24/07/2026):** Abstract lấy **nguyên văn** từ `/abs/`. **Đã xác minh (khớp abstract):** distill **Qwen-Image-20B** và **Wan2.2-28B**; hai ý tưởng lõi = *progressive distribution matching* + *score matching within subintervals* (chia dải SNR); phát hiện SGTS (stochastic gradient truncation) làm **giảm diversity T2I và chậm động lực chuyển động video** về mức 1-bước; kết quả định tính = tăng động lực chuyển động, tăng visual fidelity video, tăng diversity ảnh. **Chưa xác minh (từ note en.papernotes.org — chỉ tham khảo):** Optical-Flow 3.23 (DMD2)→9.30 (Phased, base 10.26); Dynamic Degree 65.45%→82.27% (base 79.55%); DINOv3 diversity 0.828→0.768 — các số này ở cấu hình Wan2.2 4 bước, cần đối chiếu bảng PDF.

---

# English version

## 1. Purpose of the document
Distribution Matching Distillation (DMD/DMD2) collapses a many-step diffusion teacher into a **one-step** student. But one-step students have limited capacity: they lose **generative diversity** (text-to-image) and **motion dynamics** (text-to-video). Naïvely extending DMD to multi-step blows up memory and depth and destabilizes training; the common fix — stochastic gradient truncation (SGTS) — quietly degrades multi-step models *back down to one-step quality*. Phased DMD's goal: get **few-step** distillation that genuinely uses the extra steps to restore diversity and motion, without the instability.

## 2. Main content, section by section
**Problem diagnosis.** (i) One-step DMD lacks capacity for complex tasks (intricate motion). (ii) Direct multi-step DMD → memory/compute-depth explosion, instability. (iii) SGTS, the prior workaround, substantially **cuts T2I diversity and slows video motion**, negating the benefit of multiple steps.

**Method — Phased DMD.** A multi-step distillation framework marrying **phase-wise distillation** with **Mixture-of-Experts (MoE)** to lower learning difficulty while raising capacity. Two core ideas:
1. **Progressive distribution matching:** partition the **SNR range into subintervals** and progressively refine the model toward higher-SNR levels, so each expert only has to capture part of the distribution.
2. **Score matching within subintervals:** derive a rigorous (unbiased) score-matching objective valid *inside* each subinterval; **back-simulation stops at intermediate timesteps** rather than clean samples → no reliance on ground-truth data, one expert trained per phase, and the MoE adds **no inference cost**.

**Experiments.** Distills SOTA generators **Qwen-Image-20B** (T2I) and **Wan2.2-28B** (T2V); compared against DMD/DMD2 few-step baselines.

## 3. Key conclusions
- The right way to do *few*-step DMD is **phase-wise experts over SNR subintervals**, not one giant multi-step objective (unstable) nor SGTS (collapses to one-step).
- Phased DMD **restores diversity (image) and motion dynamics/fidelity (video)** that DMD2 loses, while keeping the efficiency of few-step generation and no extra inference cost.
- Validated at very large scale (20B / 28B models), signalling practicality for modern T2I/T2V backbones.

## 4. Notable figures & to-dos
**Verified (abstract, qualitative):** enhances motion dynamics, improves video visual fidelity, increases image-generation diversity vs DMD; validated on Qwen-Image-20B and Wan2.2-28B; MoE adds no inference cost.

**Unverified (note en.papernotes.org — indicative, Wan2.2 @4 steps):**

| Metric | DMD2 | Phased DMD | Base model |
|---|---|---|---|
| Optical Flow (motion) | 3.23 | 9.30 | 10.26 |
| Dynamic Degree | 65.45% | 82.27% | 79.55% |
| Diversity (DINOv3) | 0.828 | 0.768 | — |

**Limitations / to-dos:** abstract states no explicit limitation. Implicit: MoE-per-phase raises **training** cost/complexity (multiple experts) even if inference is free; number/placement of SNR subintervals is a design choice; gains shown mainly on very large models — behavior on small consumer-scale DiT (FLUX-dev, SDXL) untested here. To do: verify the quantitative table against the PDF; check image-diversity numbers on T2I explicitly.

## 5. Quick recap (< 300 words)
Phased DMD is a **few-step** distillation method for diffusion models that fixes the core weakness of one-step Distribution Matching Distillation (DMD/DMD2): one-step students lack capacity, so they lose image **diversity** and video **motion dynamics**. Extending DMD to multiple steps directly is unstable and memory-hungry, and the popular patch — stochastic gradient truncation — silently drags multi-step quality back down to one-step levels. Phased DMD instead splits the noise-to-clean trajectory into **SNR subintervals** and trains **one expert per phase** (a Mixture-of-Experts that costs nothing extra at inference), progressively refining toward higher SNR so each expert learns an easier sub-distribution. To train each phase correctly it derives a rigorous subinterval score-matching objective and stops back-simulation at **intermediate** timesteps, removing any dependence on ground-truth clean data. Distilling two very large SOTA generators — **Qwen-Image-20B** for text-to-image and **Wan2.2-28B** for text-to-video — Phased DMD demonstrably **restores motion dynamics and video fidelity and boosts image diversity** relative to DMD, while keeping few-step efficiency. (Community notes report, unverified, Wan2.2 optical-flow motion recovering from DMD2's 3.23 to 9.30 versus the 10.26 base, and dynamic degree from 65% to 82%.) The message: don't force a diffusion model into a single step and accept the diversity/motion collapse — use a *small number* of steps but assign each step-range its own specialist, trained with a clean subinterval objective. It is the natural successor to DMD2 for the regime where one-step is too lossy but full multi-step is too expensive.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈49w):** One-step DMD kills diversity and motion; naïve multi-step is unstable and gradient-truncation collapses it back. Phased DMD splits the SNR range into subintervals, trains one expert per phase (free MoE) with a rigorous subinterval score-matching loss, restoring diversity and motion on Qwen-Image-20B and Wan2.2-28B.

**VI (≈48 từ):** DMD một-bước giết diversity và chuyển động; đa-bước ngây thơ thì bất ổn, cắt gradient lại kéo về một-bước. Phased DMD chia dải SNR thành khoảng con, huấn luyện mỗi pha một chuyên gia (MoE miễn phí) với hàm score-matching chặt chẽ trong-khoảng, khôi phục diversity và chuyển động trên Qwen-Image-20B và Wan2.2-28B.

## 7. The essence in plain language
**The problem, plainly:** To make a slow image/video model fast, we teach it to finish in one shot — but one shot is too crude, so pictures get samey and videos stop moving naturally.

**Core idea (one sentence):** Use just a few shots instead of one, and give each shot its own little specialist trained for exactly that part of the job.

**Everyday analogy — a relay team vs one sprinter:** Asking one runner to run the whole race in a single burst (one-step) exhausts quality; Phased DMD splits the track into legs and puts a fresh specialist runner on each leg (few-step experts), so the whole race is fast *and* strong — and swapping runners costs nothing at race time.

**If you remember only one thing:** A few well-coached steps beat one over-asked step — Phased DMD is DMD2 with per-phase specialists that bring back diversity and motion.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Distribution Matching Distillation (DMD/DMD2) nén teacher diffusion nhiều bước thành student **một bước**. Nhưng student một-bước dung lượng hạn chế: mất **diversity** (T2I) và **động lực chuyển động** (T2V). Mở rộng DMD sang đa-bước một cách ngây thơ thì nổ bộ nhớ/độ sâu và bất ổn; cách chữa phổ biến — stochastic gradient truncation (SGTS) — lại âm thầm kéo chất lượng đa-bước *về mức một-bước*. Mục tiêu Phased DMD: distillation **few-step** thật sự tận dụng thêm bước để khôi phục diversity và chuyển động, mà không bất ổn.

## 2. Nội dung chính từng phần
**Chẩn đoán vấn đề.** (i) DMD một-bước thiếu dung lượng cho tác vụ phức tạp (chuyển động tinh vi). (ii) DMD đa-bước trực tiếp → nổ bộ nhớ/độ sâu, bất ổn. (iii) SGTS (giải pháp trước) **giảm mạnh diversity T2I và chậm chuyển động video**, triệt tiêu lợi ích của nhiều bước.

**Phương pháp — Phased DMD.** Khung distillation đa-bước kết hợp **phase-wise distillation** với **Mixture-of-Experts (MoE)** để giảm độ khó học mà tăng dung lượng. Hai ý tưởng lõi:
1. **Progressive distribution matching:** chia **dải SNR thành các khoảng con**, tinh chỉnh dần model lên mức SNR cao hơn, để mỗi expert chỉ phải nắm một phần phân phối.
2. **Score matching within subintervals:** suy ra hàm mục tiêu score-matching chặt chẽ (không thiên lệch) hợp lệ *bên trong* mỗi khoảng con; **back-simulation dừng ở timestep trung gian** thay vì mẫu sạch → không phụ thuộc dữ liệu ground-truth, mỗi pha một expert, và MoE **không thêm chi phí suy luận**.

**Thí nghiệm.** Distill hai generator SOTA cỡ lớn **Qwen-Image-20B** (T2I) và **Wan2.2-28B** (T2V); so với baseline few-step DMD/DMD2.

## 3. Các kết luận quan trọng
- Cách đúng để làm DMD *few*-step là **experts theo pha trên các khoảng SNR**, không phải một mục tiêu đa-bước khổng lồ (bất ổn) hay SGTS (sập về một-bước).
- Phased DMD **khôi phục diversity (ảnh) và động lực chuyển động/độ trung thực (video)** mà DMD2 làm mất, giữ hiệu quả few-step và không thêm chi phí suy luận.
- Kiểm chứng ở quy mô rất lớn (20B / 28B) → tín hiệu khả dụng cho backbone T2I/T2V hiện đại.

## 4. Số liệu nổi bật & việc cần làm
**Đã xác minh (abstract, định tính):** tăng động lực chuyển động, tăng độ trung thực video, tăng diversity ảnh so với DMD; kiểm chứng trên Qwen-Image-20B và Wan2.2-28B; MoE không thêm chi phí suy luận.

**Chưa xác minh (note en.papernotes.org — tham khảo, Wan2.2 @4 bước):**

| Chỉ số | DMD2 | Phased DMD | Base |
|---|---|---|---|
| Optical Flow (chuyển động) | 3.23 | 9.30 | 10.26 |
| Dynamic Degree | 65.45% | 82.27% | 79.55% |
| Diversity (DINOv3) | 0.828 | 0.768 | — |

**Hạn chế / việc cần làm:** abstract không nêu hạn chế tường minh. Ngầm: MoE-mỗi-pha tăng chi phí/độ phức tạp **huấn luyện** (nhiều expert) dù suy luận miễn phí; số/vị trí khoảng SNR là lựa chọn thiết kế; kết quả chủ yếu ở model rất lớn — chưa thử trên DiT quy mô tiêu dùng (FLUX-dev, SDXL). Cần làm: đối chiếu bảng định lượng với PDF; kiểm số diversity T2I tường minh.

## 5. Tóm tắt ngắn (< 300 từ)
Phased DMD là phương pháp distillation **few-step** cho diffusion, sửa điểm yếu cốt lõi của DMD/DMD2 một-bước: student một-bước thiếu dung lượng nên mất **diversity** ảnh và **động lực chuyển động** video. Mở rộng DMD sang nhiều bước trực tiếp thì bất ổn và ngốn bộ nhớ, còn bản vá phổ biến — stochastic gradient truncation — âm thầm kéo chất lượng đa-bước về mức một-bước. Thay vào đó, Phased DMD chia quỹ đạo nhiễu-đến-sạch thành các **khoảng con theo SNR** và huấn luyện **mỗi pha một expert** (một Mixture-of-Experts không tốn thêm gì lúc suy luận), tinh chỉnh dần lên SNR cao hơn để mỗi expert học một phân phối con dễ hơn. Để huấn luyện đúng từng pha, bài suy ra hàm score-matching chặt chẽ trong khoảng con và dừng back-simulation ở timestep **trung gian**, bỏ mọi phụ thuộc vào dữ liệu sạch ground-truth. Distill hai generator SOTA cỡ lớn — **Qwen-Image-20B** cho T2I và **Wan2.2-28B** cho T2V — Phased DMD **khôi phục động lực chuyển động, độ trung thực video và tăng diversity ảnh** so với DMD, mà vẫn giữ hiệu quả few-step. (Ghi chú cộng đồng, chưa xác minh: optical-flow Wan2.2 phục hồi từ 3.23 của DMD2 lên 9.30 so với base 10.26, dynamic degree từ 65% lên 82%.) Thông điệp: đừng ép diffusion về đúng một bước rồi chịu sập diversity/chuyển động — dùng *một số ít* bước nhưng gán mỗi dải-bước một chuyên gia riêng, huấn luyện bằng mục tiêu trong-khoảng sạch. Đây là hậu duệ tự nhiên của DMD2 cho chế độ mà một-bước quá mất mát còn đa-bước đầy đủ thì quá đắt.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈49w):** One-step DMD kills diversity and motion; naïve multi-step is unstable and gradient-truncation collapses it back. Phased DMD splits the SNR range into subintervals, trains one expert per phase (free MoE) with a rigorous subinterval score-matching loss, restoring diversity and motion on Qwen-Image-20B and Wan2.2-28B.

**VI (≈48 từ):** DMD một-bước giết diversity và chuyển động; đa-bước ngây thơ thì bất ổn, cắt gradient lại kéo về một-bước. Phased DMD chia dải SNR thành khoảng con, huấn luyện mỗi pha một chuyên gia (MoE miễn phí) với hàm score-matching chặt chẽ trong-khoảng, khôi phục diversity và chuyển động trên Qwen-Image-20B và Wan2.2-28B.

## 7. Bản chất nói nôm na
**Vấn đề:** Để mô hình ảnh/video chậm chạy nhanh, ta dạy nó "xong trong một nhát" — nhưng một nhát thì thô, nên ảnh na ná nhau và video hết chuyển động tự nhiên.

**Ý tưởng cốt lõi:** Dùng vài nhát thay vì một, và giao mỗi nhát cho một chuyên gia nhỏ được huấn luyện đúng cho phần việc đó.

**Ẩn dụ đời thường — đội chạy tiếp sức vs một vận động viên:** Bắt một người chạy hết cuộc đua trong một hơi (một-bước) thì kiệt sức, chất lượng sụt; Phased DMD chia đường đua thành chặng và đặt một vận động viên chuyên biệt sung sức ở mỗi chặng (few-step experts), nên cả cuộc đua vừa nhanh vừa mạnh — và đổi người không tốn gì lúc thi đấu.

**Câu để đời:** Vài bước được huấn luyện tốt thắng một bước bị đòi hỏi quá mức — Phased DMD là DMD2 với chuyên gia theo pha, mang diversity và chuyển động trở lại.
