# TinyFusion: Diffusion Transformers Learned Shallow

**Tác giả:** Gongfan Fang, Kunjun Li, Xinyin Ma, Xinchao Wang (NUS)
**Venue:** CVPR 2025 (Highlight) · arXiv 2412.01199 (12/2024)
**Nguồn:** https://arxiv.org/abs/2412.01199

> **Ghi chú xác minh:** Abstract lấy nguyên văn từ trang `/abs/`. Chi tiết phương pháp & bảng kết quả lấy từ bản HTML arXiv (`/html/2412.01199v1`). Các số đã xác minh: **FID 2.86**, **2× speedup**, **<7% chi phí pre-train**, **28→14 lớp**. Một vài con số ablation (FID 33.39 vs 35.77; FID 20.69/6.45; 3.73 với KD) lấy từ HTML, độ tin cậy khá cao nhưng **chưa đối chiếu bảng gốc trong PDF** — nên kiểm lại trước khi trích dẫn chính thức.

---

## 1. Mục đích của tài liệu
Đề xuất **TinyFusion** — phương pháp **cắt tỉa độ sâu (depth pruning)** cho Diffusion Transformer (DiT): loại bỏ các *lớp* dư thừa để giảm chi phí suy luận. Điểm mới cốt lõi: thay vì cố tối thiểu hóa lỗi *ngay sau khi cắt* (như các phương pháp trước), TinyFusion **mô hình hóa và tối ưu trực tiếp hiệu năng *sau khi fine-tune*** — gọi là "khả năng phục hồi" (recoverability). Mô hình bị cắt được chọn sao cho *dễ hồi phục nhất* khi tinh chỉnh lại.

## 2. Nội dung chính từng phần

**Động lực.** DiT chất lượng cao nhưng thừa tham số → tốn kém khi suy luận. Các phương pháp cũ dựa trên *điểm quan trọng heuristic* hoặc *tối thiểu calibration loss*. Tác giả chỉ ra: loss thấp ngay sau cắt **không** tương quan với chất lượng cuối cùng → cần tối ưu đúng mục tiêu là recoverability.

**Phương pháp (learnable, khả vi).**
- **Chia block N:M** — L lớp chia thành các block không chồng lấn; ví dụ **1:2** = cứ 2 lớp giữ 1. Giúp thu nhỏ không gian tìm kiếm (28 lớp cắt 50% nếu duyệt trực tiếp ~40 triệu tổ hợp).
- **Lấy mẫu khả vi** — mỗi block coi là một phân phối categorical; dùng **Gumbel-Softmax** (nhiệt độ τ) + **Straight-Through Estimator** để gradient chảy qua quyết định rời rạc (one-hot).
- **Mô phỏng fine-tune bằng LoRA** — thay vì fine-tune đầy đủ đắt đỏ, đồng tối ưu một cập nhật trọng số ΔΦ dạng LoRA (W + αBA), chỉ **~0.9% tham số thêm**, để "giả lập" việc hồi phục sau cắt.
- **Mục tiêu chung** — tối ưu đồng thời phân phối mask và ΔΦ để chọn mask có khả năng phục hồi cao nhất.

**Thí nghiệm.** DiT-XL/2 (28 lớp, 675M), MAR-Large (32 lớp), SiT-XL/2 (28 lớp) trên ImageNet 256×256. Baseline: ShortGPT, Flux-Lite, Diff-Pruning, Sensitivity Analysis, BK-SDM.

## 3. Các kết luận quan trọng
- **Loss thấp sau cắt ≠ chất lượng cao** — lấy mẫu ngẫu nhiên 100.000 mô hình: nhóm calibration loss *thấp nhất* lại cho FID 20.69, trong khi nhóm loss *trung bình* cho FID 6.45. Bác bỏ nguyên tắc "minimize loss".
- **Paradigm học được vượt các phương pháp importance-based & error-based.**
- **Tổng quát hóa tốt** across DiT, MAR, SiT.
- **LoRA hồi phục tốt hơn cả full fine-tuning** trong giai đoạn ước lượng recoverability (FID 33.39 vs 35.77).

## 4. Số liệu nổi bật & việc cần làm

**Đã xác minh (abstract):**
- FID **2.86** · **2×** speedup · **<7%** chi phí pre-train · **28→14** lớp (DiT-XL).

**Từ bảng HTML (độ tin cậy cao, nên kiểm lại PDF):**

| Mô hình | Lớp | Chi phí train | FID | IS | Speedup |
|---|---|---|---|---|---|
| TinyDiT-D14 | 28→14 | 100K (~1%) | 5.73 | 151.88 | 2× |
| TinyDiT-D14 (+KD) | 28→14 | 500K (~7%) | **2.86** | 234.50 | 2× |
| ShortGPT | 28→14 | 100K | 22.28 | 66.10 | 2× |
| TinyMAR-D16 | 32→16 | ~10% | 2.28 | 283.4 | — |
| TinySiT-D14 | 28→14 | ~7% | 3.02 | 220.1 | — |

**Ablation đáng chú ý:** scheme **1:2 tốt nhất** (2:4, 7:14 kém do không gian tìm kiếm lớn); **Masked KD** — RepKD chuẩn thất bại do "massive activations", cắt ngưỡng >2σ/4σ giúp FID 5.79 → 3.73.

**Việc cần làm / hạn chế:** mới làm cho **sinh ảnh có điều kiện (class-conditional)**; **chưa làm text-to-image**; hướng tương lai: cắt riêng lớp attention và MLP một cách chi tiết hơn.

## 5. Tóm tắt ngắn (<300 từ)
TinyFusion là phương pháp cắt tỉa độ sâu cho Diffusion Transformer: bỏ bớt lớp để chạy nhanh gấp đôi. Khác biệt then chốt so với các phương pháp trước là *mục tiêu tối ưu*. Cách cũ chọn lớp để bỏ sao cho sai số *ngay sau khi cắt* nhỏ nhất; TinyFusion chứng minh tiêu chí này sai — mô hình có loss thấp nhất sau cắt lại cho chất lượng tệ sau fine-tune. Thay vào đó, họ tối ưu trực tiếp **khả năng phục hồi**: chọn cấu hình cắt nào *sau khi tinh chỉnh* sẽ tốt nhất. Để làm được và vẫn khả vi (train bằng gradient), họ (1) chia lớp thành block N:M rồi dùng Gumbel-Softmax + Straight-Through Estimator để "học" mask giữ/bỏ lớp; (2) đồng thời gắn một adapter LoRA nhẹ (~0.9% tham số) để *giả lập* quá trình fine-tune tương lai ngay trong lúc học mask. Trên DiT-XL, TinyFusion tạo mô hình chỉ còn 14/28 lớp, đạt **FID 2.86** và **2× tốc độ** với **<7% chi phí pre-training**, vượt xa baseline như ShortGPT (FID 22.28). Phương pháp tổng quát cho DiT, MAR, SiT. Hạn chế: mới thử nghiệm sinh ảnh theo lớp, chưa mở rộng text-to-image, và pruning còn ở mức cả-lớp (chưa tách attention/MLP). Đây là bước tiến phương pháp luận rõ ràng: đổi câu hỏi từ "lớp nào ít quan trọng nhất bây giờ?" sang "bỏ lớp nào thì mô hình dễ hồi phục nhất về sau?".

## 6. Bản chất nói nôm na
**Vấn đề:** Mô hình sinh ảnh có quá nhiều "tầng", chạy chậm và tốn kém — ta muốn bỏ bớt tầng mà ảnh vẫn đẹp.

**Ý tưởng cốt lõi:** Đừng bỏ tầng "trông có vẻ ít dùng ngay lúc này" — hãy bỏ những tầng mà *sau khi tập luyện lại*, mô hình vẫn khỏe nhất.

**Ẩn dụ:** Giống như tỉa cành một cây cảnh. Người thợ vụng cắt cành nào trông thừa nhất *ngay bây giờ*. Người thợ giỏi nghĩ xa hơn: cắt sao cho *vài tháng sau khi cây mọc lại*, dáng cây đẹp nhất. TinyFusion còn "tua nhanh" bằng cách thử tưởng tượng cây mọc lại (adapter LoRA) trước khi quyết định cắt thật.

**Câu để đời:** Chọn cái để bỏ không dựa trên "cái gì kém nhất hôm nay", mà dựa trên "bỏ cái gì thì ngày mai phục hồi tốt nhất".

---

## English quick recap (<300 words)
TinyFusion (Fang et al., CVPR 2025 Highlight) is a **depth-pruning** method that makes Diffusion Transformers shallower by removing redundant layers. Its key departure is the *optimization target*. Prior importance- and error-based methods drop layers so the loss *immediately after pruning* is smallest. TinyFusion shows this is wrong: sampling 100,000 pruned models reveals the configurations with the **lowest post-pruning calibration loss give the worst final quality** (FID 20.69), while moderate-loss ones recover far better (FID 6.45). Instead, TinyFusion directly optimizes **recoverability** — which pruned configuration is best *after* fine-tuning. To make this learnable and differentiable, it (1) groups layers into N:M blocks (1:2 works best) and samples a keep/drop mask via **Gumbel-Softmax + Straight-Through Estimator**, and (2) jointly trains a lightweight **LoRA adapter (~0.9% params)** that *simulates* future fine-tuning during mask learning; mask and LoRA are optimized together. On DiT-XL, it prunes 28→14 layers to **FID 2.86** at **2× speedup** and **<7% of pre-training cost**, far beyond ShortGPT (FID 22.28), and generalizes across **DiT, MAR, SiT**. A masked knowledge-distillation step (thresholding "massive activations" beyond 2σ/4σ) further improves FID (5.79→3.73). Limitations: class-conditional ImageNet only (no text-to-image), whole-layer granularity — independent attention/MLP-layer pruning is left as future work.

## Conference one-breath pitch (30–50 words)
**EN (≈40w):** TinyFusion prunes Diffusion Transformer *layers* by a new rule: don't drop what looks least useful now — drop what the model can best *recover* after fine-tuning. A differentiable mask plus a LoRA proxy learns this. Result: DiT-XL halved, FID 2.86, 2× faster.

**VI (≈45 từ):** TinyFusion cắt bớt *lớp* của Diffusion Transformer theo nguyên tắc mới: đừng bỏ lớp "trông ít quan trọng nhất bây giờ", mà bỏ lớp mà mô hình *phục hồi tốt nhất sau khi fine-tune*. Một mask khả vi cộng proxy LoRA học điều đó. Kết quả: DiT-XL giảm nửa số lớp, FID 2.86, nhanh 2×.
