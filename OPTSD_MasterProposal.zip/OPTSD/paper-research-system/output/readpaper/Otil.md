# Otil: Accelerating Diffusion Model Inference via Communication-Efficient Multi-GPU Parallelism

**Tác giả:** Li et al. (CVPR 2026 — danh sách đầy đủ chưa xác minh; PDF CVF không truy cập được lúc soạn)
**Venue:** CVPR 2026
**Nguồn:** [CVF Open Access PDF](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_Otil_Accelerating_Diffusion_Model_Inference_via_Communication-Efficient_Multi-GPU_Parallelism_CVPR_2026_paper.pdf) · [code](https://github.com/uplaoli/OTIL-PROJECT) · [note en.papernotes.org](https://en.papernotes.org/CVPR2026/model_compression/otil_accelerating_diffusion_model_inference_via_communication-efficient_multi-gp/)

> ⚠️ **Ghi chú xác minh (ngày 24/07/2026):** **KHÔNG lấy được abstract nguyên văn** — server CVF (openaccess.thecvf.com) liên tục từ chối kết nối (ECONNRESET/ECONNREFUSED) tại thời điểm soạn. Nội dung dưới đây tổng hợp từ **(a)** ghi chú AI ở en.papernotes.org (đã fetch), **(b)** đoạn mô tả từ kết quả tìm kiếm web ("Otil sends only variant activations"). **⇒ TẤT CẢ số liệu là *chưa xác minh gốc*** — cần mở lại PDF CVF/repo để xác nhận trước khi trích dẫn chính thức trong luận văn. Không có bản arXiv được tìm thấy.

---

# English version

## 1. Purpose of the document
Running one diffusion model across **multiple GPUs** should cut latency, but existing parallel methods (DistriFusion, AsyncDiff) **transmit entire activation maps every denoising step**. Over a low-bandwidth interconnect like **PCIe** (no NVLink), that communication cost can eat up the compute savings. Otil's goal: keep multi-GPU speedups **on commodity/PCIe setups** by drastically shrinking what has to be sent between GPUs.

## 2. Main content, section by section
**Observation.** Between adjacent denoising steps, the latent activations change **significantly only in a few spatial regions** — most of the map is nearly static. So sending the whole map is wasteful.

**Method — transmit only the "variant" activations.**
- Partition each activation map into square **sub-blocks** (reported optimal: 8×8).
- Rank sub-blocks by **cosine dissimilarity** between consecutive steps.
- Transmit only the **top-k most-changed sub-blocks (~25% of the data)**.
- Use **dynamic round-robin scheduling** so every region is eventually refreshed (avoids stale regions accumulating error).

**Setting.** Targets **PCIe** interconnect (the low-bandwidth regime where the method helps most). Tested on SD1.5 and SDXL with 2 and 4 GPUs, against DistriFusion and AsyncDiff.

## 3. Key conclusions
- Diffusion multi-GPU inference is **communication-bound, not compute-bound**, on PCIe — so compressing *what you send* (not *how you compute*) is the right lever.
- Sending only the most-changed ~25% of sub-blocks recovers most of the parallel speedup while keeping quality comparable.
- The gains are **largest exactly where DistriFusion struggles** (PCIe / no NVLink), and **shrink on high-bandwidth NVLink** (not benchmarked there).

## 4. Notable figures & to-dos
**All UNVERIFIED (from note/search — confirm against CVF PDF):**

| Setting | Otil speedup | Baseline |
|---|---|---|
| SDXL, 2 GPU | **1.88×** | DistriFusion 1.50× |
| SD1.5, 2 GPU | **1.74×** | — |
| SDXL, 4 GPU | **2.23×** | — |
| + few-step sampler | up to **2.84×** | — |
| Communication vs DistriFusion | **−75%** | — |

Quality: "FID within comparable range" (unverified). Sub-block size 8×8 optimal (unverified).

**Limitations / to-dos:**
- **NVLink:** authors note gains would be "significantly lower" on NVLink and **provide no NVLink comparison** — so the win is PCIe-specific.
- **Heterogeneous GPUs (e.g. 3090 + 4090):** *not addressed* — the note describes homogeneous multi-GPU; load-balancing sub-blocks across dissimilar cards is an open question (cf. STADI, arXiv 2509.04719, which does target heterogeneous GPUs).
- To do: verify all numbers from the CVF PDF; check whether quality holds at high compression on FLUX-scale DiT (only SD1.5/SDXL reported).

## 5. Quick recap (< 300 words)
Otil accelerates **multi-GPU** diffusion inference by attacking the communication bottleneck rather than the compute. Prior parallel methods like DistriFusion and AsyncDiff broadcast the *entire* activation map to the other GPUs at every denoising step; on a low-bandwidth **PCIe** link (i.e. consumer setups without NVLink), that transfer can cancel out the benefit of splitting the work. Otil's key observation is that between two consecutive steps, the latent activations really change in only a **few spatial regions** — so it partitions each activation map into square sub-blocks (≈8×8), ranks them by cosine dissimilarity across steps, and transmits only the **top ~25% most-changed sub-blocks**, using round-robin scheduling to make sure every region is eventually refreshed and errors don't accumulate. This cuts inter-GPU communication by about **75% versus DistriFusion** while keeping quality comparable. Reported speedups (all currently **unverified** against the official PDF): SDXL on 2 GPUs reaches **1.88×** versus DistriFusion's 1.50×, SD1.5 on 2 GPUs 1.74×, SDXL on 4 GPUs 2.23×, and up to **2.84×** when combined with few-step samplers. The important caveat: these wins are specific to **PCIe / low-bandwidth** interconnects — the authors say gains would be much smaller on NVLink and give no NVLink numbers, and they do **not** address **heterogeneous** GPU pairs. For a thesis targeting a consumer 3090+4090 rig over PCIe (no NVLink), Otil is the most directly relevant multi-GPU accelerator in the recent literature, effectively superseding DistriFusion for that exact scenario — provided the heterogeneous-card load-balancing question is handled separately.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈46w):** Multi-GPU diffusion is communication-bound on PCIe because methods like DistriFusion broadcast whole activation maps each step. Otil observes only a few spatial regions change between steps, so it sends just the top-25% most-changed sub-blocks — cutting communication 75% and reaching 1.88× on SDXL versus DistriFusion's 1.50×.

**VI (≈47 từ):** Diffusion đa-GPU bị nghẽn giao tiếp trên PCIe vì DistriFusion phát cả bản đồ activation mỗi bước. Otil nhận thấy chỉ vài vùng không gian đổi giữa các bước, nên chỉ gửi 25% sub-block đổi nhiều nhất — giảm 75% giao tiếp, đạt 1.88× trên SDXL so với 1.50× của DistriFusion.

## 7. The essence in plain language
**The problem, plainly:** Splitting one image model across two graphics cards should be faster, but the cards have to keep mailing each other huge updates every step, and on a slow cable that mailing wipes out the time saved.

**Core idea (one sentence):** Only mail the parts of the picture that actually changed since the last step, not the whole thing.

**Everyday analogy — editing a shared document:** Instead of re-sending the entire document after each edit (DistriFusion), you send only the paragraphs you just changed (Otil) — same result, a fraction of the bandwidth.

**If you remember only one thing:** On a no-NVLink consumer rig, the bottleneck is the cable, not the math — Otil wins by sending less, and it's the natural DistriFusion replacement for PCIe multi-GPU.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Chạy một model diffusion trên **nhiều GPU** lẽ ra phải giảm độ trễ, nhưng các phương pháp song song hiện có (DistriFusion, AsyncDiff) **truyền toàn bộ bản đồ activation ở mỗi bước khử nhiễu**. Trên kết nối băng thông thấp như **PCIe** (không có NVLink), chi phí giao tiếp đó có thể nuốt hết phần tiết kiệm tính toán. Mục tiêu Otil: giữ được tăng tốc đa-GPU **trên cấu hình phổ thông/PCIe** bằng cách giảm mạnh lượng dữ liệu phải gửi giữa các GPU.

## 2. Nội dung chính từng phần
**Quan sát.** Giữa hai bước khử nhiễu liền kề, activation tiềm ẩn **chỉ đổi đáng kể ở vài vùng không gian** — phần lớn bản đồ gần như đứng yên. Nên gửi cả bản đồ là lãng phí.

**Phương pháp — chỉ truyền activation "biến thiên".**
- Chia mỗi bản đồ activation thành **sub-block** vuông (tối ưu báo cáo: 8×8).
- Xếp hạng sub-block theo **độ bất tương đồng cosine** giữa các bước liên tiếp.
- Chỉ truyền **top-k sub-block đổi nhiều nhất (~25% dữ liệu)**.
- Dùng **lập lịch round-robin động** để mọi vùng cuối cùng đều được làm mới (tránh tích lũy sai số ở vùng cũ).

**Bối cảnh.** Nhắm kết nối **PCIe** (chế độ băng thông thấp nơi phương pháp lợi nhất). Thử trên SD1.5 và SDXL với 2 và 4 GPU, so với DistriFusion và AsyncDiff.

## 3. Các kết luận quan trọng
- Suy luận diffusion đa-GPU trên PCIe **bị nghẽn giao tiếp, không phải tính toán** — nên nén *cái gửi đi* (không phải *cách tính*) mới là đòn bẩy đúng.
- Chỉ gửi ~25% sub-block đổi nhiều nhất vẫn thu lại phần lớn tăng tốc song song mà chất lượng gần như giữ nguyên.
- Lợi ích **lớn nhất đúng ở nơi DistriFusion yếu** (PCIe / không NVLink) và **co lại trên NVLink băng thông cao** (không đo ở đó).

## 4. Số liệu nổi bật & việc cần làm
**Tất cả CHƯA XÁC MINH (từ note/search — cần đối chiếu PDF CVF):**

| Cấu hình | Otil tăng tốc | Baseline |
|---|---|---|
| SDXL, 2 GPU | **1.88×** | DistriFusion 1.50× |
| SD1.5, 2 GPU | **1.74×** | — |
| SDXL, 4 GPU | **2.23×** | — |
| + sampler few-step | tới **2.84×** | — |
| Giao tiếp vs DistriFusion | **−75%** | — |

Chất lượng: "FID trong khoảng tương đương" (chưa xác minh). Sub-block 8×8 tối ưu (chưa xác minh).

**Hạn chế / việc cần làm:**
- **NVLink:** tác giả lưu ý lợi ích sẽ "thấp hơn đáng kể" trên NVLink và **không có so sánh NVLink** → thắng lợi đặc thù PCIe.
- **GPU dị chủng (vd 3090 + 4090):** *không đề cập* — note mô tả đa-GPU đồng chủng; cân bằng tải sub-block giữa card khác nhau là câu hỏi mở (so STADI, arXiv 2509.04719, có nhắm GPU dị chủng).
- Cần làm: xác minh mọi số từ PDF CVF; kiểm chất lượng ở mức nén cao trên DiT cỡ FLUX (mới báo cáo SD1.5/SDXL).

## 5. Tóm tắt ngắn (< 300 từ)
Otil tăng tốc suy luận diffusion **đa-GPU** bằng cách đánh vào nghẽn giao tiếp thay vì tính toán. Các phương pháp song song trước như DistriFusion và AsyncDiff phát *toàn bộ* bản đồ activation cho các GPU khác ở mỗi bước khử nhiễu; trên kết nối băng thông thấp **PCIe** (cấu hình phổ thông không NVLink), việc truyền đó có thể triệt tiêu lợi ích chia việc. Quan sát then chốt của Otil: giữa hai bước liên tiếp, activation tiềm ẩn chỉ thực sự đổi ở **vài vùng không gian** — nên nó chia mỗi bản đồ thành sub-block vuông (≈8×8), xếp hạng theo độ bất tương đồng cosine qua các bước, và chỉ truyền **~25% sub-block đổi nhiều nhất**, dùng lập lịch round-robin để mọi vùng cuối cùng được làm mới và sai số không tích lũy. Cách này cắt giao tiếp giữa GPU khoảng **75% so với DistriFusion** mà chất lượng gần như giữ nguyên. Tăng tốc báo cáo (hiện **chưa xác minh** với PDF chính thức): SDXL trên 2 GPU đạt **1.88×** so với 1.50× của DistriFusion, SD1.5 trên 2 GPU 1.74×, SDXL trên 4 GPU 2.23×, và tới **2.84×** khi kết hợp sampler few-step. Lưu ý quan trọng: các thắng lợi này đặc thù cho kết nối **PCIe / băng thông thấp** — tác giả nói lợi ích sẽ nhỏ hơn nhiều trên NVLink và không đưa số NVLink, và **không** xử lý cặp GPU **dị chủng**. Với luận văn nhắm dàn 3090+4090 phổ thông qua PCIe (không NVLink), Otil là bộ tăng tốc đa-GPU liên quan trực tiếp nhất trong tài liệu gần đây, thay thế DistriFusion cho đúng kịch bản đó — miễn là xử lý riêng bài toán cân tải giữa hai card khác loại.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈46w):** Multi-GPU diffusion is communication-bound on PCIe because methods like DistriFusion broadcast whole activation maps each step. Otil observes only a few spatial regions change between steps, so it sends just the top-25% most-changed sub-blocks — cutting communication 75% and reaching 1.88× on SDXL versus DistriFusion's 1.50×.

**VI (≈47 từ):** Diffusion đa-GPU bị nghẽn giao tiếp trên PCIe vì DistriFusion phát cả bản đồ activation mỗi bước. Otil nhận thấy chỉ vài vùng không gian đổi giữa các bước, nên chỉ gửi 25% sub-block đổi nhiều nhất — giảm 75% giao tiếp, đạt 1.88× trên SDXL so với 1.50× của DistriFusion.

## 7. Bản chất nói nôm na
**Vấn đề:** Chia một model ảnh cho hai card đồ họa lẽ ra nhanh hơn, nhưng hai card phải liên tục "gửi thư" cập nhật khổng lồ cho nhau mỗi bước, và trên dây cáp chậm thì việc gửi thư đó xóa sạch thời gian tiết kiệm.

**Ý tưởng cốt lõi:** Chỉ gửi những phần của bức ảnh thực sự đã đổi so với bước trước, đừng gửi cả bức.

**Ẩn dụ đời thường — sửa tài liệu chung:** Thay vì gửi lại cả tài liệu sau mỗi lần sửa (DistriFusion), bạn chỉ gửi những đoạn vừa sửa (Otil) — cùng kết quả, tốn một phần nhỏ băng thông.

**Câu để đời:** Trên dàn phổ thông không NVLink, nút thắt là sợi cáp chứ không phải phép tính — Otil thắng nhờ gửi ít hơn, và là bản thay thế DistriFusion tự nhiên cho đa-GPU PCIe.
