# DMD2 — Improved Distribution Matching Distillation for Fast Image Synthesis

**Tác giả:** Tianwei Yin, Michaël Gharbi, Taesung Park, Richard Zhang, Eli Shechtman, Frédo Durand, William T. Freeman
**Venue:** NeurIPS 2024 (Oral) · arXiv 2405.14867 (v1: 23/05/2024, v2: 24/05/2024)
**Nguồn:** https://arxiv.org/abs/2405.14867 · Project page: https://tianweiy.github.io/dmd2

> **Ghi chú xác minh:** Abstract lấy nguyên văn từ `/abs/`. Method/bảng số liệu lấy từ HTML `/html/`. Venue "NeurIPS 2024 Oral" xác nhận qua GitHub README chính chủ (`tianweiy/DMD2`) + trang poster NeurIPS 2024, không nằm trong abstract nên coi là xác minh gián tiếp (nguồn thứ cấp chính chủ), không phải bịa.
> **Đã xác minh (khớp abstract nguyên văn):** FID **1.28** trên ImageNet-64×64 (1 bước), FID **8.35** trên zero-shot COCO 2014 (SD v1.5, 1 bước), **"500× reduction in inference cost"** (nguyên văn abstract), vượt qua chính teacher gốc mặc dù giảm 500× chi phí suy luận, có thể sinh ảnh megapixel qua distill SDXL.
> **Chưa xác minh (chỉ từ bảng/thân bài HTML, không xuất hiện trong abstract):** các số Table 1–6 chi tiết (FID SDXL 19.32/19.01, so sánh SDXL-Turbo/SDXL-Lightning/LCM, ablation TTUR/GAN/backward-simulation, diversity score 0.61 vs 0.64, "24% mẫu vượt teacher", chi tiết compute "7×A100/200K iter/2 ngày", "700 A100-days", "4× training compute cho dataset construction gốc" — số 4× này lấy từ thân bài, khác số "500×" nằm trong abstract).

---

# English version

## 1. Purpose of the document
Diffusion models produce high-quality images but need many sequential denoising steps, making them slow at inference. **Distribution Matching Distillation (DMD)** — the predecessor — distills a many-step teacher into a one-step generator by matching output *distributions* rather than forcing a one-to-one match with the teacher's sampling trajectory. But DMD's stability depends on an expensive **regression loss**: millions of teacher-generated noise-image pairs must be precomputed with a deterministic many-step sampler, which is prohibitively costly at text-to-image scale and also ties student quality too tightly to the teacher's own sampling paths. DMD2's purpose is to **remove this bottleneck** while making the student not just as good as, but able to **surpass**, its teacher, and to extend the method from strictly one-step to **multi-step** generation.

## 2. Main content, section by section

**Problem restated.** DMD trains a one-step generator `G` by minimizing an approximate KL divergence between the generator's output distribution and the teacher's, using two auxiliary "score" networks (real diffusion model μ_real, fake diffusion model μ_fake) to compute an implicit gradient. Removing the regression loss naively destabilizes training because the fake score network's own training signal degrades once it must track a rapidly non-stationary generator distribution.

**Improvement 1 — Two Time-scale Update Rule (TTUR).** The fix borrowed from GAN theory: update μ_fake at a much higher frequency (5×) than the generator G. This keeps the fake critic accurately tracking the generator's evolving output distribution, which the paper shows is the actual cause of the instability (visible as pixel-brightness drift) when the regression loss is dropped outright.

**Improvement 2 — GAN loss with real data.** A discriminator is added to distinguish generated samples from *real* images (not just teacher-generated ones). This lets the student train directly against real data, correcting for the teacher's own imperfect approximation of the real score, and is the mechanism that lets the student's quality **exceed** the teacher's.

**Improvement 3 — Multi-step generation via backward simulation.** Original DMD/one-step methods only produce one denoising step. DMD2 extends training to multi-step sampling (e.g., 4 steps for SDXL) but must fix a **training-inference mismatch**: during training, using *real* intermediate noisy images (as in naive extensions) doesn't match what the generator will see at inference (its own imperfect intermediate outputs). The fix is to simulate the inference-time generation process during training itself, feeding the model its own generated intermediate samples.

**Experimental setup.** Evaluated on class-conditional ImageNet-64×64 (EDM teacher), text-to-image SD v1.5 (COCO 2014, 30K prompts) and SDXL (COCO 2014, 10K prompts), against DMD, LCM-SDXL, SDXL-Turbo, SDXL-Lightning, and the respective multi-step teachers.

## 3. Key conclusions
- Removing DMD's costly regression-loss/dataset-construction step is possible **without sacrificing stability**, provided the fake-score critic is updated fast enough (TTUR) to track the generator.
- Adding a GAN loss trained on real images is what allows the *student* to **surpass its teacher** in quality — a result the original DMD (and most distillation methods) could not claim, since a pure distribution-matching/regression student is fundamentally teacher-bounded.
- Multi-step generation is compatible with this framework once the train/inference mismatch is explicitly modeled (backward simulation) — meaning distillation is not restricted to strict one-step generators.
- Practically: 1–4 step DMD2 generators for SD v1.5/SDXL close the FID gap to (and on some metrics surpass) 50–100-step teachers, at a 500× reduction in inference cost (ImageNet setting) — and crucially, at dramatically lower *training* cost than DMD because the expensive teacher-pair dataset is no longer needed.

## 4. Notable figures & to-dos

**Verified (appears verbatim/near-verbatim in the abstract):**
- FID = **1.28** on ImageNet-64×64, one-step generation.
- FID = **8.35** on zero-shot COCO 2014 (SD v1.5, one-step).
- **"500× reduction in inference cost"** vs. the original teacher, while *surpassing* that teacher's quality (abstract's own framing).
- Capable of megapixel generation via SDXL distillation (qualitative claim, abstract).

**Unverified / from HTML tables only (not corroborated by the abstract text — treat as indicative, re-check against the PDF/proceedings version before citing in the thesis):**

| Setting | Method | Steps (NFE) | FID | Notes |
|---|---|---|---|---|
| ImageNet-64×64 | EDM Teacher (ODE) | 511 | 2.32 | reference teacher |
| ImageNet-64×64 | Original DMD | 1 | 2.62 | predecessor |
| ImageNet-64×64 | DMD2 | 1 | 1.51 | base run |
| ImageNet-64×64 | DMD2 + longer training | 1 | 1.28 | = abstract number |
| SDXL / COCO2014 (10K) | SDXL Teacher (cfg=6) | 100 | 19.36 | reference teacher |
| SDXL / COCO2014 (10K) | DMD2 | 4 | 19.32 | ≈ matches teacher FID at 25× fewer passes |
| SDXL / COCO2014 (10K) | DMD2 | 1 | 19.01 | one-step SDXL |
| SDXL / COCO2014 (10K) | SDXL-Turbo | 1 | 24.57 | baseline |
| SDXL / COCO2014 (10K) | SDXL-Lightning | 4 | 24.46 | baseline |
| SDXL / COCO2014 (10K) | LCM-SDXL | 4 | 22.16 | baseline |
| SD v1.5 / COCO2014 (30K) | Teacher (50-step ODE) | 50 | 8.59 | reference |
| SD v1.5 / COCO2014 (30K) | DMD | 1 | 11.49 | predecessor |
| SD v1.5 / COCO2014 (30K) | DMD2 | 1 | 8.35 | = abstract number |

**Ablations (HTML, unverified against abstract):** removing regression loss alone → FID degrades to 3.48; +TTUR alone → FID 2.61 (recovers to ≈ original DMD's 2.62); +GAN → FID 1.51 (ImageNet). On SDXL: no-GAN → FID 26.90; no-distribution-matching (pure GAN) → FID 13.77 but poor CLIP 0.307; no-backward-simulation → FID 20.66; full DMD2 → FID 19.32.

**Other HTML-only figures (unverified):** diversity score 0.61 (DMD2) vs. 0.64 (teacher) — stated limitation; user study claims DMD2 "outperforms its teacher in image quality for 24% of samples" (128 PartiPrompts); original DMD's dataset-construction cost estimated at "more than 4× total DMD2 training compute" and ~"700 A100-days" for SDXL-scale pair generation; DMD2's own SDXL training compute reported as using 3M LAION-Aesthetics prompts + 500K images for the GAN discriminator; ImageNet run: 7×A100 GPUs, 200K iterations, ~2 days.

**Stated limitations (from HTML, unverified against abstract):** slight loss of output diversity vs. teacher; megapixel SDXL quality still needs 4 steps (not fully 1-step at that resolution); fixed guidance scale baked in at training time, reducing inference-time flexibility (no free CFG-scale knob unlike the teacher).

**To-dos for the thesis:** re-derive/re-check the Table 1–6 numbers directly from the NeurIPS proceedings PDF (not just the HTML render) before quoting them as hard facts; confirm whether "500×" (abstract) and "511/1" NFE ratio in Table 1 are the same claim (they appear consistent: 511 ≈ 500).

## 5. Quick recap (< 300 words)
DMD2 fixes the three biggest practical problems of the original Distribution Matching Distillation (DMD) method for turning slow multi-step diffusion models into fast one-/few-step generators. First, DMD required a huge precomputed dataset of teacher noise-image pairs to keep training stable — expensive to the point of being impractical for large text-to-image models. DMD2 removes this regression loss entirely, and shows the instability that follows is really a failure of the auxiliary "fake score" critic to track the generator's shifting output distribution; the fix is a **two-time-scale update rule** that updates this critic 5× faster than the generator. Second, DMD2 adds a **GAN loss trained on real images** (not just teacher outputs), which lets the student directly learn from real data and — notably — **exceed the teacher's own quality**, something a purely distribution-matching or regression-based student structurally cannot do. Third, DMD2 extends the method to **multi-step generation** (e.g., 4 steps), addressing a training/inference mismatch by simulating the inference-time generation process (using the student's own imperfect intermediate outputs) during training rather than feeding it clean real data it will never see at test time. Verified headline results: FID 1.28 on ImageNet-64×64 (one step) and FID 8.35 on zero-shot COCO2014 with SD v1.5 (one step), with the abstract explicitly claiming the method **surpasses the original teacher despite a 500× reduction in inference cost**, and that megapixel images are achievable by distilling SDXL. The paper became one of the most widely adopted few-step distillation recipes in production diffusion pipelines, precisely because it decouples distillation quality from expensive teacher-pair dataset construction while still allowing multi-step flexibility.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈46w):** DMD's stability required an expensive precomputed teacher-pair dataset. DMD2 removes it via a two-time-scale critic update, adds a GAN loss on real data so the student can beat its teacher, and extends training to multi-step sampling — hitting FID 1.28 on ImageNet-64 at 500× less inference cost.

## 7. The essence in plain language
**The problem, plainly:** Turning a slow, many-step image generator into a fast one-step generator (distillation) used to require first generating millions of expensive "practice pairs" from the slow teacher, just to keep training from blowing up.

**Core idea (one sentence):** Instead of pre-generating practice material, just make the "grader" (the fake-score critic) check the student's homework much more often than the student turns it in, and let the student also study directly from real photos instead of only the teacher's answers.

**Everyday analogy — the too-slow grader:** Imagine a student (generator) constantly changing their handwriting style while an old, slow grader tries to keep an answer key updated. If the grader updates rarely, they grade against a stale answer key and everything falls apart. DMD2's fix: let the grader re-check much more frequently (2× to 5× per student update) so it never falls behind — plus give the student real exam papers (real images) to study from, not just the teacher's worked examples, so the student can eventually outscore the teacher.

**If you remember only one thing:** You don't need an expensive pre-made answer sheet to teach a fast student well — you just need the grader to keep up.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Mô hình diffusion sinh ảnh chất lượng cao nhưng cần rất nhiều bước khử nhiễu tuần tự nên chậm khi suy luận. **Distribution Matching Distillation (DMD)** — phiên bản gốc — chưng cất teacher nhiều bước thành generator một bước bằng cách khớp *phân phối* đầu ra thay vì buộc khớp từng-điểm với quỹ đạo sampling của teacher. Nhưng độ ổn định của DMD phụ thuộc vào một **hàm mất hồi quy (regression loss)** tốn kém: phải tính trước hàng triệu cặp (nhiễu, ảnh) do teacher sinh bằng sampler tất định nhiều bước — quá đắt ở quy mô text-to-image, và còn khiến chất lượng student bị bó chặt vào đúng quỹ đạo sampling của teacher. Mục đích của DMD2 là **loại bỏ nút thắt này**, đồng thời làm cho student không chỉ ngang bằng mà còn có thể **vượt qua** teacher, và mở rộng phương pháp từ đúng-một-bước sang **nhiều bước**.

## 2. Nội dung chính từng phần

**Nhắc lại vấn đề.** DMD huấn luyện generator một bước `G` bằng cách tối thiểu hóa gần đúng độ lệch KL giữa phân phối đầu ra của generator và của teacher, dùng hai mạng "score" phụ trợ (μ_real, μ_fake) để tính gradient ngầm. Bỏ hàm hồi quy một cách ngây thơ làm mất ổn định huấn luyện vì mạng "fake score" phụ trợ không theo kịp phân phối đầu ra đang thay đổi nhanh của generator.

**Cải tiến 1 — Two Time-scale Update Rule (TTUR).** Giải pháp mượn từ lý thuyết GAN: cập nhật μ_fake với tần suất cao hơn nhiều (5×) so với generator G. Điều này giúp critic "fake" bám sát phân phối đầu ra đang biến đổi của generator — bài báo chỉ ra đây chính là nguyên nhân thật của bất ổn (thể hiện qua dao động độ sáng pixel) khi bỏ thẳng hàm hồi quy.

**Cải tiến 2 — Hàm GAN loss với dữ liệu thật.** Thêm một discriminator để phân biệt mẫu sinh ra với *ảnh thật* (không chỉ ảnh do teacher sinh). Điều này cho phép student học trực tiếp từ dữ liệu thật, sửa sai số ước lượng real-score không hoàn hảo của teacher — và chính là cơ chế giúp chất lượng student **vượt** teacher.

**Cải tiến 3 — Sinh nhiều bước qua "backward simulation".** DMD/các phương pháp một-bước gốc chỉ sinh một bước khử nhiễu. DMD2 mở rộng huấn luyện sang sampling nhiều bước (ví dụ 4 bước cho SDXL) nhưng phải xử lý **lệch pha huấn luyện–suy luận**: nếu dùng ảnh nhiễu trung gian *thật* khi huấn luyện (cách mở rộng ngây thơ) sẽ không khớp với những gì generator thực sự thấy lúc suy luận (đầu ra trung gian không hoàn hảo của chính nó). Giải pháp: mô phỏng chính quy trình sinh lúc suy luận ngay trong huấn luyện, cho model "ăn" lại đầu ra trung gian do chính nó sinh ra.

**Thiết lập thí nghiệm.** Đánh giá trên ImageNet-64×64 có điều kiện lớp (teacher EDM), text-to-image SD v1.5 (COCO 2014, 30K prompt) và SDXL (COCO 2014, 10K prompt), so với DMD, LCM-SDXL, SDXL-Turbo, SDXL-Lightning và các teacher nhiều bước tương ứng.

## 3. Các kết luận quan trọng
- Có thể bỏ bước hồi quy/tạo dataset tốn kém của DMD **mà không mất ổn định**, miễn là critic fake-score được cập nhật đủ nhanh (TTUR) để theo kịp generator.
- Thêm GAN loss huấn luyện trên ảnh thật là điều cho phép *student* **vượt qua chính teacher** về chất lượng — kết quả mà DMD gốc (và hầu hết phương pháp distillation) không thể đạt được, vì một student thuần distribution-matching/hồi quy về bản chất bị chặn trên bởi teacher.
- Sinh nhiều bước tương thích với khung này khi lệch pha train/inference được mô hình hóa rõ ràng (backward simulation) — nghĩa là distillation không bị giới hạn chỉ ở generator một-bước nghiêm ngặt.
- Về thực tiễn: generator DMD2 1–4 bước cho SD v1.5/SDXL thu hẹp (và ở một số chỉ số vượt) khoảng cách FID với teacher 50–100 bước, giảm 500× chi phí suy luận (thiết lập ImageNet) — và quan trọng là chi phí *huấn luyện* thấp hơn DMD rất nhiều vì không còn cần dataset cặp teacher tốn kém.

## 4. Số liệu nổi bật & việc cần làm

**Đã xác minh (nguyên văn/gần nguyên văn abstract):**
- FID = **1.28** trên ImageNet-64×64, sinh một bước.
- FID = **8.35** trên zero-shot COCO 2014 (SD v1.5, một bước).
- **"Giảm 500× chi phí suy luận"** so với teacher gốc, đồng thời *vượt* chất lượng teacher đó (nguyên văn khung abstract).
- Có khả năng sinh ảnh megapixel qua distill SDXL (tuyên bố định tính, trong abstract).

**Chưa xác minh / chỉ từ bảng HTML (không có trong abstract — nên coi là tham khảo, kiểm tra lại với bản PDF/proceedings trước khi trích dẫn chính thức trong luận văn):**

| Thiết lập | Phương pháp | Số bước (NFE) | FID | Ghi chú |
|---|---|---|---|---|
| ImageNet-64×64 | EDM Teacher (ODE) | 511 | 2.32 | teacher tham chiếu |
| ImageNet-64×64 | DMD gốc | 1 | 2.62 | tiền nhiệm |
| ImageNet-64×64 | DMD2 | 1 | 1.51 | chạy cơ sở |
| ImageNet-64×64 | DMD2 + train dài hơn | 1 | 1.28 | = số trong abstract |
| SDXL / COCO2014 (10K) | SDXL Teacher (cfg=6) | 100 | 19.36 | teacher tham chiếu |
| SDXL / COCO2014 (10K) | DMD2 | 4 | 19.32 | ≈ khớp FID teacher, ít hơn 25× forward pass |
| SDXL / COCO2014 (10K) | DMD2 | 1 | 19.01 | SDXL một bước |
| SDXL / COCO2014 (10K) | SDXL-Turbo | 1 | 24.57 | baseline |
| SDXL / COCO2014 (10K) | SDXL-Lightning | 4 | 24.46 | baseline |
| SDXL / COCO2014 (10K) | LCM-SDXL | 4 | 22.16 | baseline |
| SD v1.5 / COCO2014 (30K) | Teacher (50-step ODE) | 50 | 8.59 | tham chiếu |
| SD v1.5 / COCO2014 (30K) | DMD | 1 | 11.49 | tiền nhiệm |
| SD v1.5 / COCO2014 (30K) | DMD2 | 1 | 8.35 | = số trong abstract |

**Ablation (HTML, chưa xác minh với abstract):** bỏ hồi quy loss (không TTUR) → FID tụt xuống 3.48; +TTUR → FID 2.61 (hồi phục về mức DMD gốc 2.62); +GAN → FID 1.51 (ImageNet). Trên SDXL: bỏ GAN → FID 26.90; bỏ distribution-matching (chỉ GAN thuần) → FID 13.77 nhưng CLIP kém (0.307); bỏ backward-simulation → FID 20.66; đủ DMD2 → FID 19.32.

**Số liệu khác chỉ từ HTML (chưa xác minh):** diversity score 0.61 (DMD2) so với 0.64 (teacher) — hạn chế tự nêu; khảo sát người dùng cho thấy DMD2 "vượt chất lượng ảnh của teacher ở 24% mẫu" (128 PartiPrompts); chi phí tạo dataset của DMD gốc ước tính "hơn 4× tổng compute huấn luyện DMD2" và ~"700 A100-ngày" để sinh cặp ở quy mô SDXL; DMD2 tự huấn luyện SDXL dùng 3M prompt LAION-Aesthetics + 500K ảnh cho discriminator GAN; chạy ImageNet: 7×A100, 200K iteration, ~2 ngày.

**Hạn chế tự nêu (từ HTML, chưa xác minh với abstract):** giảm nhẹ độ đa dạng đầu ra so với teacher; ảnh SDXL megapixel vẫn cần 4 bước (chưa thực sự 1-bước ở độ phân giải đó); guidance scale cố định ngay lúc huấn luyện, giảm linh hoạt CFG lúc suy luận (không có "núm" CFG tự do như teacher).

**Việc cần làm cho luận văn:** đối chiếu lại các số Table 1–6 trực tiếp từ PDF NeurIPS proceedings (không chỉ bản render HTML) trước khi trích dẫn như số liệu cứng; xác nhận "500×" (trong abstract) và tỉ lệ NFE 511/1 ở Table 1 có phải cùng một tuyên bố (có vẻ khớp: 511 ≈ 500).

## 5. Tóm tắt ngắn (< 300 từ)
DMD2 sửa ba vấn đề thực tiễn lớn nhất của Distribution Matching Distillation (DMD) gốc — phương pháp biến diffusion model chậm nhiều bước thành generator nhanh một/vài bước. Thứ nhất, DMD cần một dataset khổng lồ các cặp (nhiễu, ảnh) do teacher sinh trước để giữ ổn định huấn luyện — tốn kém tới mức bất khả thi ở quy mô text-to-image lớn. DMD2 bỏ hoàn toàn hàm hồi quy này, và chỉ ra bất ổn xảy ra sau đó thực chất là do mạng "fake score" phụ trợ không theo kịp phân phối đầu ra đang thay đổi của generator; giải pháp là **quy tắc cập nhật hai tốc độ (TTUR)**, cập nhật critic này nhanh hơn 5× so với generator. Thứ hai, DMD2 thêm **hàm GAN loss huấn luyện trên ảnh thật** (không chỉ đầu ra của teacher), cho phép student học trực tiếp từ dữ liệu thật và — đáng chú ý — **vượt qua chất lượng của chính teacher**, điều mà một student thuần distribution-matching/hồi quy về cấu trúc không thể làm được. Thứ ba, DMD2 mở rộng sang **sinh nhiều bước** (ví dụ 4 bước), xử lý lệch pha huấn luyện/suy luận bằng cách mô phỏng chính quy trình sinh lúc suy luận (dùng đầu ra trung gian không hoàn hảo của chính student) trong lúc huấn luyện, thay vì cho nó ăn dữ liệu thật sạch mà nó sẽ không bao giờ thấy lúc test. Kết quả đầu bảng đã xác minh: FID 1.28 trên ImageNet-64×64 (một bước) và FID 8.35 trên zero-shot COCO2014 với SD v1.5 (một bước), với abstract khẳng định rõ phương pháp **vượt qua teacher gốc trong khi giảm 500× chi phí suy luận**, và có thể sinh ảnh megapixel bằng cách distill SDXL. Bài báo trở thành một trong những công thức chưng cất few-step được áp dụng rộng rãi nhất trong các pipeline diffusion sản xuất thực tế, chính vì nó tách rời chất lượng distillation khỏi việc xây dataset cặp teacher tốn kém mà vẫn giữ được tính linh hoạt nhiều bước.

## 6. Câu chốt hội nghị (30–50 từ)
**VI (≈48 từ):** DMD gốc cần dataset cặp teacher tốn kém để ổn định. DMD2 bỏ nó bằng cách cập nhật critic hai tốc độ, thêm GAN loss trên ảnh thật để student vượt được teacher, và mở rộng sang sinh nhiều bước — đạt FID 1.28 trên ImageNet-64 với 500× ít chi phí suy luận hơn.

## 7. Bản chất nói nôm na
**Vấn đề, nói thẳng:** Biến một máy vẽ ảnh chậm, nhiều bước thành máy vẽ nhanh một bước (chưng cất/distillation) trước đây cần sinh trước hàng triệu "bài tập mẫu" tốn kém từ máy chậm (teacher), chỉ để giữ cho việc huấn luyện không sụp.

**Ý tưởng cốt lõi (một câu):** Đừng soạn trước bài tập mẫu tốn kém — hãy để "người chấm bài" (critic fake-score) kiểm tra bài của học sinh thường xuyên hơn nhiều so với tốc độ học sinh nộp bài, và cho học sinh học thêm trực tiếp từ ảnh thật chứ không chỉ từ đáp án của thầy.

**Ẩn dụ đời thường — người chấm quá chậm:** Hình dung một học sinh (generator) liên tục đổi kiểu viết chữ, còn người chấm già chậm cứ cố cập nhật đáp án cho kịp. Nếu người chấm cập nhật đáp án hiếm hoi, họ sẽ chấm theo đáp án cũ và mọi thứ sụp đổ. Cách sửa của DMD2: cho người chấm kiểm tra thường xuyên hơn (2–5× mỗi lần học sinh nộp bài) để không bao giờ bị tụt lại — cộng thêm cho học sinh đề thi thật (ảnh thật) để luyện, không chỉ bài giải mẫu của thầy, để rồi học sinh có thể vượt điểm thầy.

**Câu để đời:** Không cần một bộ đáp án soạn trước tốn kém để dạy một học sinh nhanh giỏi — chỉ cần người chấm theo kịp là đủ.
