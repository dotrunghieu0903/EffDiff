# FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness

**Tác giả:** Tri Dao, Daniel Y. Fu, Stefano Ermon, Atri Rudra, Christopher Ré
**Venue:** NeurIPS 2022 · arXiv 2205.14135
**Nguồn:** https://arxiv.org/abs/2205.14135

> **Ghi chú xác minh:** Abstract lấy nguyên văn từ `/abs/`. Các số dưới đây đều **từ abstract (đã xác minh)**: 15% nhanh hơn trên BERT-large (seq 512), 3× trên GPT-2 (seq 1K), 2.4× trên Long-Range Arena (seq 1K–4K), +0.7 perplexity GPT-2, +6.4 điểm phân loại tài liệu dài, Path-X 61.4% (seq 16K), Path-256 63.1% (seq 64K). Mô tả cơ chế (tiling, online softmax, recomputation) là kiến thức nền chuẩn về bài báo này; không có số nào bịa thêm.
>
> **Vị trí trong luận văn:** đây là **paper gốc (A2)** của Nhóm 6, *ngoài* cửa sổ SOTA 2024–2026 và là primitive tổng quát (không đặc thù diffusion) → **không được chọn đại diện Nhóm 6** (đại diện là DistriFusion). Đọc để hiểu nền tảng của cả nhóm kernel.

---

# English version

## 1. Purpose of the document
Self-attention costs **quadratic time and memory** in sequence length, making Transformers slow and memory-hungry on long sequences. Prior "approximate attention" methods cut FLOPs but rarely deliver real wall-clock speedups. FlashAttention's goal is a **fast, memory-efficient, and *exact*** attention algorithm — no quality trade-off — by making the algorithm **IO-aware**: minimizing reads/writes between the GPU's slow high-bandwidth memory (HBM) and its fast on-chip SRAM.

## 2. Main content, section by section
**Diagnosis.** Standard attention materializes the full N×N score matrix in HBM (write) and reads it back for softmax and the value multiply. The bottleneck is **memory traffic (IO)**, not arithmetic.

**Method — tiling + online softmax + recomputation.**
- **Tiling:** split Q, K, V into blocks that fit in SRAM; compute attention block-by-block so the N×N matrix is **never fully written to HBM**.
- **Online softmax:** maintain running max and sum statistics to combine partial softmax results across blocks correctly, without seeing the whole row at once (numerically stable).
- **Recomputation (backward):** instead of storing the huge attention matrix for the backward pass, recompute it on-chip from stored statistics — trading a little extra compute for far less memory.
- **IO-complexity analysis:** proves FlashAttention needs fewer HBM accesses than standard attention and is optimal across a range of SRAM sizes.
- **Block-sparse extension:** a faster approximate variant for even longer contexts.

**Evaluation.** Transformer training (BERT-large, GPT-2), Long-Range Arena, and long-context tasks (Path-X, Path-256).

## 3. Key conclusions
- Making attention **IO-aware** yields real wall-clock speedups while staying **exact** (no approximation).
- Enables **longer contexts**, which in turn improve model quality and unlock previously impossible tasks.
- IO cost, not FLOPs, is the right optimization target for attention on modern GPUs — a principle that seeded a whole family of fused kernels.

## 4. Notable figures & to-dos
**Verified (from abstract):** 15% faster BERT-large (seq 512, vs MLPerf 1.1 record); **3× GPT-2** (seq 1K); **2.4× Long-Range Arena** (seq 1K–4K); +0.7 perplexity (GPT-2); +6.4 points long-document classification; **Path-X 61.4%** (seq 16K, first Transformer better than chance); **Path-256 63.1%** (seq 64K).

**Limitations / follow-ups:** original kernel is not maximally hardware-optimal on newer GPUs (addressed later by FlashAttention-2 for parallelism/work-partitioning, and FlashAttention-3 for Hopper async + FP8); block-sparse variant is approximate. Requires custom CUDA kernels per hardware generation.

## 5. Quick recap (< 300 words)
FlashAttention makes attention fast and memory-light **without any approximation**, by attacking the real bottleneck: data movement between the GPU's slow HBM and fast on-chip SRAM. Standard attention writes the full N×N score matrix to HBM and reads it back for softmax — quadratic memory traffic. FlashAttention instead **tiles** Q/K/V into SRAM-sized blocks and computes attention block-by-block, using an **online softmax** (running max/sum) to stitch partial results together correctly, so the giant score matrix is never fully stored. For the backward pass it **recomputes** attention on-chip from small saved statistics rather than storing the matrix, spending a bit more compute to save a lot of memory. The authors prove the algorithm is IO-optimal across a range of SRAM sizes and extend it to a faster block-sparse (approximate) variant. Because attention now costs far less memory, models can handle **much longer sequences**. Verified results: 15% faster BERT-large (seq 512), 3× faster GPT-2 (seq 1K), 2.4× on Long-Range Arena, plus quality gains (+0.7 perplexity, +6.4 points on long documents) and entirely new capabilities — the first Transformer to beat chance on Path-X (16K) at 61.4% and Path-256 (64K) at 63.1%. FlashAttention established that **IO-awareness, not FLOP-counting, is the right lens** for attention on GPUs, and became the foundation for FlashAttention-2/-3 and the broader family of fused/quantized/sparse attention kernels (SageAttention, SpargeAttention) that now underpin efficient diffusion inference.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈42w):** Attention is slow because it shuttles a giant N×N matrix through slow GPU memory. FlashAttention keeps it in fast on-chip SRAM via tiling and an online softmax — exact, not approximate — giving up to 3× faster training and enabling 64K-token contexts.

**VI (≈47 từ):** Attention chậm vì phải chuyển ma trận N×N khổng lồ qua bộ nhớ GPU chậm. FlashAttention giữ nó trong SRAM nhanh trên chip nhờ chia ô (tiling) và softmax trực tuyến — chính xác tuyệt đối, không xấp xỉ — nhanh tới 3× khi huấn luyện và mở khóa ngữ cảnh 64K token.

## 7. The essence in plain language
**The problem, plainly:** The math trick that lets AI models "pay attention" gets brutally slow on long inputs, mostly because the computer keeps hauling a huge table back and forth between a big-but-slow storage and a tiny-but-fast workbench.

**Core idea (one sentence):** Do the work in small chunks that fit on the fast workbench, and never write the huge table to slow storage at all.

**Everyday analogy — cooking from a giant recipe:** Instead of copying a 1000-page recipe onto your small kitchen counter all at once (impossible, and slow to fetch pages), you bring one page at a time, keep a running note of totals, and finish each step on the counter. Same dish, far less running back to the pantry.

**If you remember only one thing:** The speed came not from doing less math, but from **stopping needless trips to slow memory** — exact answer, much faster.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Self-attention tốn **thời gian và bộ nhớ bậc hai** theo độ dài chuỗi → Transformer chậm và ngốn bộ nhớ với chuỗi dài. Các phương pháp "attention xấp xỉ" trước đó giảm FLOPs nhưng hiếm khi tăng tốc thực (wall-clock). Mục tiêu của FlashAttention: một thuật toán attention **nhanh, tiết kiệm bộ nhớ, và *chính xác tuyệt đối*** (không đánh đổi chất lượng) — bằng cách làm thuật toán **nhận biết IO**: tối thiểu hóa đọc/ghi giữa bộ nhớ băng thông cao chậm (HBM) và SRAM nhanh trên chip.

## 2. Nội dung chính từng phần
**Chẩn đoán.** Attention chuẩn ghi cả ma trận điểm N×N ra HBM rồi đọc lại để tính softmax và nhân với V. Nút thắt là **lưu lượng bộ nhớ (IO)**, không phải số phép tính.

**Phương pháp — tiling + online softmax + recomputation.**
- **Tiling (chia ô):** chia Q, K, V thành các khối vừa SRAM; tính attention theo từng khối để **không bao giờ ghi trọn ma trận N×N ra HBM**.
- **Online softmax:** giữ thống kê max/tổng chạy dần để ghép đúng kết quả softmax từng phần qua các khối (ổn định số học) mà không cần thấy cả hàng cùng lúc.
- **Recomputation (lượt ngược):** thay vì lưu ma trận attention khổng lồ cho backward, tính lại nó ngay trên chip từ thống kê nhỏ đã lưu — đổi chút tính toán lấy tiết kiệm bộ nhớ lớn.
- **Phân tích độ phức tạp IO:** chứng minh FlashAttention truy cập HBM ít hơn attention chuẩn và tối ưu trên một dải kích thước SRAM.
- **Mở rộng block-sparse:** biến thể xấp xỉ nhanh hơn cho ngữ cảnh còn dài hơn.

**Đánh giá.** Huấn luyện Transformer (BERT-large, GPT-2), Long-Range Arena, và tác vụ ngữ cảnh dài (Path-X, Path-256).

## 3. Các kết luận quan trọng
- Làm attention **nhận biết IO** cho tăng tốc thực mà vẫn **chính xác** (không xấp xỉ).
- Cho phép **ngữ cảnh dài hơn**, nhờ đó chất lượng cao hơn và mở khóa tác vụ trước đây bất khả.
- Chi phí IO (không phải FLOPs) mới là mục tiêu tối ưu đúng cho attention trên GPU hiện đại — nguyên lý khai sinh cả họ fused kernel sau này.

## 4. Số liệu nổi bật & việc cần làm
**Đã xác minh (từ abstract):** nhanh hơn 15% BERT-large (seq 512, so kỷ lục MLPerf 1.1); **3× GPT-2** (seq 1K); **2.4× Long-Range Arena** (seq 1K–4K); +0.7 perplexity (GPT-2); +6.4 điểm phân loại tài liệu dài; **Path-X 61.4%** (seq 16K, Transformer đầu tiên vượt ngưỡng ngẫu nhiên); **Path-256 63.1%** (seq 64K).

**Hạn chế / hậu duệ:** kernel gốc chưa tối ưu tối đa trên GPU mới (được FlashAttention-2 cải tiến song song/phân chia công việc, FlashAttention-3 khai thác async Hopper + FP8); biến thể block-sparse là xấp xỉ; cần kernel CUDA tùy biến theo thế hệ phần cứng.

## 5. Tóm tắt ngắn (< 300 từ)
FlashAttention làm attention nhanh và nhẹ bộ nhớ **mà không xấp xỉ**, bằng cách tấn công đúng nút thắt: việc di chuyển dữ liệu giữa HBM chậm và SRAM nhanh trên chip GPU. Attention chuẩn ghi cả ma trận điểm N×N ra HBM rồi đọc lại để tính softmax — lưu lượng bộ nhớ bậc hai. FlashAttention thay vào đó **chia ô (tiling)** Q/K/V thành các khối vừa SRAM và tính attention theo từng khối, dùng **online softmax** (max/tổng chạy dần) để ghép đúng các kết quả từng phần, nên ma trận khổng lồ không bao giờ được lưu trọn. Ở lượt ngược, nó **tính lại (recompute)** attention ngay trên chip từ thống kê nhỏ đã lưu thay vì lưu cả ma trận — tốn thêm chút tính toán để tiết kiệm nhiều bộ nhớ. Nhóm tác giả chứng minh thuật toán tối ưu IO trên một dải kích thước SRAM và mở rộng sang biến thể block-sparse (xấp xỉ) nhanh hơn. Nhờ attention tốn ít bộ nhớ hơn hẳn, model xử lý được **chuỗi dài hơn nhiều**. Kết quả đã xác minh: nhanh hơn 15% BERT-large (seq 512), 3× GPT-2 (seq 1K), 2.4× Long-Range Arena, cùng cải thiện chất lượng (+0.7 perplexity, +6.4 điểm tài liệu dài) và năng lực hoàn toàn mới — Transformer đầu tiên vượt ngẫu nhiên trên Path-X (16K) đạt 61.4% và Path-256 (64K) đạt 63.1%. FlashAttention xác lập nguyên lý **IO-awareness, không phải đếm FLOPs, mới là lăng kính đúng** cho attention trên GPU, và trở thành nền cho FlashAttention-2/-3 cùng họ kernel fused/lượng-tử/sparse (SageAttention, SpargeAttention) đang chống lưng cho suy luận diffusion hiệu quả.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈42w):** Attention is slow because it shuttles a giant N×N matrix through slow GPU memory. FlashAttention keeps it in fast on-chip SRAM via tiling and an online softmax — exact, not approximate — giving up to 3× faster training and enabling 64K-token contexts.

**VI (≈47 từ):** Attention chậm vì phải chuyển ma trận N×N khổng lồ qua bộ nhớ GPU chậm. FlashAttention giữ nó trong SRAM nhanh trên chip nhờ chia ô (tiling) và softmax trực tuyến — chính xác tuyệt đối, không xấp xỉ — nhanh tới 3× khi huấn luyện và mở khóa ngữ cảnh 64K token.

## 7. Bản chất nói nôm na
**Vấn đề, nói mộc:** Mẹo toán giúp AI "chú ý" trở nên cực chậm với đầu vào dài, chủ yếu vì máy cứ khuân một bảng khổng lồ qua lại giữa kho lớn-nhưng-chậm và bàn làm việc nhỏ-nhưng-nhanh.

**Ý tưởng cốt lõi:** Làm việc theo từng mẩu nhỏ vừa với bàn làm việc nhanh, và tuyệt đối không ghi cả bảng khổng lồ vào kho chậm.

**Ẩn dụ đời thường — nấu theo công thức dày cộp:** Thay vì chép cả cuốn công thức 1000 trang lên mặt bếp nhỏ (bất khả, lại chậm), bạn mang từng trang một, ghi chú tổng đang chạy, và làm xong từng bước tại bếp. Vẫn ra đúng món, mà đỡ hẳn số lần chạy vào kho.

**Câu để đời:** Nhanh không nhờ tính ít đi, mà nhờ **cắt các chuyến đi vô ích tới bộ nhớ chậm** — đáp án y hệt, nhưng nhanh hơn nhiều.
