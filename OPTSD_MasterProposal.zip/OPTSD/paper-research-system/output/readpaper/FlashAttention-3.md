# FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-precision

**Tác giả:** Jay Shah, Ganesh Bikshandi, Ying Zhang, Vijay Thakkar, Pradeep Ramani, Tri Dao
**Venue:** NeurIPS 2025 · arXiv 2407.08608 (07/2024)
**Nguồn:** https://arxiv.org/abs/2407.08608

> **Ghi chú xác minh:** Abstract lấy nguyên văn `/abs/`; chi tiết cơ chế từ HTML `/html/`. **Đã xác minh (abstract):** FP16 tới **740 TFLOPs/s (75% utilization H100)**, tăng tốc **1.5–2.0×**, FP8 tới **~1.2 PFLOPs/s**, sai số FP8 **thấp hơn 2.6×** so baseline FP8; FlashAttention-2 chỉ đạt **35% utilization** trên H100. **Từ HTML (chỉ tham khảo):** ping-pong đưa FP16 forward (head-dim 128) từ 570 → 620–640 TFLOPS; backward nhanh 1.5–1.75×.
>
> **Vị trí trong luận văn:** FA-3 nằm TRONG cửa sổ SOTA (Nhóm 6A, #1). Là **primitive tổng quát** (benchmark cả diffusion) — enabler tầng kernel, không phải trục thuật toán đặc thù diffusion.

---

# English version

## 1. Purpose of the document
Attention is the bottleneck for LLMs and long-context/diffusion workloads. FlashAttention(-2) minimized memory IO but **doesn't exploit new Hopper (H100) hardware** — FlashAttention-2 reaches only **35% utilization** on H100. FlashAttention-3's goal: redesign exact attention around Hopper's **asynchronous** units and **FP8** support to close that gap, staying exact/accurate.

## 2. Main content, section by section
**Diagnosis.** On H100, the limiter is no longer just HBM traffic but **keeping the fast Tensor Cores busy** while the slow softmax runs, and using FP8 without wrecking accuracy. FA-2's synchronous schedule leaves Tensor Cores idle.

**Three techniques.**
1. **Asynchrony via warp-specialization:** split warps into **producers** (data movement via TMA — Tensor Memory Accelerator) and **consumers** (compute), so data movement and Tensor-Core work overlap and hide latency.
2. **Interleave matmul & softmax (ping-pong pipelining):** while one warpgroup does softmax on one score block, another runs the **WGMMA** matmul (async proxy) on the next block; roles alternate via barriers. (HTML: lifts FP16 fwd head-dim-128 from ~570 → 620–640 TFLOPS.)
3. **FP8 low-precision done right:** **block quantization** (one scale per block, not per-tensor) + **incoherent processing** (multiply Q,K by a random orthogonal matrix to spread outliers before quantizing), reducing FP8 error; plus in-kernel layout transforms to satisfy WGMMA's operand layout.

## 3. Key conclusions
- Redesigning attention around **hardware asynchrony** unlocks the H100: 75% FP16 utilization vs FA-2's 35%.
- **FP8 attention can be both fast and accurate** if outliers are handled (block quant + incoherent processing) — 2.6× lower error than naive FP8.
- Exact attention (FP16) and near-exact (FP8) both benefit — no model-quality trade-off in the FP16 path.

## 4. Notable figures & to-dos
**Verified (abstract):** 1.5–2.0× speedup; **FP16 740 TFLOPs/s (75% H100 util)**; **FP8 ~1.2 PFLOPs/s**; **FP8 error 2.6× lower** than baseline; FA-2 baseline = 35% util on H100.
**From HTML (indicative):** ping-pong 570→620–640 TFLOPS (FP16 fwd, head-dim 128); backward 1.5–1.75× faster.
**Limitations / to-dos:** Hopper-specific (TMA/WGMMA/FP8) — gains don't transfer to older GPUs; FP8 path is near-exact, not bit-exact; kernel engineering is highly hardware-coupled.

## 5. Quick recap (< 300 words)
FlashAttention-3 rebuilds exact attention for NVIDIA's Hopper (H100) GPUs, where FlashAttention-2 wasted most of the chip (only 35% utilization). The problem on modern GPUs is no longer just memory traffic: it's keeping the ultra-fast Tensor Cores busy while the slower softmax runs, and using 8-bit (FP8) precision without destroying accuracy. FA-3 uses three tricks. (1) **Asynchrony via warp-specialization:** some warps become "producers" that move data with Hopper's TMA engine while others are "consumers" that compute, so data movement and math overlap and hide each other's latency. (2) **Ping-pong pipelining:** it interleaves the matmul (async WGMMA on Tensor Cores) with the softmax on separate warpgroups, so while one block's softmax runs, the next block's matmul is already going. (3) **Accurate FP8:** instead of one scale per tensor, it uses **block quantization** (a scale per tile) plus **incoherent processing** (multiplying Q and K by a random orthogonal matrix to spread out outliers before quantizing), cutting FP8 error. Verified results: **1.5–2.0× faster than FA-2**, FP16 reaching **740 TFLOPs/s (75% utilization)**, FP8 approaching **1.2 PFLOPs/s**, and FP8 numerical error **2.6× lower** than a baseline FP8 attention. The catch: everything is tied to Hopper-specific features (TMA, WGMMA, FP8), so the gains don't carry to older GPUs. FA-3 is a kernel-level *enabler* — it speeds up any Transformer/DiT using attention without changing the model, and its FP8 handling (block quant + incoherent processing) is conceptually close to the outlier-management ideas used in diffusion quantization work like SVDQuant.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈45w):** On H100, FlashAttention-2 wasted 65% of the chip. FlashAttention-3 exploits Hopper's asynchrony — producer/consumer warps and ping-pong matmul/softmax pipelining — plus accurate FP8 via block quantization and incoherent processing: 1.5–2× faster, 75% FP16 utilization, ~1.2 PFLOPs/s FP8.

**VI (≈47 từ):** Trên H100, FlashAttention-2 bỏ phí 65% chip. FlashAttention-3 khai thác tính bất đồng bộ của Hopper — warp producer/consumer và pipeline ping-pong matmul/softmax — cộng FP8 chính xác nhờ lượng tử theo khối và incoherent processing: nhanh 1.5–2×, đạt 75% utilization FP16, ~1.2 PFLOPs/s ở FP8.

## 7. The essence in plain language
**The problem, plainly:** New GPUs are like a super-fast kitchen, but the old attention recipe kept the star chef (Tensor Cores) standing idle two-thirds of the time, waiting on prep work.

**Core idea (one sentence):** Split the crew so someone always fetches ingredients while the chef keeps cooking, and let one station chop while another plates — nobody waits.

**Everyday analogy — a well-run kitchen line:** Instead of one cook doing fetch-chop-cook-plate in sequence (idle gaps everywhere), you assign runners to fetch (producers) and cooks to cook (consumers), and you ping-pong stations so as one dish's sauce simmers, the next dish is already searing. Plus you learned to use cheaper ingredients (FP8) without ruining the taste by prepping them cleverly.

**If you remember only one thing:** The speed came from **never letting the fast hardware wait** — overlap everything, and make 8-bit accurate enough to trust.

---

## 📌 Note key cho FlashAttention-2 và FlashAttention-1 (bối cảnh dòng họ)

Dòng tiến hóa: **FA-1 (tối ưu IO)** → **FA-2 (tối ưu song song/phân chia công việc)** → **FA-3 (khai thác bất đồng bộ + FP8 cho Hopper)**.

### FlashAttention-2 — "Faster Attention with Better Parallelism and Work Partitioning"
- **Tác giả/venue:** Tri Dao · ICLR 2024 · arXiv 2307.08691.
- **3 đóng góp key so với FA-1:**
  1. **Giảm FLOPs ngoài matmul** — sắp lại thuật toán để phần tính không-phải-matmul (vốn chậm trên Tensor Core) ít đi.
  2. **Song song hóa theo chiều dài chuỗi** — parallelize cả cho *một* head qua nhiều thread block → tăng occupancy (FA-1 chỉ song song theo batch/head).
  3. **Phân chia công việc mức warp tốt hơn** — giảm giao tiếp qua shared memory giữa các warp.
- **Số đã xác minh:** ~**2×** nhanh hơn FA-1; đạt **50–73%** FLOPs lý thuyết trên A100 (FA-1 chỉ 25–40%); tới **225 TFLOPs/s/A100** (72% MFU) khi train GPT.

### FlashAttention-1 — "Fast and Memory-Efficient Exact Attention with IO-Awareness"
- **Tác giả/venue:** Tri Dao et al. · NeurIPS 2022 · arXiv 2205.14135. *(Xem file riêng FlashAttention.md.)*
- **Ý tưởng key:** attention **chính xác, nhận biết IO** — **tiling** vào SRAM + **online softmax** để không ghi trọn ma trận N×N ra HBM + **recomputation** ở backward. Số đã xác minh: 3× GPT-2 (seq 1K), 2.4× LRA, mở khóa ngữ cảnh 64K (Path-256 63.1%).
- **Nguyên lý để đời:** *tối ưu IO (đọc/ghi bộ nhớ), không phải đếm FLOPs.* FA-2 và FA-3 đều kế thừa và mở rộng nguyên lý này lên các trục mới (song song → bất đồng bộ/FP8).

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Attention là nút thắt của LLM và tác vụ ngữ cảnh dài/diffusion. FlashAttention(-2) đã tối thiểu hóa IO bộ nhớ nhưng **chưa khai thác phần cứng Hopper (H100) mới** — FA-2 chỉ đạt **35% utilization** trên H100. Mục tiêu FA-3: thiết kế lại attention chính xác quanh các đơn vị **bất đồng bộ** của Hopper và hỗ trợ **FP8** để lấp khoảng trống đó, vẫn giữ chính xác.

## 2. Nội dung chính từng phần
**Chẩn đoán.** Trên H100, giới hạn không chỉ còn là lưu lượng HBM mà là **giữ Tensor Core luôn bận** trong khi softmax chậm chạy, và dùng FP8 mà không phá độ chính xác. Lịch đồng bộ của FA-2 để Tensor Core rảnh.

**Ba kỹ thuật.**
1. **Bất đồng bộ qua warp-specialization:** chia warp thành **producer** (di chuyển dữ liệu bằng TMA) và **consumer** (tính toán) → chồng lấp di chuyển dữ liệu với việc chạy Tensor Core, giấu độ trễ.
2. **Xen kẽ matmul & softmax (pipeline ping-pong):** trong khi một warpgroup tính softmax trên một khối điểm, warpgroup khác chạy matmul **WGMMA** (async) trên khối kế; luân phiên vai qua barrier. (HTML: nâng FP16 fwd head-dim 128 từ ~570 → 620–640 TFLOPS.)
3. **FP8 đúng cách:** **block quantization** (một scale mỗi khối, không per-tensor) + **incoherent processing** (nhân Q,K với ma trận trực giao ngẫu nhiên để "trải" outlier trước khi lượng tử), giảm sai số FP8; kèm biến đổi layout trong kernel cho khớp yêu cầu WGMMA.

## 3. Các kết luận quan trọng
- Thiết kế lại attention quanh **bất đồng bộ phần cứng** mở khóa H100: 75% utilization FP16 so với 35% của FA-2.
- **Attention FP8 vừa nhanh vừa chính xác** nếu xử lý outlier (block quant + incoherent processing) — sai số thấp hơn 2.6× so FP8 ngây thơ.
- Cả FP16 (chính xác) lẫn FP8 (gần chính xác) đều hưởng lợi — nhánh FP16 không đánh đổi chất lượng.

## 4. Số liệu nổi bật & việc cần làm
**Đã xác minh (abstract):** tăng tốc 1.5–2.0×; **FP16 740 TFLOPs/s (75% util H100)**; **FP8 ~1.2 PFLOPs/s**; **sai số FP8 thấp hơn 2.6×**; FA-2 = 35% util trên H100.
**Từ HTML (tham khảo):** ping-pong 570→620–640 TFLOPS (FP16 fwd, head-dim 128); backward nhanh 1.5–1.75×.
**Hạn chế / việc cần làm:** đặc thù Hopper (TMA/WGMMA/FP8) — không chuyển sang GPU cũ; nhánh FP8 gần-chính-xác chứ không bit-exact; kernel gắn chặt phần cứng.

## 5. Tóm tắt ngắn (< 300 từ)
FlashAttention-3 xây lại attention chính xác cho GPU Hopper (H100), nơi FlashAttention-2 bỏ phí phần lớn chip (chỉ 35% utilization). Trên GPU hiện đại, vấn đề không còn chỉ là lưu lượng bộ nhớ mà là giữ Tensor Core cực nhanh luôn bận trong khi softmax chậm chạy, và dùng độ chính xác 8-bit (FP8) mà không phá chất lượng. FA-3 dùng ba mẹo. (1) **Bất đồng bộ qua warp-specialization:** một số warp thành "producer" chuyển dữ liệu bằng engine TMA của Hopper, số khác là "consumer" tính toán, nên di chuyển dữ liệu và tính toán chồng lấp, giấu độ trễ lẫn nhau. (2) **Pipeline ping-pong:** xen kẽ matmul (WGMMA async trên Tensor Core) với softmax trên các warpgroup riêng, nên khi softmax khối này chạy thì matmul khối kế đã bắt đầu. (3) **FP8 chính xác:** thay vì một scale mỗi tensor, dùng **block quantization** (một scale mỗi tile) cộng **incoherent processing** (nhân Q,K với ma trận trực giao ngẫu nhiên để trải outlier trước khi lượng tử), cắt sai số FP8. Kết quả đã xác minh: **nhanh 1.5–2.0× so FA-2**, FP16 đạt **740 TFLOPs/s (75% utilization)**, FP8 tiến gần **1.2 PFLOPs/s**, và sai số số học FP8 **thấp hơn 2.6×** so baseline. Điểm hạn chế: mọi thứ gắn với tính năng riêng của Hopper (TMA, WGMMA, FP8) nên lợi ích không sang GPU cũ. FA-3 là **enabler tầng kernel** — tăng tốc mọi Transformer/DiT dùng attention mà không đổi model; cách xử lý FP8 của nó (block quant + incoherent processing) rất gần tư duy quản outlier trong quantization diffusion như SVDQuant.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈45w):** On H100, FlashAttention-2 wasted 65% of the chip. FlashAttention-3 exploits Hopper's asynchrony — producer/consumer warps and ping-pong matmul/softmax pipelining — plus accurate FP8 via block quantization and incoherent processing: 1.5–2× faster, 75% FP16 utilization, ~1.2 PFLOPs/s FP8.

**VI (≈47 từ):** Trên H100, FlashAttention-2 bỏ phí 65% chip. FlashAttention-3 khai thác tính bất đồng bộ của Hopper — warp producer/consumer và pipeline ping-pong matmul/softmax — cộng FP8 chính xác nhờ lượng tử theo khối và incoherent processing: nhanh 1.5–2×, đạt 75% utilization FP16, ~1.2 PFLOPs/s ở FP8.

## 7. Bản chất nói nôm na
**Vấn đề, nói mộc:** GPU mới như một gian bếp siêu nhanh, nhưng công thức attention cũ để "đầu bếp ngôi sao" (Tensor Core) đứng chơi 2/3 thời gian, chờ khâu sơ chế.

**Ý tưởng cốt lõi:** Chia đội để luôn có người tiếp nguyên liệu trong khi đầu bếp nấu liên tục, và cho trạm này thái trong khi trạm kia bày đĩa — không ai phải chờ.

**Ẩn dụ đời thường — dây chuyền bếp vận hành khéo:** Thay vì một người làm tuần tự lấy–thái–nấu–bày (đầy khoảng chờ), bạn phân người chạy tiếp liệu (producer) và người nấu (consumer), và luân phiên trạm để khi món này đang rim sốt thì món kia đã áp chảo. Lại còn biết dùng nguyên liệu rẻ hơn (FP8) mà không hỏng vị nhờ sơ chế khéo.

**Câu để đời:** Nhanh nhờ **không bao giờ để phần cứng nhanh phải chờ** — chồng lấp mọi thứ, và làm 8-bit đủ chính xác để tin dùng.
