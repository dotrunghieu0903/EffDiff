# SVDQuant: Absorbing Outliers by Low-Rank Components for 4-Bit Diffusion Models

**Authors:** Muyang Li, Yujun Lin, Zhekai Zhang, Tianle Cai, Xiuyu Li, Junxian Guo, Enze Xie, Chenlin Meng, Jun-Yan Zhu, Song Han (MIT / NVIDIA and collaborators)
**Venue:** ICLR 2025 (Spotlight) · arXiv:2411.05007 · submitted Nov 7 2024, last revised Nov 8 2025
**Source:** https://arxiv.org/abs/2411.05007

> Note on numbers: the abstract page loaded cleanly, but the full PDF exceeded the fetch size limit, so section details came from the arXiv HTML render via a small model. Figures are marked as **verified** (cross-checked against the abstract) or **unverified** (from the HTML table render, not independently confirmed).

---

# English version

## 1. Purpose of the document

The paper tackles a deployment problem: modern diffusion models (up to FLUX.1's 12B parameters) are expensive in memory and slow at inference. Its goal is to push **both weights and activations down to 4 bits** — a much more aggressive target than the weight-only quantization common for LLMs — because diffusion models are *compute-bound even at batch size 1*, so you only get real speedups if activations are quantized too. The core idea is a way to survive 4-bit precision without destroying image quality, plus an inference engine that actually realizes the theoretical speedup on hardware.

## 2. Main content, section by section

**Motivation & problem formulation.** Diffusion models scale their compute faster than LLMs, so weight-only quantization is insufficient. At 4-bit, both weights and activations become highly sensitive to *outliers*. The authors decompose quantization error into four terms (magnitude + quantization error, for weights and activations) and aim to minimize all four.

**SVDQuant method — the two-step trick:**
- *Step 1 — Smoothing (migrate activation outliers to weights):* scale the input by a per-channel factor λ. This flattens activation outliers but pushes them into the weights, which is only a partial win.
- *Step 2 — Low-rank absorption via SVD:* instead of quantizing the smoothed weight Ŵ directly, decompose it as **Ŵ = L₁L₂ + R** using truncated SVD (rank r, typically 16 or 32). The **low-rank branch (L₁L₂) runs at 16-bit** and soaks up the large singular values / outliers; only the well-behaved **residual R is quantized to 4-bit**. Because the first ~32 singular values drop steeply, the residual becomes far easier to quantize. The forward pass is `X·W ≈ (X̂·L₁L₂)[16-bit] + Q(X̂)·Q(R)[4-bit]`.

**Nunchaku inference engine.** Running the extra 16-bit low-rank branch naively adds ~57% latency from redundant memory movement. Nunchaku **fuses kernels** — the down-projection shares input with the quantize kernel, the up-projection shares output with the 4-bit compute kernel — cutting the low-rank overhead to just ~5–10%, "nearly free." It also lets off-the-shelf LoRA adapters be fused into the low-rank branch **without re-quantization**.

**Experiments.** Evaluated on FLUX.1 (12B), PixArt-Σ, SANA, SDXL, SDXL-Turbo. Prompts from MJHQ-30K and sDCI; calibration on COCO Captions. Baselines: NF4 (weight-only W4A16), ViDiT-Q, MixDQ, TensorRT. Metrics: FID, Image Reward, LPIPS, PSNR.

## 3. Key conclusions

- 4-bit post-training quantization of *both* weights and activations is feasible for diffusion models if outliers are absorbed by a high-precision low-rank branch.
- The quality-limiting factor is residual magnitude ‖R‖_F; SVD provably minimizes it, and smoothing + SVD together beat either alone.
- Prior methods (ViDiT-Q, MixDQ) collapse at W4A4; SVDQuant stays close to the full-precision model.
- Kernel fusion (Nunchaku) is essential — without it the low-rank branch would erase the speedup.

## 4. Notable figures & to-dos

**Verified against the abstract:**
- **~3.5× memory reduction** for the 12B FLUX.1 model.
- **~3.0× speedup** over the 4-bit weight-only (NF4) baseline on a 16 GB laptop RTX 4090, and **~10.1× vs. the original 16-bit model** (by removing CPU offloading).

**Unverified (from HTML table render — treat as indicative):**
- FLUX.1-dev, MJHQ: BF16 FID 20.3 / IR 0.953 → INT W4A4 FID 19.9 / IR 0.935; NVFP4 FID 20.4 / IR 0.937.
- PixArt-Σ W4A4: SVDQuant NVFP FID 16.6 / IR 0.940 vs. ViDiT-Q FID 412 / IR −2.27 (baseline failure).
- SDXL-Turbo W4A4: SVDQuant FID 24.6 vs. MixDQ FID 353 (baseline failure).
- Model size 22.2 → 6.1 GiB (~3.6×); NVFP4 3.1× on RTX 5090; naive low-rank branch ~57% overhead → ~5–10% fused.
- Ablation (PixArt-Σ): SVDQuant+smoothing IR 0.878 vs. FP16 0.944.

**Limitations / to-dos:** fails below ~3-bit (2-bit ≈ ternary, needs QAT); more quality loss on compact models (PixArt-Σ, SDXL) than on large DiTs; requires offline calibration and per-layer tuning; hardware support is NVIDIA-centric (INT4 on 4090, NVFP4 on Blackwell/5090). Implied future work: quantization-aware training for sub-3-bit, broader hardware support.

## 5. Quick recap (< 300 words)

SVDQuant is a post-training quantization method that compresses diffusion models to **4-bit weights *and* activations (W4A4)** — necessary because diffusion models, unlike LLMs, are compute-bound even at batch 1, so quantizing weights alone yields no real speedup. The obstacle at 4-bit is **outliers** in both weights and activations. SVDQuant handles them in two steps: (1) *smoothing* shifts activation outliers into the weights, then (2) an **SVD low-rank branch** decomposes the smoothed weight into a rank-16/32 component (kept at 16-bit, which absorbs the large singular values and outliers) plus a residual that is now smooth enough to quantize to 4-bit. Mathematically, minimizing the residual magnitude bounds the quantization error, and SVD is the optimal way to do this.

Running the extra 16-bit branch would normally add ~57% latency, so the authors built **Nunchaku**, an inference engine that fuses the low-rank kernels with the quantization/4-bit compute kernels, dropping overhead to ~5–10% and making the branch nearly free. Nunchaku also fuses LoRA adapters directly, so styles can be swapped without re-quantizing.

Across FLUX.1 (12B), PixArt-Σ, SANA, and SDXL, SVDQuant preserves image quality close to full precision while competing methods (ViDiT-Q, MixDQ) collapse at W4A4. The verified headline results: **~3.5× memory reduction** on the 12B FLUX.1, **~3.0× speedup** over the 4-bit weight-only baseline on a 16 GB laptop 4090, and up to **~10.1×** versus the 16-bit model by eliminating CPU offloading. Limitations: it breaks down below ~3-bit (needs quantization-aware training), shows more degradation on smaller models, and depends on offline calibration and NVIDIA-specific kernels.

## 6. Conference one-breath pitch (30–50 words)

**EN (≈45w):** SVDQuant runs diffusion models at 4-bit weights *and* activations. Instead of shuffling outliers around by smoothing, it absorbs them into a high-precision low-rank branch and quantizes only the easy residual, then fuses that branch into the kernel (Nunchaku). Near-BF16 quality, ~3.5× less memory, ~3× faster.

**VI (≈48 từ):** SVDQuant chạy mô hình diffusion ở 4-bit cho *cả* trọng số lẫn activation. Thay vì "đẩy qua đẩy lại" outlier bằng smoothing, nó hút outlier vào một nhánh low-rank độ chính xác cao rồi chỉ lượng tử phần dư dễ, sau đó fuse nhánh đó vào kernel (Nunchaku). Chất lượng gần BF16, giảm ~3.5× bộ nhớ, nhanh ~3×.

## 7. The essence in plain language

**The problem, plainly:** A giant image-generating model is heavy and slow. You want to "compress" every number in it from a detailed form (16-bit) down to a crude form (4-bit) to make it ~3–4× lighter and faster. But a few numbers are freakishly large "outliers" — squeeze everything to 4-bit and those outliers stretch the scale so the ordinary numbers get rounded sloppily, wrecking the image.

**Core idea (one sentence):** Set the few troublemaker numbers aside in a small high-precision notebook, so everything that's left is tame enough to crush down to 4-bit safely.

**Everyday analogy — packing a suitcase:** You want to vacuum-pack your whole wardrobe (4-bit), but a few bulky items stop the lid from closing. SVDQuant puts those few bulky items in a small carry-on kept intact (the 16-bit low-rank branch) and vacuum-packs the soft clothes into the suitcase (4-bit). You still travel light, nothing important gets crushed, and the little carry-on is so small it barely costs extra space — the Nunchaku engine is the trick that lets you carry it "for free" without slowing down.

**If you remember only one thing:** SVDQuant shrinks an image model to 4-bit without ruining quality by *stashing the outliers in a tiny precise branch first, then crushing the rest* — giving ~3× faster, ~3.5× lighter, even on a laptop.

---

# Phiên bản Tiếng Việt

> Lưu ý về số liệu: trang abstract tải được đầy đủ, nhưng file PDF vượt quá giới hạn dung lượng nên chi tiết từng phần được lấy từ bản HTML trên arXiv qua một mô hình nhỏ. Các con số được đánh dấu **đã xác minh** (đối chiếu với abstract) hoặc **chưa xác minh** (lấy từ bảng render HTML, chưa kiểm chứng độc lập).

## 1. Mục đích của tài liệu

Bài báo giải quyết một bài toán triển khai: các mô hình diffusion hiện đại (lên tới 12 tỷ tham số như FLUX.1) tốn nhiều bộ nhớ và chậm khi suy luận. Mục tiêu là ép **cả trọng số (weights) lẫn kích hoạt (activations) xuống 4-bit** — mục tiêu quyết liệt hơn nhiều so với quantization chỉ-trọng-số vốn phổ biến ở LLM — bởi vì mô hình diffusion *bị giới hạn bởi tính toán ngay cả khi batch size = 1*, nên chỉ khi lượng tử hóa cả activations mới có tăng tốc thực sự. Ý tưởng cốt lõi là cách sống sót ở độ chính xác 4-bit mà không phá hỏng chất lượng ảnh, kèm một engine suy luận thực sự hiện thực hóa mức tăng tốc lý thuyết trên phần cứng.

## 2. Nội dung chính từng phần

**Động lực & phát biểu bài toán.** Mô hình diffusion tăng nhu cầu tính toán nhanh hơn LLM, nên lượng tử hóa chỉ-trọng-số là không đủ. Ở 4-bit, cả weights và activations đều rất nhạy với *giá trị ngoại lai (outliers)*. Nhóm tác giả phân rã sai số lượng tử hóa thành bốn thành phần (sai số độ lớn + sai số lượng tử hóa, cho cả weights và activations) và tìm cách tối thiểu hóa cả bốn.

**Phương pháp SVDQuant — mẹo hai bước:**
- *Bước 1 — Smoothing (dời outlier từ activation sang weight):* nhân đầu vào với hệ số λ theo từng kênh. Cách này làm phẳng outlier ở activation nhưng lại đẩy chúng sang weight, nên chỉ thắng một nửa.
- *Bước 2 — Hấp thụ outlier bằng nhánh hạng thấp qua SVD:* thay vì lượng tử hóa trực tiếp weight đã làm mượt Ŵ, ta phân rã **Ŵ = L₁L₂ + R** bằng SVD cắt gọn (hạng r, thường là 16 hoặc 32). **Nhánh hạng thấp (L₁L₂) chạy ở 16-bit** và hút hết các singular value lớn / outlier; chỉ **phần dư R (đã "hiền") mới bị lượng tử hóa xuống 4-bit**. Vì ~32 singular value đầu tiên giảm rất dốc, phần dư trở nên dễ lượng tử hóa hơn nhiều. Phép tính xuôi: `X·W ≈ (X̂·L₁L₂)[16-bit] + Q(X̂)·Q(R)[4-bit]`.

**Engine suy luận Nunchaku.** Nếu chạy nhánh 16-bit hạng thấp một cách ngây thơ sẽ thêm ~57% độ trễ vì di chuyển bộ nhớ dư thừa. Nunchaku **hợp nhất kernel (kernel fusion)** — down-projection dùng chung đầu vào với kernel lượng tử hóa, up-projection dùng chung đầu ra với kernel tính toán 4-bit — kéo chi phí phụ của nhánh hạng thấp xuống chỉ ~5–10%, "gần như miễn phí". Nó cũng cho phép nhét thẳng các adapter LoRA có sẵn vào nhánh hạng thấp **mà không cần lượng tử hóa lại**.

**Thí nghiệm.** Đánh giá trên FLUX.1 (12B), PixArt-Σ, SANA, SDXL, SDXL-Turbo. Prompt lấy từ MJHQ-30K và sDCI; hiệu chuẩn (calibration) trên COCO Captions. Baseline: NF4 (chỉ-trọng-số W4A16), ViDiT-Q, MixDQ, TensorRT. Chỉ số: FID, Image Reward, LPIPS, PSNR.

## 3. Các kết luận quan trọng

- Lượng tử hóa hậu-huấn-luyện 4-bit cho *cả* weights lẫn activations là khả thi với mô hình diffusion, nếu outlier được hấp thụ bởi một nhánh hạng thấp độ chính xác cao.
- Yếu tố giới hạn chất lượng là độ lớn phần dư ‖R‖_F; SVD tối thiểu hóa nó một cách tối ưu, và smoothing + SVD kết hợp tốt hơn dùng riêng lẻ.
- Các phương pháp trước (ViDiT-Q, MixDQ) sụp đổ ở W4A4; SVDQuant vẫn bám sát mô hình full-precision.
- Kernel fusion (Nunchaku) là thiết yếu — thiếu nó, nhánh hạng thấp sẽ xóa sạch phần tăng tốc.

## 4. Số liệu nổi bật & những việc cần làm

**Đã xác minh (đối chiếu abstract):**
- **Giảm ~3.5× bộ nhớ** cho mô hình FLUX.1 12B.
- **Tăng tốc ~3.0×** so với baseline chỉ-trọng-số 4-bit (NF4) trên laptop RTX 4090 16 GB, và **~10.1× so với mô hình gốc 16-bit** (nhờ loại bỏ việc offload sang CPU).

**Chưa xác minh (lấy từ bảng render HTML — chỉ mang tính tham khảo):**
- FLUX.1-dev, MJHQ: BF16 FID 20.3 / IR 0.953 → INT W4A4 FID 19.9 / IR 0.935; NVFP4 FID 20.4 / IR 0.937.
- PixArt-Σ W4A4: SVDQuant NVFP FID 16.6 / IR 0.940 so với ViDiT-Q FID 412 / IR −2.27 (baseline thất bại).
- SDXL-Turbo W4A4: SVDQuant FID 24.6 so với MixDQ FID 353 (baseline thất bại).
- Kích thước mô hình 22.2 → 6.1 GiB (~3.6×); NVFP4 3.1× trên RTX 5090; nhánh hạng thấp ngây thơ ~57% chi phí phụ → ~5–10% sau khi fuse.
- Ablation (PixArt-Σ): SVDQuant+smoothing IR 0.878 so với FP16 0.944.

**Hạn chế / việc cần làm:** thất bại dưới ~3-bit (2-bit ≈ lượng tử hóa tam phân, cần QAT); mất chất lượng nhiều hơn trên mô hình nhỏ gọn (PixArt-Σ, SDXL) so với các DiT lớn; cần hiệu chuẩn offline và tinh chỉnh siêu tham số theo từng lớp; hỗ trợ phần cứng thiên về NVIDIA (INT4 trên 4090, NVFP4 trên Blackwell/5090). Hướng tương lai ngụ ý: huấn luyện có nhận thức lượng tử hóa (QAT) cho dưới 3-bit, mở rộng hỗ trợ phần cứng.

## 5. Tóm tắt ngắn (< 300 từ)

SVDQuant là phương pháp lượng tử hóa hậu-huấn-luyện nén mô hình diffusion xuống **4-bit cho cả weights *lẫn* activations (W4A4)** — cần thiết vì mô hình diffusion, khác với LLM, bị giới hạn tính toán ngay cả ở batch 1, nên chỉ lượng tử hóa weights sẽ không mang lại tăng tốc thực sự. Trở ngại ở 4-bit là **outlier** trong cả weights và activations. SVDQuant xử lý bằng hai bước: (1) *smoothing* dời outlier của activation sang weight, rồi (2) một **nhánh hạng thấp qua SVD** phân rã weight đã làm mượt thành thành phần hạng 16/32 (giữ ở 16-bit, hút hết singular value lớn và outlier) cộng với phần dư giờ đã đủ "mượt" để lượng tử hóa xuống 4-bit. Về mặt toán học, tối thiểu hóa độ lớn phần dư sẽ chặn trên sai số lượng tử hóa, và SVD là cách tối ưu để làm điều đó.

Chạy nhánh 16-bit phụ này thông thường sẽ thêm ~57% độ trễ, nên nhóm tác giả xây dựng **Nunchaku**, một engine suy luận hợp nhất các kernel hạng thấp với kernel lượng tử hóa / tính toán 4-bit, giảm chi phí phụ xuống ~5–10% khiến nhánh này gần như miễn phí. Nunchaku còn nhét thẳng adapter LoRA, cho phép đổi phong cách mà không phải lượng tử hóa lại.

Trên FLUX.1 (12B), PixArt-Σ, SANA và SDXL, SVDQuant giữ chất lượng ảnh gần với full-precision trong khi các phương pháp cạnh tranh (ViDiT-Q, MixDQ) sụp đổ ở W4A4. Kết quả nổi bật đã xác minh: **giảm ~3.5× bộ nhớ** trên FLUX.1 12B, **tăng tốc ~3.0×** so với baseline chỉ-trọng-số 4-bit trên laptop 4090 16 GB, và tới **~10.1×** so với mô hình 16-bit nhờ loại bỏ offload CPU. Hạn chế: sụp đổ dưới ~3-bit (cần QAT), suy giảm nhiều hơn trên mô hình nhỏ, và phụ thuộc vào hiệu chuẩn offline cùng kernel riêng cho NVIDIA.

## 6. Câu chốt hội nghị (30–50 từ)

**EN (≈45w):** SVDQuant runs diffusion models at 4-bit weights *and* activations. Instead of shuffling outliers around by smoothing, it absorbs them into a high-precision low-rank branch and quantizes only the easy residual, then fuses that branch into the kernel (Nunchaku). Near-BF16 quality, ~3.5× less memory, ~3× faster.

**VI (≈48 từ):** SVDQuant chạy mô hình diffusion ở 4-bit cho *cả* trọng số lẫn activation. Thay vì "đẩy qua đẩy lại" outlier bằng smoothing, nó hút outlier vào một nhánh low-rank độ chính xác cao rồi chỉ lượng tử phần dư dễ, sau đó fuse nhánh đó vào kernel (Nunchaku). Chất lượng gần BF16, giảm ~3.5× bộ nhớ, nhanh ~3×.

## 7. Bản chất nói nôm na

**Vấn đề, nói mộc:** Một mô hình vẽ ảnh khổng lồ thì nặng và chậm. Bạn muốn "nén" mỗi con số trong nó từ dạng chi tiết (16-bit) xuống dạng thô (4-bit) để nhẹ và nhanh hơn ~3–4 lần. Nhưng vài con số lớn bất thường — "outlier" — khi ép hết xuống 4-bit sẽ kéo giãn thang đo, khiến các số bình thường bị làm tròn ẩu → ảnh hỏng.

**Ý tưởng cốt lõi (một câu):** Để riêng mấy con số "quậy" ra một cuốn sổ nhỏ ghi thật chính xác, để phần còn lại toàn số hiền lành thì mới nén thô xuống 4-bit an toàn.

**Ẩn dụ đời thường — xếp vali:** Bạn muốn nhồi cả tủ đồ vào vali nén chân không (4-bit), nhưng vài món cồng kềnh làm không đóng nổi nắp. SVDQuant bỏ mấy món cồng kềnh đó vào **một túi xách tay nhỏ giữ nguyên** (nhánh hạng thấp 16-bit) và **nén thoải mái** phần quần áo mềm vào vali (4-bit). Vẫn gọn nhẹ, không móp món quan trọng, mà cái túi nhỏ ấy bé đến mức gần như không tốn thêm chỗ — engine Nunchaku chính là mẹo giúp "mang thêm túi mà không chậm đi".

**Nếu chỉ nhớ một điều:** SVDQuant nén mô hình vẽ ảnh xuống 4-bit mà không hỏng chất lượng bằng cách *cất riêng outlier vào một nhánh nhỏ chính xác trước, rồi mới nén mạnh phần còn lại* — nhờ đó nhanh hơn ~3 lần, nhẹ hơn ~3,5 lần, chạy được cả trên laptop.
