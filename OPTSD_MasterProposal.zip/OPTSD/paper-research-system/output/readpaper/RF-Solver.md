# Ghi chú xác minh (verification note)

- Nguồn đã fetch trực tiếp ngày **18/07/2026**:
  - `https://arxiv.org/abs/2411.04746` (trang abstract, 2 lần fetch — khớp tiêu đề, tác giả, lịch sử version).
  - `https://arxiv.org/html/2411.04746v3` (bản HTML đầy đủ — method, công thức, bảng kết quả, ablation).
- **arXiv ID:** 2411.04746 — nộp lần đầu **07/11/2024**, v2 **28/11/2024**, v3 **13/06/2025**. Trong mốc kiến thức 01/2026, không cần cảnh báo "đọc lại".
- **Venue xác nhận:** **ICML 2025** (được accept — v3 gắn với vòng camera-ready). SURVEY.md trước đó ghi "arXiv" — cần cập nhật venue thành ICML 2025.
- **Tác giả (khớp trang abs):** Jiangshan Wang, Junfu Pu, Zhongang Qi, Jiayi Guo, Yue Ma, Nisha Huang, Yuxin Chen, Xiu Li, Ying Shan.
- Toàn bộ số liệu trong các bảng dưới đây được đọc trực tiếp từ bản HTML v3 (mục "Notable figures" tách rõ số đã xác minh / số chưa xác minh — KHÔNG có số liệu latency/wall-clock/GPU nào được tìm thấy trong phần đã fetch, nên các số đó được đánh dấu "chưa xác minh").

---

# English version

## 1. Purpose

Rectified-flow (RF) diffusion transformers such as FLUX and OpenSora generate high-quality images/videos but are inaccurate when **inverted** (mapped back from data to noise) with the vanilla first-order Euler ODE solver — the reconstruction drifts away from the source. This inversion error then poisons any downstream editing pipeline that relies on inversion (structure-preserving edits). The paper's purpose is to fix the *numerical* root cause: derive the exact rectified-flow ODE solution and approximate its nonlinear (network) term with a higher-order Taylor expansion, producing **RF-Solver**, a training-free sampler with strictly lower per-step error than Euler/Heun. On top of that accurate sampler, the authors build **RF-Edit**, a feature-sharing framework that reuses inverted self-attention value features during denoising to preserve source structure while following a new edit prompt — all without any fine-tuning, applicable to any pretrained RF backbone.

## 2. Section-by-section

- **Motivation/analysis:** Shows empirically that vanilla RF inversion accumulates MSE across timesteps (their Figure 2) because Euler-style solving only captures the zeroth-order term of the velocity field.
- **RF-Solver method:** Starts from the exact integral form of the RF ODE (variation-of-constants), then Taylor-expands the velocity network v_θ around each timestep: v_θ(Z_τ,τ) = Σ_{k=0}^{n-1} (τ-t_i)^k/k! · v_θ^(k)(Z_{t_i},t_i) + O((τ-t_i)^n). Integrating analytically gives an n-th order step update; the practical instantiation uses **n=2**:
  Z_{t_{i-1}} = Z_{t_i} + (t_{i-1}-t_i)·v_θ(Z_{t_i},t_i) + ½(t_{i-1}-t_i)²·v_θ^(1)(Z_{t_i},t_i).
  Since the analytic derivative v_θ^(1) is unavailable, it is estimated by a **finite difference** with a small forward step Δt=0.01: v_θ^(1) ≈ (v̂_{t_i+Δt} − v̂_{t_i})/Δt. This lowers the per-step local error from O(h²) (Euler) to O(h³) (2nd-order), at the cost of one extra forward pass per timestep.
- **RF-Edit method:** During inversion, stores self-attention **value** features from the last M transformer blocks at the final n timesteps; during denoising these values replace the original ones (turning self-attention into a form of cross-attention against the stored values), preserving source structure. Applied to FLUX's single-stream blocks (image) and OpenSora's spatial-attention modules (video). Default feature-sharing horizon = 5 steps.
- **Experiments:** Four task families — (i) plain text-to-image generation (COCO-30K, FID/CLIP), (ii) inversion/reconstruction (image and video, MSE/LPIPS/SSIM/PSNR), (iii) image editing (LPIPS/CLIP vs. P2P, DiffEdit, SDEdit, PnP, Pix2Pix, RF-Inversion), (iv) video editing (VBench: Semantic Consistency, Motion Smoothness, Appearance Quality, Image Quality vs. FateZero, FLATTEN, COVE, RAVE, Tokenflow). Backbones: FLUX (guidance-distilled), OpenSora, HunyuanVideo. Fairness protocol: vanilla RF is given **2× the timesteps** of RF-Solver so both sides use the same NFE budget.
- **Ablation:** Taylor order n=1 (vanilla RF) vs n=2 (RF-Solver) vs n=3, under a fixed NFE budget. n=2 is the sweet spot — n=3 needs more evaluations per step, which under a fixed total budget forces fewer steps overall and *degrades* quality. Feature-sharing horizon ablation: too few steps (<5) under-preserves structure; too many steps makes edits collapse back toward the source, hurting editability.
- **Conclusion:** RF-Solver reduces ODE-solving error and improves generation/inversion quality; RF-Edit built on it delivers structure-preserving, training-free editing that is compatible with any pretrained RF model.

## 3. Key conclusions

1. Treating the RF ODE's nonlinear network term with a 2nd-order Taylor expansion (rather than 1st-order Euler) is enough to markedly cut inversion/reconstruction error, with only one extra forward pass per step.
2. This numerical fix, stacked with a self-attention value-sharing trick (RF-Edit), yields consistent gains over strong published baselines across image and video editing, without any training or per-task fine-tuning.
3. Under a *fixed* total-NFE comparison, RF-Solver still wins — the improvement is not simply "spend more compute," it is a genuine accuracy-per-compute gain (at least on the metrics/tasks tested).

## 4. Notable figures & to-dos

**Verified (read directly from arXiv HTML v3, fetched 18/07/2026):**
- COCO-30K text-to-image: FID 23.98 / CLIP 31.09 (RF-Solver) vs. FID 25.33 / CLIP 31.01 (vanilla RF), vs. DPMSolver++ FID 24.63 / CLIP 30.62.
- Image inversion: MSE 0.0092, LPIPS 0.4239, SSIM 0.9276, PSNR 29.89 (RF-Solver) vs. vanilla RF MSE 0.0268, LPIPS 0.6253, SSIM 0.7626, PSNR 28.28.
- Video inversion: MSE 0.0134, LPIPS 0.3287, SSIM 0.8812, PSNR 18.41 (RF-Solver) vs. vanilla RF MSE 0.0206, LPIPS 0.4159, SSIM 0.8134, PSNR 18.12.
- Image editing: LPIPS 0.149 / CLIP 33.66 (RF-Edit) vs. RF-Inversion baseline LPIPS 0.318 / CLIP 33.02; vs. PnP LPIPS 0.080 / CLIP 30.58 (PnP wins on LPIPS but loses on CLIP — RF-Edit is not uniformly best on every metric).
- Video editing (VBench): SC 0.9501, MS 0.9712, AQ 0.6796, IQ 0.7207 (ours) vs. best baseline Tokenflow SC 0.9439, MS 0.9632, AQ 0.6742, IQ 0.7128.
- Ablation: n=1→n=2 cuts sampling FID 25.33→23.98 and inversion MSE 0.0268→0.0092; n=3 (0.0131 MSE) is worse than n=2 (0.0092) under fixed NFE.
- Fixed hyperparameters: Δt=0.01 for finite-difference derivative; default feature-sharing horizon = 5 steps.

**NOT verified in the sources fetched (need to check the full PDF/appendix before citing):**
- Any wall-clock latency, throughput, or GPU-hardware numbers — none appeared in the abstract or the HTML sections retrieved.
- Exact parameter counts of FLUX/OpenSora/HunyuanVideo as used in this paper.
- Whether an explicit "Limitations" section exists (none was found in the fetched HTML; only implicit constraints were inferred from method text).
- Direct head-to-head numbers against FireFlow (2412.07517) — that paper postdates RF-Solver and no comparison table between the two was located.

## 5. Quick recap (<300 words)

Rectified-flow generators like FLUX are fast to sample from but hard to invert precisely: running the flow "backwards" with a plain Euler step accumulates error, so reconstructed images/videos drift from the source — a problem for any editing method that needs faithful inversion first. RF-Solver fixes this at the numerics level. It writes the exact integral solution of the rectified-flow ODE, then approximates the network's nonlinear velocity term with a second-order Taylor expansion instead of the usual zeroth/first-order treatment, using one extra forward pass to estimate the needed derivative via finite differences. This provably shrinks the local error per step from O(h²) to O(h³). On top of this more accurate sampler, RF-Edit reuses the self-attention "value" features recorded during inversion and re-injects them during denoising, which anchors the edited output to the source's structure while letting a new prompt drive content changes. Both components are training-free and drop into any pretrained rectified-flow backbone — FLUX and HunyuanVideo for images/video editing, OpenSora for video. Across text-to-image generation, image/video inversion, and image/video editing benchmarks, the method beats vanilla RF, Heun-style RF, and several strong published editing baselines (P2P, DiffEdit, PnP, RF-Inversion, Tokenflow, etc.), and it still wins when the baselines are given twice the sampling steps to match total compute. Ablations show second order is the sweet spot: third order needs an extra evaluation per step that, under a fixed compute budget, forces fewer total steps and hurts quality; the feature-sharing horizon (default 5 steps) trades off structure preservation against actual editability. Accepted at ICML 2025, the method has already become a reference baseline for later fast RF-inversion work such as FireFlow.

## 6. Conference pitch (30–50 words)

**EN:** "Euler-stepping a rectified-flow ODE backward accumulates error and breaks inversion. RF-Solver Taylor-expands the network's velocity term to second order — one extra forward pass buys a provably tighter ODE solution, and the resulting accurate inversion powers training-free, structure-preserving image and video editing on FLUX and OpenSora."

**VI:** "Đảo ngược ODE rectified-flow bằng Euler tích lũy lỗi, làm hỏng việc invert ảnh/video. RF-Solver khai triển Taylor bậc hai cho số hạng vận tốc phi tuyến — thêm một lần forward để đổi lấy nghiệm ODE chính xác hơn hẳn, từ đó cho phép chỉnh sửa ảnh/video giữ đúng cấu trúc nguồn, không cần huấn luyện, trên FLUX và OpenSora."

## 7. Essence (plain language)

Think of following a curving path using only the direction you're facing right now (Euler) — you'll drift off the path the longer you walk. RF-Solver instead peeks slightly ahead, measures how much the direction is *changing*, and bakes that curvature into each step — so it hugs the true path much more closely, using barely any extra effort (one quick peek per step). Because the "walk backward" (inversion) is now accurate, the paper can also record what the model was "paying attention to" on the way back and hand that back to it on the way forward, so an edit changes what you asked for but keeps everything else looking like the original.

---

# Phiên bản Tiếng Việt

## 1. Mục đích

Các mô hình diffusion transformer kiểu rectified-flow (RF) như FLUX, OpenSora sinh ảnh/video chất lượng cao nhưng khi **inversion** (đảo từ ảnh gốc ngược về noise) bằng solver Euler bậc một thông thường thì kết quả tái tạo bị trôi lệch khỏi ảnh gốc. Lỗi inversion này lan sang mọi pipeline editing dựa vào inversion để giữ cấu trúc. Mục đích của bài là sửa tận gốc vấn đề *số học*: viết nghiệm tích phân chính xác của ODE rectified-flow, rồi xấp xỉ số hạng phi tuyến (mạng nơ-ron) bằng khai triển Taylor bậc cao — cho ra **RF-Solver**, một sampler training-free có lỗi mỗi bước thấp hơn hẳn Euler/Heun. Dựa trên sampler chính xác đó, nhóm tác giả xây **RF-Edit** — khung chia sẻ đặc trưng self-attention, tái sử dụng feature "value" đã ghi lại lúc inversion để tiêm lại lúc denoising, giữ cấu trúc ảnh/video gốc trong khi theo prompt chỉnh sửa mới — hoàn toàn không cần fine-tune, áp dụng được cho bất kỳ backbone RF đã pretrain.

## 2. Tóm tắt theo từng phần

- **Động lực/phân tích:** Chỉ ra bằng thực nghiệm rằng inversion RF gốc tích lũy MSE qua từng timestep (Hình 2 của bài) vì cách giải kiểu Euler chỉ nắm được số hạng bậc không của trường vận tốc.
- **Phương pháp RF-Solver:** Xuất phát từ dạng tích phân chính xác của ODE RF (biến thiên hằng số), sau đó khai triển Taylor trường vận tốc v_θ quanh mỗi timestep: v_θ(Z_τ,τ) = Σ_{k=0}^{n-1} (τ-t_i)^k/k! · v_θ^(k)(Z_{t_i},t_i) + O((τ-t_i)^n). Tích phân giải tích cho công thức cập nhật bậc n; bản triển khai thực tế dùng **n=2**:
  Z_{t_{i-1}} = Z_{t_i} + (t_{i-1}-t_i)·v_θ(Z_{t_i},t_i) + ½(t_{i-1}-t_i)²·v_θ^(1)(Z_{t_i},t_i).
  Vì đạo hàm giải tích v_θ^(1) không có sẵn, nó được ước lượng bằng **sai phân hữu hạn** với bước nhỏ Δt=0.01: v_θ^(1) ≈ (v̂_{t_i+Δt} − v̂_{t_i})/Δt. Cách này hạ lỗi cục bộ mỗi bước từ O(h²) (Euler) xuống O(h³) (bậc hai), đổi lại một lần forward thêm mỗi timestep.
- **Phương pháp RF-Edit:** Lúc inversion, lưu lại feature **value** của self-attention từ M block transformer cuối tại n timestep cuối; lúc denoising, các value này thay thế value gốc (biến self-attention thành một dạng cross-attention với value đã lưu), giữ cấu trúc ảnh/video gốc. Áp dụng cho block single-stream của FLUX (ảnh) và module spatial-attention của OpenSora (video). Số bước chia sẻ đặc trưng mặc định = 5.
- **Thí nghiệm:** 4 nhóm tác vụ — (i) sinh text-to-image thường (COCO-30K, FID/CLIP), (ii) inversion/tái tạo (ảnh và video, MSE/LPIPS/SSIM/PSNR), (iii) chỉnh sửa ảnh (LPIPS/CLIP so với P2P, DiffEdit, SDEdit, PnP, Pix2Pix, RF-Inversion), (iv) chỉnh sửa video (VBench: Semantic Consistency, Motion Smoothness, Appearance Quality, Image Quality so với FateZero, FLATTEN, COVE, RAVE, Tokenflow). Backbone: FLUX (guidance-distilled), OpenSora, HunyuanVideo. Giao thức công bằng: RF gốc được cấp **gấp đôi số timestep** của RF-Solver để cùng ngân sách NFE.
- **Ablation:** Bậc Taylor n=1 (RF gốc) vs n=2 (RF-Solver) vs n=3, dưới ngân sách NFE cố định. n=2 là điểm tối ưu — n=3 cần nhiều lần evaluation hơn mỗi bước, dưới ngân sách cố định buộc phải giảm tổng số bước, làm *giảm* chất lượng. Ablation số bước chia sẻ đặc trưng: quá ít bước (<5) không giữ được cấu trúc; quá nhiều bước khiến kết quả chỉnh sửa quay ngược lại giống ảnh gốc, mất khả năng chỉnh sửa.
- **Kết luận:** RF-Solver giảm lỗi giải ODE, cải thiện chất lượng sinh/inversion; RF-Edit dựa trên đó cho editing giữ cấu trúc, training-free, tương thích mọi mô hình RF pretrain.

## 3. Kết luận chính

1. Xử lý số hạng phi tuyến của mạng trong ODE RF bằng khai triển Taylor bậc hai (thay vì Euler bậc một) đủ để giảm rõ rệt lỗi inversion/tái tạo, chỉ tốn thêm một lần forward mỗi bước.
2. Sửa lỗi số học này, kết hợp với thủ thuật chia sẻ value self-attention (RF-Edit), cho kết quả nhất quán tốt hơn nhiều baseline mạnh đã công bố trên cả ảnh và video, không cần huấn luyện hay fine-tune riêng cho từng tác vụ.
3. Khi so sánh ở **cùng tổng NFE**, RF-Solver vẫn thắng — cải thiện không đơn thuần là "tốn thêm compute", mà là lợi ích thật về độ chính xác trên mỗi đơn vị compute (ít nhất với các metric/tác vụ đã thử).

## 4. Số liệu đáng chú ý & việc cần làm

**Đã xác minh (đọc trực tiếp từ arXiv HTML v3, fetch ngày 18/07/2026):**
- Text-to-image COCO-30K: FID 23.98 / CLIP 31.09 (RF-Solver) so với FID 25.33 / CLIP 31.01 (RF gốc), so với DPMSolver++ FID 24.63 / CLIP 30.62.
- Inversion ảnh: MSE 0.0092, LPIPS 0.4239, SSIM 0.9276, PSNR 29.89 (RF-Solver) so với RF gốc MSE 0.0268, LPIPS 0.6253, SSIM 0.7626, PSNR 28.28.
- Inversion video: MSE 0.0134, LPIPS 0.3287, SSIM 0.8812, PSNR 18.41 (RF-Solver) so với RF gốc MSE 0.0206, LPIPS 0.4159, SSIM 0.8134, PSNR 18.12.
- Chỉnh sửa ảnh: LPIPS 0.149 / CLIP 33.66 (RF-Edit) so với baseline RF-Inversion LPIPS 0.318 / CLIP 33.02; so với PnP LPIPS 0.080 / CLIP 30.58 (PnP thắng LPIPS nhưng thua CLIP — RF-Edit không thắng tuyệt đối mọi metric).
- Chỉnh sửa video (VBench): SC 0.9501, MS 0.9712, AQ 0.6796, IQ 0.7207 (RF-Edit) so với baseline mạnh nhất Tokenflow SC 0.9439, MS 0.9632, AQ 0.6742, IQ 0.7128.
- Ablation: n=1→n=2 giảm FID sampling 25.33→23.98 và MSE inversion 0.0268→0.0092; n=3 (MSE 0.0131) tệ hơn n=2 (0.0092) khi cùng ngân sách NFE.
- Siêu tham số cố định: Δt=0.01 cho ước lượng đạo hàm sai phân hữu hạn; số bước chia sẻ đặc trưng mặc định = 5.

**CHƯA xác minh trong nguồn đã fetch (cần kiểm tra bản PDF/phụ lục đầy đủ trước khi trích dẫn):**
- Bất kỳ số liệu latency thực tế, throughput hay cấu hình GPU — không xuất hiện trong abstract hay các phần HTML đã lấy được.
- Số tham số chính xác của FLUX/OpenSora/HunyuanVideo dùng trong bài.
- Có mục "Limitations" tường minh hay không (không thấy trong HTML đã fetch; chỉ suy ra hạn chế ngầm từ nội dung phương pháp).
- Số liệu so sánh trực tiếp đối đầu với FireFlow (2412.07517) — bài đó ra sau RF-Solver và không tìm thấy bảng so sánh trực tiếp giữa hai bài.

## 5. Tóm tắt nhanh (<300 từ)

Các mô hình rectified-flow như FLUX sinh ảnh nhanh nhưng khó đảo ngược chính xác: chạy flow "ngược" bằng một bước Euler đơn giản sẽ tích lũy lỗi, khiến ảnh/video tái tạo trôi lệch khỏi ảnh gốc — vấn đề chí mạng cho mọi phương pháp editing cần inversion trung thực trước. RF-Solver sửa vấn đề này ở tầng số học. Bài viết nghiệm tích phân chính xác của ODE rectified-flow, rồi xấp xỉ số hạng vận tốc phi tuyến của mạng bằng khai triển Taylor bậc hai thay vì xử lý bậc không/một như thường lệ, dùng thêm một lần forward để ước lượng đạo hàm cần thiết qua sai phân hữu hạn. Điều này giảm chứng minh được lỗi cục bộ mỗi bước từ O(h²) xuống O(h³). Dựa trên sampler chính xác hơn này, RF-Edit tái sử dụng feature "value" của self-attention ghi lại lúc inversion và tiêm lại lúc denoising, giúp neo kết quả chỉnh sửa vào cấu trúc ảnh gốc trong khi vẫn theo prompt mới để đổi nội dung. Cả hai thành phần đều training-free và cắm được vào bất kỳ backbone rectified-flow đã pretrain — FLUX và HunyuanVideo cho ảnh/video, OpenSora cho video. Trên các benchmark sinh text-to-image, inversion ảnh/video, và chỉnh sửa ảnh/video, phương pháp vượt RF gốc, RF kiểu Heun, và nhiều baseline editing mạnh đã công bố (P2P, DiffEdit, PnP, RF-Inversion, Tokenflow...), và vẫn thắng khi các baseline được cấp gấp đôi số bước sampling để cùng ngân sách compute. Ablation cho thấy bậc hai là điểm ngọt: bậc ba cần thêm một lần evaluation mỗi bước, dưới ngân sách cố định buộc giảm tổng số bước và làm giảm chất lượng; ngưỡng chia sẻ đặc trưng (mặc định 5 bước) đánh đổi giữa giữ cấu trúc và khả năng chỉnh sửa thực sự. Được nhận ở ICML 2025, phương pháp đã trở thành baseline tham chiếu cho các công trình fast RF-inversion sau này như FireFlow.

## 6. Câu chào hội nghị (30–50 từ)

**VI:** "Đảo ngược ODE rectified-flow bằng Euler tích lũy lỗi, làm hỏng việc invert ảnh/video. RF-Solver khai triển Taylor bậc hai cho số hạng vận tốc phi tuyến — thêm một lần forward để đổi lấy nghiệm ODE chính xác hơn hẳn, từ đó cho phép chỉnh sửa ảnh/video giữ đúng cấu trúc nguồn, không cần huấn luyện, trên FLUX và OpenSora."

**EN:** "Euler-stepping a rectified-flow ODE backward accumulates error and breaks inversion. RF-Solver Taylor-expands the network's velocity term to second order — one extra forward pass buys a provably tighter ODE solution, and the resulting accurate inversion powers training-free, structure-preserving image and video editing on FLUX and OpenSora."

## 7. Bản chất (ngôn ngữ đơn giản)

Hãy tưởng tượng đi theo một con đường cong chỉ dựa vào hướng đang đứng ngay lúc này (Euler) — đi càng lâu càng lệch khỏi đường. RF-Solver thay vào đó nhìn hơi xa hơn một chút, đo xem hướng đi đang *thay đổi* thế nào, và đưa độ cong đó vào mỗi bước — nên nó bám sát đường đi thật hơn nhiều, chỉ tốn thêm một chút công (một lần "ngó" thêm mỗi bước). Vì bước "đi ngược" (inversion) giờ chính xác hơn, bài báo còn ghi lại "mạng đã chú ý vào đâu" lúc đi ngược và trả lại thông tin đó lúc đi tới, nên khi chỉnh sửa, ảnh/video đổi đúng phần được yêu cầu mà vẫn giữ mọi thứ khác giống bản gốc.
