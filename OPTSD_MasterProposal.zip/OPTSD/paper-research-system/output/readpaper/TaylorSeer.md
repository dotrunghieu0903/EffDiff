# TaylorSeer: From Reusing to Forecasting — Accelerating Diffusion Models with TaylorSeers

**Tác giả:** Jiacheng Liu, Chang Zou, Yuanhuiyi Lyu, Junjie Chen, Linfeng Zhang
**Venue:** ICCV 2025 · arXiv 2503.06923
**Nguồn:** https://arxiv.org/abs/2503.06923

> **Ghi chú xác minh:** Abstract lấy nguyên văn `/abs/`; chi tiết method/bảng từ HTML `/html/`. **Đã xác minh (khớp abstract):** tăng tốc **4.99× trên FLUX**, **5.00× trên HunyuanVideo** (không cần train thêm, gần như không mất mát), **FID thấp hơn SOTA 3.41 ở mức 4.53× trên DiT**. **Chưa xác minh (từ bảng HTML — chỉ tham khảo):** ImageReward 1.0039 (FLUX), VBench 79.93% (HunyuanVideo), FID-50k 2.65 (DiT), các số PSNR/SSIM/LPIPS và ablation bậc Taylor.

---

# English version

## 1. Purpose of the document
Diffusion Transformers (DiT) generate high-fidelity images/videos but are too costly for real-time use. **Feature caching** (cache features at one step, reuse them at later steps) accelerates them, but once the gap between steps grows, feature similarity drops sharply, so reusing "stale" features injects large errors and hurts quality. TaylorSeer aims to **break the ~3–4× ceiling** of caching by switching from *reusing* to *forecasting* the features of future timesteps.

## 2. Main content, section by section
**Motivation.** "Cache-then-reuse" replays already-computed features, but feature similarity between two steps **decays exponentially** as their distance grows — so you cannot push acceleration high without collapsing quality. Key observation: features and their derivatives vary slowly and continuously along stable trajectories over timesteps.

**Method — "cache-then-forecast" via Taylor series.**
- At fully-activated steps, cache not just feature F but its **higher-order finite differences** (ΔF, Δ²F, …, ΔᵐF) as derivative approximations across steps spaced N apart.
- Predict the feature at a future step t−k via an **m-th order Taylor expansion**: `F_pred(x_{t−k}) = F(x_t) + Σᵢ [ΔⁱF(x_t)/(i!·Nⁱ)]·(−k)ⁱ`.
- **Schedule:** only m+1 fully-computed steps are needed to predict all intermediate ones — training-free, plug-in.

**Experiments.** FLUX.1-dev (T2I 1000×1000, 200 DrawBench prompts), HunyuanVideo (T2V, 946 VBench prompts), DiT-XL/2 (ImageNet 256, 50k images). Baselines: TeaCache, ToCa, FORA, DuCa, Δ-DiT.

## 3. Key conclusions
- Diffusion features are **predictable** from past values → forecasting beats reusing, especially at high acceleration.
- High-order Taylor terms preserve quality even at large step gaps (N=5–7) where reuse collapses.
- Training-free, plugs into existing models/solvers, works on both images and video.
- A **paradigm pivot** for caching (reuse → forecast); foundation for later work (HiCache, SpeCa).

## 4. Notable figures & to-dos
**Verified (matches abstract):** **4.99×** on FLUX (near-lossless), **5.00×** on HunyuanVideo (no extra training), **3.41 lower FID than prior SOTA at 4.53×** on DiT.

**Unverified (HTML table render — indicative):**

| Model | Speedup | Metric | Value | vs prior SOTA |
|---|---|---|---|---|
| FLUX | 4.99× | ImageReward | 1.0039 | > TeaCache 0.8683 |
| HunyuanVideo | 5.0× | VBench | 79.93% | +1.57% vs TeaCache |
| DiT | 4.53× | FID-50k | 2.65 | < FORA 6.58 / ToCa 6.20 |

**Ablation (Taylor order, DiT ~4.98×):** O=0 (reuse) FID 9.24 → O=1 FID 3.59 → O=2–3 saturate ~2.5–3.2 → O≥4 marginal.

**Limitations / to-dos:** none stated explicitly; sometimes *beats* baselines at low speedups (suspected Flow-Matching regularization effect). Implicit: memory cost of caching derivative orders, manual choice of order m / interval N.

## 5. Quick recap (< 300 words)
TaylorSeer accelerates Diffusion Transformers by rethinking feature caching: instead of **reusing** stale features (cache-then-reuse), it **forecasts** the features of future timesteps (cache-then-forecast). The problem with reuse is that feature similarity between two steps decays exponentially as their distance grows, so pushing acceleration past ~3–4× collapses quality. TaylorSeer observes that features and their derivatives vary slowly and continuously along stable trajectories; therefore, at fully-activated steps it caches both the feature and its higher-order finite differences (derivative approximations), then uses an **m-th order Taylor series expansion** to predict features at the skipped steps. Only m+1 fully-computed steps are needed to derive all intermediate ones, and it is entirely training-free. Results: **4.99× on FLUX** and **5.00× on HunyuanVideo** with near-lossless quality, and on DiT it reaches **FID 3.41 points lower than prior SOTA at 4.53×**. Ablations show the expansion order is decisive: order 0 (pure reuse) gives FID 9.24, order 1 drops to 3.59, orders 2–3 saturate around 2.5–3.2. It applies to both image and video, plugs into existing models/solvers, and has become the foundation of later caching work (HiCache, SpeCa). The core message: don't re-paste an old, drifted feature — **extrapolate** it to where it should be, which unlocks strong acceleration while keeping quality.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈44w):** Feature caching reuses stale features, so quality collapses past ~4× speedup. TaylorSeer instead *forecasts* future features: it caches finite-difference derivatives and extrapolates via a Taylor series. Training-free, it hits near-lossless 4.99× on FLUX and 5.0× on HunyuanVideo.

**VI (≈46 từ):** Caching kiểu tái dùng dán lại đặc trưng cũ nên vượt ~4× là chất lượng sập. TaylorSeer thay bằng *dự báo* đặc trưng tương lai: cache các sai phân (đạo hàm) rồi ngoại suy bằng chuỗi Taylor. Không cần train, đạt 4.99× trên FLUX và 5.0× trên HunyuanVideo gần như không mất mát.

## 7. The essence in plain language
**The problem, plainly:** An image/video model runs many steps and is slow. People "remember" one step's result and reuse it to save time — but reusing something too old wrecks the picture.

**Core idea (one sentence):** Don't re-paste the old picture; look at *which way it's changing* and predict what it will become at the next step.

**Everyday analogy — predicting a car's position:** To know where a moving car is *now*, don't use a photo from 10 seconds ago (reuse — wrong position). Look at its *speed and acceleration* and compute where it is now (forecast). TaylorSeer does exactly this with the model's "features": record their rate of change, then extrapolate to the step you need.

**If you remember only one thing:** Speed doesn't come from reusing the old — it comes from **predicting what's next**.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Diffusion Transformer (DiT) sinh ảnh/video chất lượng cao nhưng quá tốn tính toán để chạy thời gian thực. Hướng **feature caching** (cache đặc trưng ở bước trước rồi tái dùng ở bước sau) giúp tăng tốc, nhưng khi khoảng cách giữa các bước lớn, độ tương đồng đặc trưng tụt nhanh → tái dùng đặc trưng "cũ" gây sai số lớn, hỏng chất lượng. TaylorSeer đặt mục tiêu **phá trần tăng tốc ~3–4×** của caching bằng cách **chuyển từ "tái dùng" sang "dự báo"** đặc trưng ở bước tương lai.

## 2. Nội dung chính từng phần

**Động lực.** Caching kiểu "cache-then-reuse" dùng lại đặc trưng đã tính; nhưng độ tương đồng đặc trưng giữa hai bước **giảm theo hàm mũ** khi khoảng cách bước tăng → không thể đẩy tăng tốc cao mà không sập chất lượng. Quan sát then chốt: đặc trưng và **đạo hàm của chúng biến thiên chậm, liên tục, theo quỹ đạo ổn định** qua các timestep.

**Phương pháp — "cache-then-forecast" bằng chuỗi Taylor.**
- Tại bước được "kích hoạt đầy đủ", cache không chỉ đặc trưng F mà cả các **sai phân bậc cao** (ΔF, Δ²F, …, ΔᵐF) — xấp xỉ đạo hàm theo phương pháp hữu hạn (finite difference) giữa các bước cách nhau N khoảng.
- Đặc trưng ở bước tương lai t−k được **dự báo bằng khai triển Taylor bậc m**: `F_pred(x_{t−k}) = F(x_t) + Σᵢ [ΔⁱF(x_t)/(i!·Nⁱ)]·(−k)ⁱ`.
- **Lịch cache:** chỉ cần m+1 bước tính đầy đủ là dự báo được toàn bộ bước trung gian → cân bằng độ chính xác và chi phí. Không cần huấn luyện.

**Thí nghiệm.** FLUX.1-dev (T2I 1000×1000, 200 prompt DrawBench), HunyuanVideo (T2V, 946 prompt VBench), DiT-XL/2 (ImageNet 256, 50k ảnh). Baseline: TeaCache, ToCa, FORA, DuCa, Δ-DiT.

## 3. Các kết luận quan trọng
- Đặc trưng của diffusion **có thể dự báo** từ giá trị bước trước → dự báo (forecast) đánh bại tái dùng (reuse), nhất là ở tỉ lệ tăng tốc cao.
- Khai triển Taylor bậc cao giúp giữ chất lượng ngay cả khi khoảng cách bước lớn (N=5–7), nơi reuse sụp đổ.
- Training-free, cắm vào solver/model có sẵn; áp dụng cả ảnh lẫn video.
- Là **bước ngoặt paradigm** cho caching (reuse → forecast), nền tảng cho các bài sau (HiCache, SpeCa).

## 4. Số liệu nổi bật & việc cần làm

**Đã xác minh (abstract):**
- **4.99×** trên FLUX (gần như không mất mát), **5.00×** trên HunyuanVideo (không train thêm), **FID thấp hơn SOTA 3.41** ở **4.53×** trên DiT.

**Chưa xác minh (bảng HTML — tham khảo):**

| Model | Tăng tốc | Chỉ số | Giá trị | vs SOTA trước |
|---|---|---|---|---|
| FLUX | 4.99× | ImageReward | 1.0039 | > TeaCache 0.8683 |
| HunyuanVideo | 5.0× | VBench | 79.93% | +1.57% vs TeaCache |
| DiT | 4.53× | FID-50k | 2.65 | < FORA 6.58 / ToCa 6.20 |

**Ablation bậc Taylor (DiT, ~4.98×):** O=0 (reuse) FID 9.24 → O=1 FID 3.59 → O=2–3 bão hòa ~2.5–3.2 → O≥4 lợi ích cận biên.

**Hạn chế / để ngỏ:** paper không nêu hạn chế tường minh; đôi khi *vượt* baseline ở tốc độ thấp (nghi do hiệu ứng regularization của Flow Matching) → gợi ý hướng khai thác lúc huấn luyện. Ngầm hiểu: chi phí lưu các bậc sai phân, chọn bậc m/khoảng N còn thủ công.

## 5. Tóm tắt ngắn (< 300 từ)
TaylorSeer tăng tốc Diffusion Transformer bằng cách đổi tư duy của feature caching: thay vì **tái dùng** đặc trưng cũ (cache-then-reuse), nó **dự báo** đặc trưng ở bước tương lai (cache-then-forecast). Vấn đề của tái dùng: độ tương đồng đặc trưng giữa hai bước giảm theo hàm mũ khi khoảng cách bước tăng, nên đẩy tăng tốc quá ~3–4× là chất lượng sập. TaylorSeer quan sát rằng đặc trưng và đạo hàm của chúng biến thiên chậm, liên tục theo quỹ đạo ổn định; do đó tại các bước "kích hoạt đầy đủ", nó cache cả đặc trưng lẫn các sai phân bậc cao (xấp xỉ đạo hàm bằng hữu hạn), rồi dùng **khai triển chuỗi Taylor bậc m** để tiên đoán đặc trưng cho các bước bị bỏ qua. Chỉ cần m+1 bước tính đầy đủ là suy ra toàn bộ bước trung gian, hoàn toàn training-free. Kết quả: **4.99× trên FLUX** và **5.00× trên HunyuanVideo** gần như không mất chất lượng, và trên DiT đạt **FID thấp hơn SOTA trước 3.41 điểm ở mức 4.53×**. Ablation cho thấy bậc khai triển là mấu chốt: bậc 0 (tái dùng thuần) FID 9.24, lên bậc 1 còn 3.59, bậc 2–3 bão hòa ~2.5–3.2. Phương pháp áp dụng cho cả ảnh và video, cắm vào model/solver có sẵn, và trở thành nền tảng cho các bài caching sau (HiCache, SpeCa). Điểm cốt lõi: đừng dán lại miếng đặc trưng cũ đã lệch, hãy **ngoại suy** nó tới đúng chỗ cần — nhờ đó tăng tốc mạnh mà vẫn giữ chất lượng.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈44w):** Feature caching reuses stale features, so quality collapses past ~4× speedup. TaylorSeer instead *forecasts* future features: it caches finite-difference derivatives and extrapolates via a Taylor series. Training-free, it hits near-lossless 4.99× on FLUX and 5.0× on HunyuanVideo.

**VI (≈46 từ):** Caching kiểu tái dùng dán lại đặc trưng cũ nên vượt ~4× là chất lượng sập. TaylorSeer thay bằng *dự báo* đặc trưng tương lai: cache các sai phân (đạo hàm) rồi ngoại suy bằng chuỗi Taylor. Không cần train, đạt 4.99× trên FLUX và 5.0× trên HunyuanVideo gần như không mất mát.

## 7. Bản chất nói nôm na
**Vấn đề:** Mô hình vẽ ảnh/video chạy nhiều bước rất chậm. Người ta "ghi nhớ" kết quả một bước để tái dùng cho bước sau cho nhanh — nhưng dùng lại đồ quá cũ thì ảnh hỏng.

**Ý tưởng cốt lõi:** Đừng dán lại tấm ảnh cũ; hãy nhìn nó đang *thay đổi theo hướng nào* rồi đoán trước nó sẽ thành gì ở bước tiếp theo.

**Ẩn dụ đời thường — đoán vị trí xe:** Muốn biết chiếc xe đang ở đâu lúc này, bạn đừng dùng tấm ảnh chụp nó 10 giây trước (reuse — đã sai vị trí). Hãy nhìn *tốc độ và gia tốc* của nó rồi tính ra nó giờ đang ở đâu (forecast). TaylorSeer làm đúng vậy với "đặc trưng" của mô hình: ghi lại tốc độ thay đổi rồi ngoại suy tới bước cần.

**Câu để đời:** Nhanh không phải nhờ dùng lại cái cũ, mà nhờ **đoán đúng cái sắp tới**.
