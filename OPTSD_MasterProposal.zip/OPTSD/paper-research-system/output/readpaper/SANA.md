# SANA: Efficient High-Resolution Text-to-Image Synthesis with Linear Diffusion Transformers

**Tác giả:** Enze Xie, Junsong Chen, Junyu Chen, Han Cai, Haotian Tang, Yujun Lin, Zhekai Zhang, Muyang Li, Ligeng Zhu, Yao Lu, Song Han (NVIDIA / MIT / Tsinghua / Playground)
**Venue:** ICLR 2025 (Oral) · arXiv 2410.10629 (v1: 14/10/2024, v3: 20/10/2024)
**Nguồn:** https://arxiv.org/abs/2410.10629 · https://arxiv.org/html/2410.10629

**Lựa chọn SOTA Nhóm 5 & lý do (1 câu):** Chọn **SANA** vì đây là công trình duy nhất trong nhóm gộp *đồng thời* ba trục kiến trúc (attention xấp xỉ tuyến tính, autoencoder nén sâu, text-encoder LLM decoder-only) thành một hệ thống T2I hoàn chỉnh đạt venue mạnh (ICLR Oral), tạo ra tác động thực tế đo được (mã nguồn/checkpoint dùng rộng) và sinh trực tiếp dòng follow-up trong chính nhóm khảo sát (SANA 1.5, DC-AE tách riêng, EDiT, DiT-Air).
**Á quân:** LightningDiT/VA-VAE (CVPR 2025 Oral, 2501.01423) — hội tụ nhanh ấn tượng (~21×) và SOTA ImageNet-256, nhưng phạm vi hẹp hơn (class-conditional, không phải hệ T2I đầy đủ).

> **Ghi chú xác minh:** Abstract lấy nguyên văn từ trang `/abs/2410.10629` (đã fetch, khớp tác giả/ngày). Nội dung phương pháp, cấu trúc mục, và toàn bộ bảng số liệu lấy từ bản HTML `/html/2410.10629` qua agent trích xuất — độ tin cậy cao (số liệu có ngữ cảnh bảng rõ ràng) nhưng **chưa đối chiếu trực tiếp với PDF gốc/OpenReview**, nên kiểm lại trước khi trích dẫn chính thức trong luận văn. Các số lấy trực tiếp từ abstract (20×, 100+×, <1s, 32×) được xếp vào nhóm "đã xác minh cao nhất".

---

# English version

## 1. Purpose
SANA proposes a complete, retrainable **text-to-image (T2I) framework** aimed at generating images up to **4096×4096** at very high throughput on constrained hardware (a 16 GB laptop GPU), while remaining competitive in quality with far larger diffusion models (e.g., FLUX-12B). The core purpose is architectural: show that the *right combination* of (1) a much more aggressively compressed autoencoder, (2) linear-complexity attention in the DiT backbone, and (3) a modern decoder-only LLM as the text encoder can jointly remove the quadratic and parameter-count bottlenecks that make high-resolution T2I diffusion expensive — without a proportional quality loss.

## 2. Section-by-section
- **Introduction** — motivates the cost of quadratic self-attention and heavy 8×-compression autoencoders at high resolution; frames the paper as jointly redesigning encoder + backbone + text encoder + solver rather than optimizing one component.
- **2.1 Deep Compression Autoencoder (AE-F32C32P1)** — replaces the standard 8×-compression AE with a 32× spatial compression, 32-channel design; argues the AE should absorb *all* spatial compression so the diffusion model can "focus solely on denoising." Ablations (Fig. 3) show that best *reconstruction* FID (F8C16) does not translate to best *generation* FID — F32C32 wins on the generation side despite worse rFID than F8C16.
- **2.2 Efficient Linear DiT Design** — replaces all vanilla O(N²) softmax self-attention in the DiT blocks with **ReLU linear attention** (O(N)); compensates the weaker local-modeling capacity of linear attention with a **Mix-FFN** (inverted residual + 3×3 depthwise conv + GLU); introduces **NoPE** (no positional embedding at all in the DiT), claimed as the first fully PE-free DiT design, argued to give better length/resolution generalization.
- **2.3 Text Encoder Design** — swaps T5-XXL for a **decoder-only small LLM (Gemma-2-2B)**, using **Complex Human Instruction (CHI)** — an in-context-learning prompt template — to sharpen instruction following; fixes training instability from raw LLM embeddings via **RMSNorm + a small learnable scale (~0.01)**.
- **3. Efficient Training/Inference** — data curation/captioning strategy (CLIP-score-based multi-caption selection) and a flow-matching training objective; proposes **Flow-DPM-Solver**, a DPM-Solver++ adapted to rectified-flow velocity prediction, cutting sampling to ~14–20 steps vs. 28–50 for Flow-Euler.
- **4. On-device Deployment** — W8A8 post-training quantization of the DiT for laptop-GPU inference.
- **5. Experiments** — head-to-head comparisons vs. PixArt-Σ, SDXL, SD3-medium, FLUX-dev/schnell at 512² and 1024² (throughput, latency, FID, CLIP, GenEval, DPG-Bench); block-design ablation (attention/FFN/AE variants); text-encoder ablation; CHI ablation; 4K-generation timing.
- **Related Work / Conclusion** — positions SANA against PixArt/FLUX/SD3 lineages; states explicit limitations (safety/controllability not guaranteed; text rendering and faces/hands remain hard) and future work (video generation pipeline based on SANA).

## 3. Key conclusions
- Pushing autoencoder compression from 8× to 32× is the single biggest lever for high-resolution efficiency, because it cuts the *token count* the (already-linearized) DiT has to process, and generation quality is decoupled from raw reconstruction fidelity of the AE.
- Linear attention + Mix-FFN can match softmax-attention DiT quality at a fraction of the FLOPs, provided local inductive bias is reintroduced via convolution.
- A much smaller decoder-only LLM (Gemma-2-2B) with an in-context instruction template can replace T5-XXL (4.7B) for text conditioning with comparable or better alignment scores at a fraction of the encoder cost.
- Sana-0.6B is stated to be competitive with FLUX-12B while being ~20× smaller and 100+× faster in measured throughput — the paper's central efficiency claim.

## 4. Notable figures & to-dos

**Verified (quoted verbatim from the abstract, `/abs/` page):**
- Generates up to **4096×4096** resolution.
- Sana-0.6B vs. FLUX-12B: **~20× smaller**, **100+× faster** measured throughput.
- **<1 second** to generate a 1024×1024 image on a **16 GB laptop GPU**.
- Autoencoder compression ratio: **32×** (vs. traditional 8×).

**From HTML tables (high confidence, but re-check against the camera-ready PDF/OpenReview before formal citation):**
- Table 7 (1024²): Sana-0.6B — throughput 1.7, latency 0.9 s, FID 5.81, CLIP 28.36, GenEval 0.64, DPG 83.6, 0.6B params. FLUX-dev — throughput 0.04, latency 23.0 s, FID 10.15, 12B params. → Sana-0.6B ≈ **39.5× faster** than FLUX-dev at 1024².
- Table 1 (AE reconstruction, MJHQ-30K): AE-F32C32 (ours) rFID 0.34, PSNR 29.29, SSIM 0.84, LPIPS 0.05 — vs. SDXL F8C4 rFID 0.31; vs. SD F32C64 rFID 0.82.
- Table 9 (text encoder): Gemma2-2B — 2614 M params, latency 0.28 s, FID 6.0, CLIP 26.9; vs. T5-XXL — 4762 M params, latency 1.61 s, FID 6.1, CLIP 27.1 → **~6× faster** text encoding at comparable quality.
- Table 5 (on-device W8A8): FP16 latency 0.88 s → W8A8 0.37 s (**2.4× speedup**) with near-lossless CLIP-score/ImageReward.
- Table 2 (CHI ablation): +2.2 GenEval at 52K steps, +2.0 after 5K fine-tune steps.
- Figure 8: Flow-DPM-Solver converges in **14–20 steps** vs. 28–50 for Flow-Euler.
- 4K generation: **469 s → 9.6 s** (stated "100+× faster than FLUX" at 4K).

**To-do / unverified — needs re-check before citing formally:**
- Exact GenEval/DPG numbers should be cross-checked against the ICLR 2025 camera-ready and OpenReview thread (id N8Oj1XhtYZ), since v1→v3 revisions occurred within a week of the initial submission.
- The "first design to fully omit positional embedding in DiT" claim is **not independently verified against all concurrent DiT variants** — treat as an author claim, not a confirmed fact (see critique file, prior-art check).
- SANA's own claim that decoder-only LLM text encoding is a novel contribution needs qualification: Lumina-Next (already used Gemma-2B as text encoder, June 2024) predates SANA by ~4 months (see critique).

## 5. Quick recap (<300 words)
SANA is an ICLR 2025 Oral T2I framework built to generate up to 4096×4096 images cheaply, down to a 16 GB laptop GPU in under a second at 1024². Its efficiency comes from redesigning three components at once rather than optimizing one. First, a **32×-compression autoencoder** (vs. the usual 8×) shrinks the number of latent tokens the diffusion backbone must process — the paper argues generation quality is more sensitive to *token count* than to raw AE reconstruction fidelity. Second, the **DiT backbone replaces all softmax self-attention with O(N) ReLU linear attention**, recovering the lost local modeling capacity via a **Mix-FFN** (depthwise conv + GLU), and drops positional embeddings entirely (NoPE). Third, the **T5-XXL text encoder is replaced by a much smaller decoder-only LLM (Gemma-2-2B)**, guided by a hand-designed **Complex Human Instruction** prompt template that exploits in-context learning to sharpen text-image alignment; training stability required RMSNorm plus a small learned scale on the LLM embeddings. A custom **Flow-DPM-Solver** cuts sampling to 14–20 steps. The headline result: Sana-0.6B is competitive with FLUX-12B while being ~20× smaller and 100+× faster in measured throughput, and W8A8 quantization gives a further 2.4× on-device speedup at near-lossless quality. Authors acknowledge limits: no guaranteed safety/controllability, and text rendering plus faces/hands remain weak points; they flag video generation as future work. The paper's real contribution is less any single trick and more the *systems-level argument* that compression budget should be reallocated from the diffusion backbone to the autoencoder and text encoder, since those are cheaper places to pay for capacity.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈45w):** SANA generates 4K images on a laptop GPU in under a second by moving compute where it's cheap: a 32×-compression autoencoder shrinks tokens, linear attention replaces quadratic self-attention, and a small decoder-only LLM replaces T5 — Sana-0.6B rivals FLUX-12B at 20× fewer parameters, 100+× the throughput.

**VI (≈48 từ):** SANA sinh ảnh 4K trên laptop GPU dưới 1 giây bằng cách dồn "chi phí" vào nơi rẻ nhất: autoencoder nén 32× giảm số token, attention tuyến tính thay softmax bậc hai, và một LLM decoder-only nhỏ thay T5. Sana-0.6B sánh ngang FLUX-12B nhưng nhỏ hơn 20 lần, thông lượng nhanh hơn 100+ lần.

## 7. Essence (plain-language)
Imagine a factory line for making pictures. The old way spends huge effort at the "drawing" station (the diffusion transformer) even though the "compressing" station (the autoencoder) and the "reading instructions" station (the text encoder) could each do more of the work more cheaply. SANA rebalances the line: it makes the compressor squeeze the picture much smaller before drawing even starts (32× instead of 8×), it makes the drawing station use a faster, "skim-reading" style of attention instead of comparing every pixel to every other pixel, and it swaps a giant instruction-reader (T5) for a smaller, smarter one (a small LLM) that's told very explicitly how to read the prompt. The result: almost the same picture quality, drawn 20–100× faster on much cheaper hardware.

---

# Phiên bản Tiếng Việt

## 1. Mục đích
SANA đề xuất một **khung sinh ảnh từ văn bản (T2I)** hoàn chỉnh, huấn luyện lại từ đầu, nhằm sinh ảnh tới **4096×4096** với thông lượng rất cao trên phần cứng hạn chế (laptop GPU 16 GB), đồng thời giữ chất lượng cạnh tranh với các mô hình diffusion lớn hơn nhiều (ví dụ FLUX-12B). Mục đích cốt lõi mang tính **kiến trúc**: chứng minh rằng tổ hợp *đúng* của (1) autoencoder nén mạnh hơn hẳn, (2) attention độ phức tạp tuyến tính trong backbone DiT, và (3) text encoder là LLM decoder-only hiện đại, có thể cùng lúc loại bỏ các nút nghẽn bậc hai và số tham số khiến T2I độ phân giải cao trở nên đắt đỏ — mà không đánh đổi chất lượng tương ứng.

## 2. Nội dung từng phần
- **Giới thiệu** — nêu chi phí của self-attention bậc hai và autoencoder nén 8× truyền thống ở độ phân giải cao; định vị bài báo là thiết kế lại đồng thời encoder + backbone + text encoder + solver, không chỉ tối ưu một thành phần.
- **2.1 Autoencoder nén sâu (AE-F32C32P1)** — thay AE nén 8× chuẩn bằng thiết kế nén không gian **32×**, 32 kênh; lập luận AE nên gánh *toàn bộ* việc nén không gian để mô hình diffusion "chỉ tập trung khử nhiễu." Ablation (Fig. 3) cho thấy FID *tái tạo* tốt nhất (F8C16) không chuyển thành FID *sinh ảnh* tốt nhất — F32C32 thắng ở khâu sinh ảnh dù rFID kém hơn F8C16.
- **2.2 Thiết kế Linear DiT hiệu quả** — thay toàn bộ self-attention softmax O(N²) trong các block DiT bằng **ReLU linear attention** (O(N)); bù lại khả năng mô hình hóa cục bộ yếu hơn của linear attention bằng **Mix-FFN** (inverted residual + depthwise conv 3×3 + GLU); đưa ra **NoPE** (bỏ hoàn toàn positional embedding trong DiT), tự nhận là thiết kế DiT đầu tiên loại bỏ hoàn toàn PE, lập luận cho khả năng tổng quát hóa độ dài/độ phân giải tốt hơn.
- **2.3 Thiết kế Text Encoder** — thay T5-XXL bằng **LLM decoder-only nhỏ (Gemma-2-2B)**, dùng **Complex Human Instruction (CHI)** — một mẫu prompt tận dụng in-context learning — để tăng độ bám sát chỉ dẫn; khắc phục mất ổn định huấn luyện từ embedding LLM thô bằng **RMSNorm + hệ số học được nhỏ (~0.01)**.
- **3. Huấn luyện/Suy luận hiệu quả** — chiến lược chọn/gán caption dựa CLIP-score đa caption; mục tiêu huấn luyện flow-matching; đề xuất **Flow-DPM-Solver**, biến thể DPM-Solver++ thích ứng với dự đoán vận tốc rectified-flow, giảm số bước sampling xuống ~14–20 (so với 28–50 của Flow-Euler).
- **4. Triển khai on-device** — lượng tử hóa post-training W8A8 cho DiT để suy luận trên laptop GPU.
- **5. Thực nghiệm** — so sánh trực tiếp với PixArt-Σ, SDXL, SD3-medium, FLUX-dev/schnell ở 512² và 1024² (throughput, latency, FID, CLIP, GenEval, DPG-Bench); ablation thiết kế block (attention/FFN/AE); ablation text encoder; ablation CHI; đo thời gian sinh ảnh 4K.
- **Related Work / Kết luận** — định vị SANA so với dòng PixArt/FLUX/SD3; nêu rõ hạn chế (chưa bảo đảm an toàn/kiểm soát nội dung; render chữ và mặt/tay còn yếu) và hướng tương lai (pipeline sinh video dựa trên SANA).

## 3. Các kết luận quan trọng
- Đẩy mức nén autoencoder từ 8× lên 32× là đòn bẩy lớn nhất cho hiệu quả ở độ phân giải cao, vì nó giảm *số token* mà DiT (đã tuyến tính hóa) phải xử lý; chất lượng sinh ảnh tách biệt khỏi độ trung thực tái tạo thô của AE.
- Linear attention + Mix-FFN có thể sánh chất lượng DiT dùng softmax attention với phần nhỏ FLOPs, miễn là bù lại inductive bias cục bộ bằng convolution.
- Một LLM decoder-only nhỏ hơn nhiều (Gemma-2-2B) với mẫu chỉ dẫn in-context có thể thay T5-XXL (4.7B) cho điều kiện văn bản, với điểm bám sát tương đương hoặc tốt hơn ở chi phí encoder thấp hơn nhiều.
- Sana-0.6B được tuyên bố cạnh tranh với FLUX-12B trong khi nhỏ hơn ~20× và nhanh hơn 100+× về thông lượng đo được — tuyên bố hiệu quả trung tâm của bài báo.

## 4. Số liệu nổi bật & việc cần làm

**Đã xác minh (trích nguyên văn từ abstract, trang `/abs/`):**
- Sinh ảnh tới **4096×4096**.
- Sana-0.6B so FLUX-12B: **nhỏ hơn ~20×**, **thông lượng đo được nhanh hơn 100+×**.
- **Dưới 1 giây** để sinh ảnh 1024×1024 trên **laptop GPU 16 GB**.
- Tỉ lệ nén autoencoder: **32×** (so với 8× truyền thống).

**Từ bảng HTML (độ tin cậy cao, nên đối chiếu lại bản PDF chính thức/OpenReview trước khi trích dẫn):**
- Bảng 7 (1024²): Sana-0.6B — throughput 1.7, latency 0.9s, FID 5.81, CLIP 28.36, GenEval 0.64, DPG 83.6, 0.6B tham số. FLUX-dev — throughput 0.04, latency 23.0s, FID 10.15, 12B tham số. → Sana-0.6B ≈ **nhanh hơn 39.5×** so FLUX-dev ở 1024².
- Bảng 1 (tái tạo AE, MJHQ-30K): AE-F32C32 (của bài) rFID 0.34, PSNR 29.29, SSIM 0.84, LPIPS 0.05 — so SDXL F8C4 rFID 0.31; so SD F32C64 rFID 0.82.
- Bảng 9 (text encoder): Gemma2-2B — 2614M tham số, latency 0.28s, FID 6.0, CLIP 26.9; so T5-XXL — 4762M tham số, latency 1.61s, FID 6.1, CLIP 27.1 → **nhanh hơn ~6×** cho text encoding ở chất lượng tương đương.
- Bảng 5 (on-device W8A8): FP16 latency 0.88s → W8A8 0.37s (**tăng tốc 2.4×**) với CLIP-score/ImageReward gần như không đổi.
- Bảng 2 (ablation CHI): +2.2 GenEval ở bước 52K, +2.0 sau 5K bước fine-tune.
- Hình 8: Flow-DPM-Solver hội tụ trong **14–20 bước** so 28–50 bước của Flow-Euler.
- Sinh 4K: **469s → 9.6s** (tuyên bố "nhanh hơn 100+× so FLUX" ở 4K).

**Việc cần làm / chưa xác minh — kiểm lại trước khi trích dẫn chính thức:**
- Số GenEval/DPG chính xác nên đối chiếu với bản camera-ready ICLR 2025 và thread OpenReview (id N8Oj1XhtYZ), vì có revision v1→v3 trong vòng một tuần sau nộp ban đầu.
- Tuyên bố "thiết kế đầu tiên loại bỏ hoàn toàn positional embedding trong DiT" **chưa được xác minh độc lập** so với mọi biến thể DiT cùng thời điểm — coi là tuyên bố của tác giả, chưa phải sự thật đã kiểm chứng (xem file critique, phần kiểm tra khe hở).
- Tuyên bố của SANA rằng dùng LLM decoder-only làm text encoder là đóng góp mới cần được xem lại có điều kiện: Lumina-Next (đã dùng Gemma-2B làm text encoder, tháng 6/2024) ra đời trước SANA khoảng 4 tháng (xem file critique).

## 5. Tóm tắt ngắn (<300 từ)
SANA là khung T2I ICLR 2025 Oral, được xây để sinh ảnh tới 4096×4096 chi phí thấp, tới mức chạy trên laptop GPU 16GB dưới 1 giây ở 1024². Hiệu quả đến từ việc thiết kế lại ba thành phần cùng lúc thay vì tối ưu một. Thứ nhất, **autoencoder nén 32×** (so với 8× thông thường) giảm số token latent mà backbone diffusion phải xử lý — bài báo lập luận chất lượng sinh ảnh nhạy với *số token* hơn là độ trung thực tái tạo thô của AE. Thứ hai, **backbone DiT thay toàn bộ self-attention softmax bằng ReLU linear attention O(N)**, phục hồi khả năng mô hình hóa cục bộ đã mất qua **Mix-FFN** (depthwise conv + GLU), và bỏ hẳn positional embedding (NoPE). Thứ ba, **text encoder T5-XXL được thay bằng LLM decoder-only nhỏ hơn nhiều (Gemma-2-2B)**, dẫn dắt bởi mẫu prompt **Complex Human Instruction** thủ công khai thác in-context learning để tăng độ bám sát text-ảnh; ổn định huấn luyện cần RMSNorm cộng hệ số học được nhỏ trên embedding LLM. Một **Flow-DPM-Solver** tùy biến giảm sampling xuống 14–20 bước. Kết quả nổi bật: Sana-0.6B cạnh tranh với FLUX-12B trong khi nhỏ hơn ~20× và nhanh hơn 100+× về thông lượng đo được, và lượng tử hóa W8A8 mang lại thêm 2.4× tăng tốc on-device ở chất lượng gần như không đổi. Tác giả nhìn nhận hạn chế: chưa bảo đảm an toàn/kiểm soát nội dung, render chữ và mặt/tay còn yếu; đánh dấu sinh video là hướng tương lai. Đóng góp thực sự của bài không nằm ở một mẹo đơn lẻ mà ở **luận điểm tầng hệ thống**: nên phân bổ lại "ngân sách nén" từ backbone diffusion sang autoencoder và text encoder, vì đó là những nơi rẻ hơn để trả chi phí cho năng lực mô hình.

## 6. Conference one-breath pitch (30–50 từ)
**EN (≈45w):** SANA generates 4K images on a laptop GPU in under a second by moving compute where it's cheap: a 32×-compression autoencoder shrinks tokens, linear attention replaces quadratic self-attention, and a small decoder-only LLM replaces T5 — Sana-0.6B rivals FLUX-12B at 20× fewer parameters, 100+× the throughput.

**VI (≈48 từ):** SANA sinh ảnh 4K trên laptop GPU dưới 1 giây bằng cách dồn "chi phí" vào nơi rẻ nhất: autoencoder nén 32× giảm số token, attention tuyến tính thay softmax bậc hai, và một LLM decoder-only nhỏ thay T5. Sana-0.6B sánh ngang FLUX-12B nhưng nhỏ hơn 20 lần, thông lượng nhanh hơn 100+ lần.

## 7. Bản chất nói nôm na
Hãy tưởng tượng một dây chuyền vẽ tranh. Cách cũ dồn hầu hết công sức vào công đoạn "vẽ" (diffusion transformer), dù công đoạn "nén ảnh" (autoencoder) và "đọc chỉ dẫn" (text encoder) đều có thể làm nhiều việc hơn với chi phí rẻ hơn. SANA cân bằng lại dây chuyền: bắt máy nén ép ảnh nhỏ hơn nhiều trước khi vẽ (32× thay vì 8×), bắt công đoạn vẽ dùng kiểu "chú ý lướt" nhanh hơn thay vì so sánh từng điểm ảnh với mọi điểm ảnh khác, và đổi một "người đọc chỉ dẫn" khổng lồ (T5) bằng một người nhỏ mà thông minh hơn (một LLM nhỏ), được dặn dò rất cụ thể cách đọc prompt. Kết quả: chất lượng ảnh gần như không đổi, nhưng vẽ nhanh hơn 20–100 lần trên phần cứng rẻ hơn nhiều.
