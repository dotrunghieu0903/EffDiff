# DistriFusion: Distributed Parallel Inference for High-Resolution Diffusion Models

**Tác giả:** Muyang Li, Tianle Cai, Jiaxin Cao, Qinsheng Zhang, Han Cai, Junjie Bai, Yangqing Jia, Ming-Yu Liu, Kai Li, Song Han (MIT, NVIDIA, Princeton)
**Venue:** CVPR 2024 (**Highlight**) · arXiv 2402.19481
**Nguồn:** https://arxiv.org/abs/2402.19481 (submit v1: 29/02/2024, v4: 14/07/2024) · HTML: https://arxiv.org/html/2402.19481

> **Ghi chú xác minh:** Abstract lấy nguyên văn `/abs/`. Bảng số liệu (Table 1, Figure 6) lấy từ `/html/`, đã fetch 2 lần độc lập để loại nhiễu render — bản dưới là bản **nhất quán nội bộ** (latency giảm đơn điệu theo #GPU, khớp abstract). **Đã xác minh (khớp abstract + bảng HTML nhất quán):** speedup tới **6.1×** trên 8×A100 ở 3840×3840; ở 1024×1024/50-step, latency 1 GPU = **5.02s** → 8 GPU (Ours) = **1.77s** (**2.8×**); FID "Ours" 8 GPU = **24.4** rất gần Original **24.0** (naïve patch 8 GPU FID vỡ tới **252**). **Chưa xác minh sâu (số phụ trong bảng — tham khảo):** MACs tuyệt đối (338T), so sánh chi tiết với ParaDiGMS/tensor parallelism (số % giảm giao tiếp).
> **Nhóm 6 — vai trò "enabler hạ tầng":** đây là paper **KHÔNG đổi công thức thuật toán** (exact, không mất chất lượng về nguyên tắc) — thuộc nhánh 6B distributed/parallel inference, khác về bản chất với Nhóm 4 (caching đổi kết quả) và Nhóm 5 (kiến trúc mới).

---

# English version

## 1. Purpose of the document
High-resolution image synthesis with diffusion models is prohibitively slow for interactive use because compute scales with resolution. Existing parallelism (tensor/pipeline) either breaks patch-to-patch interaction (losing fidelity) or requires expensive synchronous communication. DistriFusion's purpose: split a single image across multiple GPUs **without quality loss**, by exploiting the fact that successive denoising steps are nearly identical.

## 2. Main content, section by section
**Introduction / Background.** SDXL needs 6,763 GMACs per step at 1024×1024 — the goal is to parallelize a *single* image generation (not just batch), which classic data/tensor/pipeline parallelism does not solve well for diffusion's iterative, communication-heavy structure.

**Related work.** Surveys diffusion acceleration (step reduction, network optimization), existing parallelism strategies (data/pipeline/tensor) and their limits for diffusion, and sparse computation.

**Method — Displaced Patch Parallelism (core contribution).**
- Split the image into patches, one per GPU.
- **Key insight:** inputs across *adjacent* denoising steps are highly similar.
- **Activation displacement / stale-feature reuse:** instead of synchronizing patch boundaries every step, each GPU reuses the **pre-computed feature map from the previous timestep** as context for cross-patch interaction at the current step — turning synchronous communication into **asynchronous, pipelined-with-compute** communication.
- **Sparse re-computation:** layers only recompute the "fresh" (newly updated) regions, cutting per-device work.
- **Corrected Asynchronous GroupNorm:** approximates the global mean/var from stale statistics plus a correction term, avoiding a synchronous global-norm reduction.
- **Warm-up steps:** the first few steps run fully synchronous (they shape low-frequency image structure), then displaced parallelism kicks in.

**Experiments.** SDXL, 1024×1024 up to 3840×3840, NVIDIA A100 (1/2/4/8 GPUs), 50-step DDIM (also 25-step DDIM, 10-step DPM-Solver), evaluated on 5K COCO Captions 2014 images.

## 3. Key conclusions
- Training-free, drop-in for an off-the-shelf SDXL — no retraining, no quality degradation vs. the original single-GPU output (FID/LPIPS ≈ unchanged).
- Up to **6.1× speedup on 8×A100** at 3840×3840; **2.8×** at 1024×1024/50-step.
- Naïve patch parallelism (no interaction) collapses quality (FID up to 252) — the displaced-reuse mechanism is what preserves fidelity.
- Beats tensor parallelism (60% less communication, 1.6–2.1× faster) and ParaDiGMS (which needs more total MACs and degrades at fewer steps).
- Became the **foundational mechanism** cited/extended by PipeFusion, xDiT, USP, STADI, CompactFusion, PCPP.

## 4. Notable figures & to-dos
**Verified (abstract + consistent HTML table):**
| #GPU | Method | Latency (s) | Speedup | FID |
|---|---|---|---|---|
| 1 | Original | 5.02 | – | 24.0 |
| 2 | Ours | 3.35 | 1.5× | 24.2 |
| 4 | Ours | 2.26 | 2.2× | 24.2 |
| 8 | Ours | 1.77 | 2.8× | 24.4 |
| 8 | Naïve Patch | 1.27 | 4.0× | 252 (collapsed) |

At 3840×3840 (Figure 6, quoted directly): "DistriFusion achieves 1.8×, 3.4× and 6.1× speedups with 2, 4, and 8 A100s, respectively."

**Unverified / secondary (indicative only):** exact MACs column (338T "Ours" vs 322–324T naïve — near-identical, plausible since patch interaction adds little extra compute); precise communication-volume numbers for the 3840×3840 tensor-parallelism comparison table (18.7G vs 5.38G).

**Stated limitations (verified quotes):** "NVLink is essential ... to maximize the speedup"; "may not work for the extremely-few-step methods ..., due to the rapid changes of the denoising states"; low-resolution gains are limited by GPU underutilization; benefits from compiler backends (TVM/TensorRT) not yet exploited.

## 5. Quick recap (< 300 words)
DistriFusion accelerates high-resolution diffusion image generation by splitting a single image across multiple GPUs — **displaced patch parallelism**. The naive way to do this (each GPU handles a patch independently) breaks cross-patch interaction and destroys quality (FID exploding to 252 at 8 GPUs); adding synchronous interaction every step would fix quality but costs too much communication. DistriFusion's insight: consecutive diffusion steps produce nearly identical inputs, so each GPU can safely use the **feature map computed one step ago** (from all patches) as "context" for the current step's boundary interactions. This converts synchronous communication into asynchronous communication that overlaps with computation (pipelined), plus a corrected async GroupNorm approximation and a short synchronous warm-up phase for the first few steps. On SDXL with 50-step DDIM at 1024×1024, this yields 1.5×/2.2×/2.8× speedup on 2/4/8 A100s, virtually matching the original model's FID/LPIPS (24.0→24.4), while naive patch parallelism at the same GPU counts collapses to FID 33.6→125→252. At the higher 3840×3840 resolution the speedup reaches 6.1× on 8 A100s. It also beats tensor parallelism (60% less communication) and ParaDiGMS (parallel-in-time Picard iterations, which need more total compute and degrade at low step counts). Training-free and exact in spirit (no algorithmic change to the diffusion process, just how compute is distributed), it is CVPR 2024 Highlight and has become the base mechanism that PipeFusion, xDiT, USP, and several 2025 follow-ups (STADI, CompactFusion, PCPP) build on or compare against. Its main caveat: it needs NVLink to fully hide communication, and it may break down for extremely-few-step samplers where consecutive steps are no longer similar.

## 6. Conference one-breath pitch (30–50 words)
**EN (≈47w):** Diffusion image synthesis is too slow at high resolution for one GPU, but naive multi-GPU patch splitting wrecks quality. DistriFusion reuses each patch's feature map from the *previous* denoising step as context, hiding communication behind compute — training-free, up to 6.1× on 8 A100s, no quality loss.

**VI (≈49 từ):** Sinh ảnh diffusion độ phân giải cao quá chậm cho một GPU, nhưng chia patch đa GPU ngây thơ thì hỏng chất lượng. DistriFusion tái dùng feature map của mỗi patch từ bước denoising *trước đó* làm ngữ cảnh, giấu giao tiếp sau tính toán — không cần train, tới 6.1× trên 8 A100, không mất chất lượng.

## 7. The essence in plain language
**The problem, plainly:** Painting a huge canvas alone takes forever. Give each of 8 painters a slice — but if they never look at their neighbor's slice, the seams don't match. If they constantly check with every neighbor before every brushstroke, they spend more time talking than painting.

**Core idea (one sentence):** Since the picture barely changes between two consecutive steps, let each painter peek at what the *whole* canvas looked like one step ago instead of stopping to ask their neighbor right now.

**Everyday analogy:** It's like a relay of translators subtitling a live speech — instead of waiting for the exact current sentence from a colleague (blocking), each translator uses the sentence from a moment ago (which is 99% still valid) to keep their own subtitle in sync, and they only pause to fully re-sync at the very start of the talk.

**If you remember only one thing:** You don't need to talk to your neighbor *right now* if what they said *a moment ago* is still almost true — that's how DistriFusion turns waiting (sync communication) into working (async, overlapped communication).

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Sinh ảnh độ phân giải cao bằng diffusion model quá chậm cho ứng dụng tương tác vì chi phí tính toán tăng theo độ phân giải. Các cách song song hoá cũ (tensor/pipeline) hoặc phá vỡ tương tác giữa các patch (mất chất lượng) hoặc cần giao tiếp đồng bộ quá đắt. Mục tiêu của DistriFusion: chia **một ảnh duy nhất** ra nhiều GPU mà **không mất chất lượng**, bằng cách khai thác việc các bước denoising liên tiếp gần như giống nhau.

## 2. Nội dung chính từng phần
**Giới thiệu / Nền tảng.** SDXL cần 6.763 GMACs mỗi bước ở 1024×1024 — mục tiêu là song song hoá việc sinh **một** ảnh (khác với song song theo batch), điều mà data/tensor/pipeline parallelism cổ điển không giải quyết tốt cho cấu trúc lặp, nặng giao tiếp của diffusion.

**Related work.** Khảo sát các hướng tăng tốc diffusion (giảm bước, tối ưu mạng), các chiến lược song song hoá hiện có (data/pipeline/tensor) và hạn chế của chúng với diffusion, cùng các kỹ thuật tính toán sparse.

**Phương pháp — Displaced Patch Parallelism (đóng góp cốt lõi).**
- Chia ảnh thành các patch, mỗi GPU nhận một patch.
- **Quan sát then chốt:** input giữa hai bước denoising **liên tiếp** rất giống nhau.
- **Dịch chuyển activation / tái dùng đặc trưng "cũ":** thay vì đồng bộ biên patch mỗi bước, mỗi GPU tái dùng **feature map đã tính từ bước trước** làm ngữ cảnh cho tương tác liên-patch ở bước hiện tại — biến giao tiếp đồng bộ thành **giao tiếp bất đồng bộ, xen kẽ (pipeline) với tính toán**.
- **Tính toán sparse:** các lớp chỉ tính lại phần "mới" (fresh), giảm khối lượng tính trên mỗi thiết bị.
- **Corrected Asynchronous GroupNorm:** xấp xỉ mean/variance toàn cục từ thống kê "cũ" cộng số hạng hiệu chỉnh, tránh phải đồng bộ hoá global-norm.
- **Bước khởi động (warm-up):** vài bước đầu chạy đồng bộ hoàn toàn (định hình cấu trúc tần số thấp của ảnh), sau đó mới chuyển sang displaced parallelism.

**Thí nghiệm.** SDXL, 1024×1024 tới 3840×3840, NVIDIA A100 (1/2/4/8 GPU), DDIM 50 bước (thêm DDIM 25 bước, DPM-Solver 10 bước), đánh giá trên 5K ảnh COCO Captions 2014.

## 3. Các kết luận quan trọng
- Training-free, cắm thẳng vào SDXL có sẵn — không train lại, không mất chất lượng so với chạy 1 GPU gốc (FID/LPIPS gần như không đổi).
- Tới **6.1× trên 8×A100** ở 3840×3840; **2.8×** ở 1024×1024/50-bước.
- Patch parallelism ngây thơ (không tương tác) làm chất lượng sập (FID tới 252) — cơ chế tái dùng dịch chuyển (displaced reuse) chính là thứ giữ được chất lượng.
- Vượt tensor parallelism (giảm 60% giao tiếp, nhanh 1.6–2.1×) và ParaDiGMS (cần nhiều MACs hơn, giảm hiệu quả khi ít bước).
- Trở thành **cơ chế nền tảng** được PipeFusion, xDiT, USP, STADI, CompactFusion, PCPP kế thừa hoặc dùng làm baseline so sánh.

## 4. Số liệu nổi bật & việc cần làm
**Đã xác minh (khớp abstract + bảng HTML nhất quán):**

| #GPU | Method | Latency (s) | Speedup | FID |
|---|---|---|---|---|
| 1 | Original | 5.02 | – | 24.0 |
| 2 | Ours | 3.35 | 1.5× | 24.2 |
| 4 | Ours | 2.26 | 2.2× | 24.2 |
| 8 | Ours | 1.77 | 2.8× | 24.4 |
| 8 | Naïve Patch | 1.27 | 4.0× | 252 (sập chất lượng) |

Ở 3840×3840 (Figure 6, trích nguyên văn): "DistriFusion achieves 1.8×, 3.4× and 6.1× speedups with 2, 4, and 8 A100s, respectively."

**Chưa xác minh sâu / phụ (chỉ tham khảo):** cột MACs tuyệt đối (338T "Ours" vs 322–324T naïve — gần như bằng nhau, hợp lý vì tương tác patch tốn thêm ít tính toán); số liệu giao tiếp chi tiết ở bảng so sánh tensor-parallelism tại 3840×3840 (18.7G vs 5.38G).

**Hạn chế đã công bố (trích nguyên văn):** "NVLink is essential ... to maximize the speedup"; "may not work for the extremely-few-step methods ..., due to the rapid changes of the denoising states"; lợi ích thấp ở độ phân giải thấp do GPU chưa được tận dụng hết; chưa khai thác compiler backend (TVM/TensorRT).

## 5. Tóm tắt ngắn (< 300 từ)
DistriFusion tăng tốc sinh ảnh diffusion độ phân giải cao bằng cách chia **một ảnh** ra nhiều GPU — **displaced patch parallelism**. Cách ngây thơ (mỗi GPU xử lý một patch độc lập) phá vỡ tương tác liên-patch và hỏng chất lượng (FID vỡ tới 252 ở 8 GPU); thêm đồng bộ mỗi bước thì chất lượng ổn nhưng chi phí giao tiếp quá lớn. Điểm mấu chốt: các bước diffusion liên tiếp cho input gần như giống nhau, nên mỗi GPU có thể an toàn dùng **feature map đã tính từ một bước trước** (của toàn ảnh) làm "ngữ cảnh" cho tương tác biên ở bước hiện tại. Điều này biến giao tiếp đồng bộ thành giao tiếp bất đồng bộ chạy song song (pipeline) với tính toán, cộng thêm một phép xấp xỉ GroupNorm bất đồng bộ có hiệu chỉnh và vài bước khởi động đồng bộ ở đầu. Trên SDXL với DDIM 50 bước ở 1024×1024, kết quả là speedup 1.5×/2.2×/2.8× trên 2/4/8 A100, FID/LPIPS gần như không đổi so với gốc (24.0→24.4), trong khi patch parallelism ngây thơ ở cùng số GPU sập từ FID 33.6→125→252. Ở độ phân giải cao hơn 3840×3840, speedup đạt 6.1× trên 8 A100. Phương pháp cũng vượt tensor parallelism (giảm 60% giao tiếp) và ParaDiGMS (Picard iteration song song-theo-thời-gian, cần nhiều tính toán hơn và giảm hiệu quả khi ít bước). Training-free và về bản chất là "exact" (không đổi công thức thuật toán diffusion, chỉ đổi cách phân phối tính toán), đây là CVPR 2024 Highlight và đã trở thành cơ chế nền cho PipeFusion, xDiT, USP cùng loạt follow-up 2025 (STADI, CompactFusion, PCPP). Hạn chế chính: cần NVLink để giấu hết giao tiếp, và có thể không hoạt động tốt với sampler cực ít bước vì lúc đó các bước liên tiếp không còn giống nhau.

## 6. Câu chốt hội nghị (30–50 từ)
**EN (≈47w):** Diffusion image synthesis is too slow at high resolution for one GPU, but naive multi-GPU patch splitting wrecks quality. DistriFusion reuses each patch's feature map from the *previous* denoising step as context, hiding communication behind compute — training-free, up to 6.1× on 8 A100s, no quality loss.

**VI (≈49 từ):** Sinh ảnh diffusion độ phân giải cao quá chậm cho một GPU, nhưng chia patch đa GPU ngây thơ thì hỏng chất lượng. DistriFusion tái dùng feature map của mỗi patch từ bước denoising *trước đó* làm ngữ cảnh, giấu giao tiếp sau tính toán — không cần train, tới 6.1× trên 8 A100, không mất chất lượng.

## 7. Bản chất nói nôm na
**Vấn đề:** Một mình vẽ cả tấm tranh khổng lồ thì quá lâu. Chia cho 8 người vẽ mỗi người một góc — nhưng nếu không ai nhìn phần của người bên cạnh, các mép ghép sẽ lệch. Nếu ai cũng phải hỏi hàng xóm trước mỗi nét vẽ, thì thời gian hỏi nhiều hơn thời gian vẽ.

**Ý tưởng cốt lõi:** Vì tranh gần như không đổi giữa hai bước liên tiếp, hãy cho mỗi người vẽ nhìn vào toàn cảnh của **một bước trước** thay vì phải dừng lại hỏi hàng xóm ngay lúc này.

**Ẩn dụ đời thường:** Giống một chuỗi phiên dịch làm phụ đề trực tiếp — thay vì chờ đúng câu hiện tại từ đồng nghiệp (bị chặn/blocking), mỗi người dùng câu của một khoảnh khắc trước (vẫn đúng 99%) để phụ đề của mình không bị lệch nhịp, và chỉ dừng lại đồng bộ hoàn toàn ở đầu buổi nói.

**Câu để đời:** Không cần hỏi hàng xóm *ngay bây giờ* nếu điều họ nói *một khoảnh khắc trước* vẫn gần như đúng — đó là cách DistriFusion biến chờ đợi (giao tiếp đồng bộ) thành làm việc (giao tiếp bất đồng bộ, xen kẽ tính toán).
