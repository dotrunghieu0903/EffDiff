# DisCa: Accelerating Video Diffusion Transformers with Distillation-Compatible Learnable Feature Caching

**Authors:** Chang Zou, Changlin Li, Yang Li, Patrol Li, Jianbing Wu, Xiao He, Songtao Liu, Zhao Zhong, Kailin Huang, Linfeng Zhang (Shanghai Jiao Tong University · Tencent Hunyuan · Xidian University)
**Venue:** CVPR 2026
**Source:** [arXiv:2602.05449](https://arxiv.org/abs/2602.05449) · [PDF](https://arxiv.org/pdf/2602.05449) · [HTML](https://arxiv.org/html/2602.05449v1) · [Code](https://github.com/Tencent-Hunyuan/DisCa)

> **Verification note.** The abstract below and the headline **11.8×** speedup are **verified** against the arXiv abstract page. All numeric values in the tables (VBench semantic/quality/total scores, latencies, per-baseline speedups, VRAM figures) were extracted from the HTML full text by an automated reader and are **NOT independently verified** — treat them as indicative and confirm against the PDF tables before citing.

---

# English version

## 1. Purpose of the document
The paper attacks the escalating compute cost of **video diffusion transformers**. Two acceleration families are dominant but flawed: **training-free feature caching** (fast, but loses semantics/detail under heavy compression) and **training-aware step distillation** (great for images, but collapses for video at few steps). Worse, naively stacking caching on top of a step-distilled model degrades badly because the distilled sampling trajectory is *sparse* — adjacent steps are no longer similar, which is exactly the assumption caching relies on. DisCa sets out to make these two techniques **compatible** and push acceleration to a new frontier without quality loss.

## 2. Main content, section by section
- **Introduction.** Motivates the core problem: under an undistilled model adjacent timesteps are similar (caching works); after distillation, large inter-step differences make traditional caching fail (Fig. 1).
- **Related work.** Two axes — *sampling-step reduction* (DDIM, DPM-Solver, MeanFlow) and *per-denoising-step acceleration* (model compression, feature caching such as TeaCache / TaylorSeer / PAB / FORA / Δ-DiT).
- **Method 3.1 — Preliminary.** Diffusion / DiT / flow matching background, naïve caching, and prior art (TaylorSeer, MeanFlow).
- **Method 3.2 — Restricted MeanFlow.** MeanFlow's aggressive one-step compression causes catastrophic distortion on large video models. Fix: restrict the flow interval from `(t−r)∈[0,1]` to `(t−r)∈[0,R]` with a restriction factor `R∈(0,1)` (e.g. R=0.2). This "conservative" scheme drops the hardest, most-compressed training scenarios and yields stable **multi-step** distillation.
- **Method 3.3 — Learnable feature caching predictor.** Replace hand-crafted caching heuristics with a **lightweight neural predictor 𝒫** (small DiT blocks, ~4% of the base model). Step 1 runs the full model ℳ to fill a cache 𝒞; the remaining N−1 steps are produced by 𝒫 from cached features + noise + timestep + conditioning. Trained with an **MSE** objective against the distilled model's outputs, plus a **GAN** objective (multi-scale discriminator + spectral norm) to preserve high-frequency detail and perceptual fidelity.
- **Integration.** Pipeline = CFG distillation → Restricted MeanFlow distillation → train the learnable predictor *on the distilled model*, so training-aware compression and training-aware caching reinforce each other.
- **Experiments.** Baseline HunyuanVideo, evaluated on VBench (semantic / quality / total), covering Restricted MeanFlow alone, the full DisCa vs. 8+ caching baselines, and ablations.
- **Conclusion.** Frames *learnable, distillation-compatible* caching as a new acceleration pathway.

## 3. Key conclusions
- Feature caching and step distillation, previously seen as an awkward pair, can be made **complementary** — but only if caching becomes *learnable* rather than heuristic.
- A **conservative** distillation (Restricted MeanFlow) beats maximally-aggressive one-step MeanFlow on large video models, because it avoids the unstable high-compression regime.
- Combining the two reaches **11.8× acceleration** with quality preserved far better than competing caching methods at comparable speed.
- The learnable predictor is small (~4% of base) and the cache is compact (single-tensor), so the speedup does not come at a heavy memory cost.

## 4. Notable figures & to-dos
**Verified:** headline **11.8×** acceleration "while preserving generation quality" (from the abstract).

**Unverified (from the HTML reader — confirm against PDF tables):**
- *Restricted MeanFlow vs. MeanFlow (HunyuanVideo, VBench):* at 10 steps (~9.68×), semantic ≈ 60.9% → **68.2%** and total ≈ 76.7% → **78.7%**; at 20 steps (~4.97×), semantic ≈ 66.6% → **70.4%**.
- *Full DisCa:* 20-step region — R=0.2, N=2 → ~152.8 s, **7.56×**, total ≈ 79.7%. 10-step region — R=0.2, N=4 → ~97.7 s, **11.8×**, total ≈ 78.8% (≈ −1.4% vs. baseline).
- *Baselines at similar budget:* TeaCache ≈ 9.22× / total −5.6%; TaylorSeer ≈ 6.96× / −4.0%; PAB ≈ 6.46× / −9.8%; Δ-DiT ≈ 4.55× / −18.4%.
- *Memory:* DisCa ≈ 97.6 GB VRAM (single-tensor cache) vs. TaylorSeer ≈ 130.7 GB, FORA ≈ 124.6 GB.
- *Ablation (remove-one from full DisCa):* removing Restricted MeanFlow hurts most (total −1.8%), then the learnable predictor (−1.0%), then GAN training (−0.3%).

**To-dos / limitations:** evaluated essentially on a single model (HunyuanVideo) at one resolution; the predictor is *not* training-free (needs the distilled model); results shown up to 11.8× only; generalization to other video/image architectures untested; GAN adds training complexity and R must be tuned.

## 5. Quick recap (< 300 words)
Video diffusion transformers are powerful but slow, needing many denoising steps. Two speed tricks dominate. **Feature caching** reuses computed features between steps — it's training-free and fast, but details and semantics degrade as you push it harder. **Step distillation** cuts the number of steps and works well for images, but for video with only a few steps it degrades sharply. And you can't simply combine them: once a model is step-distilled, its sampling trajectory becomes *sparse* — neighboring steps look very different — which breaks the "adjacent steps are similar" assumption that caching depends on.

DisCa makes the two compatible with two ideas. First, **Restricted MeanFlow**: instead of MeanFlow's most aggressive one-step compression (which causes catastrophic distortion on large video models), it restricts the flow interval to a conservative range, dropping the hardest training cases and enabling *stable multi-step* distillation. Second, a **learnable feature-caching predictor**: rather than a hand-designed caching formula, a lightweight neural network (~4% of the base model) learns to predict how features evolve. The first step runs the full model to fill a cache; the remaining steps are generated by the predictor. It's trained with MSE against the distilled model plus a GAN objective to keep high-frequency detail sharp.

Assembled as CFG distillation → Restricted MeanFlow → learnable predictor, DisCa reaches **11.8× acceleration** on HunyuanVideo with roughly a 1.4% VBench total drop — far better than caching baselines (TeaCache, TaylorSeer, PAB, Δ-DiT) at similar speeds, which lose 4–18%. It also uses a compact single-tensor cache, keeping VRAM close to the lightest baselines. Ablations confirm all three parts matter, Restricted MeanFlow most.

## 6. Conference one-breath pitch (30–50 words)
**English:** Video diffusion is slow, and feature caching breaks on step-distilled models because their steps are too sparse. DisCa makes them compatible: a conservative "Restricted MeanFlow" for stable multi-step distillation plus a tiny *learnable* caching predictor — reaching 11.8× speedup with near-lossless quality.

**Tiếng Việt:** Sinh video khuếch tán rất chậm, và feature caching hỏng trên mô hình đã step-distill vì các bước quá thưa. DisCa hợp nhất hai kỹ thuật: "Restricted MeanFlow" bảo thủ để distill đa bước ổn định, cộng một bộ dự đoán cache *học được* nhỏ gọn — đạt tăng tốc 11.8× gần như không mất chất lượng.

## 7. The essence in plain language
**Problem (one sentence):** making video-AI generate fast is hard because the two best speed-up shortcuts fight each other.
**Core idea:** stop hand-coding the shortcut — train a tiny helper to *learn* how the picture changes between steps, and distill the model gently instead of brutally, so the two tricks finally cooperate.
**Everyday analogy:** imagine drawing 50 frames of a cartoon. A "cache" is tracing from the previous frame instead of redrawing — fine when frames barely change, useless when you skip so many frames that each looks totally different. DisCa does two things: it skips frames *carefully* (not all at once), and instead of a dumb tracing rule it hires a fast junior artist who has *learned* how the scene tends to move, so they can sketch the skipped frames convincingly while the master artist rests.
**If you remember one thing:** don't guess the shortcut with a formula — teach a small model to predict it, and you can go ~12× faster with almost no quality loss.

---

# Phiên bản Tiếng Việt

## 1. Mục đích của tài liệu
Bài báo giải quyết chi phí tính toán ngày càng lớn của **video diffusion transformer**. Hai họ phương pháp tăng tốc đang phổ biến nhưng đều có nhược điểm: **feature caching không cần huấn luyện** (nhanh, nhưng mất ngữ nghĩa/chi tiết khi nén mạnh) và **step distillation có huấn luyện** (rất tốt cho ảnh, nhưng sụp đổ với video khi còn ít bước). Tệ hơn, chồng thẳng caching lên một mô hình đã step-distill khiến chất lượng giảm nặng, vì quỹ đạo lấy mẫu sau distill trở nên *thưa* — các bước kề nhau không còn giống nhau, đúng thứ giả định mà caching dựa vào. DisCa đặt mục tiêu làm hai kỹ thuật này **tương thích** với nhau và đẩy giới hạn tăng tốc lên mức mới mà không mất chất lượng.

## 2. Nội dung chính từng phần
- **Giới thiệu / Hình 1:** với mô hình chưa distill, các bước kề nhau giống nhau (caching hiệu quả); sau distill, chênh lệch giữa các bước lớn khiến caching truyền thống thất bại.
- **Công trình liên quan:** hai trục — *giảm số bước lấy mẫu* (DDIM, DPM-Solver, MeanFlow) và *tăng tốc mỗi bước khử nhiễu* (nén mô hình, feature caching như TeaCache / TaylorSeer / PAB / FORA / Δ-DiT).
- **Phương pháp 3.1 — Nền tảng:** diffusion / DiT / flow matching, caching ngây thơ, và tiền đề (TaylorSeer, MeanFlow).
- **Phương pháp 3.2 — Restricted MeanFlow:** nén một-bước quá mạnh của MeanFlow gây méo thảm khốc trên mô hình video lớn. Cách khắc phục: giới hạn khoảng flow từ `(t−r)∈[0,1]` xuống `(t−r)∈[0,R]` với hệ số giới hạn `R∈(0,1)` (ví dụ R=0.2). Cơ chế "bảo thủ" này loại bỏ các kịch bản huấn luyện bị nén mạnh nhất, cho phép distill **đa bước** ổn định.
- **Phương pháp 3.3 — Bộ dự đoán caching học được:** thay công thức caching thủ công bằng một **mạng nơ-ron nhẹ 𝒫** (các khối DiT nhỏ, ~4% mô hình gốc). Bước 1 chạy toàn bộ mô hình ℳ để nạp cache 𝒞; N−1 bước còn lại do 𝒫 sinh ra từ đặc trưng đã cache + nhiễu + timestep + điều kiện. Huấn luyện bằng mục tiêu **MSE** so với đầu ra của mô hình đã distill, cộng mục tiêu **GAN** (discriminator đa tỉ lệ + spectral norm) để giữ chi tiết tần số cao và độ trung thực thị giác.
- **Tích hợp:** quy trình = CFG distillation → Restricted MeanFlow distillation → huấn luyện bộ dự đoán *trên chính mô hình đã distill*, để nén có huấn luyện và caching có huấn luyện củng cố lẫn nhau.
- **Thực nghiệm:** baseline HunyuanVideo, đánh giá trên VBench (semantic / quality / total), gồm Restricted MeanFlow đơn lẻ, DisCa đầy đủ so với 8+ baseline caching, và ablation.
- **Kết luận:** định vị caching *học được, tương thích distillation* như một hướng tăng tốc mới.

## 3. Các kết luận quan trọng
- Feature caching và step distillation — trước đây bị xem là cặp đôi khó dung hòa — có thể trở nên **bổ trợ** cho nhau, nhưng chỉ khi caching là *học được* thay vì heuristic.
- Distillation **bảo thủ** (Restricted MeanFlow) đánh bại MeanFlow một-bước cực đoan trên mô hình video lớn, vì tránh vùng nén cao bất ổn.
- Kết hợp hai kỹ thuật đạt **tăng tốc 11.8×** với chất lượng được giữ tốt hơn nhiều so với các phương pháp caching khác ở cùng mức tốc độ.
- Bộ dự đoán nhỏ (~4% mô hình gốc) và cache gọn (single-tensor), nên tốc độ không đánh đổi bằng chi phí bộ nhớ nặng.

## 4. Số liệu nổi bật & những việc cần làm
**Đã xác minh:** con số chủ đạo **11.8×** tăng tốc "trong khi vẫn giữ chất lượng sinh" (từ abstract).

**Chưa xác minh (đọc từ HTML bằng mô hình tự động — hãy đối chiếu bảng trong PDF):**
- *Restricted MeanFlow vs. MeanFlow (HunyuanVideo, VBench):* ở 10 bước (~9.68×), semantic ≈ 60.9% → **68.2%** và total ≈ 76.7% → **78.7%**; ở 20 bước (~4.97×), semantic ≈ 66.6% → **70.4%**.
- *DisCa đầy đủ:* vùng 20 bước — R=0.2, N=2 → ~152.8 s, **7.56×**, total ≈ 79.7%. Vùng 10 bước — R=0.2, N=4 → ~97.7 s, **11.8×**, total ≈ 78.8% (≈ −1.4% so với baseline).
- *Baseline ở cùng ngân sách:* TeaCache ≈ 9.22× / total −5.6%; TaylorSeer ≈ 6.96× / −4.0%; PAB ≈ 6.46× / −9.8%; Δ-DiT ≈ 4.55× / −18.4%.
- *Bộ nhớ:* DisCa ≈ 97.6 GB VRAM (cache single-tensor) vs. TaylorSeer ≈ 130.7 GB, FORA ≈ 124.6 GB.
- *Ablation (bỏ từng thành phần khỏi DisCa đầy đủ):* bỏ Restricted MeanFlow ảnh hưởng nặng nhất (total −1.8%), rồi đến bộ dự đoán học được (−1.0%), rồi huấn luyện GAN (−0.3%).

**Việc cần làm / hạn chế:** chỉ đánh giá trên một mô hình (HunyuanVideo) ở một độ phân giải; bộ dự đoán *không* training-free (cần mô hình đã distill); kết quả chỉ tới 11.8×; chưa kiểm chứng khả năng tổng quát sang kiến trúc video/ảnh khác; GAN thêm độ phức tạp huấn luyện và phải tinh chỉnh R.

## 5. Tóm tắt ngắn (< 300 từ)
Video diffusion transformer mạnh nhưng chậm, cần rất nhiều bước khử nhiễu. Có hai mẹo tăng tốc phổ biến. **Feature caching** tái dùng đặc trưng giữa các bước — không cần huấn luyện, nhanh, nhưng chi tiết và ngữ nghĩa giảm khi ép mạnh hơn. **Step distillation** cắt số bước, tốt cho ảnh, nhưng với video chỉ vài bước thì giảm mạnh. Và không thể ghép đơn giản: khi mô hình đã step-distill, quỹ đạo lấy mẫu trở nên *thưa* — các bước kề nhau khác nhau rõ rệt — làm hỏng giả định "các bước kề nhau giống nhau" mà caching phụ thuộc.

DisCa dung hòa hai kỹ thuật bằng hai ý tưởng. Thứ nhất, **Restricted MeanFlow**: thay vì nén một-bước cực đoan của MeanFlow (gây méo thảm khốc trên mô hình video lớn), nó giới hạn khoảng flow về một dải bảo thủ, loại bỏ các ca huấn luyện khó nhất và cho phép distill *đa bước ổn định*. Thứ hai, một **bộ dự đoán caching học được**: thay vì công thức caching thiết kế tay, một mạng nhẹ (~4% mô hình gốc) học cách đặc trưng tiến hóa. Bước đầu chạy toàn bộ mô hình để nạp cache; các bước sau do bộ dự đoán sinh. Huấn luyện bằng MSE so với mô hình đã distill cộng mục tiêu GAN để giữ chi tiết tần số cao sắc nét.

Ghép thành CFG distillation → Restricted MeanFlow → bộ dự đoán học được, DisCa đạt **11.8×** trên HunyuanVideo với mức giảm VBench total khoảng 1.4% — tốt hơn hẳn các baseline caching (TeaCache, TaylorSeer, PAB, Δ-DiT) ở cùng tốc độ vốn mất 4–18%. Nó cũng dùng cache single-tensor gọn, giữ VRAM gần các baseline nhẹ nhất. Ablation xác nhận cả ba thành phần đều quan trọng, Restricted MeanFlow nhất.

## 6. Câu chốt hội nghị (30–50 từ)
**English:** Video diffusion is slow, and feature caching breaks on step-distilled models because their steps are too sparse. DisCa makes them compatible: a conservative "Restricted MeanFlow" for stable multi-step distillation plus a tiny *learnable* caching predictor — reaching 11.8× speedup with near-lossless quality.

**Tiếng Việt:** Sinh video khuếch tán rất chậm, và feature caching hỏng trên mô hình đã step-distill vì các bước quá thưa. DisCa hợp nhất hai kỹ thuật: "Restricted MeanFlow" bảo thủ để distill đa bước ổn định, cộng một bộ dự đoán cache *học được* nhỏ gọn — đạt tăng tốc 11.8× gần như không mất chất lượng.

## 7. Bản chất nói nôm na
**Vấn đề (một câu):** làm cho AI sinh video chạy nhanh rất khó, vì hai "đường tắt" tăng tốc tốt nhất lại cản nhau.
**Ý tưởng cốt lõi:** đừng viết đường tắt bằng công thức cứng — hãy huấn luyện một trợ lý nhỏ *học* xem hình thay đổi thế nào giữa các bước, và distill mô hình một cách nhẹ nhàng thay vì thô bạo, để hai mẹo cuối cùng hợp tác được.
**Ẩn dụ đời thường:** hãy tưởng tượng vẽ 50 khung hình hoạt hình. "Cache" giống như đồ lại từ khung trước thay vì vẽ lại — ổn khi các khung gần như không đổi, nhưng vô dụng khi bạn nhảy qua quá nhiều khung đến mức khung nào cũng khác hẳn. DisCa làm hai việc: nhảy khung một cách *cẩn thận* (không nhảy hết cùng lúc), và thay vì quy tắc đồ hình máy móc, nó thuê một họa sĩ trẻ vẽ nhanh đã *học* được cảnh thường chuyển động ra sao, để phác các khung bị bỏ qua một cách thuyết phục trong lúc họa sĩ chính nghỉ.
**Nếu chỉ nhớ một điều:** đừng đoán đường tắt bằng công thức — hãy dạy một mô hình nhỏ dự đoán nó, và bạn có thể chạy nhanh ~12× mà gần như không mất chất lượng.
