---
name: readpaper
description: Read a paper/document (uploaded file, local path, or arXiv/URL link) and produce a structured summary — purpose, section-by-section content, key conclusions, notable figures & to-dos, a <300-word quick recap, plus a 30–50 word conference one-breath pitch. Supports English and Vietnamese output. Use when the user asks to "read this paper", "tóm tắt bài báo/tài liệu", "đọc file này và tóm tắt", or gives a PDF/arXiv link to summarize.
---

# readpaper

Read a paper or document end-to-end and summarize it with a fixed structure, in **English** or **Vietnamese**.

## 1. Locate the source

The source may be:
- An **uploaded / local file** (PDF, Markdown, txt, docx). Use the most recently mentioned file, or ask which one if ambiguous.
- An **arXiv link** (e.g. `arxiv.org/abs/XXXX` or `arxiv.org/pdf/XXXX`) or any **web URL**.

## 2. Read the content

- **Local text files** (`.md`, `.txt`, code): use the `Read` tool directly.
- **PDF files**: try `Read` with a `pages` range. If it fails with *"pdftoppm is not installed"* (poppler not available on this machine), fall back to `WebFetch` for arXiv/URL PDFs.
- **arXiv / web URLs**: use `WebFetch`.
  - For arXiv, fetch the **abstract page** (`/abs/`) to get a reliable verbatim abstract, AND the **PDF** (`/pdf/`) with a focused prompt for section details, methods, and result tables.
  - The small model behind `WebFetch` may **hallucinate numeric values** from compressed PDFs. Cross-check every figure against the abstract. **Only report numbers you are confident about; explicitly flag any table values you could not verify** rather than inventing them.

## 3. Output format

**Always produce BOTH an English version AND a Vietnamese version** — no matter what language the user writes in. Put them in the same output under a `# English version` heading and a `# Phiên bản Tiếng Việt` heading. (The user can still say "only English" / "chỉ tiếng Việt" to opt out of one — honor that if asked, but the default is both.)

Always include a title/author line, then these sections in order:

**English version**
1. **Purpose of the document** — what it sets out to do and why.
2. **Main content, section by section** — key points of each part.
3. **Key conclusions** — the important takeaways.
4. **Notable figures & to-dos** — standout numbers/statistics, plus limitations and future work / action items. Clearly separate *verified* numbers from *unverified* ones.
5. **Quick recap (< 300 words)** — a short standalone paragraph so the reader grasps the whole thing in 2 minutes.

6. **Conference one-breath pitch (30–50 words)** — a single, dense sentence-or-two the reader could *say out loud* at an academic conference/Q&A: names the problem, the core idea, and the headline result, with **no lost meaning**. Must land in 30–50 words. If both languages are requested, give this pitch in **both** English and Vietnamese.

7. **The essence in plain language** — the very last section. Explain the paper's core idea the way you would to a non-expert listener with no jargon: state the problem in one plain sentence, give a **one-sentence "core idea"**, then an **everyday analogy** (luggage, sorting, shortcuts — something concrete), and finish with a single punchy takeaway line. This is the "if you remember only one thing" section. Keep it short and human — no formulas.

**Vietnamese version** (same structure)
1. **Mục đích của tài liệu**
2. **Nội dung chính từng phần**
3. **Các kết luận quan trọng**
4. **Số liệu nổi bật & những việc cần làm** — tách rõ số liệu *đã xác minh* và *chưa xác minh*.
5. **Tóm tắt ngắn (< 300 từ)** — một đoạn độc lập để nắm cốt lõi trong 2 phút.
6. **Câu chốt hội nghị (30–50 từ)** — một-hai câu cô đọng có thể *nói thành lời* tại hội nghị/Q&A học thuật: nêu đủ vấn đề, ý tưởng cốt lõi và kết quả nổi bật, **không thiếu ý**. Phải gói trong 30–50 từ. Nếu yêu cầu cả hai ngôn ngữ, đưa câu chốt này ở **cả** tiếng Anh lẫn tiếng Việt.
7. **Bản chất nói nôm na** — mục cuối cùng. Giải thích ý tưởng cốt lõi như đang nói cho người ngoài ngành, không thuật ngữ: nêu vấn đề bằng một câu đời thường, đưa **một câu "ý tưởng cốt lõi"**, rồi **một ẩn dụ đời thường** (vali hành lý, sắp xếp đồ, đường tắt — thứ gì đó cụ thể), và chốt bằng **một câu để đời** ("nếu chỉ nhớ một điều"). Ngắn gọn, đời thường, không công thức.

## 4. Save the output as a Markdown file

Always write the full summary to a **`.md` file** in this skill's output folder (in addition to showing it in the chat).

- **Filename:** derive it from the paper — a clean, kebab-or-Pascal-case title slug, e.g. `SVDQuant.md`. If the paper title is unknown, fall back to the arXiv id (e.g. `2411.05007.md`). Ask only if truly ambiguous.
- **Location:** `output/readpaper/` under the project root — **create the folder if it doesn't exist** (e.g. `mkdir -p output/readpaper`). This keeps skill outputs tidy instead of scattering files in the root. Use another path only if the user specifies one.
- **Contents:** the exact same structured summary produced for the chat — title/author line, source link, the verified/unverified note, and every section. If both languages are produced, put both in the one file under `# English version` and `# Phiên bản Tiếng Việt` headings.
- If a file with that name already exists, `Read` it first (it may be empty), then overwrite with `Write`.

## 5. Canonical prompt templates

Use these as the guiding instruction (they mirror the section list above).

**English**
> Read the entire file/document I provided and summarize it under these headings:
> - Purpose of the document
> - Main content, section by section
> - Key conclusions
> - Notable figures/statistics and to-dos
> Finally, add a short recap under 300 words so I can grasp all the core content in just 2 minutes, then a 30–50 word one-breath pitch I could say at a conference.

**Tiếng Việt**
> Hãy đọc toàn bộ file tôi vừa tải lên và tóm tắt theo các mục:
> - Mục đích của tài liệu
> - Nội dung chính từng phần
> - Các kết luận quan trọng
> - Số liệu nổi bật và những việc cần làm
> Cuối cùng, viết thêm một đoạn tóm tắt ngắn dưới 300 từ để tôi nắm được toàn bộ nội dung cốt lõi chỉ trong 2 phút, rồi một câu chốt 30–50 từ để tôi phát biểu tại hội nghị.

## Notes
- This machine does **not** have poppler/`pdftoppm` installed, so direct PDF page rendering via `Read` will fail — rely on `WebFetch` for PDFs until poppler is installed.
- Never fabricate metrics. Honesty about what could not be extracted is required.
