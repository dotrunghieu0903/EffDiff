---
name: survey
description: Collect a state-of-the-art literature survey of research papers for a topic or a set of technique groups, from arXiv or reputable venues (CVPR/ICCV/ECCV/NeurIPS/ICML/ICLR/SIGGRAPH, etc.), within a target time window. Every paper is discovered via real search and its URL is VERIFIED (no hallucinated titles/IDs/links). Produces a deduplicated, categorized table with verification status. Supports English and Vietnamese. Use when the user asks to "khảo sát / thu thập paper SOTA", "build a literature survey", "tìm các paper state-of-the-art", "collect papers for a survey/thesis related work".
---

# survey

Build a **state-of-the-art literature survey**: discover, verify, deduplicate, and categorize real papers for a topic or set of technique groups.

## ⛔ The one non-negotiable rule: NO hallucinated papers

A large model will happily invent plausible-looking titles, authors, arXiv IDs, and URLs. This skill exists to prevent that.

- **Never** write a paper title, author list, arXiv ID, DOI, or URL from memory.
- Every entry MUST come from a **tool result** (`WebSearch` / `WebFetch`), and its URL MUST be **verified to resolve to a page whose title matches** before it is listed.
- If a candidate cannot be verified, either drop it or list it in a separate **"Unverified / needs manual check"** section — clearly labeled. Never mix unverified items into the main table.
- Prefer canonical identifiers: arXiv `/abs/ID`, ACL Anthology, OpenReview forum id, DOI, or the official proceedings page.
- The user has said they will spot-check URLs — earn that trust: it is better to return fewer verified papers than many shaky ones.

**Fabricated-ID pattern (learned the hard way):** web-search *summarizers* frequently emit plausible titles paired with **impossible arXiv IDs** — most often a future/too-high month prefix (e.g. `2602.xxxxx`, `2605.xxxxx`, `2607.xxxxx` when the real month is earlier) or an implausibly high sequence number. Treat these as fabricated: **drop them.** Separately, when a *borderline-but-possibly-real* recent ID appears (e.g. a genuine `26MM.xxxxx` that is high but the month has actually passed), **re-fetch it yourself** to confirm title + authors + submission date before trusting a subagent's "verified" claim. Do not let a subagent's ✅ substitute for a suspicious ID you can cheaply re-check.

## 1. Scope the survey

Confirm (or infer, then state) up front:
- **Technique groups / sub-topics** to cover. Default groups for *diffusion efficiency optimization* (from MASTERPLAN.md) — **6 groups**:
  1. **Distillation** — consistency models (sCM, CM, LCM, rCM), DMD/DMD2, ADD/LADD, progressive/adversarial distillation, MeanFlow.
  2. **Fast solvers / samplers** — DPM-Solver(++), DEIS, UniPC, higher-order ODE/SDE solvers, flow-matching solvers.
  3. **Quantization & pruning** — PTQ/QAT for diffusion, sparsity, low-bit UNet/DiT, structural pruning.
  4. **Caching & feature reuse** — step/feature caching, DeepCache, block caching, token merging, forecast caching.
  5. **Efficient architectures** — latent diffusion, efficient/linear attention DiT, efficient autoencoders, mobile/edge diffusion.
  6. **System / kernel-level optimization** — attention kernels (FlashAttention family, quantized/sparse attention), distributed/parallel inference (DistriFusion, xDiT, PipeFusion), compilation/serving/low-precision execution. This is the **infrastructure tier**: it optimizes *execution* (often exact, no quality change), distinct from the algorithm/model tiers (1–5).
- **Time window** — default **2024–2026** to stay SOTA.
- **SOTA vs. anchor counting (important):** distinguish 🆕 **SOTA (in-window, 2024–2026)** from 📌 **foundational anchors (pre-window, older seminal papers)**. **Only SOTA papers count toward the target quota**; anchors are kept for provenance but grouped separately and NOT counted. Aim for the quota in in-window papers alone.
- **Venue bar** — arXiv OR reputable venues: CVPR, ICCV, ECCV, NeurIPS, ICML, ICLR, SIGGRAPH/TOG, AAAI, WACV, TPAMI, JMLR, ACM MM, ACL/EMNLP (if relevant).
- **Target count** per group (e.g. **≥10 SOTA** each, anchors on top) so coverage is balanced.

## 2. Discovery strategy (aim for exhaustive, not lucky)

Run these passes; combine and dedupe. Do multiple `WebSearch` queries per group with varied phrasing.

1. **Keyword search** per group — vary terms and synonyms; include `arxiv`, the year, and venue names. Example queries:
   - `"consistency model" diffusion distillation 2025 arxiv`
   - `diffusion model post-training quantization 2024 CVPR`
   - `feature caching diffusion acceleration 2025`
2. **Venue sweep** — search proceedings/OpenReview directly (`site:openreview.net diffusion distillation 2025`, `CVPR 2025 diffusion acceleration`).
3. **Survey/benchmark anchor** — find a recent *survey* paper for each group; its reference list is a high-recall seed.
4. **Citation snowballing** — for each key paper, look at what cites it and what it cites (Semantic Scholar / Connected Papers / Google Scholar). This is the single biggest recall booster.
5. **Aggregators** — Papers With Code (leaderboards per task), Semantic Scholar, DBLP author pages of prolific groups.

## 3. Verification workflow (per candidate)

1. `WebFetch` the canonical URL (prefer arXiv `/abs/`).
2. Confirm the page **loads** and the **title + authors + year** match the candidate. Cross-host redirects mean re-fetch the redirect URL.
3. Record: canonical URL, exact title, first author + "et al.", year, venue, and a one-line contribution **taken from the abstract** (not invented).
4. Mark **Verified ✅**. If it fails, move to the unverified section with the reason.

## 4. Deduplicate & categorize

- Dedupe by normalized title / arXiv id (a paper may appear as both arXiv + camera-ready — keep the canonical, note the venue).
- Assign each paper to exactly one primary group. **A paper that fits two groups is listed once** in its best-fit group with a cross-reference note in the other — never duplicate the row (e.g. a mobile-diffusion paper belongs in *efficient architectures* OR *system-level*, not both; FP-quantization sits between *quantization* and *execution* — pick one and note the overlap).

## 4b. Running it at scale (parallel subagents)

For a multi-group survey, **dispatch one subagent per group in parallel** (a single message with multiple Agent calls). Give each subagent: its group scope + keywords, the strict anti-hallucination rules above, an **exclusion list** of papers already collected (for expansion rounds), and the required return-table format. Then **you** merge, dedupe across groups, re-verify any suspicious IDs, and assemble the final document. This is far faster than one sequential pass and keeps each subagent's context focused.

## 5. Output format

Match the user's language (default Vietnamese if they write Vietnamese; both if asked). Structure:

- **Scope block** — groups, time window, venue bar, counting rule (SOTA counts, anchors don't), date of search.
- **Per group, TWO sub-tables** (this cleanly satisfies "keep anchors grouped, count only SOTA"):
  - 🆕 **SOTA 2024–2026** — numbered `1…N` (this N is the counted quota).
  - 📌 **Foundational anchors** — numbered `A1…` and labeled **"NOT counted toward quota"**, grouped at the end of the group.
  - Columns: **# · Title · First author, Year · Venue · URL (verified) · Core contribution (1 line) · Status**. Add a **"Domain-specific?"** column when a group mixes purpose-built vs. general-primitive papers (e.g. system-level kernels).
- **Summary coverage table** — per group: 🆕 SOTA count · 📌 anchor count · total.
- **Coverage note** — honest gaps ("group 4 thin, only N verified"; "no 2026 paper survived verification").
- **Unverified / needs manual check + overflow** — separate table, clearly labeled, with the reason each could not be verified or was trimmed.
- **Methodology note** — which queries/sources were used, so the search is reproducible and auditable.

**Save the survey** to this skill's output folder — **`output/survey/` under the project root, created if it doesn't exist** (e.g. `mkdir -p output/survey`), as `SURVEY.md` (or a topic-slug filename). This keeps skill outputs tidy instead of scattering files in the root. If the file already exists, `Read` it first, then overwrite with `Write`. Use another path only if the user specifies one.

## 6. Rigor for a thesis (offer if relevant)

For a master-thesis-grade survey, offer a lightweight **PRISMA-style** protocol: record search sources, queries, inclusion/exclusion criteria, counts at each stage (identified → screened → included). This makes the "Related Work" defensible.

## 7. Optional enrichment: citation counts & influence

Citation counts are a useful signal of impact (and, for recent papers, of momentum). Add them when asked, or offer them.

- **Source of truth — never invent a citation number.** Fetch from the **Semantic Scholar API** (works through `WebFetch`, returns JSON):
  `https://api.semanticscholar.org/graph/v1/paper/arXiv:<ID>?fields=title,year,citationCount,influentialCitationCount`
  Extract `citationCount` and `influentialCitationCount` from the actual JSON. If a fetch fails or returns no data, record **N/A** — do not guess.
- **Rate limiting is real.** The unauthenticated API returns frequent **HTTP 429**. Pace requests and retry once on 429; mark N/A if it still fails. Spreading fetches across one subagent per group helps. (If available, an API key or the batch POST endpoint avoids most 429s.)
- **Always timestamp** — counts change daily. Label the column e.g. "Citations (S2, <date>)".
- **Correct for age bias — the key methodological point.** Raw citation count unfairly favors older/foundational papers; a 2022 anchor will always out-cite a 2025 SOTA paper. So ALSO report a velocity proxy: **citations ÷ months since submission** (derive months from the arXiv `YYMM` prefix vs. the search date). This is what surfaces "new but rapidly rising" SOTA — exactly the papers a fresh survey should highlight.
- **Present it** as an extra column per row (`Citations (S2, date)`) plus an optional **"⚡ fast-rising"** callout listing recent (in-window) papers with unusually high cites/month for their age. Optionally use cites/month as a soft ranking/filter within each group — but never drop a methodologically important paper just because it is new and uncited yet.

## Canonical prompt templates

**English**
> Collect the state-of-the-art papers for these technique groups, from arXiv or reputable conferences, within <time window>. Verify every URL — do not hallucinate titles or links. Present a deduplicated, categorized table with a verification status column.

**Tiếng Việt**
> Thu thập các paper state-of-the-art cho các nhóm kỹ thuật sau, từ arXiv hoặc các hội nghị uy tín, trong khoảng <thời gian>. Xác minh mọi URL — không bịa tiêu đề hay đường dẫn. Trình bày bảng đã khử trùng lặp, phân nhóm, có cột trạng thái xác minh.

## Notes
- Tools: `WebSearch` for discovery, `WebFetch` for verification AND for the Semantic Scholar citation API (both are plain GETs). poppler is NOT installed, so PDFs go through WebFetch.
- Authenticated scholarly MCP servers may be unavailable in non-interactive sessions; rely on WebSearch/WebFetch + the Semantic Scholar public API.
- Related skills: [readpaper](../readpaper/SKILL.md), [critiquepaper](../critiquepaper/SKILL.md), [paperreport](../paperreport/SKILL.md), [actionplan](../actionplan/SKILL.md).
