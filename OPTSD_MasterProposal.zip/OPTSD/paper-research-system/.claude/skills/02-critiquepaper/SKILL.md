---
name: critiquepaper
description: Evaluate a paper/document as a domain expert (not just summarize) — analyze strengths, limitations, unproven assumptions, potential risks, and notable opportunities. Works on an uploaded file, local path, or arXiv/URL link. Supports English and Vietnamese output. Use when the user asks to "đánh giá tài liệu dưới góc độ chuyên gia", "critique this paper", "phân tích điểm mạnh/điểm yếu", or wants a critical expert review rather than a summary.
---

# critiquepaper

Read a paper or document and deliver an **expert critical evaluation** — not a summary — in **English** or **Vietnamese**.

## 1. Locate the source

May be an uploaded/local file (PDF, Markdown, txt, docx), an arXiv link, or any web URL. Use the most recently referenced source; ask if ambiguous.

## 2. Read the content

- **Local text files** (`.md`, `.txt`, code): use `Read`.
- **PDF files**: try `Read` with a `pages` range; if it fails with *"pdftoppm is not installed"* (poppler not on this machine), fall back to `WebFetch`.
- **arXiv / web URLs**: use `WebFetch`. For arXiv, fetch the `/abs/` page for a reliable verbatim abstract AND the `/pdf/` with focused prompts for method, experiments, ablations, and limitations.
- The model behind `WebFetch` may **hallucinate numbers and technical details** from compressed PDFs. Treat body-text extraction skeptically, cross-check against the abstract, and **explicitly separate what the paper claims from your own expert reasoning**. Flag anything you could not verify; never invent metrics.

## 3. Ground the critique before writing

A good expert critique is domain-aware, not generic. Before writing:
- Position the work against its **closest alternatives / prior art** (what school of methods does it belong to, what does it compete with, what trade-off is it navigating).
- Distinguish the paper's **central claim** from its **secondary claims**, and note where a claim is "matches / on par" vs "beats".
- Identify the **load-bearing assumption** the whole approach rests on.

## 4. Prior-art check on the research gaps (novelty search)

A critique's "opportunities / follow-up directions" are only useful if they are still *open*. Before finalizing, take each **concrete, researchable gap** you identified (e.g. for TinyFusion: "prune attention and MLP layers independently", "extend to text-to-image") and **search the world's literature to see whether it has already been done** as of today's date.

- Use `WebSearch` with targeted queries (paper title + gap phrasing, method keywords, "arXiv", venue names). Then **`WebFetch` the candidate's `/abs/` page to VERIFY** title + authors + year + that it truly addresses the gap. Never cite a hallucinated title/ID/link — same verification bar as the survey skill.
- Be **date-aware**: state the search date explicitly. Only count work that exists *now*; do not invent future arXiv IDs (future-year prefixes like 2602–2607 are fabrications).
- Classify each gap as one of: **🔴 đã có người làm** (link + 1-line what they did + how it overlaps/differs), **🟡 làm một phần / lân cận** (related but leaves room), **🟢 chưa thấy ai làm** (searched, nothing found — the strongest opening for the user's own contribution).
- If a search is inconclusive, say so honestly ("tìm chưa ra, cần snowballing thêm") rather than declaring the gap open or closed.

## 5. Output format

Match the user's language (default Vietnamese if they write Vietnamese; otherwise English; produce both if they ask for "both / cả hai"). Start with a short paragraph positioning the work in its field, then:

**English**
1. **Strengths** — what is genuinely strong and why (substantive, not flattery).
2. **Limitations** — real weaknesses in method, evaluation, or scope.
3. **Unproven assumptions** — claims taken for granted that lack sufficient evidence; call out the load-bearing one.
4. **Potential risks** — reproducibility, evaluation validity, hidden costs, deployment/safety, generalization risks.
5. **Notable opportunities** — where this could lead, reusable pieces, follow-up directions.

6. **Research-gap prior-art check** — for each concrete gap, report 🔴/🟡/🟢 status with verified links and the search date, per Section 4. This is what tells the reader whether an "opportunity" is still theirs to take.

7. **Three rebuttal questions & model answers** — the kind a reviewer/committee would press the authors on. Each question must target something load-bearing (a central assumption, a fairness-of-comparison issue, an evaluation-validity issue — not trivia). For each, give a *model answer* that first states the strongest defense of the paper, then explicitly names what remains open/unproven ("Điểm còn để ngỏ"). Keep questions and answers grounded in the paper, not generic.

End with a **one-sentence verdict**.

**Tiếng Việt**
1. **Điểm mạnh**
2. **Điểm hạn chế**
3. **Những giả định chưa được chứng minh** (chỉ rõ giả định trung tâm)
4. **Rủi ro có thể phát sinh**
5. **Cơ hội đáng chú ý**
6. **Kiểm tra khe hở nghiên cứu — đã có ai làm chưa** — với mỗi khe hở cụ thể, báo trạng thái 🔴 đã có người làm / 🟡 làm một phần-lân cận / 🟢 chưa thấy ai làm, kèm **link đã xác minh** và **ngày tìm kiếm** (theo Mục 4). Đây là phần cho người đọc biết "cơ hội" có còn để họ khai thác hay không.
7. **Ba câu hỏi phản biện & đáp án gợi ý** — loại câu hỏi mà reviewer/hội đồng sẽ chất vấn tác giả. Mỗi câu nhắm vào điểm chịu tải (giả định trung tâm, tính công bằng của so sánh, hiệu lực đánh giá — không hỏi vụn vặt). Đáp án gợi ý nêu trước cách bảo vệ paper mạnh nhất, rồi chỉ rõ **"Điểm còn để ngỏ"**. Câu hỏi và đáp án phải bám sát paper, tránh chung chung.

Kết thúc bằng **một câu kết luận đánh giá**.

## 6. Save the output as a Markdown file

Always write the full critique to a **`.md` file** in this skill's output folder (in addition to showing it in the chat).

- **Filename:** `<paper-slug>-critique.md`, e.g. `SVDQuant-critique.md`. Fall back to the arXiv id (`2411.05007-critique.md`) if the title is unknown. Ask only if truly ambiguous.
- **Location:** `output/critiquepaper/` under the project root — **create the folder if it doesn't exist** (e.g. `mkdir -p output/critiquepaper`). This keeps skill outputs tidy instead of scattering files in the root. Use another path only if the user specifies one.
- **Contents:** the exact same critique produced for the chat — positioning paragraph, all sections (including the three rebuttal questions & answers), the verified/unverified note, and the one-sentence verdict. If both languages are produced, put both in the one file under clear language headings.
- If a file with that name already exists, `Read` it first, then overwrite with `Write`.

## 7. Canonical prompt templates

**English**
> Evaluate this document as a domain expert rather than merely summarizing it. Analyze clearly: strengths, limitations, unproven assumptions, potential risks, and notable opportunities.

**Tiếng Việt**
> Hãy đánh giá tài liệu này dưới góc độ chuyên gia thay vì chỉ tóm tắt. Phân tích rõ: điểm mạnh, điểm hạn chế, những giả định chưa được chứng minh, rủi ro có thể phát sinh và cơ hội đáng chú ý.

## Notes
- Be critical and specific; avoid boilerplate praise/criticism that would apply to any paper.
- Clearly label expert inference vs. what the document actually states.
- This machine does **not** have poppler/`pdftoppm`, so rely on `WebFetch` for PDFs until it is installed.
- Related skill: [readpaper](../readpaper/SKILL.md) for a structured summary instead of a critique.
