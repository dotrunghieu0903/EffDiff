---
name: paperreport
description: Turn a paper/document into a complete professional report — executive summary, current-state assessment, key findings, prioritized action recommendations, and conclusion. Visualizes any numbers as tables. Works on an uploaded file, local path, or arXiv/URL link. Supports English and Vietnamese output. Use when the user asks to "biến tài liệu này thành báo cáo hoàn chỉnh", "turn this into a report", "viết báo cáo từ file này", or wants a polished business/technical report rather than a plain summary.
---

# paperreport

Turn a paper or document into a **complete, professional report** with tables for any quantitative data, in **English** or **Vietnamese**.

## 1. Locate the source

May be an uploaded/local file (PDF, Markdown, txt, docx), an arXiv link, or any web URL. Use the most recently referenced source; ask if ambiguous.

## 2. Read the content

- **Local text files** (`.md`, `.txt`, code): use `Read`.
- **PDF files**: try `Read` with a `pages` range; if it fails with *"pdftoppm is not installed"* (poppler not on this machine), fall back to `WebFetch`.
- **arXiv / web URLs**: use `WebFetch`. For arXiv, fetch the `/abs/` page for a reliable verbatim abstract AND the `/pdf/` with focused prompts for methods, experiments, and result tables.
- The model behind `WebFetch` may **hallucinate numbers** from compressed PDFs. Cross-check every figure against the abstract. In tables, **mark each number as "verified" vs "unverified"** and never invent metrics.

## 3. Output format

A polished, cleanly formatted report. Start with a header block (title, source citation, report date), then these sections in order. Match the user's language (default Vietnamese if they write Vietnamese; otherwise English; both if they ask).

**English**
1. **Executive Summary** — the whole story in one tight block: what it is, core value, headline numbers.
2. **Current-State Assessment** — position the work vs prior art / alternatives; where it stands in the field. Use a comparison table when it clarifies.
3. **Key Findings** — the important discoveries, ideally as a numbered findings table (finding → significance). Include a separate **notable-figures table** with a status column (verified / unverified).
4. **Prioritized Action Recommendations** — a table with columns: Priority (P0/P1/P2), Owner/Audience, Action, Rationale.
5. **Conclusion** — overall judgment, key caveats, and one clear overall recommendation.

**Tiếng Việt**
1. **Tóm tắt tổng quan**
2. **Đánh giá hiện trạng**
3. **Các phát hiện quan trọng** (bảng phát hiện + bảng số liệu nổi bật có cột trạng thái: đã xác minh / chưa xác minh)
4. **Đề xuất hành động theo thứ tự ưu tiên** (bảng: Ưu tiên / Đối tượng / Hành động / Lý do)
5. **Kết luận**

## 4. Presentation rules

- **Visualize numbers as tables.** Any time there are ≥2 comparable figures, put them in a table rather than prose.
- Keep it **mạch lạc, chuyên nghiệp** (clear, professional): headings, short paragraphs, consistent terminology.
- Every quantitative claim carries a **verified / unverified** status when the source could not be fully read.
- Prioritization must be **actionable and specific**, not generic advice.
- **Save the report** (in addition to showing it in the chat) to this skill's output folder — **`output/paperreport/` under the project root, created if it doesn't exist** (e.g. `mkdir -p output/paperreport`), as `<paper-slug>-report.md`. This keeps skill outputs tidy instead of scattering files in the root. If the file already exists, `Read` it first, then overwrite with `Write`. Use another path only if the user specifies one.

## 5. Canonical prompt templates

**English**
> Turn the content of this file into a complete report, including: executive summary, current-state assessment, key findings, prioritized action recommendations, and a conclusion. Present it clearly and professionally. If there are any figures, visualize them with tables.

**Tiếng Việt**
> Biến nội dung file này thành một báo cáo hoàn chỉnh, bao gồm: tóm tắt tổng quan, đánh giá hiện trạng, các phát hiện quan trọng, đề xuất hành động theo thứ tự ưu tiên và kết luận. Trình bày mạch lạc, chuyên nghiệp. Nếu có số liệu, hãy trực quan hóa bằng bảng biểu.

## Notes
- This machine does **not** have poppler/`pdftoppm`, so rely on `WebFetch` for PDFs until it is installed.
- Related skills: [readpaper](../readpaper/SKILL.md) (structured summary) and [critiquepaper](../critiquepaper/SKILL.md) (expert critique).
