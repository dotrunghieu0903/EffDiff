---
name: actionplan
description: Build a detailed, ready-to-execute action plan from a topic, thesis title, project brief, paper, or document. Breaks work into phases, each with concrete goals, a task list, owner/responsible person, completion timeline, priority level, and KPIs. Presents everything as tables. Supports English and Vietnamese output. Use when the user asks to "xây dựng kế hoạch hành động", "lập kế hoạch chi tiết theo giai đoạn", "build an action plan / roadmap", "chia nhỏ thành từng giai đoạn với timeline/KPI", or wants a project/thesis execution plan.
---

# actionplan

Turn a topic, thesis title, brief, or document into a **detailed, ready-to-execute action plan**, presented as **tables**, in **English** or **Vietnamese**.

## 1. Understand the input

The input may be a **topic / thesis title / project goal** given directly, OR a **file / arXiv link / URL** to base the plan on.
- If it's a file/link, read it first (see reading rules below) to ground the plan in real content.
- If it's just a title/topic, position it in its domain and infer the natural workstreams before planning.

**Reading rules** (when a source is provided):
- Local text files (`.md`, `.txt`, code): use `Read`.
- PDF: try `Read` with a `pages` range; if it fails with *"pdftoppm is not installed"*, fall back to `WebFetch`.
- arXiv/URL: use `WebFetch`. Cross-check numbers; never invent metrics.

## 2. State assumptions up front

Before the tables, briefly state the planning assumptions the user can adjust: total duration, roles/owners (and their abbreviations), start date, and any scope decisions. Convert relative timing to absolute dates when a start date is known. Make owners generic-but-realistic if the real team is unknown (e.g. for a thesis: Student, Advisor, Lab).

## 3. Output format

Match the user's language (default Vietnamese if they write Vietnamese; otherwise English; both if asked). Structure:

1. **Header** — plan title + the assumptions block.
2. **Phase overview table** — columns: Phase # · Phase name · Timeline · Priority · Deliverable. Overlap phases deliberately so there is no idle waiting; note this.
3. **One section per phase** — a one-line **goal**, then a task table with columns:
   **Task · Owner (người phụ trách) · Timeline · Priority (ưu tiên) · KPI**.
4. **Overall success criteria table** (target metrics) when the domain has measurable outcomes.
5. **Risks & mitigations table** — columns: Risk · Severity · Mitigation.

**Vietnamese column headers:** Công việc · Người phụ trách · Timeline · Ưu tiên · KPI đánh giá. Phase table: GĐ · Tên giai đoạn · Thời gian · Ưu tiên · Kết quả bàn giao.

## 4. Quality rules

- **Everything actionable.** Each task must be concrete enough to start; each KPI must be measurable (a number, a threshold, or a clear yes/no artifact).
- **Priorities** use a consistent scale (e.g. Rất cao / Cao / Trung bình / Thấp, or P0/P1/P2).
- **Timelines** are specific (week ranges or dates), and phases may overlap.
- Prefer **tables over prose** — the user wants to apply it immediately.
- If asked to export, write the plan to a `.md` file in this skill's output folder — **`output/actionplan/` under the project root, created if it doesn't exist** (e.g. `mkdir -p output/actionplan`). This keeps skill outputs tidy instead of scattering files in the root. Confirm the target filename; if overwriting, inspect the existing file first. Use another path only if the user specifies one.

## 5. Canonical prompt templates

**English**
> Based on this topic/document, build a detailed action plan. Break it into phases, each with: concrete goals, a task list, the responsible person, completion timeline, priority level, and evaluation KPIs. Present it as tables so I can apply and execute it immediately.

**Tiếng Việt**
> Dựa trên nội dung này, hãy xây dựng một kế hoạch hành động chi tiết. Chia nhỏ thành từng giai đoạn với: mục tiêu cụ thể, danh sách công việc, người phụ trách, timeline hoàn thành, mức độ ưu tiên và các chỉ tiêu (KPI) đánh giá. Trình bày dạng bảng để tôi có thể áp dụng triển khai ngay.

## Notes
- This machine does **not** have poppler/`pdftoppm`; rely on `WebFetch` for PDFs until it is installed.
- Related skills: [readpaper](../readpaper/SKILL.md), [critiquepaper](../critiquepaper/SKILL.md), [paperreport](../paperreport/SKILL.md).
