---
name: algoviz
description: Re-implement an algorithm from a paper in a new, easy-to-grasp way and visualize it with charts, animations, worked samples and examples. Takes a readpaper *.md summary, a paper (PDF/arXiv/URL), or existing paper/repo code as the source, cleanly re-codes the algorithm instrumented to record its intermediate states, then produces a runnable Google Colab notebook (.ipynb) with matplotlib animations + interactive Plotly charts AND a standalone interactive HTML companion. All output is in English. Use when the user asks to "visualize this algorithm", "code and visualize an algorithm", "make an animation/diagram explaining an algorithm", "create a Colab notebook illustrating an algorithm", "explain algorithm with animated diagrams", or "turn this paper's method into an interactive demo".
---

# algoviz

Turn an algorithm into an **intuitive, visual, runnable demo**. The output is two artifacts driven by the *same* recorded execution trace:

1. A **Google Colab notebook** (`.ipynb`) — clean re-implementation + narration + matplotlib animation + interactive Plotly charts.
2. A **standalone interactive HTML** (`.html`) — play/pause/step/slider replay of the same trace, no install needed.

The guiding principle is **"record once, replay everywhere"**: re-code the algorithm so that each meaningful step appends a *snapshot* to a `frames` list. That single trace drives the matplotlib animation, the Plotly views, and the HTML player — so all three stay perfectly consistent.

**All output is in English only** — notebook narration, markdown cells, HTML text, frame captions, and the delivery summary. (Regardless of the language the user writes their request in.) Instructions below are the process you follow.

## 1. Locate & understand the source

The algorithm description can come from (the user may give several — reconcile them):
- A **readpaper `.md` file** (output of the `01-readpaper` skill) — the preferred structured source. Look in **`output/readpaper/`** first (that's where readpaper now saves), then the project root as a fallback. Use `Read`.
- A **paper**: PDF / arXiv / web URL. Read it like the `01-readpaper` skill does (`Read` with `pages`; fall back to `WebFetch` for arXiv/URL PDFs — poppler/`pdftoppm` is **not** installed here). Cross-check any numbers; never fabricate.
- **Existing code** from the paper's repo (GitHub link or local path). This is the ground truth for behavior — read it to get the exact algorithm, then simplify.

If the source is ambiguous or multiple algorithms are present, ask **which algorithm** to visualize before building.

## 2. Extract the algorithm skeleton

Before writing any code, write down (briefly, in the chat) so the user can correct you:
- **Name & one-line purpose** of the algorithm.
- **Inputs → Outputs** with concrete types/shapes.
- **Core steps** in plain pseudocode (numbered).
- **The key insight / "aha"** — the one idea that makes it work. This is what the visualization must make *obvious*.
- **The hardest thing to picture** — the part people usually get wrong. The animation should target exactly this.
- **A tiny running example** — pick the smallest inputs that still show the interesting behavior (e.g. an array of 6–10 numbers, a 4×4 matrix, ~20 sample points). Small enough to follow by hand.

## 3. Choose the visual story

Pick the visualization idiom from the algorithm's *class*, not by habit. See [references/viz-patterns.md](references/viz-patterns.md) for the mapping (sorting/search → bars & pointers; graph/tree → node-link; optimization/gradient → loss surface + descent path; sampling/diffusion → point cloud over time; matrix/linear-algebra → heatmaps; pruning/compression → structure diagram with dropped parts greyed; sequence/DP → filling table; etc.).

For **color, palettes, axes, legends and accessibility**, follow the project's `dataviz` skill — invoke or read it before choosing chart colors. Use a colorblind-safe categorical palette; keep one consistent color meaning across all views (e.g. "active element" is always the same accent).

Decide the **stages** of the story: each stage is one visual answer to "what just happened and why". Aim for 3–6 stages, ending on the "aha".

## 4. Re-implement the algorithm, instrumented

Re-write the algorithm in **clean, heavily-commented Python** that a newcomer can read — favor clarity over the paper's terse notation, but keep it faithful (note any simplification you make).

Instrument it with a recorder so the run emits a trace. Use the `Tracer` pattern from [references/notebook-template.md](references/notebook-template.md):

```python
tracer = Tracer()
# inside the algorithm, at each meaningful step:
tracer.snap(state=..., highlight=..., caption="what happened & why")
```

Each snapshot must be **self-contained** (a full picture of the state at that step) and carry a short human caption. The list of snapshots is the single source of truth for every visualization. Verify the algorithm is correct by running it on the tiny example and checking the output before animating.

## 5. Build the Colab notebook (`.ipynb`)

Construct the notebook cell-by-cell (write the `.ipynb` JSON with `Write`, or use `NotebookEdit`). Follow the cell structure in [references/notebook-template.md](references/notebook-template.md). Required cells, in order:

1. **Title + Colab badge** (markdown) — title, source citation/link, and an "Open in Colab" badge.
2. **The idea in 60 seconds** (markdown) — plain-language problem, the core idea, an everyday analogy, and one "if you remember one thing" line. No formulas here.
3. **Setup** (code) — `pip install`/imports; must run clean on a fresh Colab (matplotlib, plotly, numpy, ipywidgets).
4. **The algorithm, commented** (code) — the instrumented re-implementation.
5. **Run on a tiny example** (code) — build `frames`, print the result, sanity-check.
6. **Animated walkthrough** (code) — matplotlib `FuncAnimation` over `frames`; render inline via `HTML(anim.to_jshtml())` (works in Colab) and also save a `.gif`/`.mp4`.
7. **Interactive exploration** (code) — Plotly figure(s) with a frame slider / hover, and/or `ipywidgets` sliders for key hyperparameters so the user can *feel* their effect.
8. **Try it yourself** (markdown + code) — parameterized cell inviting the reader to change inputs.
9. **Recap & the "aha"** (markdown) — what the visuals revealed; tie back to the paper.

Keep each code cell runnable independently after Setup. Prefer small, fast examples so the whole notebook runs in under ~1 minute on free Colab (no GPU assumptions unless the algorithm truly needs one — if so, provide a CPU-sized toy version).

## 6. Build the interactive HTML companion (`.html`)

Export the recorded `frames` to JSON and embed them in a single self-contained HTML file (no external build, works by double-click). Use [references/html-template.html](references/html-template.html) as the scaffold: it has play/pause, step forward/back, a frame slider, a speed control, and a canvas/SVG render area plus a caption line. You supply only the per-frame `draw(frame)` function for this algorithm and paste the `FRAMES` JSON.

The HTML must render the **same trace** as the notebook — do not re-derive states in JS; replay the exported ones.

## 7. Save the outputs & deliver

Save both artifacts to this skill's output folder — **`output/algoviz/` under the project root, created if it doesn't exist** (e.g. `mkdir -p output/algoviz`). This keeps skill outputs tidy instead of scattering files in the root. Use another path only if the user specifies one.
- `output/algoviz/AlgoName-viz.ipynb`
- `output/algoviz/AlgoName-viz.html`
Derive `AlgoName` from the algorithm (kebab/Pascal slug). If a file exists, `Read` then overwrite with `Write`.

In the chat, give the user:
- A short **"what the visualization shows"** summary.
- The file paths.
- A ready-to-use **Colab link**: `https://colab.research.google.com/github/<user>/<repo>/blob/<branch>/<path>` if the repo is on GitHub, otherwise instruct: *upload the `.ipynb` to Colab (File → Upload notebook) or push to GitHub and open via colab.research.google.com/github/...*. Do **not** invent a working URL for a repo that isn't pushed.
- One line on how to open the HTML (double-click / drag into a browser).

## Notes & guardrails
- **Faithfulness first.** The visualization must reflect what the algorithm actually does. If you simplify (smaller model, toy dims, dropped edge cases), say so explicitly in a markdown cell.
- **Never fabricate paper numbers.** Reproduce behavior on toy inputs; don't claim the paper's headline metrics unless you actually reproduced them.
- **Small & fast.** Free Colab, CPU. If the real method needs a GPU/large model, build a faithful *miniature* that shows the mechanism.
- **One consistent visual language** across notebook and HTML (same colors, same meaning).
- **Accessibility:** colorblind-safe palette, labels/legends, captions on every frame — follow `dataviz`.
- This machine has **no poppler** → use `WebFetch` for PDFs.
