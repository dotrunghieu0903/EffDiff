# Visualization patterns — pick the idiom by algorithm class

Choose the visual by what the algorithm *is*, not by what's easy. Column 3 is the
one thing the animation must make obvious.

| Algorithm class | Visual idiom | What to make obvious (the "aha") |
|---|---|---|
| Sorting / selection | Bars whose heights = values; colored pointers (i, j, pivot); swaps animate | Which comparisons happen and why order emerges |
| Searching (binary, BFS/DFS) | Array/grid with a shrinking active window or expanding frontier | How the search space collapses each step |
| Graph / tree (shortest path, MST, traversal) | Node-link diagram; edges light up as relaxed/added; distances as node labels | Why the greedy/relaxation choice is safe |
| Dynamic programming | The DP table filling in cell-by-cell; arrows to the sub-results used | That each cell reuses already-solved subproblems |
| Optimization / gradient descent | 2-D loss surface (contour + 3-D) with the descent path as a moving dot & trail | How the step size / momentum shapes the trajectory |
| Sampling / MCMC / diffusion | Point cloud (or histogram) evolving over "time"; target density underlaid | How samples migrate toward the target distribution |
| Clustering / EM / k-means | Scatter points recolored by assignment; centroids as moving markers | The assign↔update alternation converging |
| Matrix / linear algebra (SVD, PCA, attention) | Heatmaps of matrices; arrows/basis vectors for transforms | What each factor/rank contributes |
| Neural net pruning / quantization / compression | Layer/structure diagram; dropped units greyed out; size & accuracy meters | The size↓ vs accuracy↓ trade-off as structure shrinks |
| Sequence models / attention | Token grid with attention weights as a heatmap that updates per step | Which tokens attend to which, and how strongly |
| Geometry / computational geometry | 2-D plane with points/lines/hull; sweep line animates | The invariant the sweep maintains |
| Numerical / iterative solvers | Value-vs-iteration line chart + the quantity being refined | The convergence rate / when to stop |
| Probabilistic / Bayesian update | Prior → posterior density morphing as evidence arrives | How each observation reshapes belief |

## Rules of thumb
- **One accent color = one meaning**, held constant across every frame and across
  the notebook and the HTML (e.g. the "currently active" element is always the same hue).
- **Show state, not just motion.** Every frame is a complete, readable snapshot with a
  caption saying *what happened and why*.
- **Underlay the target/ground truth** when the algorithm converges toward something
  (target density, optimum, sorted order) so progress is visible.
- **Small inputs.** 6–12 elements, ~20 points, 4×4 matrices. The viewer should be able
  to verify a step by hand.
- **End on the aha.** The last stage should visually answer "so *that's* why it works."
- Colors, palettes, axes and legends: follow the project `dataviz` skill; use a
  colorblind-safe categorical palette.
