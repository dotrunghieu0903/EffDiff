# Colab notebook template & code snippets

Build the `.ipynb` by writing its JSON with `Write` (or `NotebookEdit`). A notebook is
JSON: `{"cells": [...], "metadata": {...}, "nbformat": 4, "nbformat_minor": 5}`. Each
cell is `{"cell_type": "markdown"|"code", "metadata": {}, "source": ["line\n", ...]}`
(code cells also need `"outputs": [], "execution_count": null`). Keep `metadata` minimal
so Colab accepts it:

```json
"metadata": {
  "colab": {"provenance": []},
  "kernelspec": {"name": "python3", "display_name": "Python 3"},
  "language_info": {"name": "python"}
}
```

The cell order is fixed in SKILL.md §5. Below are drop-in snippets for the key cells.
Adapt the `draw`/`snap` bodies to the specific algorithm.

---

## Cell 1 — Title + Colab badge (markdown)

```markdown
# <Algorithm name> — visual walkthrough

**Source:** <paper title / arXiv link / repo>
**What this shows:** <one line>

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/<user>/<repo>/blob/<branch>/<path>.ipynb)
```
(Only emit a real badge URL if the repo is actually on GitHub; otherwise say
"Upload to Colab via File → Upload notebook.")

## Cell 3 — Setup (code)

```python
# Colab already has numpy/matplotlib/plotly. ipywidgets is preinstalled on Colab.
# Uncomment if running elsewhere:
# !pip -q install numpy matplotlib plotly ipywidgets
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
from IPython.display import HTML
import plotly.graph_objects as go
plt.rcParams["figure.dpi"] = 110
ACCENT, MUTED, DONE = "#2563eb", "#cbd5e1", "#16a34a"  # colorblind-safe; keep meanings fixed
```

## The Tracer (put near the top of Cell 4 — the "record once" core)

```python
from dataclasses import dataclass, field
from copy import deepcopy

@dataclass
class Tracer:
    frames: list = field(default_factory=list)
    def snap(self, **payload):
        """Record a full, self-contained snapshot of the current state.
        deepcopy so later mutations don't corrupt earlier frames."""
        self.frames.append(deepcopy(payload))
    def to_json(self):
        import json
        return json.dumps(self.frames)
```

## Cell 4 — instrumented algorithm (example: bubble-ish, replace with the real one)

```python
def run(values):
    tracer = Tracer()
    a = list(values)
    n = len(a)
    tracer.snap(array=a, highlight=[], done=[], caption="Start: unsorted input")
    for i in range(n):
        for j in range(n - 1 - i):
            tracer.snap(array=a, highlight=[j, j + 1], done=list(range(n - i, n)),
                        caption=f"Compare positions {j} and {j+1}")
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                tracer.snap(array=a, highlight=[j, j + 1], done=list(range(n - i, n)),
                            caption=f"Swap → {a[j]} before {a[j+1]}")
    tracer.snap(array=a, highlight=[], done=list(range(n)), caption="Done: sorted")
    return a, tracer
```

## Cell 6 — matplotlib animation (renders inline on Colab)

```python
values = [5, 2, 9, 1, 7, 3]           # tiny example
result, tracer = run(values)
frames = tracer.frames

fig, ax = plt.subplots(figsize=(7, 3.2))
def draw(k):
    ax.clear()
    f = frames[k]
    colors = [DONE if i in f["done"] else ACCENT if i in f["highlight"] else MUTED
              for i in range(len(f["array"]))]
    ax.bar(range(len(f["array"])), f["array"], color=colors)
    ax.set_title(f["caption"]); ax.set_ylim(0, max(values) + 1); ax.set_xticks([])

anim = animation.FuncAnimation(fig, draw, frames=len(frames), interval=600, repeat=False)
plt.close(fig)
HTML(anim.to_jshtml())          # inline player in Colab
# anim.save("algo.gif", writer="pillow", fps=2)   # also export a GIF
```

## Cell 7 — interactive Plotly (frame slider) + optional widget

```python
steps = []
fig = go.Figure()
for k, f in enumerate(frames):
    fig.add_bar(x=list(range(len(f["array"]))), y=f["array"], visible=(k == 0),
                marker_color=["#16a34a" if i in f["done"]
                              else "#2563eb" if i in f["highlight"] else "#cbd5e1"
                              for i in range(len(f["array"]))])
for k, f in enumerate(frames):
    steps.append(dict(method="update",
                      args=[{"visible": [i == k for i in range(len(frames))]},
                            {"title": f["caption"]}], label=str(k)))
fig.update_layout(sliders=[dict(active=0, steps=steps)], title=frames[0]["caption"],
                  showlegend=False, height=360)
fig.show()
```

For hyperparameters use `ipywidgets`:
```python
from ipywidgets import interact
@interact(step_size=(0.01, 1.0, 0.01))
def _(step_size=0.1):
    # re-run the algorithm with this param and draw the outcome
    ...
```

## Export frames for the HTML companion (last code cell)

```python
from pathlib import Path
Path("AlgoName-frames.json").write_text(tracer.to_json())
print(tracer.to_json()[:200], "...")   # paste this JSON into the HTML's FRAMES const
```

## Tips
- `deepcopy` in `snap()` is essential — otherwise every frame shows the final state.
- Keep frame count modest (< ~150) so `to_jshtml()` and the HTML stay light.
- If matplotlib animation doesn't show, ensure `HTML(anim.to_jshtml())` is the **last**
  expression in the cell and `plt.close(fig)` was called.
- Test the notebook logic by running the algorithm cell locally on the tiny example
  before finalizing.
