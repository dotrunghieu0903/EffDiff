# HAI ĐÓNG GÓP CỦA LUẬN VĂN — PHÁT BIỂU DỄ HIỂU

> Tài liệu phụ trợ cho [PROPOSAL.md](PROPOSAL.md) — diễn giải 2 đóng góp lớn nhất theo kiểu gần gũi, dễ hình dung.
> Gồm **Phần A** (bản gọn cho Abstract/mở đầu) và **Phần B** (bản ví von cho thuyết trình / bảo vệ).

---

# PHẦN A — BẢN CỰC GỌN (cho Abstract / mở đầu)

### Đóng góp 1 — Thuật toán
> Đề xuất một phương pháp pruning mới cho Diffusion Transformer: **cắt riêng biệt hai nhánh attention và MLP trong mỗi block** dựa trên **tín hiệu "khả năng phục hồi" học được** (khả vi), thay vì cắt cả block một cách đồng loạt như SOTA hiện tại (TinyFusion). Nhờ đó mô hình tự học được *chỗ nào cắt được mà vẫn hồi phục tốt sau finetune*.

### Đóng góp 2 — Hệ thống
> Xây dựng **Error-Aware Unified Acceleration Stack**: ghép 4 trục tăng tốc trực giao (pruning × lượng tử hóa × dự đoán-caching × đa-GPU) thành một pipeline duy nhất, kèm **phân tích tương tác sai số** giữa chúng và một **bộ điều phối nhận-biết-sai-số** — đạt mục tiêu **>10× tăng tốc end-to-end** ở chất lượng gần gốc, điều mà việc ghép nối tuần tự ngây thơ không đạt được.

### Khớp nối (1 câu)
> Đóng góp 1 chính là **trục pruning (#1)** mà Đóng góp 2 tiêu thụ — không phải hai đề tài rời, mà là "chế ra một thành phần mới rồi chứng minh nó ghép được với phần còn lại".

---

# PHẦN B — BẢN VÍ VON (cho thuyết trình / bảo vệ)

## Đóng góp 1 — "Cắt tỉa thông minh: mỗi nửa của mô hình cắt theo kiểu riêng"

**Nói ngắn gọn:** Dạy cho AI tự học *chỗ nào cắt được mà vẫn hồi phục tốt* — và quan trọng là **cắt riêng hai phần khác nhau bên trong mỗi tầng**, thay vì cắt cả cụm một lần.

**Ví von — cắt tỉa cây cảnh:**
> Mô hình Diffusion giống một cái cây gồm nhiều tầng. Mỗi tầng có **2 loại cành**: cành "attention" (lo việc *các điểm ảnh nhìn nhau, phối cảnh*) và cành "MLP" (lo việc *tô màu, chi tiết từng điểm*).
>
> - **Cách cũ (TinyFusion — SOTA hiện tại):** thấy tầng nào thừa thì **chặt nguyên cả tầng** — cả hai loại cành cùng lúc. Thô.
> - **Cách của mình:** nhận ra hai loại cành **hồi phục khác nhau** sau khi cắt. Cành attention có thể quý ở tầng này, cành MLP quý ở tầng khác. Nên **cắt bất đối xứng** — tầng này giữ attention bỏ MLP, tầng kia làm ngược lại.
> - **"Học được" nghĩa là:** không dùng quy tắc cứng ("cứ cành nhỏ thì chặt"), mà để mô hình **tự thử và học xem cắt chỗ nào thì sau khi tỉa vẫn mọc lại đẹp**.

**Một câu tagline:** *"Cùng một cái kéo, nhưng biết cắt attention và MLP theo hai nhịp khác nhau — vì chúng hồi phục khác nhau."*

---

## Đóng góp 2 — "Ghép 4 chiêu tăng tốc mà không giẫm chân nhau"

**Nói ngắn gọn:** Có 4 kỹ thuật tăng tốc độc lập. Ghép bừa thì chúng **cộng dồn sai số làm hỏng ảnh**. Đóng góp này là **tấm bản đồ + nhạc trưởng** để ghép chúng lại đạt **>10× nhanh hơn** mà ảnh vẫn đẹp.

**Ví von — nhóm nhạc 4 người:**
> Bạn có 4 nhạc công, mỗi người giỏi một cách làm bài hát nhanh hơn:
> 1. **Cắt tỉa** (bỏ bớt phần thừa của mô hình — chính là Đóng góp 1)
> 2. **Lượng tử hóa** (dùng số ít chữ số hơn cho nhẹ)
> 3. **Dự đoán/caching** (đoán trước bước sau, khỏi tính lại)
> 4. **Chia nhiều GPU** (nhiều người cùng làm)
>
> - **Vấn đề:** cho cả 4 chơi cùng lúc mà không ai chỉ huy → **lỗi của người này làm người kia đoán sai** (ví dụ: số làm tròn thô của "lượng tử hóa" khiến "dự đoán" đoán trật) → nhạc lạc.
> - **Đóng góp:** (a) **đo từng cặp** xem ai đá nhau, vẽ ra **bản đồ "cặp nào ghép được, cặp nào cãi nhau"**; (b) làm một **nhạc trưởng (orchestrator) nhận biết sai số** — điều tiết để 4 người chơi ăn khớp.

**Một câu tagline:** *"Không phải phát minh chiêu mới, mà là nhạc trưởng biết 4 chiêu cũ chơi chung sao cho nhanh gấp 10 lần mà không phá nhau."*

---

## 🔗 Mối liên hệ giữa 2 đóng góp (để không bị hiểu là 2 đề tài rời)

> Đóng góp 1 **chính là "nhạc công cắt tỉa"** trong ban nhạc của Đóng góp 2. Không phải hai luận văn — mà là: *"mình chế ra một nhạc công mới (pruning thông minh hơn), rồi chứng minh nó chơi ăn khớp với 3 nhạc công còn lại."*
