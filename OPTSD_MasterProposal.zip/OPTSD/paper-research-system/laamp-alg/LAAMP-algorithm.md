# LAAMP — Learned Asymmetric Attention–MLP Pruning
### Thuật toán (bản `.md`, khớp 1–1 với [LAAMP-algorithm.tex](LAAMP-algorithm.tex))

> Đặc tả thuật toán cho **Đóng góp 1** — xem [PROPOSAL.md](PROPOSAL.md) §2★ và giao thức thực nghiệm ở [CONTRIB1-Pruning-Algorithm-Experiments.md](CONTRIB1-Pruning-Algorithm-Experiments.md).

## Setup / ký hiệu

DiT có $L$ block; block $\ell$ gồm hai khối con trên đường residual:

$$
x \leftarrow x + m^{\text{attn}}_\ell\, g^{\text{attn}}_\ell\, \mathrm{Attn}_\ell(\mathrm{LN}(x)), \qquad
x \leftarrow x + m^{\text{mlp}}_\ell\, g^{\text{mlp}}_\ell\, \mathrm{MLP}_\ell(\mathrm{LN}(x))
$$

với mask keep/drop nhị phân $m^{\text{attn}}_\ell, m^{\text{mlp}}_\ell \in \{0,1\}$ (khối con bị drop → identity).

| Ký hiệu | Ý nghĩa |
|---|---|
| $S = \{(\ell,b): \ell=1..L,\ b\in\{\text{attn},\text{mlp}\}\}$ | tập khối con, $\lvert S\rvert = 2L$ |
| $\pi_{\ell,b}\in\mathbb{R}^2$ | logit 2 lớp keep/drop cho mỗi khối con |
| $p_{\ell,b} = \mathrm{softmax}(\pi_{\ell,b})_{\text{keep}}$ | xác suất giữ |
| $\Delta\Phi^{\text{attn}}, \Delta\Phi^{\text{mlp}}$ | LoRA-proxy **tách nhánh** (giả lập phục hồi) |
| $\mathbf{c}\in\mathbb{R}^{2L}_{>0}$ | vector chi phí FLOPs đo được từng khối con |
| $B$ | ngân sách FLOPs mục tiêu (= chi phí baseline → iso-FLOPs) |

## Hàm mục tiêu (đồng tối ưu)

$$
\min_{\{\pi\},\,\Delta\Phi^{\text{attn}},\,\Delta\Phi^{\text{mlp}}}
\underbrace{\mathbb{E}_{x_0,t,\epsilon}\!\big[\|\hat\epsilon^{\,\mathbf{m},\Delta\Phi}(x_t,t)-\epsilon\|^2\big]}_{\text{recoverability học được}}
+ \lambda_B\Big(\tfrac{\mathbf{p}^\top\mathbf{c}-B}{\mathrm{FLOPs}_{\text{full}}}\Big)^2
+ \lambda_D\,\mathcal{R}_{\text{depth}}(\mathbf{p})
$$

---

## Algorithm 1 — Phase A: học mask kép khả vi

```
Input : DiT θ đã pretrain; calib D; ngân sách B; số bước N;
        lịch nhiệt τ0→τN; trọng số λ_B, λ_D; LoRA rank r_a, r_m
Output: mask cứng m* ∈ {0,1}^{2L}

 1  init π[ℓ,b] lệch về KEEP,  ∀(ℓ,b) ∈ S
 2  attach ΔΦ_attn (rank r_a) vào các projection Attn
 3  attach ΔΦ_mlp  (rank r_m) vào các MLP
 4  c ← measure_flops_per_subblock(θ)          # fvcore / calflops
 5  FLOPs_full ← 1ᵀc
 6  for k = 1 … N:
 7      τ ← anneal(k)                           # 2.0 → 0.1
 8      (x0, t, ε) ~ D ;  tạo x_t
 9      m̃[ℓ,b] ← GumbelSoftmax(π[ℓ,b], τ)
10      m[ℓ,b]  ← STE_hard(m̃[ℓ,b])              # mask KÉP (attn, mlp độc lập)
11      ε̂ ← θ(x_t, t | m, {ΔΦ_attn, ΔΦ_mlp})
12      L_denoise ← ‖ε̂ − ε‖²                    # v-/ε-/flow loss tùy substrate
13      p[ℓ,b] ← softmax(π[ℓ,b])_keep
14      R_budget ← ((pᵀc − B) / FLOPs_full)²    # FLOPs kỳ vọng, khả vi
15      L ← L_denoise + λ_B·R_budget + λ_D·R_depth(p)   # λ_D = 0 mặc định
16      L.backward()
17      opt_mask.step();  opt_lora.step()        # lr_mask ≫ lr_lora
18      if mask đã cứng (p[ℓ,b] > 0.95 cho ≥95% S):  break
19  m* ← argmax_{keep,drop} π
20  assert |m*ᵀc − B| / B < 0.02                # đạt ngân sách ±2%
21  return m*
```

## Algorithm 2 — Phase B: phục hồi thật & đánh giá

```
Input : θ đã pretrain; mask cứng m*; RECOVERY_BUDGET dùng chung
Output: model đã cắt θ*; báo cáo

 1  θ* ← physically_remove(θ, m*)               # xóa hẳn khối con bị drop khỏi đồ thị
 2  finetune(θ*, RECOVERY_BUDGET)               # CÙNG budget cho MỌI phương pháp (công bằng)
 3  report {FID, IS/ImageReward/CLIP, latency, VRAM}
 4         + thống kê mask  A = (1/L)·Σ_ℓ |m_attn[ℓ] − m_mlp[ℓ]|
 5  return θ*
```

---

## Ba điểm khác TinyFusion (bản chất đóng góp)

1. **Mask kép độc lập** attn/MLP (không ép $m^{\text{attn}}_\ell \equiv m^{\text{mlp}}_\ell$) → không gian cấu hình $2^{2L}$ thay vì $2^L$.
2. **LoRA-proxy tách nhánh** → tín hiệu recoverability của attention và MLP không bị trộn.
3. **Ngân sách FLOPs khả vi** cho phép **mật độ prune biến thiên theo độ sâu**, thay vì N:M cứng.

> **Công bằng khi so sánh:** mọi baseline và LAAMP dùng chung `RECOVERY_BUDGET` và cùng mức $B$ (iso-FLOPs) → chênh lệch chất lượng chỉ đến từ *chọn cắt gì*.
