# LAAMP — Sơ đồ trình chiếu (Mermaid + SVG)

> Bản hình vẽ đẹp cho slide bảo vệ Đóng góp 1. Bổ trợ [LAAMP-algorithm.md](LAAMP-algorithm.md), [LAAMP-so-do-luong.md](LAAMP-so-do-luong.md) (bản ASCII).
>
> - **SVG** (nét ở mọi độ phóng, nhúng thẳng vào PowerPoint/Google Slides): [LAAMP-training-loop.svg](LAAMP-training-loop.svg) · [LAAMP-dual-mask.svg](LAAMP-dual-mask.svg)
> - **Mermaid** (render sống trong VSCode/GitHub, dễ chỉnh) — bên dưới.

---

## 1. Vòng lặp học Pha A — "recoverability học được"

![training loop](LAAMP-training-loop.svg)

```mermaid
flowchart TD
    TAU["nhiệt độ τ : 2.0 → 0.1<br/>(annealing)"]:::inp
    XT["(x₀,t,ε) ~ calib → x_t"]:::inp
    PI["π — logit giữ/bỏ (2L khối con)<br/>★ tham số CẦN học · init bias→KEEP"]:::learn
    GS["Gumbel-Softmax(π,τ) → mask mềm m̃<br/>STE: forward CỨNG {0,1} · backward m̃"]:::gumbel
    DIT["DiT θ (pretrain · ĐÓNG BĂNG)<br/>+ LoRA_attn + LoRA_mlp<br/>★ 'thợ sửa' tách nhánh — giả lập phục hồi"]:::model
    LOSS["L = ‖ε̂−ε‖² ← loss ĐÃ được LoRA bù<br/>+ λ_B·((p·c−B)/FLOPs)² ← ngân sách"]:::loss
    UPD["opt_mask.step (lr CAO) + opt_lora.step (lr THẤP)"]:::upd
    MSTAR["m* = argmax(π), đạt B ±2%<br/>→ PHA B: phục hồi thật"]:::out

    PI -->|forward| GS
    TAU -.-> GS
    GS -->|"mask kép m = (m_attn, m_mlp)"| DIT
    XT -.-> DIT
    DIT -->|"ε̂ (sau khi LoRA bù)"| LOSS
    LOSS -->|L.backward| UPD
    UPD -->|"lặp tới khi mask cứng"| MSTAR
    LOSS -.->|"GRADIENT = recoverability<br/>bỏ mà loss ~không tăng → π về DROP"| PI
    LOSS -.->|cập nhật 'thợ sửa'| DIT

    classDef learn fill:#FDE68A,stroke:#D97706,stroke-width:2px,color:#7C2D12;
    classDef gumbel fill:#DBEAFE,stroke:#2563EB,stroke-width:2px,color:#1E3A8A;
    classDef model fill:#E5E7EB,stroke:#6B7280,stroke-width:2px,color:#374151;
    classDef loss fill:#FEE2E2,stroke:#DC2626,stroke-width:2px,color:#991B1B;
    classDef upd fill:#DCFCE7,stroke:#16A34A,stroke-width:2px,color:#166534;
    classDef out fill:#F3E8FF,stroke:#9333EA,stroke-width:2px,color:#6B21A8;
    classDef inp fill:#F1F5F9,stroke:#64748B,stroke-width:1.5px,color:#334155;
```

**Đọc sơ đồ:** mũi tên liền = forward, mũi tên đứt = gradient. Gradient chảy ngược về `π` chính là *tín hiệu recoverability học được* — khối nào bỏ đi mà LoRA sửa lại gần như hoàn hảo (loss ~không tăng) thì gradient đẩy `π` về **DROP**.

---

## 2. Mask KÉP trong một block DiT — điểm khác TinyFusion

![dual mask](LAAMP-dual-mask.svg)

```mermaid
flowchart LR
    x((x)) --> P1(("+"))
    P1 --> P2(("+"))
    P2 --> xo((x'))

    MA["m_attn"]:::sw --> ATT["Attn_ℓ<br/>trộn token · O(T²)"]:::attn
    ATT --> P1
    MM["m_mlp"]:::sw --> MLP["MLP_ℓ<br/>biến đổi kênh · O(T)"]:::mlp
    MLP --> P2

    ATT -.-> RA["recoverability RIÊNG<br/>(LoRA_attn)"]:::note
    MLP -.-> RM["recoverability RIÊNG<br/>(LoRA_mlp)"]:::note

    classDef sw fill:#FDE68A,stroke:#D97706,stroke-width:2px,color:#7C2D12;
    classDef attn fill:#DBEAFE,stroke:#2563EB,stroke-width:2px,color:#1E3A8A;
    classDef mlp fill:#FEF3C7,stroke:#CA8A04,stroke-width:2px,color:#854D0E;
    classDef note fill:#ECFEFF,stroke:#0891B2,stroke-width:1.5px,color:#0E7490;
```

| | Ràng buộc mask | Hệ quả | Không gian cấu hình |
|---|---|---|---|
| **TinyFusion (SOTA cũ)** | `m_attn ≡ m_mlp` | bỏ CẢ block | `2^L` |
| **LAAMP (đóng góp)** | `m_attn ⟂ m_mlp` | bỏ RIÊNG lẻ, bất đối xứng | `2^(2L)` |

Ví dụ mask học ra: block **nông** giữ Attn/bỏ MLP, block **sâu** bỏ Attn/giữ MLP — *do dữ liệu tự quyết*. Khi `m=0`, khối con thành **identity** (residual đi thẳng) → biến mất khỏi đồ thị tính toán.

---

## 3. Hai pha tổng thể (học rẻ → phục hồi thật)

```mermaid
flowchart TD
    TH["θ pretrain"]:::model
    subgraph A["PHA A — HỌC MASK (rẻ, trên calib nhỏ)"]
      LOOP["vòng lặp §1: mask kép + LoRA-proxy tách nhánh"]:::learn
      NOTE["LoRA-proxy CHỈ để ước lượng recoverability<br/>→ VỨT sau pha này"]:::note
      LOOP --- NOTE
    end
    MSTAR["m* — mask cứng, đạt ngân sách B ±2%"]:::out
    subgraph B["PHA B — PHỤC HỒI THẬT & ĐÁNH GIÁ"]
      RM["θ* = physically_remove(θ, m*)<br/>xóa HẲN khối con bị drop"]:::model
      FT["finetune(θ*, RECOVERY_BUDGET)<br/>CÙNG ngân sách cho MỌI phương pháp"]:::upd
      REP["report: FID · ImageReward · CLIP · latency · VRAM · chỉ số A"]:::loss
      RM --> FT --> REP
    end
    TH --> LOOP
    LOOP --> MSTAR --> RM

    classDef learn fill:#FDE68A,stroke:#D97706,stroke-width:2px,color:#7C2D12;
    classDef model fill:#E5E7EB,stroke:#6B7280,stroke-width:2px,color:#374151;
    classDef upd fill:#DCFCE7,stroke:#16A34A,stroke-width:2px,color:#166534;
    classDef loss fill:#FEE2E2,stroke:#DC2626,stroke-width:2px,color:#991B1B;
    classDef out fill:#F3E8FF,stroke:#9333EA,stroke-width:2px,color:#6B21A8;
    classDef note fill:#ECFEFF,stroke:#0891B2,stroke-width:1.5px,color:#0E7490;
```

> Vì mọi baseline (TinyFusion, Diff-Pruning, OBS-Diff…) dùng **chung** `RECOVERY_BUDGET` và cùng mức FLOPs `B` (iso-FLOPs) ⇒ chênh lệch chất lượng chỉ đến từ *"CHỌN CẮT GÌ"*, không từ *"được phục hồi bao nhiêu"*.

---

Bảng màu thống nhất giữa mọi sơ đồ (dễ nhớ khi thuyết trình):

🟡 Vàng = tham số CẦN học (logit π, LoRA "thợ sửa")
🔵 Xanh dương = Gumbel-Softmax / nhánh Attention
🟠 Vàng-cam = nhánh MLP
⬜ Xám = DiT đóng băng
🔴 Đỏ = Loss · 🟢 Xanh lá = cập nhật · 🟣 Tím = đầu ra m*
Mũi tên liền = forward, mũi tên đứt = gradient (recoverability)

## 4. Cách xuất PNG cho slide

**Từ SVG (khuyến nghị — nét nhất):**
- PowerPoint/Google Slides: `Insert → Picture` chọn thẳng file `.svg` (giữ vector, phóng to không vỡ).
- Cần PNG độ phân giải cao:
  ```bash
  rsvg-convert -w 2160 LAAMP-training-loop.svg -o LAAMP-training-loop.png
  # hoặc: inkscape LAAMP-training-loop.svg --export-width=2160 --export-filename=out.png
  ```
- Hoặc mở `.svg` trong trình duyệt rồi chụp màn hình.

**Từ Mermaid:**
- VSCode: cài extension *Markdown Preview Mermaid Support* → mở preview → chuột phải sơ đồ → save image.
- [mermaid.live](https://mermaid.live): dán code → `Actions → PNG/SVG` (nền trong suốt, phân giải cao).
- CLI: `mmdc -i LAAMP-diagram.md -o out.png -s 3` (mermaid-cli, scale 3×).

> **Font tiếng Việt:** cả hai `.svg` đã khai báo `Segoe UI, Arial, sans-serif`. Nếu xuất PNG bị mất dấu, chọn font đó trong Inkscape hoặc truyền `--cssFile` cho `mmdc`.
