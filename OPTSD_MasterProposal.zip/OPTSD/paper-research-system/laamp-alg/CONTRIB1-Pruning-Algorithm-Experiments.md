# ĐÓNG GÓP 1 — Thuật toán & Giao thức thực nghiệm
## LAAMP: Learned Asymmetric Attention–MLP Pruning cho Diffusion Transformer

> **Mục đích file này:** đặc tả **cụ thể, khả-thực-thi** (1) thuật toán pruning cắt độc lập attention/MLP theo recoverability *học được*, và (2) các bước thực nghiệm so với baseline để đi tới **kết luận có bằng chứng** cho Đóng góp 1 của [PROPOSAL.md](PROPOSAL.md) §2★.
>
> **Quan hệ với PROPOSAL:** đây là cụ thể hóa §2★ (RQ0a/RQ0b) + Phân pha P0b (§9). TinyFusion ([output/readpaper/TinyFusion.md](output/readpaper/TinyFusion.md)) là baseline-để-vượt. Xem [[thesis-pruning-direction]].
>
> **Ngày:** 24/07/2026.

---

## 0. Tóm tắt một dòng
Thay quyết định giữ/bỏ **cả block** DiT của TinyFusion bằng **hai quyết định độc lập** cho nhánh **attention** và nhánh **MLP** của từng block, học qua **mask kép khả vi** (Gumbel-Softmax + STE) đồng-tối-ưu với **LoRA-proxy tách nhánh** (giả lập bước phục hồi), dưới **ngân sách FLOPs bất đối xứng theo độ sâu**. Kết luận cần chứng minh: cắt bất đối xứng attn/MLP **vượt** cắt block nguyên khối (RQ0a) và **vượt** tiêu chí cố định cùng độ mịn (RQ0b) ở **iso-FLOPs**.

---

## 1. Ký hiệu & mô hình khối DiT

Một DiT/MMDiT có $L$ block. Block $\ell$ gồm **hai khối con** trên đường residual:

$$
x \leftarrow x + g^{\text{attn}}_\ell \cdot \mathrm{Attn}_\ell(\mathrm{LN}(x)), \qquad
x \leftarrow x + g^{\text{mlp}}_\ell \cdot \mathrm{MLP}_\ell(\mathrm{LN}(x))
$$

trong đó $g$ là gate/scale (AdaLN). **Đơn vị prune của chúng ta = một khối con** (không phải cả block). Ta gắn mask nhị phân $m^{\text{attn}}_\ell, m^{\text{mlp}}_\ell \in \{0,1\}$:

$$
x \leftarrow x + m^{\text{attn}}_\ell\, g^{\text{attn}}_\ell\, \mathrm{Attn}_\ell(\mathrm{LN}(x)), \qquad
x \leftarrow x + m^{\text{mlp}}_\ell\, g^{\text{mlp}}_\ell\, \mathrm{MLP}_\ell(\mathrm{LN}(x))
$$

Khi $m=0$ khối con trở thành **identity** (residual đi thẳng) → khối con bị bỏ hoàn toàn khỏi đồ thị tính toán khi suy luận. Đây là điểm khác then chốt so với TinyFusion (bỏ **cặp** $m^{\text{attn}}_\ell = m^{\text{mlp}}_\ell$ đồng thời).

**Ký hiệu gộp:** đặt tập khối con $S = \{(\ell, b) : \ell = 1..L,\ b \in \{\text{attn}, \text{mlp}\}\}$, $|S| = 2L$. Mask $\mathbf{m} \in \{0,1\}^{2L}$.

### 1.1. Kế toán FLOPs (nền lý luận cho tính bất đối xứng)

Với $T$ token, chiều ẩn $d$, tỉ lệ MLP $r$ (thường $r=4$), mỗi khối con (bỏ qua hệ số nhỏ):

| Khối con | FLOPs xấp xỉ | Thành phần |
|---|---|---|
| Attention | $c^{\text{attn}}_\ell \approx \underbrace{4 T d^2}_{\text{QKVO proj}} + \underbrace{2 T^2 d}_{\text{scores+ctx}}$ | có số hạng **bậc hai theo $T$** |
| MLP | $c^{\text{mlp}}_\ell \approx 2 r\, T d^2$ | **tuyến tính theo $T$**, nặng theo $d$ |

**Hệ quả (động lực RQ0a):** ở độ phân giải cao ($T$ lớn, ví dụ FLUX 1024²) số hạng $2T^2d$ khiến **attention đắt hơn**; ở độ phân giải thấp/token ít, **MLP đắt hơn** (do $r=4$). Đồng thời hai nhánh có **bản chất hàm khác nhau** (trộn token vs biến đổi kênh) → giả thuyết chúng có **profile recoverability khác nhau** ⇒ cắt bất đối xứng có thể thắng. Ta **đo** $c^{\text{attn}}_\ell, c^{\text{mlp}}_\ell$ thực tế bằng `fvcore`/`calflops` cho từng substrate và lưu thành vector chi phí $\mathbf{c} \in \mathbb{R}^{2L}_{>0}$.

---

## 2. Thuật toán LAAMP

### 2.1. Ba thành phần (kế thừa & mở rộng TinyFusion)

1. **Mask kép khả vi.** Mỗi khối con $(\ell,b)$ có logit categorical 2 lớp (keep/drop) $\pi_{\ell,b} \in \mathbb{R}^2$. Không gian cấu hình mịn gấp **đôi** TinyFusion ($2^{2L}$ thay vì $2^{L}$ khi bỏ ràng buộc N:M cứng).
2. **Recoverability-proxy tách nhánh.** Hai họ adapter LoRA riêng — $\Delta\Phi^{\text{attn}}$ gắn vào các projection của attention, $\Delta\Phi^{\text{mlp}}$ gắn vào MLP — đồng-tối-ưu với mask để **giả lập finetune phục hồi** (đúng tinh thần TinyFusion, nhưng **tách nhánh** để tín hiệu recoverability của attn và mlp không bị trộn).
3. **Ngân sách bất đối xứng theo độ sâu.** Ràng buộc FLOPs mục tiêu $B$ (để iso-FLOPs với baseline) qua **penalty khả vi trên FLOPs kỳ vọng**, cho phép **mật độ prune biến thiên theo độ sâu** (không ép N:M cứng, không ép tỉ lệ attn=mlp).

### 2.2. Lấy mẫu mask khả vi (Gumbel-Softmax + STE)

Với xác suất giữ $p_{\ell,b} = \mathrm{softmax}(\pi_{\ell,b})_{\text{keep}}$. Mẫu mềm:

$$
\tilde{m}_{\ell,b} = \frac{\exp((\pi^{\text{keep}}_{\ell,b} + G^{\text{keep}})/\tau)}{\sum_{k \in \{\text{keep,drop}\}} \exp((\pi^{k}_{\ell,b} + G^{k})/\tau)}, \quad G \sim \mathrm{Gumbel}(0,1)
$$

Forward dùng **hard** $m_{\ell,b} = \mathbb{1}[\tilde m > 0.5]$; backward dùng gradient của $\tilde m$ (**Straight-Through**). Nhiệt độ $\tau$ hạ dần (annealing) từ $\tau_0=2.0 \to \tau_T=0.1$.

### 2.3. Hàm mục tiêu

$$
\min_{\{\pi\},\,\Delta\Phi^{\text{attn}},\,\Delta\Phi^{\text{mlp}}}\quad
\underbrace{\mathbb{E}_{x_0,t,\epsilon}\big[\,\| \epsilon_\theta^{\mathbf{m},\Delta\Phi}(x_t,t) - \epsilon \|^2 \,\big]}_{\mathcal{L}_{\text{denoise}}\ \text{(recoverability học được)}}
\;+\; \lambda_B\,\underbrace{\mathcal{R}_{\text{budget}}}_{\text{FLOPs}}
\;+\; \lambda_D\,\underbrace{\mathcal{R}_{\text{depth}}}_{\text{prior tùy chọn}}
$$

- $\mathcal{L}_{\text{denoise}}$: **loss huấn luyện gốc của model** (v-pred / ε-pred / flow-matching tùy substrate) chạy trên model **đã mask + đã gắn LoRA-proxy**. Đây chính là "hiệu năng-sau-phục-hồi" được tối ưu trực tiếp.
- **Ngân sách FLOPs (khả vi):** dùng **xác suất giữ** $p_{\ell,b}$ để tính FLOPs kỳ vọng
  $$
  \widehat{\mathrm{FLOPs}} = \sum_{(\ell,b)} p_{\ell,b}\, c_{\ell,b}, \qquad
  \mathcal{R}_{\text{budget}} = \Big(\tfrac{\widehat{\mathrm{FLOPs}} - B}{\mathrm{FLOPs}_{\text{full}}}\Big)^2 .
  $$
  (Dùng $p$ chứ không dùng mẫu $\tilde m$ để penalty ổn định, ít nhiễu.)
- **Prior độ sâu (tùy chọn, mặc định TẮT — bật ở ablation):** khuyến khích mật độ biến thiên đã quan sát ("attention-heavy tầng nông, MLP-heavy tầng sâu") **chỉ nếu** dữ liệu ủng hộ; mặc định $\lambda_D=0$ để **dữ liệu tự quyết** — tránh cài sẵn kết luận RQ0a.

### 2.4. Lịch huấn luyện hai pha

**Pha A — Học mask (search):** đồng-tối-ưu $\{\pi\}$ và $\Delta\Phi$ trên tập calib nhỏ. Có thể dùng **optimizer tách**: mask logits (Adam, lr cao ~1e-1) vs LoRA (Adam, lr ~1e-4). Chạy tới khi mask "cứng lại" ($\max_b p_{\ell,b} > 0.95$ cho ≥95% khối con) HOẶC hết ngân sách bước.

**Pha B — Phục hồi thật (recovery) & đánh giá:** chốt mask cứng $\mathbf{m}^\star$ (argmax), **loại bỏ vật lý** các khối con bị drop, rồi finetune model đã cắt:
- SDXL/DiT-XL: full finetune HOẶC LoRA (chọn theo VRAM).
- FLUX-dev (12B): **chỉ LoRA-proxy/mask** (full-finetune không vừa 24GB — xem PROPOSAL §6).
- **QUAN TRỌNG — công bằng:** mọi baseline và LAAMP dùng **cùng ngân sách phục hồi** (cùng số bước, cùng lr, cùng LoRA rank, cùng data) → chênh lệch chất lượng chỉ đến từ *chọn cắt gì*, không từ *phục hồi bao nhiêu*.

### 2.5. Pseudocode

```python
# ---- Pha A: học mask kép + LoRA-proxy tách nhánh ----
init logits pi[l,b]  for (l,b) in subblocks        # keep/drop, khởi tạo bias về keep
attach LoRA_attn on all Attn projections           # rank r_a
attach LoRA_mlp  on all MLP  layers                # rank r_m
c[l,b] = measured_flops_per_subblock(model)        # fvcore/calflops
B      = target_budget_flops                       # đặt = FLOPs(baseline) để iso-FLOPs

for step in range(N_search):
    tau = anneal(step)                             # 2.0 -> 0.1
    x0, t, eps = sample_batch()
    m_soft = gumbel_softmax(pi, tau); m = STE_hard(m_soft)   # mask kép
    eps_hat = model.forward(x_t, t, mask=m, lora=[LoRA_attn, LoRA_mlp])
    L_denoise = mse(eps_hat, eps)                  # hoặc v-/flow loss
    p = softmax(pi)[..., keep]
    R_budget = ((p @ c - B) / flops_full) ** 2
    loss = L_denoise + lam_B * R_budget + lam_D * R_depth(p)   # lam_D=0 mặc định
    loss.backward()
    opt_mask.step(); opt_lora.step()

m_star = argmax(pi)                                # mask cứng cuối cùng
assert abs(m_star @ c - B) / B < 0.02              # đạt ngân sách ±2%

# ---- Pha B: phục hồi thật + đánh giá ----
model_pruned = physically_remove(model, m_star)    # xóa hẳn khối con drop
finetune(model_pruned, budget=RECOVERY_BUDGET)     # CÙNG budget cho mọi phương pháp
report(FID, IS/ImageReward/CLIP, latency, mem, m_star)
```

---

## 3. Câu hỏi nghiên cứu & giả thuyết cần kết luận

| RQ | Phát biểu | Giả thuyết H | Bác bỏ nếu |
|---|---|---|---|
| **RQ0a** | Attn & MLP trong DiT có profile recoverability đủ khác để cắt bất đối xứng thắng cắt block nguyên khối? | LAAMP đạt **FID thấp hơn TinyFusion** ở iso-FLOPs trên ≥2 substrate, có ý nghĩa thống kê; mask học ra **bất đối xứng** rõ rệt | LAAMP ≈ TinyFusion trong khoảng tin cậy; mask ~đối xứng |
| **RQ0b** | Tín hiệu recoverability *học được* có vượt tiêu chí cố định ở **cùng độ mịn** (sub-block)? | LAAMP < FID so với magnitude/Taylor/Hessian/random áp ở mức sub-block, iso-FLOPs | Không tách được khỏi baseline cố định |

**Kết luận chính của Đóng góp 1** = cặp bằng chứng (RQ0a ∧ RQ0b) + **bản đồ mask** (đặc trưng bất đối xứng theo độ sâu) + đường cong **FID–FLOPs** (Pareto) vượt baseline.

---

## 4. Thiết kế thực nghiệm

### 4.1. Substrate & dataset (thứ tự thực thi)

| Ưu tiên | Model | #Layer/Param | Dataset | Vai trò | Ghi chú tài nguyên |
|---|---|---|---|---|---|
| **1 (head-to-head)** | **DiT-XL/2** | 28 / 675M | ImageNet 256² (class-cond) | So **trực tiếp** số công bố của TinyFusion (FID 2.86 @14 lớp) | Vừa 24GB thoải mái, full-finetune được |
| **2 (prototype T2I)** | **SDXL** UNet-DiT/2.6B | — / 2.6B | COCO-2017 / MJHQ-30K prompts | Mở rộng T2I (điều TinyFusion để ngỏ) | Full-finetune vừa 24GB |
| **3 (scale, LoRA-only)** | **FLUX.1-dev** | 19+38 / ~12B | MJHQ-30K / prompt bench | Chứng minh khả-mở-rộng ở scale lớn | Chỉ LoRA-proxy (§6 PROPOSAL) |
| Ablation nền | SANA / SANA-1.5 | — | — | Kiểm co-ROI (linear-attn, ít token) | Chỉ nếu còn thời gian |

> **Lý do lấy DiT-XL/2 làm benchmark chính của thuật toán:** TinyFusion công bố số trên đúng setup này ⇒ so sánh **táo-với-táo** đáng tin nhất. SDXL/FLUX chứng minh tính tổng quát + đóng góp phụ "mở rộng sang T2I".

### 4.2. Baseline (tất cả ở **iso-FLOPs**, **cùng ngân sách phục hồi**)

| Nhóm | Baseline | Độ mịn | Vai trò |
|---|---|---|---|
| **Learned depth (SOTA cần vượt)** | **TinyFusion** (1:2, coupled block) | Block nguyên khối | **Đối thủ chính RQ0a** |
| ↳ *trong code* | method **`tinyfusion`** = LAAMP-machinery **coupled** ($m^{attn}_\ell\equiv m^{mlp}_\ell$), mask **học được** Gumbel+LoRA | Block nguyên khối | **Control RQ0a chuẩn** (LAAMP trừ đi tính bất đối xứng, cùng iso-FLOPs) |
| ↳ *đừng nhầm* | method **`coupled`** = **magnitude**-coupled heuristic | Block | Tham chiếu yếu, **KHÔNG phải TinyFusion** |
| Fixed criterion | **Diff-Pruning** (Taylor) | Áp lại ở **sub-block** | RQ0b |
| Fixed criterion | **OBS-Diff** (Hessian/OBS) | sub-block | RQ0b |
| Fixed criterion | Magnitude / activation-norm | sub-block | RQ0b (đáy) |
| Trivial | **Random** mask (10 seed) | sub-block | Sàn tham chiếu |
| Trivial | Uniform (cắt đều attn+mlp) | sub-block | Kiểm "bất đối xứng có cần?" |
| Recovery baseline | **2ndMatch** (khớp $J^\top J$) | thay bước Pha B | So khâu phục hồi vs LoRA-proxy |
| Phân biệt phạm vi (KHÔNG so trực tiếp) | **DiffSparse** | token-caching | Chỉ nêu khác trục — token vs structural |

> **Điểm mấu chốt cho RQ0b:** ta **hạ độ mịn** của Diff-Pruning/OBS-Diff xuống mức sub-block để so **cùng không gian quyết định** với LAAMP → cô lập biến "*học được vs cố định*", loại nhiễu "độ mịn khác nhau".
>
> **TinyFusion — hai mức so sánh:** (1) *Control nội bộ* (cô lập biến "bất đối xứng") = method `tinyfusion` — chính là LAAMP với ràng buộc coupled, cùng máy móc học/LoRA/iso-FLOPs ⇒ chênh lệch chỉ do *asymmetry*. (2) *Số tuyệt đối vs công bố* (FID 2.86 @14 lớp): chạy **repo gốc** [VainF/TinyFusion](https://github.com/VainF/TinyFusion) trực tiếp — ta *tái lập phương pháp*, không dùng code/checkpoint của họ. Repo xác nhận: depth-pruning cả layer, mask khả vi học được tối ưu recoverability, LoRA đồng-tối-ưu, DiT-XL 28→14 ~2×.

### 4.3. Điểm ngân sách FLOPs (quét Pareto)

Chạy mỗi phương pháp ở **≥3 mức**: giữ **{75%, 50%, 35%}** FLOPs của model gốc (50% khớp mốc "28→14 lớp" của TinyFusion). Vẽ đường **FID vs FLOPs** cho từng phương pháp trên cùng trục.

### 4.4. Chỉ số

- **Chất lượng:** FID (chính), IS (ImageNet); **ImageReward + CLIP-score + HPSv2** (T2I); **LPIPS/PSNR** so ảnh model-gốc (đo méo cấu trúc).
- **Hiệu năng:** latency (ms/ảnh) & VRAM **thực đo trên RTX 4090** (và 3090 để khả-chuyển), tách rõ *nén lý thuyết* vs *wall-clock*.
- **Đặc trưng mask:** tỉ lệ giữ attn vs mlp theo độ sâu; chỉ số bất đối xứng $A = \frac{1}{L}\sum_\ell |m^{\text{attn}}_\ell - m^{\text{mlp}}_\ell|$.
- **Thống kê:** ≥**3 seed** cho Pha A+B; báo cáo mean±std; kiểm định **paired bootstrap / Wilcoxon** cho FID chênh lệch (ngưỡng $p<0.05$).

### 4.5. Ba thí nghiệm lõi

**TN-1 (RQ0a — profiling recoverability tách nhánh).**
Với mỗi khối con $(\ell,b)$: drop **đơn lẻ** nó, gắn LoRA-proxy, phục hồi $K$ bước ngắn, đo $\Delta\text{loss}_{\ell,b}$ (recoverability). Vẽ **heatmap** $L \times \{$attn,mlp$\}$.
→ Kiểm định: phân phối recoverability của attn **khác** mlp? (paired test theo tầng). Xu hướng theo độ sâu có khác nhau? **Đây là bằng chứng động lực trước cả khi chạy pruning đầy đủ.**

**TN-2 (RQ0a — bất đối xứng vs nguyên khối, iso-FLOPs).**
LAAMP (mask kép) **vs** biến thể-ràng-buộc-đối-xứng của chính LAAMP ($m^{\text{attn}}_\ell \equiv m^{\text{mlp}}_\ell$, = TinyFusion tái lập) **vs** TinyFusion gốc. Cả 3 ở {75,50,35}% FLOPs, cùng recovery.
→ Kết luận RQ0a: đường Pareto LAAMP **nằm dưới** (FID thấp hơn) ⇒ bất đối xứng có lợi.

**TN-3 (RQ0b — học được vs cố định, iso-FLOPs, iso-granularity).**
LAAMP **vs** {Diff-Pruning, OBS-Diff, magnitude, random, uniform} — tất cả ở **mức sub-block**, cùng {75,50,35}% FLOPs, cùng recovery.
→ Kết luận RQ0b: LAAMP thắng ⇒ tín hiệu học được > tiêu chí cố định ngay ở cùng độ mịn.

### 4.6. Ablation (cô lập đóng góp của từng thành phần)

| # | Biến thể | Cô lập điều gì |
|---|---|---|
| AB-1 | Mask **đơn** (coupled) vs **kép** | Giá trị của việc tách attn/mlp |
| AB-2 | LoRA-proxy **tách nhánh** vs **chung** vs **không proxy** (tối ưu loss tức thời) | Giá trị recoverability học được & tách nhánh |
| AB-3 | Ngân sách **biến thiên theo độ sâu** vs **N:M cứng** vs **tỉ lệ attn=mlp cố định** | Giá trị mật độ bất đối xứng |
| AB-4 | Prior độ sâu $\lambda_D$: {0, nhỏ, lớn} | Có cần cài prior hay dữ liệu tự tìm ra? |
| AB-5 | LoRA rank $\{4,8,16,32\}$; $\tau$-schedule; lr-mask | Độ nhạy siêu tham số |
| AB-6 | Pha B = **2ndMatch** vs LoRA-finetune vs full-finetune | Khâu phục hồi tốt nhất |

### 4.7. Mở rộng phụ (chỉ nếu RQ0a xác nhận — KHÔNG phải đóng góp thứ ba)
Nếu attn/mlp thật bất đối xứng recoverability → thử **bit-width bất đối xứng** (attn vs mlp khác precision) phản chiếu mask, báo cáo dưới dạng **một ablation** nối sang trục lượng tử (PROPOSAL §2★ ghi chú; tiền lệ Homogeneous-Keys-Heterogeneous-Values, phản đề Spark Transformer).

---

## 5. Tiêu chí kết luận (định lượng — chốt trước khi chạy)

Đóng góp 1 được coi là **thành công** nếu **đồng thời**:

1. **RQ0a:** LAAMP đạt **giảm FID ≥ 5% tương đối** so với TinyFusion ở ≥2 trong 3 mức FLOPs, trên **≥2 substrate**, $p<0.05$ (≥3 seed); **và** chỉ số bất đối xứng $A$ khác 0 có ý nghĩa (mask thật sự lệch attn/mlp).
2. **RQ0b:** LAAMP **thấp hơn FID** mọi baseline cố định ở cùng iso-FLOPs/iso-granularity (không chồng lấn khoảng tin cậy với baseline mạnh nhất — thường Diff-Pruning-subblock).
3. **Không thoái lui hệ thống:** latency/VRAM thực đo trên 4090 **không tệ hơn** TinyFusion ở cùng FLOPs (nén cấu trúc dịch được thành wall-clock).

**Kết luận "âm" cũng có giá trị đăng:** nếu RQ0a bị bác (attn/mlp *đối xứng* về recoverability) → đó là phát hiện đối lập Spark-Transformer-style đáng báo cáo; khi đó lùi về TinyFusion nguyên khối + tập trung Đóng góp 2.

---

## 6. Rủi ro & giảm thiểu

| Rủi ro | Giảm thiểu |
|---|---|
| Mask kép làm không gian tìm kiếm lớn → khó hội tụ | Khởi tạo bias-về-keep; annealing $\tau$; warm-start từ mask TinyFusion coupled |
| FLUX-dev không full-finetune được (24GB) | Chỉ LoRA-proxy; head-to-head chính đặt ở DiT-XL/SDXL |
| Baseline cố định "không công bằng" vì khác độ mịn | Hạ tất cả về **sub-block** (§4.2) → cô lập biến học-được |
| SVDQuant-INT4 trên Ampere (3090) | Khóa rủi ro ở P0a tuần đầu (PROPOSAL §9) — độc lập với thuật toán này |
| Recovery budget lệch giữa các phương pháp | Chốt cứng RECOVERY_BUDGET dùng chung; ghi vào log mỗi run |

---

## 7. Bám phân pha (khớp PROPOSAL §9 · P0b)

1. **Tuần 1–2:** cài mask kép + LoRA tách nhánh trên **DiT-XL/2**; đo vector chi phí $\mathbf{c}$; chạy **TN-1** (heatmap recoverability) → *bằng chứng động lực sớm cho RQ0a*.
2. **Tuần 3–5:** **TN-2 + TN-3** trên DiT-XL/2 ở {75,50,35}%, 3 seed → kết luận RQ0a/RQ0b sơ bộ.
3. **Tuần 6–8:** port sang **SDXL** (full-finetune) → kiểm tổng quát + đóng góp T2I.
4. **Tuần 9–10:** **FLUX-dev** (LoRA-proxy) — chứng minh scale; **AB-1..AB-6** ablation.
5. **Tuần 11–12:** đo latency/VRAM 4090+3090; tổng hợp bản đồ mask + Pareto; viết mục Đóng góp 1.

---

## 8. Sản phẩm bàn giao (deliverables)

- Bảng **FID/IS/IR/CLIP** × {phương pháp} × {75,50,35}% × {DiT-XL, SDXL, FLUX} (mean±std, p-value).
- **Đường Pareto FID–FLOPs** (LAAMP vs TinyFusion vs cố định).
- **Heatmap recoverability** (TN-1) + **bản đồ mask học được** (tỉ lệ giữ attn/mlp theo độ sâu) + chỉ số $A$.
- Bảng **latency/VRAM thực đo** 4090/3090.
- Code + config tái lập (seed, RECOVERY_BUDGET, $\tau$-schedule, LoRA rank).
- Kết luận RQ0a/RQ0b theo tiêu chí §5.
