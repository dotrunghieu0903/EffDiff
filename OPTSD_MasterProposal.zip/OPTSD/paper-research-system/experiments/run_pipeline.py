"""One-command pipeline for Contribution 1 (LAAMP).

Reads a single YAML config and runs the entire GPU_RUNBOOK end-to-end:
  checkpoint -> latents -> sanity_gate -> tn1 -> sweep -> latency -> summary

Each stage is gated (`enabled`) and RESUMABLE: if its output already exists it is
skipped unless `force: true`. Two modes share one flow:
  * mode: dit_xl  -> real run (official ckpt, ImageNet latents, real FID)
  * mode: tiny    -> CPU dry-run (synthetic data, proxy metric) to validate wiring

Run:
    python -m experiments.run_pipeline --config experiments/configs/pipeline.yaml
"""
from __future__ import annotations

import argparse
import copy
import json
import time
import urllib.request
from pathlib import Path

import torch
import yaml

from .laamp import (DiTConfig, build_model, build_objective, SearchConfig,
                    run_search, apply_hard_mask, recover, asymmetry_index,
                    kept_counts, baselines, profiling)
from .laamp.flops import full_flops
from .harness import latency as lat_h, stats as stats_h, metrics as metrics_h
from .data import synthetic_iter, latent_folder_iter


# --------------------------------------------------------------------------
# config helpers
# --------------------------------------------------------------------------
def g(d, path, default=None):
    cur = d
    for k in path.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def stage_on(cfg, name):
    return bool(g(cfg, f"stages.{name}.enabled", True))


def stage_force(cfg, name):
    return bool(g(cfg, f"stages.{name}.force", False))


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def banner(s):
    print("\n" + "=" * 64 + f"\n== {s}\n" + "=" * 64, flush=True)


# --------------------------------------------------------------------------
# shared factories
# --------------------------------------------------------------------------
def make_model_cfg(cfg) -> DiTConfig:
    return DiTConfig.tiny() if g(cfg, "mode") == "tiny" else DiTConfig.dit_xl_2()


def make_data_factory(cfg, mcfg, device):
    """Return a function seed->infinite (x0,y) iterator, matching the mode."""
    if g(cfg, "mode") == "tiny":
        return lambda seed=0: synthetic_iter(
            batch=g(cfg, "data.batch", 16), channels=mcfg.in_channels,
            size=mcfg.input_size, num_classes=mcfg.num_classes, seed=seed, device=device)
    latents = g(cfg, "data.latents")
    return lambda seed=0: latent_folder_iter(latents, batch=g(cfg, "data.batch", 32),
                                             device=device)


# --------------------------------------------------------------------------
# stage 1: checkpoint -> base_state.pt
# --------------------------------------------------------------------------
def stage_checkpoint(cfg, mcfg, objective, data_factory, device, out):
    base_path = out / "base_state.pt"
    if base_path.exists() and not stage_force(cfg, "checkpoint"):
        log(f"checkpoint: reuse {base_path}")
        return torch.load(base_path, map_location=device)

    mode = g(cfg, "mode")
    if mode == "dit_xl":
        ckpt = g(cfg, "checkpoint.official_path", "DiT-XL-2-256x256.pt")
        url = g(cfg, "checkpoint.download_url")
        if not Path(ckpt).exists() and url:
            log(f"checkpoint: downloading -> {ckpt}")
            urllib.request.urlretrieve(url, ckpt)
        from .laamp.load_official import load_official_dit_xl2
        model = load_official_dit_xl2(ckpt, device=device)
        state = model.state_dict()
    else:  # tiny: quick pretrain so pruning has a meaningful model
        log("checkpoint: pretraining tiny model on synthetic data")
        model = build_model(mcfg).to(device)
        opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
        it = data_factory(0)
        model.train()
        for step in range(g(cfg, "checkpoint.pretrain_steps", 300)):
            loss = objective.loss(model, *next(it))
            opt.zero_grad(); loss.backward(); opt.step()
        state = model.state_dict()

    torch.save(state, base_path)
    log(f"checkpoint: saved base -> {base_path}")
    return state


# --------------------------------------------------------------------------
# stage 2: latents (dit_xl only)
# --------------------------------------------------------------------------
def stage_latents(cfg, out):
    if g(cfg, "mode") == "tiny":
        log("latents: tiny mode uses synthetic data (skip)")
        return
    latents = Path(g(cfg, "data.latents"))
    if latents.exists() and list(latents.glob("*.pt")) and not stage_force(cfg, "latents"):
        log(f"latents: reuse {latents} ({len(list(latents.glob('*.pt')))} shards)")
        return
    imagenet = g(cfg, "data.imagenet")
    assert imagenet, "data.imagenet required to build latents"
    from .preprocess_latents import encode_imagenet
    encode_imagenet(imagenet, str(latents), vae=g(cfg, "data.vae", "stabilityai/sd-vae-ft-ema"),
                    img=g(cfg, "data.img", 256), batch=g(cfg, "data.enc_batch", 64),
                    shard_size=g(cfg, "data.shard_size", 10000),
                    dtype=g(cfg, "data.dtype", "fp16"))


# --------------------------------------------------------------------------
# stage 3: sanity gate (dit_xl only) -- base FID must be small before pruning
# --------------------------------------------------------------------------
def stage_sanity(cfg, mcfg, base_state, device, out):
    if g(cfg, "mode") == "tiny" or not stage_on(cfg, "sanity_gate"):
        log("sanity_gate: skipped")
        return None
    res_path = out / "sanity_fid.json"
    if res_path.exists() and not stage_force(cfg, "sanity_gate"):
        log(f"sanity_gate: reuse {res_path}")
        return json.loads(res_path.read_text())["fid"]
    from . import eval_fid
    model = build_model(mcfg).to(device)
    model.load_state_dict(base_state, strict=False)
    vae = eval_fid.load_vae(g(cfg, "data.vae"), device)
    fid = eval_fid.fid_torchmetrics(
        model, vae, g(cfg, "eval.real_dir"), n=g(cfg, "sanity_gate.n", 10000),
        cfg_scale=g(cfg, "eval.cfg", 1.5), steps=g(cfg, "eval.sanity_steps", 250),
        batch=g(cfg, "eval.batch", 64), device=device)
    thr = g(cfg, "sanity_gate.max_fid", 10.0)
    log(f"sanity_gate: base FID = {fid:.3f} (threshold {thr})")
    if fid > thr:
        log(f"[WARN] base FID {fid:.3f} > {thr}: checkpoint port or sampler likely wrong!")
    res_path.write_text(json.dumps({"fid": fid, "threshold": thr}, indent=2))
    return fid


# --------------------------------------------------------------------------
# stage 4: TN-1 recoverability heatmap
# --------------------------------------------------------------------------
def stage_tn1(cfg, mcfg, base_state, objective, data_factory, device, out):
    if not stage_on(cfg, "tn1"):
        log("tn1: skipped")
        return
    prefix = str(out / "tn1_heatmap")
    if Path(prefix + ".csv").exists() and not stage_force(cfg, "tn1"):
        log("tn1: reuse existing heatmap")
        return
    delta = profiling.profile_recoverability(
        lambda: build_model(mcfg), base_state, mcfg, objective,
        lambda: data_factory(3), k_recover=g(cfg, "tn1.k_recover", 40),
        n_eval=g(cfg, "tn1.n_eval", 8), device=device, verbose=False)
    summ = profiling.summarize(delta)
    profiling.render_heatmap(delta, prefix)
    (out / "tn1_summary.json").write_text(json.dumps(summ, indent=2))
    log(f"tn1: {summ}")


# --------------------------------------------------------------------------
# stage 5: sweep (TN-2 / TN-3)
# --------------------------------------------------------------------------
def build_scorer(cfg, mcfg, objective, data_factory, device):
    metric = g(cfg, "eval.metric", "proxy")
    if metric == "proxy":
        def scorer(model, seed):
            return metrics_h.denoise_proxy(model, objective, data_factory(seed + 999),
                                           n_batches=g(cfg, "eval.proxy_batches", 16))
        return scorer, "denoise_proxy"
    # real FID
    from . import eval_fid
    vae = eval_fid.load_vae(g(cfg, "data.vae"), device)

    def scorer(model, seed):
        return eval_fid.fid_torchmetrics(
            model, vae, g(cfg, "eval.real_dir"), n=g(cfg, "eval.fid_n", 50000),
            cfg_scale=g(cfg, "eval.cfg", 1.5), steps=g(cfg, "eval.steps", 50),
            batch=g(cfg, "eval.batch", 64), device=device)
    return scorer, "fid"


def get_mask(method, model, keep_ratio, objective, data_iter, seed, device, search_steps, scfg_over):
    # 'tinyfusion'/'laamp_coupled' = LEARNED coupled mask (TinyFusion reproduction,
    # primary RQ0a control). 'coupled' (baselines) = magnitude heuristic, NOT TinyFusion.
    if method in ("laamp", "laamp_coupled", "tinyfusion"):
        scfg = SearchConfig(keep_ratio=keep_ratio, n_steps=search_steps,
                            coupled=(method != "laamp"), **scfg_over)
        res = run_search(copy.deepcopy(model), objective, data_iter, scfg, device, verbose=False)
        return res["m_star"], {"achieved": res["achieved_flops"]}
    m = baselines.select(method, model, keep_ratio, objective=objective,
                         data_iter=data_iter, seed=seed, device=device)
    return m, {}


def stage_sweep(cfg, mcfg, base_state, objective, data_factory, device, out):
    res_path = out / "sweep_results.json"
    if res_path.exists() and not stage_force(cfg, "sweep"):
        log(f"sweep: reuse {res_path}")
        return json.loads(res_path.read_text())

    methods = g(cfg, "sweep.methods", ["laamp", "coupled", "random"])
    keep_ratios = g(cfg, "sweep.keep_ratios", [0.5])
    seeds = g(cfg, "sweep.seeds", [0, 1, 2])
    search_steps = g(cfg, "sweep.search_steps", 2000)
    recover_steps = g(cfg, "sweep.recover_steps", 2000)
    recover_lr = g(cfg, "sweep.recover_lr", 1e-4)
    save_models = g(cfg, "sweep.save_pruned", False)
    scfg_over = g(cfg, "sweep.search_overrides", {}) or {}
    scorer, metric_name = build_scorer(cfg, mcfg, objective, data_factory, device)
    ckpt_dir = out / "pruned"; ckpt_dir.mkdir(exist_ok=True)

    results = []
    for kr in keep_ratios:
        for method in methods:
            for seed in seeds:
                torch.manual_seed(seed)
                model = build_model(mcfg).to(device); model.load_state_dict(base_state, strict=False)
                m_star, extra = get_mask(method, model, kr, objective, data_factory(seed),
                                         seed, device, search_steps, scfg_over)
                model = build_model(mcfg).to(device); model.load_state_dict(base_state, strict=False)
                apply_hard_mask(model, m_star)
                recover(model, objective, data_factory(seed + 100),
                        n_steps=recover_steps, lr=recover_lr, device=device, verbose=False)
                score = scorer(model, seed)
                rec = dict(method=method, keep_ratio=kr, seed=seed, metric=metric_name,
                           score=score, asymmetry=asymmetry_index(m_star, mcfg.depth),
                           kept=kept_counts(m_star, mcfg.depth), **extra)
                results.append(rec)
                log(f"  {method:10s} kr={kr} seed={seed} {metric_name}={score:.4f} "
                    f"A={rec['asymmetry']:.3f} kept={rec['kept']}")
                if save_models:
                    torch.save(model.state_dict(),
                               ckpt_dir / f"{method}_kr{kr}_seed{seed}.pt")

    comparisons = compare(results, methods, keep_ratios)
    payload = dict(results=results, comparisons=comparisons, metric=metric_name)
    res_path.write_text(json.dumps(payload, indent=2))
    log(f"sweep: wrote {res_path}")
    return payload


def compare(results, methods, keep_ratios):
    comps = []
    for kr in keep_ratios:
        def sc(m):
            return [x["score"] for x in results if x["method"] == m and x["keep_ratio"] == kr]
        if "laamp" not in methods or not sc("laamp"):
            continue
        for b in methods:
            if b == "laamp" or not sc(b):
                continue
            bs = stats_h.paired_bootstrap_diff(sc("laamp"), sc(b))
            wc = stats_h.wilcoxon_test(sc("laamp"), sc(b))
            rel = stats_h.relative_improvement(sc("laamp"), sc(b))
            comps.append(dict(keep_ratio=kr, vs=b, rel_improvement_pct=rel, wilcoxon=wc, **bs))
            log(f"  [cmp] kr={kr} LAAMP vs {b}: rel={rel:+.1f}% "
                f"diff={bs['mean_diff']:+.4f} CI=[{bs['ci_low']:+.4f},{bs['ci_high']:+.4f}] "
                f"p(lower)={bs['prob_a_lower']:.2f}")
    return comps


# --------------------------------------------------------------------------
# stage 6: latency / VRAM
# --------------------------------------------------------------------------
def stage_latency(cfg, mcfg, base_state, device, out):
    if not stage_on(cfg, "latency"):
        log("latency: skipped")
        return None
    res_path = out / "latency.json"
    if res_path.exists() and not stage_force(cfg, "latency"):
        return json.loads(res_path.read_text())
    b = g(cfg, "latency.batch", 4)
    model = build_model(mcfg).to(device); model.load_state_dict(base_state, strict=False)
    T = mcfg.input_size
    sample = lambda: (torch.randn(b, mcfg.in_channels, T, T, device=device),
                      torch.rand(b, device=device) * 999,
                      torch.randint(0, mcfg.num_classes, (b,), device=device))
    out_d = dict(base=lat_h.measure_latency(model, sample, device, warmup=3, iters=10),
                 base_peak_mb=lat_h.measure_peak_memory(model, sample, device),
                 base_params=lat_h.param_count(model, only_alive=False))
    res_path.write_text(json.dumps(out_d, indent=2, default=str))
    log(f"latency: base {out_d['base']}")
    return out_d


# --------------------------------------------------------------------------
# stage 7: summary
# --------------------------------------------------------------------------
def stage_summary(cfg, out, sweep, lat, sanity):
    lines = ["# Pipeline summary", ""]
    lines.append(f"- mode: `{g(cfg, 'mode')}`   metric: `{sweep.get('metric') if sweep else '-'}`")
    if sanity is not None:
        lines.append(f"- sanity-gate base FID: {sanity:.3f}")
    if lat:
        lines.append(f"- base latency: {lat['base'].get('ms_mean'):.2f} ms   "
                     f"peak: {lat.get('base_peak_mb')} MB   params: {lat.get('base_params'):,}")
    if sweep:
        lines += ["", "## Results (score: lower=better)", "",
                  "| method | keep | seed | score | A | attn_kept | mlp_kept |",
                  "|---|---|---|---|---|---|---|"]
        for r in sweep["results"]:
            k = r["kept"]
            lines.append(f"| {r['method']} | {r['keep_ratio']} | {r['seed']} | "
                         f"{r['score']:.4f} | {r['asymmetry']:.3f} | {k['attn_kept']} | {k['mlp_kept']} |")
        lines += ["", "## LAAMP vs baselines", "",
                  "| keep | vs | rel % | mean_diff | CI | p(lower) | wilcoxon p |",
                  "|---|---|---|---|---|---|---|"]
        for c in sweep["comparisons"]:
            lines.append(f"| {c['keep_ratio']} | {c['vs']} | {c['rel_improvement_pct']:+.1f} | "
                         f"{c['mean_diff']:+.4f} | [{c['ci_low']:+.4f},{c['ci_high']:+.4f}] | "
                         f"{c['prob_a_lower']:.2f} | {c['wilcoxon'].get('pvalue')} |")
    (out / "SUMMARY.md").write_text("\n".join(lines))
    log(f"summary: wrote {out/'SUMMARY.md'}")


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())

    device = "cuda" if torch.cuda.is_available() and g(cfg, "device", "auto") != "cpu" else "cpu"
    out = Path(g(cfg, "output_dir", "experiments/results/run"))
    out.mkdir(parents=True, exist_ok=True)
    mcfg = make_model_cfg(cfg)
    objective = build_objective(g(cfg, "objective", "flow"), device)
    data_factory = make_data_factory(cfg, mcfg, device)

    log(f"mode={g(cfg,'mode')} device={device} depth={mcfg.depth} "
        f"full_flops={full_flops(mcfg):.3e} out={out}")

    banner("STAGE 2  latents");        stage_latents(cfg, out)
    banner("STAGE 1  checkpoint")
    base_state = stage_checkpoint(cfg, mcfg, objective, data_factory, device, out)
    banner("STAGE 3  sanity gate");    sanity = stage_sanity(cfg, mcfg, base_state, device, out)
    banner("STAGE 4  TN-1 heatmap");   stage_tn1(cfg, mcfg, base_state, objective, data_factory, device, out)
    banner("STAGE 5  sweep")
    sweep = stage_sweep(cfg, mcfg, base_state, objective, data_factory, device, out) if stage_on(cfg, "sweep") else None
    banner("STAGE 6  latency");        lat = stage_latency(cfg, mcfg, base_state, device, out)
    banner("STAGE 7  summary");        stage_summary(cfg, out, sweep, lat, sanity)
    banner("PIPELINE DONE")
    log(f"all artifacts under {out}")


if __name__ == "__main__":
    main()
