# GPU Runbook — Contribution 1 (LAAMP) on DiT-XL/2

Step-by-step to reproduce the head-to-head vs TinyFusion on a real GPU
(RTX 4090 primary, 3090 for portability — PROPOSAL §6). Answers the two open
questions: **(1)** how to get the checkpoint + latents, **(2)** how to run real FID.

> **Status of assets in this repo:** none present. No DiT checkpoint and no
> ImageNet latents exist under the project — steps 1–3 below create them.

---

## ⭐ ONE FILE, ONE COMMAND (recommended)

Everything below (dataset → checkpoint → sanity → TN-1 → sweep → FID → latency →
results) is driven by a single YAML and a single command:

```bash
# 0. install deps (step 0 below)
# 1. edit paths in experiments/configs/pipeline.yaml  (data.imagenet, data.latents,
#    eval.real_dir)  -- checkpoint auto-downloads
# 2. run everything:
python -m experiments.run_pipeline --config experiments/configs/pipeline.yaml
```

- **Resumable:** each stage skips if its output exists; set `force: true` on a
  stage (or delete its file under `output_dir`) to rerun just that one.
- **Toggle stages** via `stages.<name>.enabled` in the YAML.
- **Validate the wiring first on CPU** (no GPU/downloads, synthetic data):
  ```bash
  python -m experiments.run_pipeline --config experiments/configs/pipeline_tiny.yaml
  ```
- Artifacts land in `output_dir`: `base_state.pt`, `sanity_fid.json`,
  `tn1_heatmap.csv`, `sweep_results.json`, `pruned/*.pt`, `latency.json`,
  and a human-readable `SUMMARY.md`.

The sections below explain each stage the pipeline runs, and how to run any step
manually if you want to.

---

## 0. Environment (once, on the GPU box)

```bash
# CUDA build of torch (match your driver; example cu124)
pip install torch --index-url https://download.pytorch.org/whl/cu124
pip install diffusers torchvision pillow scipy pyyaml tqdm
pip install "torchmetrics[image]"          # real FID
# optional (T2I / extra metrics later): image-reward lpips
```

Everything under `experiments/` is pure PyTorch; only preprocessing (VAE),
sampling (VAE), and FID need `diffusers` / `torchmetrics`.

---

## 1. (Q1a) Get the DiT-XL/2 checkpoint

Official Meta checkpoint, 256×256, `learn_sigma=True`:

```bash
curl -L -o DiT-XL-2-256x256.pt \
  https://dl.fbaipublicfiles.com/DiT/models/DiT-XL-2-256x256.pt
```

Load it into our `MaskableDiT` (only `adaLN_modulation.→adaLN.` keys are renamed;
mask buffers keep default 1.0):

```python
from experiments.laamp.load_official import load_official_dit_xl2
model = load_official_dit_xl2("DiT-XL-2-256x256.pt", device="cuda")
```

The loader prints missing/unexpected keys — the ONLY acceptable "missing" are the
`m_attn`/`m_mlp` mask buffers. Any other missing/unexpected key ⇒ stop and fix
the remap before continuing.

### 1b. SANITY GATE (do this before ANY pruning)

A wrong port silently poisons every later number. Confirm the loaded model
reproduces DiT-XL/2's published quality first:

```bash
# save the loaded (un-pruned) model, then FID it
python -c "import torch; from experiments.laamp.load_official import load_official_dit_xl2; \
  torch.save(load_official_dit_xl2('DiT-XL-2-256x256.pt').state_dict(), 'dit_xl2_base.pt')"

python -m experiments.eval_fid --ckpt dit_xl2_base.pt --config dit_xl \
  --n 10000 --cfg 1.5 --steps 250 --mode torchmetrics --real_dir /data/imagenet256_val
```

Expect FID in the low single digits (published: **2.27** @ cfg=1.5, 250-step DDPM,
50k). A torchmetrics/10k number will be a bit higher but must be *small*. If you
get tens/hundreds, the checkpoint port or sampler is wrong — do not proceed.

> To match the *exact* published 2.27 you need learned-sigma variance + 250-step
> ancestral DDPM + the ADM reference (step 6b). For method-vs-method comparison
> the fixed DDIM path here is sufficient and consistent.

---

## 2. (Q1b) Pre-encode ImageNet-256 → SD-VAE latents

DiT trains in latent space; cache latents once so search/recovery never runs the
VAE. Needs ImageNet `train/` as an `ImageFolder` (class subdirs).

```bash
python -m experiments.preprocess_latents \
  --imagenet /data/imagenet/train \
  --out /data/imagenet256_sdvae_latents \
  --vae stabilityai/sd-vae-ft-ema --img 256 --shard_size 10000 --dtype fp16
```

Produces `shard_XXXX.pt` = `{"latent": (N,4,32,32), "label": (N,)}`. ~1.3M images
→ ~130 shards. `data.latent_folder_iter` streams these during search/recovery.

> No ImageNet? Use a subset (even 100–200 imgs/class) for search+recovery; FID
> still needs a real reference set (step 6). The class-conditional structure is
> what matters for recoverability, not the full 1.28M.

---

## 3. Confirm the FLOPs cost vector on the real model

```python
import torch
from experiments.laamp.load_official import load_official_dit_xl2
from experiments.laamp.flops import analytic_cost_vector, measured_cost_vector
m = load_official_dit_xl2("DiT-XL-2-256x256.pt", device="cuda")
x = torch.randn(2,4,32,32,device="cuda"); t=torch.rand(2,device="cuda")*999
y = torch.randint(0,1000,(2,),device="cuda")
ca = analytic_cost_vector(m.cfg).cuda()
cm = measured_cost_vector(m, x, t, y).cuda()/2   # de-batch
print("analytic/measured ratio per subblock:", (ca/cm)[:4])
```

Analytic includes the T² attention-scores term (not in the Linear-only measured
count) so attention entries differ by that term — expected. Use analytic `c` for
the budget (it is the one the search penalises).

---

## 4. Run TN-1 (recoverability heatmap) — early motivational evidence

```python
import torch
from experiments.laamp import DiTConfig, build_model, build_objective, profiling
from experiments.data import latent_folder_iter
cfg = DiTConfig.dit_xl_2(); obj = build_objective("ddpm","cuda")
state = torch.load("dit_xl2_base.pt")
di = lambda: latent_folder_iter("/data/imagenet256_sdvae_latents", batch=32, device="cuda")
delta = profiling.profile_recoverability(lambda: build_model(cfg), state, cfg, obj,
                                         di, k_recover=100, n_eval=16, device="cuda")
print(profiling.summarize(delta))
profiling.render_heatmap(delta, "experiments/results/tn1_ditxl")
```

Deliverable: the L×{attn,mlp} heatmap + Wilcoxon(attn vs mlp) + depth-correlation.
This alone answers "do attn and mlp differ?" before the full sweep.

---

## 5. Run TN-2 / TN-3 (the Pareto sweep vs baselines)

```bash
python -m experiments.run_contrib1 --config dit_xl \
  --latents /data/imagenet256_sdvae_latents --objective ddpm \
  --ckpt dit_xl2_base.pt \
  --methods laamp coupled magnitude taylor random uniform \
  --keep_ratios 0.75 0.5 0.35 --seeds 0 1 2 \
  --search_steps 3000 --recover_steps 5000 --batch 32 \
  --out experiments/results/contrib1_ditxl.json
```

This writes per-run quality + mask asymmetry `A` + kept counts + LAAMP-vs-baseline
bootstrap CIs / Wilcoxon p (harness/stats.py). Hyperparameters: `configs/dit_xl.yaml`.

Each `(method, keep_ratio, seed)` run: Phase-A search → physical prune →
**shared recovery budget** → score. It scores with the denoise proxy by default —
switch to real FID next.

---

## 6. (Q2) Real FID instead of the proxy

The proxy (held-out denoise loss) is only for the CPU logic check. For paper
numbers, score each pruned+recovered checkpoint with real FID.

### 6a. Internal comparison (torchmetrics) — backs RQ0a/RQ0b

Save each pruned+recovered model to its own `.pt`, then:

```bash
python -m experiments.eval_fid --ckpt pruned_laamp_kr0.5_seed0.pt --config dit_xl \
  --vae stabilityai/sd-vae-ft-ema --n 50000 --cfg 1.5 --steps 50 \
  --mode torchmetrics --real_dir /data/imagenet256_val
```

Use the **same** `--cfg/--steps/--n/--real_dir` for every method — only then are
FID deltas comparable. This is the number that goes in the RQ0a/RQ0b tables.

### 6b. Absolute head-to-head vs TinyFusion's reported 2.86 (ADM reference)

To claim "LAAMP FID X vs TinyFusion 2.86" on the same yardstick, use the ADM /
guided-diffusion protocol:

1. Generate 50k PNGs: `--mode adm-npz --save_dir samples_laamp`.
2. Download `VIRTUAL_imagenet256_labeled.npz` (openai/guided-diffusion).
3. Run their `evaluations/evaluator.py VIRTUAL_imagenet256_labeled.npz samples.npz`.

Report both: ADM-FID for the absolute claim, torchmetrics-FID for the internal
sweep (state which in the table).

### 6c. Official TinyFusion head-to-head (their repo, their number)

The `tinyfusion` method in our sweep is a *controlled* reproduction (LAAMP minus
asymmetry). For the *absolute* claim against TinyFusion's own published 2.86, run
the authors' repo and put both models through the SAME ADM evaluator/reference:

```bash
# fast: released TinyDiT-D14 checkpoint -> sample + FID (skips the 100-epoch KD)
GPUS=2 IMAGENET_TRAIN=/data/imagenet/train \
  bash experiments/baselines_official/run_tinyfusion.sh released
# full reproduce (expensive): prune + 100-epoch Masked-KD + FID
GPUS=8 bash experiments/baselines_official/run_tinyfusion.sh reproduce
```

Then FID LAAMP through the same evaluator (6b) with the same
`VIRTUAL_imagenet256_labeled.npz`. See
[baselines_official/README.md](baselines_official/README.md). (GPU only; verify
the repo's script/flag names before trusting a run.)

### Where the wiring lives

`run_contrib1.run_one()` currently calls `metrics.denoise_proxy`. To fold FID into
the sweep, replace that call with a `generate → FID.update → compute` block (the
pieces are in `sampling.py` + `harness/metrics.FID`); keep everything else
(iso-FLOPs, shared recovery, seeds, stats) unchanged.

---

## 7. Measured latency / VRAM (never copy paper numbers)

```python
from experiments.harness import latency
import torch
sample = lambda: (torch.randn(4,4,32,32,device="cuda"),
                  torch.rand(4,device="cuda")*999,
                  torch.randint(0,1000,(4,),device="cuda"))
print(latency.measure_latency(model, sample, "cuda"))
print("peak MB:", latency.measure_peak_memory(model, sample, "cuda"))
```

Report on 4090 (primary) and 3090 (portability). Success criterion §3: pruned
latency/VRAM must be no worse than TinyFusion at equal FLOPs.

---

## Checklist

- [ ] torch-CUDA + diffusers + torchmetrics installed
- [ ] `DiT-XL-2-256x256.pt` downloaded, loads with clean keys (step 1)
- [ ] **SANITY GATE** passed — base FID is small (step 1b)
- [ ] ImageNet latents cached to shards (step 2)
- [ ] TN-1 heatmap generated (step 4)
- [ ] TN-2/TN-3 sweep run, `contrib1_ditxl.json` written (step 5)
- [ ] real FID swapped in for the proxy, same sampler config across methods (step 6)
- [ ] official TinyFusion run (released ckpt) through the same ADM evaluator (step 6c)
- [ ] latency/VRAM measured on 4090 + 3090 (step 7)
- [ ] SDXL substrate repeated for the ≥2-substrate criterion (CONTRIB1 §4.1)
