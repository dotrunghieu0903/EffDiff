# Experiments — Contribution 1 (LAAMP)

Runnable implementation of **LAAMP: Learned Asymmetric Attention–MLP Pruning**,
the algorithm of Contribution 1. Spec: [../CONTRIB1-Pruning-Algorithm-Experiments.md](../CONTRIB1-Pruning-Algorithm-Experiments.md);
proposal §2★: [../PROPOSAL.md](../PROPOSAL.md).

The measurement harness under [harness/](harness/) is **shared** and will be
reused by Contribution 2 (the error-aware stack / orchestrator).

## What this proves

LAAMP cuts the **attention** and **MLP** branches of each DiT block
*independently* (mask `m_attn_l`, `m_mlp_l`) — TinyFusion is the special case
`m_attn_l == m_mlp_l` (whole block dropped as a monolith). Target conclusions:

- **RQ0a** — asymmetric sub-block cutting beats monolithic block cutting at iso-FLOPs.
- **RQ0b** — a *learned* recoverability signal beats *fixed* criteria (magnitude / Taylor) at the same granularity.

## Layout

| File | Role (CONTRIB1 ref) |
|---|---|
| `laamp/dit.py` | Maskable DiT — independent attn/mlp sub-blocks (§1) |
| `laamp/masking.py` | Dual Gumbel-Softmax + STE mask (§2.1–2.2) |
| `laamp/lora_proxy.py` | Branch-separated LoRA recoverability proxy (§2.1) |
| `laamp/flops.py` | Per-sub-block FLOPs cost vector `c` (§1.1) |
| `laamp/diffusion.py` | Flow-matching / DDPM denoise objective (§2.3) |
| `laamp/search.py` | Phase A: learn mask + LoRA under FLOPs budget (§2.4) |
| `laamp/prune.py` | Phase B: physical removal + shared recovery (§2.4) |
| `laamp/baselines.py` | coupled / magnitude / taylor / random / uniform (§4.2) |
| `laamp/profiling.py` | TN-1 recoverability heatmap (§4.5) |
| `harness/latency.py` | wall-clock latency + peak VRAM + param count (§4.4) |
| `harness/stats.py` | paired bootstrap + Wilcoxon + rel-improvement (§5) |
| `harness/metrics.py` | FID/CLIP/ImageReward/LPIPS wrappers + denoise proxy |
| `run_contrib1.py` | TN-2/TN-3 runner across methods × keep-ratios × seeds |
| `smoke_test.py` | CPU end-to-end logic check (no GPU, no downloads) |

## Quick start (CPU, ~1 min — logic check only)

```bash
python -m experiments.smoke_test
```

Verifies every stage: maskable forward, FLOPs accounting, Phase-A search hits
the budget and hardens, TN-1 heatmap, Phase-B prune+recover, latency harness.

> **The tiny/synthetic numbers are NOT results.** A 6-layer model on random
> Gaussian data has no real recoverability structure, so LAAMP need not beat
> baselines there — the smoke test only proves the *machinery* runs. Scientific
> claims (RQ0a/RQ0b) come only from the real substrates below.

## Real run (GPU — DiT-XL/2, head-to-head with TinyFusion)

**One file, one command.** Edit paths in [configs/pipeline.yaml](configs/pipeline.yaml)
then:

```bash
python -m experiments.run_pipeline --config experiments/configs/pipeline.yaml
```

This runs the whole flow — dataset latents → checkpoint (auto-download + remap) →
sanity gate → TN-1 → TN-2/TN-3 sweep → real FID → latency → `SUMMARY.md`. Every
stage is resumable (skips if its output exists; `force: true` to rerun one).
Validate the wiring on CPU first with
[configs/pipeline_tiny.yaml](configs/pipeline_tiny.yaml) (synthetic, no GPU).

**Full explanation of each stage + manual per-step commands:
[GPU_RUNBOOK.md](GPU_RUNBOOK.md).**

The lighter `run_contrib1.py` (proxy metric only, argparse-driven) remains for
quick sweeps without the full orchestration.

### From proxy to real FID

`run_contrib1.py` currently scores with `metrics.denoise_proxy` (a held-out
denoise loss) so it runs anywhere. For paper numbers, swap in `metrics.FID`
(needs a sampler + 50k generated images + `torchmetrics[image]`) — the wiring
point is `run_one()`; everything else (iso-FLOPs, shared recovery, stats) is
already correct.

## Success criteria (CONTRIB1 §5)

LAAMP "wins" iff **simultaneously**: (1) ≥5% relative FID reduction vs TinyFusion
at ≥2 of 3 FLOPs levels on ≥2 substrates, p<0.05; asymmetry `A` significantly
≠0; (2) beats every fixed-criterion baseline at iso-FLOPs/iso-granularity;
(3) measured 4090 latency/VRAM no worse than TinyFusion at equal FLOPs.

## Contribution 2 — error-aware stack

Built as a **separate package** [stack/](stack/) (reuses `harness/`, consumes
LAAMP as axis #1). It measures the pairwise error-interaction matrix (PROPOSAL
§3c), runs an error-aware orchestrator vs naive stacking (H1), and drives the
`analyze → recommend → apply` tool brain. One command:

```bash
python -m experiments.stack.run_stack --config experiments/stack/configs/stack_tiny.yaml   # CPU dry-run
python -m experiments.stack.run_stack --config experiments/stack/configs/stack.yaml         # real (needs Contrib 1 base_state.pt)
```

See [stack/README.md](stack/README.md).

**Trạng thái tổng: Đóng góp 1 (LAAMP, pipeline 1-command + GPU runbook) và Đóng góp 2 (stack + tool demo + adapter scaffold) đều xong phần CPU-verifiable. Việc còn lại đều là chạy/verify trên GPU thật: điền TODO adapter Nunchaku/TaylorSeer, thay proxy→FID, chạy DiT-XL.**