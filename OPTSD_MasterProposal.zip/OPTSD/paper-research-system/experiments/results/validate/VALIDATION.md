# Validation report — mode `tiny` (device cpu)

> ⚠️ **tiny/synthetic = LOGIC check only.** Criteria are evaluated mechanically; random-data toys have no real structure, so a FAIL here is NOT scientific evidence. Run `mode: dit_xl` on GPU for real verdicts.

## Contribution 1 — LAAMP

| hypothesis | verdict |
|---|---|
| RQ0a — asymmetric > learned-coupled (TinyFusion), mask A>0 | ✅ PASS |
| RQ0b — learned > best fixed criterion | ✅ PASS |

scores (lower=better): laamp=2.3120, tinyfusion=2.3336, taylor=2.3960, obs=2.3960, magnitude=2.4617, random=2.3663

LAAMP asymmetry A = 0.944

## Contribution 2 — error-aware stack

| hypothesis | verdict |
|---|---|
| H1 — error-aware/coordinated ≤ naive stacking | ✅ PASS |
| RQ4 — distillation crossover k* exists | — none in range |

naive error=0.0123, best error-aware/coordinated=0.0123