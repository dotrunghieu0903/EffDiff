# Error-Aware Stack — summary

## Interaction matrix (rho: +compounding / 0 orthogonal / - sub-additive)

| pair | e_A | e_B | e_AB | delta | rho | verdict |
|---|---|---|---|---|---|---|
| prune×quant | 0.6412 | 0.0811 | 0.6568 | -0.0654 | -0.09 | orthogonal |
| prune×cache | 0.6412 | 0.0210 | 0.6370 | -0.0251 | -0.04 | orthogonal |
| quant×cache | 0.0811 | 0.0210 | 0.0815 | -0.0206 | -0.20 | sub-additive |

## Orchestrator: naive vs error-aware

| target | naive err (axes) | error-aware err (axes) | aware better by |
|---|---|---|---|
| 2.0x | 0.0044 ['quant'] | 0.0044 ['quant'] | +0.0000 |
| 4.0x | 0.0102 ['quant', 'cache'] | 0.0102 ['quant', 'cache'] | +0.0000 |

## Recommendations (tool brain)

**@ 2.0x** (achieved 2.0x): `{'prune': 1.0, 'quant': 8, 'cache': 1}`
- Target 2.0x -> enabled axes: ['quant'].
-   'quant' @ 8: +4.0x for error 0.0044.

**@ 4.0x** (achieved 4.0x): `{'prune': 1.0, 'quant': 8, 'cache': 2}`
- Target 4.0x -> enabled axes: ['quant', 'cache'].
-   'quant' @ 8: +4.0x for error 0.0044.
-   'cache' @ 2: +4.0x for error 0.0094.
