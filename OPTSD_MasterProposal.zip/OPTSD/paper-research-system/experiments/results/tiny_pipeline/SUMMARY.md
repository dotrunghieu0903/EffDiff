# Pipeline summary

- mode: `tiny`   metric: `denoise_proxy`
- base latency: 4.48 ms   peak: None MB   params: 480,528

## Results (score: lower=better)

| method | keep | seed | score | A | attn_kept | mlp_kept |
|---|---|---|---|---|---|---|
| laamp | 0.5 | 0 | 2.4162 | 0.833 | 0 | 5 |
| laamp | 0.5 | 1 | 2.1184 | 1.000 | 6 | 0 |
| coupled | 0.5 | 0 | 2.3243 | 0.000 | 3 | 3 |
| coupled | 0.5 | 1 | 2.2206 | 0.000 | 3 | 3 |
| magnitude | 0.5 | 0 | 2.4464 | 0.500 | 1 | 4 |
| magnitude | 0.5 | 1 | 2.3162 | 0.500 | 1 | 4 |
| random | 0.5 | 0 | 2.4448 | 0.500 | 1 | 4 |
| random | 0.5 | 1 | 2.2311 | 1.000 | 3 | 3 |

## LAAMP vs baselines

| keep | vs | rel % | mean_diff | CI | p(lower) | wilcoxon p |
|---|---|---|---|---|---|---|
| 0.5 | coupled | +0.2 | -0.0052 | [-0.1023,+0.0919] | 0.76 | nan |
| 0.5 | magnitude | +4.8 | -0.1140 | [-0.1978,-0.0301] | 1.00 | nan |
| 0.5 | random | +3.0 | -0.0707 | [-0.1127,-0.0286] | 1.00 | nan |