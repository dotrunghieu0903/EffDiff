"""Load the official Meta DiT-XL/2 checkpoint into our MaskableDiT.

MaskableDiT mirrors the official DiT module layout on purpose, so only a couple
of keys need renaming:

    blocks.{i}.adaLN_modulation.1.*   ->  blocks.{i}.adaLN.1.*
    final_layer.adaLN_modulation.1.*  ->  final_layer.adaLN.1.*

Everything else (x_embedder.proj, t_embedder.mlp.0/2, y_embedder.embedding_table,
pos_embed, blocks.*.attn.qkv/proj, blocks.*.mlp.fc1/fc2, final_layer.linear)
matches by name. The per-sub-block mask buffers (m_attn/m_mlp) are absent from
the checkpoint and keep their default 1.0 (loaded with strict=False).

CHECKPOINT
----------
Official DiT-XL/2 @ 256x256 (learn_sigma=True), from facebookresearch/DiT:
    https://dl.fbaipublicfiles.com/DiT/models/DiT-XL-2-256x256.pt
Download once, e.g.:
    curl -L -o DiT-XL-2-256x256.pt \\
      https://dl.fbaipublicfiles.com/DiT/models/DiT-XL-2-256x256.pt

Then verify the port with the SANITY GATE (see GPU_RUNBOOK.md) BEFORE pruning:
a correctly-loaded model should reproduce DiT-XL/2's published FID (~2.27 with
cfg=1.5 / 250-step DDPM). If not, the remap is wrong -- do not proceed.
"""
from __future__ import annotations

import torch

from .dit import DiTConfig, MaskableDiT, build_model


def _remap_key(k: str) -> str:
    return k.replace("adaLN_modulation.", "adaLN.")


def load_official_dit_xl2(ckpt_path: str, device="cpu", verbose=True) -> MaskableDiT:
    cfg = DiTConfig.dit_xl_2()               # 28 blocks, 1152, learn_sigma=True
    model = build_model(cfg).to(device)

    raw = torch.load(ckpt_path, map_location=device)
    sd = raw.get("model", raw.get("ema", raw))  # official file may nest under 'ema'
    remapped = {_remap_key(k): v for k, v in sd.items()}

    missing, unexpected = model.load_state_dict(remapped, strict=False)
    # expected 'missing' = only the mask buffers we add
    real_missing = [m for m in missing if not (m.endswith("m_attn") or m.endswith("m_mlp"))]
    if verbose:
        print(f"[load] loaded {len(remapped)} tensors")
        print(f"[load] mask buffers kept default: "
              f"{sum(1 for m in missing if m.endswith(('m_attn','m_mlp')))}")
        if real_missing:
            print(f"[load][WARN] unexpected MISSING keys ({len(real_missing)}): {real_missing[:8]}")
        if unexpected:
            print(f"[load][WARN] UNEXPECTED checkpoint keys ({len(unexpected)}): {unexpected[:8]}")
        if not real_missing and not unexpected:
            print("[load] key match clean -> run the SANITY GATE next")
    return model
