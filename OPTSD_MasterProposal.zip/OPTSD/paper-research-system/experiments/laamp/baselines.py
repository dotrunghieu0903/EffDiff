"""Baseline sub-block selectors at iso-FLOPs (CONTRIB1 Section 4.2 / TN-3).

All baselines return an m_star vector in {0,1}^{2*depth} that keeps a set of
sub-blocks whose FLOPs cost <= B, so they are compared to LAAMP at the SAME
budget and SAME granularity (sub-block). This isolates the variable under test:
LEARNED recoverability (LAAMP) vs FIXED criteria (these). RQ0b.

  * coupled     : TinyFusion regime -- decision at block level (m_attn==m_mlp),
                  the primary RQ0a competitor rendered in the sub-block space.
  * magnitude   : keep sub-blocks with largest weight L2 norm.
  * taylor      : first-order Taylor importance |grad . weight| (Diff-Pruning
                  family) estimated on a calib batch, applied at sub-block level.
  * random      : random subset hitting budget (report over multiple seeds).
  * uniform     : drop attn and mlp evenly (tests "is asymmetry even needed?").
"""
from __future__ import annotations

import torch

from .dit import MaskableDiT
from .flops import analytic_cost_vector, full_flops


def _greedy_keep(scores: torch.Tensor, cost: torch.Tensor, B: float) -> torch.Tensor:
    """Keep highest-score sub-blocks while total cost <= B (knapsack heuristic)."""
    order = torch.argsort(scores, descending=True)
    keep = torch.zeros_like(scores)
    running = 0.0
    for i in order.tolist():
        if running + cost[i].item() <= B:
            keep[i] = 1.0
            running += cost[i].item()
    return keep


def _subblock_param_norm(model: MaskableDiT) -> torch.Tensor:
    depth = model.cfg.depth
    scores = torch.zeros(2 * depth)
    for l, blk in enumerate(model.blocks):
        scores[2 * l] = sum(p.detach().float().norm() ** 2 for p in blk.attn.parameters()) ** 0.5
        scores[2 * l + 1] = sum(p.detach().float().norm() ** 2 for p in blk.mlp.parameters()) ** 0.5
    return scores


def select(method: str, model: MaskableDiT, keep_ratio: float, *,
           objective=None, data_iter=None, seed: int = 0, device="cpu") -> torch.Tensor:
    depth = model.cfg.depth
    c = analytic_cost_vector(model.cfg)
    B = keep_ratio * full_flops(model.cfg)

    if method == "random":
        g = torch.Generator().manual_seed(seed)
        return _greedy_keep(torch.rand(2 * depth, generator=g), c, B)

    if method == "magnitude":
        return _greedy_keep(_subblock_param_norm(model), c, B)

    if method == "uniform":
        # keep the same fraction of attn and of mlp, spread evenly across depth
        keep = torch.zeros(2 * depth)
        for branch in (0, 1):
            idx = torch.arange(depth) * 2 + branch
            budget_b = B / 2
            # keep evenly spaced layers until per-branch budget hit
            per = c[idx][0].item()
            n_keep = max(0, min(depth, int(budget_b // per)))
            step = max(1, depth // max(n_keep, 1))
            chosen = list(range(0, depth, step))[:n_keep]
            for l in chosen:
                keep[2 * l + branch] = 1.0
        return keep

    if method == "coupled":  # MAGNITUDE-coupled whole-block heuristic (weak
        # reference only). NOT TinyFusion: TinyFusion learns the coupled mask --
        # that is the 'tinyfusion' method (learned, in run_contrib1/run_pipeline).
        block_score = _subblock_param_norm(model).view(depth, 2).sum(dim=1)
        block_cost = c.view(depth, 2).sum(dim=1)
        keep_blocks = _greedy_keep(block_score, block_cost, B)
        keep = torch.zeros(2 * depth)
        for l in range(depth):
            keep[2 * l] = keep_blocks[l]
            keep[2 * l + 1] = keep_blocks[l]
        return keep

    if method == "taylor":  # Diff-Pruning first-order importance at sub-block level
        assert objective is not None and data_iter is not None
        return _grad_select(model, objective, data_iter, c, B, device, order=1)

    if method == "obs":     # OBS-Diff: second-order (empirical-Fisher diagonal) saliency
        assert objective is not None and data_iter is not None
        return _grad_select(model, objective, data_iter, c, B, device, order=2)

    raise ValueError(f"unknown baseline: {method}")


def _grad_select(model, objective, data_iter, c, B, device, order=1, n_batches=8):
    """order=1 -> Taylor |grad·w| (Diff-Pruning). order=2 -> OBS/OBD saliency
    0.5·H_ii·w² with the empirical-Fisher diagonal H_ii≈E[grad²] (OBS-Diff-style,
    a distinct FIXED second-order criterion). Both applied at sub-block level."""
    model.to(device).train()
    for p in model.parameters():
        p.requires_grad_(True)
    depth = model.cfg.depth
    accum = torch.zeros(2 * depth)
    for _ in range(n_batches):
        x0, y = next(data_iter)
        x0, y = x0.to(device), y.to(device)
        model.zero_grad()
        objective.loss(model, x0, y).backward()
        for l, blk in enumerate(model.blocks):
            for j, sub in enumerate((blk.attn, blk.mlp)):
                s = 0.0
                for p in sub.parameters():
                    if p.grad is None:
                        continue
                    g, w = p.grad.detach(), p.detach()
                    s += ((g * w).abs().sum().item() if order == 1
                          else (0.5 * (g ** 2) * (w ** 2)).sum().item())
                accum[2 * l + j] += s
    model.zero_grad()
    return _greedy_keep(accum, c, B)


