"""TN-1: branch-separated recoverability profiling (CONTRIB1 Section 4.5).

For each sub-block (layer, branch) in turn: drop ONLY that sub-block, attach a
LoRA proxy, run K short recovery steps, and measure the recovered denoise loss
minus the full-model baseline loss. That delta is the sub-block's
"recoverability cost": low = easy to recover after removal. The resulting
L x {attn, mlp} heatmap is the *early motivational evidence* for RQ0a -- do attn
and mlp show different recoverability profiles, and do they trend differently
with depth? This runs before any full pruning search.
"""
from __future__ import annotations

import copy

import torch

from .dit import MaskableDiT
from .lora_proxy import attach_branch_lora


@torch.no_grad()
def _baseline_loss(model, objective, data_iter, n_eval):
    model.eval()
    tot = 0.0
    for _ in range(n_eval):
        x0, y = next(data_iter)
        tot += float(objective.loss(model, x0, y))
    return tot / n_eval


def profile_recoverability(build_model_fn, state_dict, cfg, objective, make_data_iter,
                           k_recover: int = 40, lr: float = 1e-3, n_eval: int = 8,
                           device="cpu", verbose=True):
    """build_model_fn() -> fresh MaskableDiT; state_dict = trained weights.

    Returns delta[depth, 2] where column 0=attn, 1=mlp. Higher = harder to
    recover after dropping that single sub-block.
    """
    depth = cfg.depth

    base = build_model_fn().to(device)
    base.load_state_dict(state_dict)
    base_loss = _baseline_loss(base, objective, make_data_iter(), n_eval)
    if verbose:
        print(f"[TN-1] full-model baseline loss = {base_loss:.4f}")

    delta = torch.zeros(depth, 2)
    for l in range(depth):
        for j, branch in enumerate(("attn", "mlp")):
            model = build_model_fn().to(device)
            model.load_state_dict(state_dict)
            blk = model.blocks[l]
            # drop exactly this sub-block
            if branch == "attn":
                blk.alive_attn = False
            else:
                blk.alive_mlp = False
            # short recovery with a fresh LoRA proxy (branch-separated)
            attn_p, mlp_p = attach_branch_lora(model)
            model.to(device)
            params = attn_p + mlp_p
            opt = torch.optim.Adam(params, lr=lr)
            it = make_data_iter()
            model.train()
            for _ in range(k_recover):
                x0, y = next(it)
                x0, y = x0.to(device), y.to(device)
                loss = objective.loss(model, x0, y)
                opt.zero_grad(); loss.backward(); opt.step()
            rec_loss = _baseline_loss(model, objective, make_data_iter(), n_eval)
            delta[l, j] = rec_loss - base_loss
            if verbose:
                print(f"[TN-1] L={l:2d} {branch:4s} recovered={rec_loss:.4f} "
                      f"delta={delta[l, j]:.4f}")
            del model
    return delta


def summarize(delta: torch.Tensor):
    """Paired test attn-vs-mlp + depth trend (CONTRIB1 Section 4.5)."""
    import numpy as np
    from scipy import stats

    attn = delta[:, 0].numpy()
    mlp = delta[:, 1].numpy()
    out = {
        "attn_mean": float(attn.mean()), "mlp_mean": float(mlp.mean()),
        "asym_mean": float((attn - mlp).mean()),
    }
    if len(attn) >= 3:
        try:
            w = stats.wilcoxon(attn, mlp)
            out["wilcoxon_p"] = float(w.pvalue)
        except ValueError:
            out["wilcoxon_p"] = float("nan")
        depth_idx = np.arange(len(attn))
        out["attn_depth_corr"] = float(np.corrcoef(depth_idx, attn)[0, 1])
        out["mlp_depth_corr"] = float(np.corrcoef(depth_idx, mlp)[0, 1])
    return out


def render_heatmap(delta: torch.Tensor, path_prefix: str):
    """Always write CSV; write PNG too if matplotlib is available."""
    import csv
    import os
    depth = delta.shape[0]
    os.makedirs(os.path.dirname(path_prefix) or ".", exist_ok=True)
    with open(path_prefix + ".csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["layer", "attn_delta", "mlp_delta"])
        for l in range(depth):
            w.writerow([l, float(delta[l, 0]), float(delta[l, 1])])
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(3, depth * 0.25 + 1))
        im = ax.imshow(delta.numpy(), aspect="auto", cmap="viridis")
        ax.set_xticks([0, 1]); ax.set_xticklabels(["attn", "mlp"])
        ax.set_ylabel("layer"); ax.set_title("recoverability delta")
        fig.colorbar(im, ax=ax)
        fig.tight_layout(); fig.savefig(path_prefix + ".png", dpi=120)
        plt.close(fig)
        return path_prefix + ".png"
    except Exception:
        return path_prefix + ".csv"
