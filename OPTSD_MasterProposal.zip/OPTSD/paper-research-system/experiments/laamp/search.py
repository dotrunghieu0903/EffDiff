"""Phase A: learn the dual mask + branch-separated LoRA proxy (CONTRIB1 Section 2.4).

Objective (Section 2.3):
    L = L_denoise(masked + LoRA-adapted model)
        + lam_B * ((E[FLOPs] - B) / FLOPs_full)^2      # differentiable budget
        + lam_D * R_depth(p)                            # optional depth prior (off by default)

Two optimizer groups: mask logits (high lr) vs LoRA params (low lr). Temperature
anneals tau0 -> tauT. Stops when the mask has hardened or the step budget runs
out. Returns the hard argmax mask m* plus a training log.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import torch

from .dit import MaskableDiT
from .masking import DualMask, anneal_tau
from .lora_proxy import attach_branch_lora
from .flops import analytic_cost_vector, full_flops


@dataclass
class SearchConfig:
    keep_ratio: float = 0.5          # target FLOPs fraction (iso-FLOPs anchor)
    n_steps: int = 2000
    lr_mask: float = 1e-1
    lr_lora: float = 1e-4
    lam_budget: float = 30.0
    lam_depth: float = 0.0           # off by default -> data decides asymmetry
    rank_attn: int = 8
    rank_mlp: int = 8
    tau0: float = 2.0
    tauT: float = 0.1
    keep_bias: float = 3.0
    harden_thresh: float = 0.95
    harden_frac: float = 0.95        # stop when >=95% subblocks are >0.95 confident
    log_every: int = 50
    coupled: bool = False            # AB-1 / TinyFusion-style symmetric mask
    grad_clip: float = 1.0


def depth_prior(keep_prob: torch.Tensor, depth: int) -> torch.Tensor:
    """Optional soft prior: encourage attn-heavy shallow, mlp-heavy deep.
    Only active if lam_depth>0 (AB-4). Returns a scalar."""
    p = keep_prob.view(depth, 2)
    layers = torch.linspace(0, 1, depth, device=p.device)
    # want keep_attn high early, keep_mlp high late -> penalise deviation
    target_attn = 1 - layers
    target_mlp = layers
    return ((p[:, 0] - target_attn) ** 2 + (p[:, 1] - target_mlp) ** 2).mean()


def run_search(model: MaskableDiT, objective, data_iter, cfg: SearchConfig,
               device="cpu", verbose=True):
    depth = model.cfg.depth
    mask = DualMask(depth, keep_bias=cfg.keep_bias).to(device)
    attn_params, mlp_params = attach_branch_lora(model, cfg.rank_attn, cfg.rank_mlp)
    model.to(device)

    c = analytic_cost_vector(model.cfg).to(device)
    flops_full = full_flops(model.cfg)
    B = cfg.keep_ratio * flops_full

    opt_mask = torch.optim.Adam([mask.logits], lr=cfg.lr_mask)
    opt_lora = torch.optim.Adam(attn_params + mlp_params, lr=cfg.lr_lora)

    log = []
    model.train()
    for step in range(cfg.n_steps):
        tau = anneal_tau(step, cfg.n_steps, cfg.tau0, cfg.tauT)
        x0, y = next(data_iter)
        x0, y = x0.to(device), y.to(device)

        gate = mask.sample(tau, hard=True)          # (2*depth,) STE {0,1}
        if cfg.coupled:                              # AB-1: force m_attn == m_mlp
            g = gate.view(depth, 2)
            shared = (g[:, 0] + g[:, 1]) / 2
            gate = torch.stack([shared, shared], dim=1).view(-1)
        m_attn, m_mlp = mask.pack(gate)
        model.set_masks(m_attn, m_mlp)

        loss_denoise = objective.loss(model, x0, y)

        p = mask.keep_prob()
        if cfg.coupled:
            pv = p.view(depth, 2)
            p = torch.stack([(pv[:, 0] + pv[:, 1]) / 2] * 2, dim=1).view(-1)
        exp_flops = (p * c).sum()
        r_budget = ((exp_flops - B) / flops_full) ** 2
        r_depth = depth_prior(p, depth) if cfg.lam_depth > 0 else torch.zeros((), device=device)

        loss = loss_denoise + cfg.lam_budget * r_budget + cfg.lam_depth * r_depth

        opt_mask.zero_grad(); opt_lora.zero_grad()
        loss.backward()
        if cfg.grad_clip:
            torch.nn.utils.clip_grad_norm_([mask.logits], cfg.grad_clip)
            torch.nn.utils.clip_grad_norm_(attn_params + mlp_params, cfg.grad_clip)
        opt_mask.step(); opt_lora.step()

        if step % cfg.log_every == 0 or step == cfg.n_steps - 1:
            hf = mask.hardened_fraction(cfg.harden_thresh)
            frac_kept = (mask.hard_mask() * c).sum().item() / flops_full
            rec = dict(step=step, loss=float(loss.detach()), denoise=float(loss_denoise.detach()),
                       budget=float(r_budget.detach()), tau=tau, hardened=hf, flops_frac=frac_kept)
            log.append(rec)
            if verbose:
                print(f"[search] step={step:5d} L={rec['loss']:.4f} "
                      f"denoise={rec['denoise']:.4f} budget={rec['budget']:.2e} "
                      f"tau={tau:.2f} hard={hf:.2f} flops={frac_kept:.3f}")
            if hf >= cfg.harden_frac and step > cfg.n_steps // 5:
                if verbose:
                    print(f"[search] mask hardened at step {step}, stopping early")
                break

    if cfg.coupled:
        # TinyFusion regime: the FINAL mask must be coupled per block (m_attn==m_mlp),
        # not just the training gate. Keep whole blocks by averaged keep-prob until the
        # FLOPs budget B is met (guarantees A==0 at iso-FLOPs).
        p_block = mask.keep_prob().view(depth, 2).mean(dim=1)
        block_cost = c.view(depth, 2).sum(dim=1)
        keep_block = torch.zeros(depth, device=device)
        running = 0.0
        for i in torch.argsort(p_block, descending=True).tolist():
            if running + block_cost[i].item() <= B:
                keep_block[i] = 1.0
                running += block_cost[i].item()
        m_star = keep_block.repeat_interleave(2).detach()
    else:
        m_star = mask.hard_mask().detach()
    achieved = (m_star * c).sum().item() / flops_full
    model.reset_masks()
    return dict(mask=mask, m_star=m_star, achieved_flops=achieved,
                target_flops=cfg.keep_ratio, cost=c, log=log)
