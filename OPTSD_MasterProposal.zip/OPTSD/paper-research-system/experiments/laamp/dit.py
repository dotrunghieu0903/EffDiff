"""Maskable DiT for LAAMP (Contribution 1).

Key departure from a standard DiT / from TinyFusion: every transformer block is
split into TWO independently-maskable sub-blocks on the residual path -- the
self-attention branch and the MLP branch. Each sub-block carries its own binary
gate m in {0,1}. When m == 0 the sub-block collapses to identity (the residual
passes straight through) so it can be *physically removed* from the compute graph
at inference. TinyFusion is the special case m_attn_l == m_mlp_l (whole block
dropped as a monolith). See CONTRIB1-Pruning-Algorithm-Experiments.md Section 1.

The masks here are plain buffers/floats set from the outside (search.py provides
the differentiable dual Gumbel-Softmax sampler and writes hard samples in).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------
@dataclass
class DiTConfig:
    input_size: int = 32        # latent spatial size (e.g. 32 for 256px / VAE-8)
    patch_size: int = 2
    in_channels: int = 4
    hidden_size: int = 1152     # DiT-XL/2 = 1152
    depth: int = 28             # DiT-XL/2 = 28 blocks
    num_heads: int = 16
    mlp_ratio: float = 4.0
    num_classes: int = 1000
    class_dropout_prob: float = 0.1
    learn_sigma: bool = True

    @property
    def out_channels(self) -> int:
        return self.in_channels * 2 if self.learn_sigma else self.in_channels

    @classmethod
    def dit_xl_2(cls) -> "DiTConfig":
        return cls(input_size=32, patch_size=2, hidden_size=1152, depth=28,
                   num_heads=16, num_classes=1000)

    @classmethod
    def tiny(cls) -> "DiTConfig":
        # runs on CPU in seconds; used by smoke_test.py
        return cls(input_size=8, patch_size=2, in_channels=4, hidden_size=64,
                   depth=6, num_heads=4, num_classes=4, learn_sigma=False)
    # NB: stack substrates (e.g. SANA-like) live in stack/backbones.py, not here,
    # so the LAAMP package stays pure (Contribution 1 only).


# ---------------------------------------------------------------------------
# embedders
# ---------------------------------------------------------------------------
def modulate(x, shift, scale):
    return x * (1 + scale.unsqueeze(1)) + shift.unsqueeze(1)


class TimestepEmbedder(nn.Module):
    def __init__(self, hidden_size, freq_dim=256):
        super().__init__()
        self.freq_dim = freq_dim
        self.mlp = nn.Sequential(
            nn.Linear(freq_dim, hidden_size), nn.SiLU(),
            nn.Linear(hidden_size, hidden_size),
        )

    def _sinusoid(self, t):
        half = self.freq_dim // 2
        freqs = torch.exp(-math.log(10000) * torch.arange(half, device=t.device) / half)
        args = t[:, None].float() * freqs[None]
        return torch.cat([torch.cos(args), torch.sin(args)], dim=-1)

    def forward(self, t):
        return self.mlp(self._sinusoid(t))


class LabelEmbedder(nn.Module):
    def __init__(self, num_classes, hidden_size, dropout_prob):
        super().__init__()
        self.dropout_prob = dropout_prob
        self.embedding_table = nn.Embedding(num_classes + 1, hidden_size)  # +1 = null
        self.num_classes = num_classes

    def forward(self, labels, train, force_drop_ids=None):
        if (train and self.dropout_prob > 0) or force_drop_ids is not None:
            if force_drop_ids is None:
                drop = torch.rand(labels.shape[0], device=labels.device) < self.dropout_prob
            else:
                drop = force_drop_ids == 1
            labels = torch.where(drop, self.num_classes, labels)
        return self.embedding_table(labels)


class PatchEmbed(nn.Module):
    def __init__(self, cfg: DiTConfig):
        super().__init__()
        self.proj = nn.Conv2d(cfg.in_channels, cfg.hidden_size,
                              kernel_size=cfg.patch_size, stride=cfg.patch_size)
        self.grid = cfg.input_size // cfg.patch_size
        self.num_patches = self.grid ** 2

    def forward(self, x):
        x = self.proj(x)                      # (B, C, H', W')
        return x.flatten(2).transpose(1, 2)   # (B, T, C)


# ---------------------------------------------------------------------------
# attention / mlp branches
# ---------------------------------------------------------------------------
class Attention(nn.Module):
    def __init__(self, dim, num_heads):
        super().__init__()
        assert dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.qkv = nn.Linear(dim, dim * 3, bias=True)
        self.proj = nn.Linear(dim, dim, bias=True)

    def forward(self, x):
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        x = nn.functional.scaled_dot_product_attention(q, k, v)
        x = x.transpose(1, 2).reshape(B, T, C)
        return self.proj(x)


class Mlp(nn.Module):
    def __init__(self, dim, mlp_ratio):
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.fc1 = nn.Linear(dim, hidden)
        self.act = nn.GELU(approximate="tanh")
        self.fc2 = nn.Linear(hidden, dim)

    def forward(self, x):
        return self.fc2(self.act(self.fc1(x)))


class DiTBlock(nn.Module):
    """A DiT block with independently maskable attn and mlp sub-blocks.

    The masks m_attn / m_mlp are floats in {0,1} (hard) that scale the branch
    output. search.py may instead inject a soft/STE value for the differentiable
    phase. `alive_attn` / `alive_mlp` let prune.py mark a branch physically gone
    (skips the compute entirely, not just multiply-by-zero).
    """

    def __init__(self, cfg: DiTConfig, layer_idx: int):
        super().__init__()
        self.layer_idx = layer_idx
        h = cfg.hidden_size
        self.norm1 = nn.LayerNorm(h, elementwise_affine=False, eps=1e-6)
        self.attn = Attention(h, cfg.num_heads)
        self.norm2 = nn.LayerNorm(h, elementwise_affine=False, eps=1e-6)
        self.mlp = Mlp(h, cfg.mlp_ratio)
        self.adaLN = nn.Sequential(nn.SiLU(), nn.Linear(h, 6 * h, bias=True))

        # masks: default kept (=1.0). Registered as buffers so they move w/ .to()
        self.register_buffer("m_attn", torch.tensor(1.0))
        self.register_buffer("m_mlp", torch.tensor(1.0))
        self.alive_attn = True
        self.alive_mlp = True

    def forward(self, x, c):
        (shift_msa, scale_msa, gate_msa,
         shift_mlp, scale_mlp, gate_mlp) = self.adaLN(c).chunk(6, dim=1)

        if self.alive_attn:
            attn_out = gate_msa.unsqueeze(1) * self.attn(modulate(self.norm1(x), shift_msa, scale_msa))
            x = x + self.m_attn * attn_out
        if self.alive_mlp:
            mlp_out = gate_mlp.unsqueeze(1) * self.mlp(modulate(self.norm2(x), shift_mlp, scale_mlp))
            x = x + self.m_mlp * mlp_out
        return x


class FinalLayer(nn.Module):
    def __init__(self, cfg: DiTConfig):
        super().__init__()
        h = cfg.hidden_size
        self.norm = nn.LayerNorm(h, elementwise_affine=False, eps=1e-6)
        self.linear = nn.Linear(h, cfg.patch_size ** 2 * cfg.out_channels, bias=True)
        self.adaLN = nn.Sequential(nn.SiLU(), nn.Linear(h, 2 * h, bias=True))

    def forward(self, x, c):
        shift, scale = self.adaLN(c).chunk(2, dim=1)
        return self.linear(modulate(self.norm(x), shift, scale))


# ---------------------------------------------------------------------------
# full model
# ---------------------------------------------------------------------------
class MaskableDiT(nn.Module):
    def __init__(self, cfg: DiTConfig):
        super().__init__()
        self.cfg = cfg
        self.x_embedder = PatchEmbed(cfg)
        self.t_embedder = TimestepEmbedder(cfg.hidden_size)
        self.y_embedder = LabelEmbedder(cfg.num_classes, cfg.hidden_size, cfg.class_dropout_prob)
        num_patches = self.x_embedder.num_patches
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, cfg.hidden_size), requires_grad=False)
        self._init_pos_embed()
        self.blocks = nn.ModuleList([DiTBlock(cfg, i) for i in range(cfg.depth)])
        self.final_layer = FinalLayer(cfg)

    def _init_pos_embed(self):
        # simple 2D sin-cos; not critical for the algorithm, deterministic init
        grid = self.x_embedder.grid
        h = self.cfg.hidden_size
        pe = torch.zeros(grid * grid, h)
        pos = torch.arange(grid * grid).float()
        div = torch.exp(torch.arange(0, h, 2).float() * (-math.log(10000.0) / h))
        pe[:, 0::2] = torch.sin(pos[:, None] * div)
        pe[:, 1::2] = torch.cos(pos[:, None] * div)
        self.pos_embed.data.copy_(pe.unsqueeze(0))

    def unpatchify(self, x):
        c = self.cfg.out_channels
        p = self.cfg.patch_size
        grid = self.x_embedder.grid
        x = x.reshape(x.shape[0], grid, grid, p, p, c)
        x = torch.einsum("nhwpqc->nchpwq", x)
        return x.reshape(x.shape[0], c, grid * p, grid * p)

    def forward(self, x, t, y):
        x = self.x_embedder(x) + self.pos_embed
        c = self.t_embedder(t) + self.y_embedder(y, self.training)
        for block in self.blocks:
            x = block(x, c)
        x = self.final_layer(x, c)
        return self.unpatchify(x)

    # -- mask plumbing -------------------------------------------------------
    def set_masks(self, m_attn, m_mlp):
        """m_attn, m_mlp: 1-D tensors length=depth of floats (soft or hard)."""
        for i, blk in enumerate(self.blocks):
            blk.m_attn = m_attn[i].to(blk.m_attn.device)
            blk.m_mlp = m_mlp[i].to(blk.m_mlp.device)

    def reset_masks(self):
        for blk in self.blocks:
            blk.m_attn = torch.tensor(1.0, device=self.pos_embed.device)
            blk.m_mlp = torch.tensor(1.0, device=self.pos_embed.device)
            blk.alive_attn = True
            blk.alive_mlp = True

    def subblock_index(self):
        """Return list of (layer, branch) in the canonical order used everywhere."""
        idx = []
        for l in range(self.cfg.depth):
            idx.append((l, "attn"))
            idx.append((l, "mlp"))
        return idx


def build_model(cfg: DiTConfig) -> MaskableDiT:
    return MaskableDiT(cfg)
