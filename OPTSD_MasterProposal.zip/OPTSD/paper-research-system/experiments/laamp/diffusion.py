"""Minimal diffusion objective used to drive the recoverability loss.

Defaults to flow-matching (rectified-flow) which is substrate-agnostic and what
FLUX/SD3-style DiTs use; a DDPM eps-prediction variant is provided for DiT-XL/2
head-to-head with TinyFusion's ImageNet setup. This module only needs to produce
a scalar denoise loss on a (masked, LoRA-adapted) model -- that scalar is the
"post-recovery performance" LAAMP optimises (CONTRIB1 Section 2.3).
"""
from __future__ import annotations

import torch


class FlowMatching:
    """x_t = (1-t) x0 + t*eps ; target velocity = eps - x0."""

    def loss(self, model, x0, y):
        b = x0.shape[0]
        t = torch.rand(b, device=x0.device)
        eps = torch.randn_like(x0)
        tb = t.view(b, *([1] * (x0.dim() - 1)))
        xt = (1 - tb) * x0 + tb * eps
        target = eps - x0
        # model timestep convention: scale t to [0, 1000)
        pred = model(xt, t * 999.0, y)
        if pred.shape[1] != target.shape[1]:  # learn_sigma -> take mean channels
            pred = pred[:, : target.shape[1]]
        return ((pred - target) ** 2).mean()


class DDPMEps:
    """Standard eps-prediction with a linear beta schedule (DiT/ImageNet)."""

    def __init__(self, timesteps: int = 1000, device="cpu"):
        betas = torch.linspace(1e-4, 2e-2, timesteps)
        alphas = torch.cumprod(1 - betas, dim=0)
        self.sqrt_ab = alphas.sqrt().to(device)
        self.sqrt_1mab = (1 - alphas).sqrt().to(device)
        self.T = timesteps

    def loss(self, model, x0, y):
        b = x0.shape[0]
        t = torch.randint(0, self.T, (b,), device=x0.device)
        eps = torch.randn_like(x0)
        sh = [b] + [1] * (x0.dim() - 1)
        xt = self.sqrt_ab[t].view(sh) * x0 + self.sqrt_1mab[t].view(sh) * eps
        pred = model(xt, t.float(), y)
        if pred.shape[1] != eps.shape[1]:
            pred = pred[:, : eps.shape[1]]
        return ((pred - eps) ** 2).mean()


def build_objective(name: str, device="cpu"):
    if name == "flow":
        return FlowMatching()
    if name == "ddpm":
        return DDPMEps(device=device)
    raise ValueError(name)
