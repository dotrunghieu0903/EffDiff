"""Phase B setup: physically remove dropped sub-blocks (CONTRIB1 Section 2.4 / 2.5).

`apply_hard_mask` marks each dropped sub-block as not-alive so its forward is
skipped entirely (real compute saving, not multiply-by-zero) and freezes/zeros
the pruned parameters so a subsequent recovery finetune cannot resurrect them.
The kept sub-blocks are left trainable for the recovery step.
"""
from __future__ import annotations

import torch

from .dit import MaskableDiT


def apply_hard_mask(model: MaskableDiT, m_star: torch.Tensor):
    """m_star: (2*depth,) in {0,1}, order [attn_0, mlp_0, attn_1, mlp_1, ...]."""
    depth = model.cfg.depth
    v = m_star.view(depth, 2)
    removed = {"attn": [], "mlp": []}
    for l, blk in enumerate(model.blocks):
        keep_attn = bool(v[l, 0] > 0.5)
        keep_mlp = bool(v[l, 1] > 0.5)
        blk.alive_attn = keep_attn
        blk.alive_mlp = keep_mlp
        blk.m_attn = torch.tensor(1.0 if keep_attn else 0.0, device=blk.m_attn.device)
        blk.m_mlp = torch.tensor(1.0 if keep_mlp else 0.0, device=blk.m_mlp.device)
        if not keep_attn:
            removed["attn"].append(l)
            for p in blk.attn.parameters():
                p.detach_().zero_(); p.requires_grad_(False)
        if not keep_mlp:
            removed["mlp"].append(l)
            for p in blk.mlp.parameters():
                p.detach_().zero_(); p.requires_grad_(False)
    return removed


def asymmetry_index(m_star: torch.Tensor, depth: int) -> float:
    """A = (1/L) sum_l |m_attn_l - m_mlp_l|  (CONTRIB1 Section 4.4).
    A=0 means every kept/dropped decision is symmetric (== TinyFusion regime)."""
    v = m_star.view(depth, 2)
    return (v[:, 0] - v[:, 1]).abs().mean().item()


def kept_counts(m_star: torch.Tensor, depth: int):
    v = m_star.view(depth, 2)
    return dict(attn_kept=int(v[:, 0].sum()), mlp_kept=int(v[:, 1].sum()), total=2 * depth)


def recover(model: MaskableDiT, objective, data_iter, n_steps: int, lr: float,
            device="cpu", verbose=True, log_every=50, mode="denoise", teacher=None):
    """Common recovery finetune. CRITICAL for fairness: every method (LAAMP and
    all baselines) must call this with the SAME (n_steps, lr, data) so quality
    gaps come only from *what was cut*, not *how much recovery* (CONTRIB1 2.4).

    mode="denoise" (default): minimise the model's own denoise loss.
    mode="match"  (2ndMatch, CONTRIB1 AB-6): minimise ||f_pruned - f_teacher||²,
      i.e. match the un-pruned teacher's outputs (Gauss-Newton/JᵀJ spirit). A light
      stand-in for 2ndMatch; needs `teacher` (the base model before pruning)."""
    model.to(device).train()
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=lr)
    if mode == "match":
        assert teacher is not None, "2ndMatch recovery needs a teacher model"
        teacher.to(device).eval()
    losses = []
    for step in range(n_steps):
        x0, y = next(data_iter)
        x0, y = x0.to(device), y.to(device)
        if mode == "match":
            b = x0.shape[0]
            t = torch.rand(b, device=device)
            eps = torch.randn_like(x0)
            tb = t.view(b, *([1] * (x0.dim() - 1)))
            xt = (1 - tb) * x0 + tb * eps
            with torch.no_grad():
                tgt = teacher(xt, t * 999.0, y)
            out = model(xt, t * 999.0, y)
            loss = ((out - tgt) ** 2).mean()
        else:
            loss = objective.loss(model, x0, y)
        opt.zero_grad(); loss.backward(); opt.step()
        losses.append(float(loss.detach()))
        if verbose and (step % log_every == 0 or step == n_steps - 1):
            print(f"[recover:{mode}] step={step:5d} loss={loss.item():.4f}")
    return losses
