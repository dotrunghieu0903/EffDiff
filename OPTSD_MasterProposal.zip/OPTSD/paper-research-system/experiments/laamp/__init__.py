"""LAAMP: Learned Asymmetric Attention-MLP Pruning for Diffusion Transformers.

Contribution 1 of the thesis. See CONTRIB1-Pruning-Algorithm-Experiments.md.
"""
from .dit import DiTConfig, MaskableDiT, build_model
from .masking import DualMask, anneal_tau
from .lora_proxy import attach_branch_lora, attach_shared_lora
from .flops import analytic_cost_vector, full_flops, budget_from_ratio, measured_cost_vector
from .diffusion import build_objective
from .search import SearchConfig, run_search
from .prune import apply_hard_mask, recover, asymmetry_index, kept_counts
from . import baselines, profiling

__all__ = [
    "DiTConfig", "MaskableDiT", "build_model", "DualMask", "anneal_tau",
    "attach_branch_lora", "attach_shared_lora", "analytic_cost_vector",
    "full_flops", "budget_from_ratio", "measured_cost_vector", "build_objective",
    "SearchConfig", "run_search", "apply_hard_mask", "recover",
    "asymmetry_index", "kept_counts", "baselines", "profiling",
]
