"""Branch-separated LoRA recoverability proxy (CONTRIB1 Section 2.1 item 2).

Two disjoint families of LoRA adapters are attached:
  * LoRA_attn  -> the qkv / proj Linears inside every Attention branch
  * LoRA_mlp   -> the fc1 / fc2 Linears inside every Mlp branch

Co-optimising these with the mask *simulates the recovery finetune* so the mask
is chosen for post-recovery loss, not instantaneous error. Keeping the two
families separate is the whole point: it stops the attn and mlp recoverability
signals from bleeding into each other (that mixing is exactly what a single
coupled proxy -- or TinyFusion -- cannot separate). Ablation AB-2 swaps this for
a shared proxy or no proxy.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn

from .dit import Attention, Mlp, MaskableDiT


class LoRALinear(nn.Module):
    """Wraps a frozen nn.Linear with a trainable low-rank update B @ A."""

    def __init__(self, base: nn.Linear, rank: int, alpha: float | None = None):
        super().__init__()
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)
        self.rank = rank
        self.alpha = alpha if alpha is not None else rank
        self.scaling = self.alpha / rank
        self.A = nn.Parameter(torch.zeros(rank, base.in_features))
        self.B = nn.Parameter(torch.zeros(base.out_features, rank))
        nn.init.kaiming_uniform_(self.A, a=math.sqrt(5))
        # B stays zero -> adapter starts as identity (no perturbation)

    def forward(self, x):
        return self.base(x) + self.scaling * (x @ self.A.t()) @ self.B.t()


def _swap(parent: nn.Module, attr: str, rank: int, bucket: list):
    lin = getattr(parent, attr)
    if isinstance(lin, nn.Linear):
        wrapped = LoRALinear(lin, rank)
        setattr(parent, attr, wrapped)
        bucket.append(wrapped)


def attach_branch_lora(model: MaskableDiT, rank_attn: int = 8, rank_mlp: int = 8):
    """Attach separated LoRA families. Returns (attn_params, mlp_params) lists of
    nn.Parameter for building separate optimizer groups."""
    attn_adapters, mlp_adapters = [], []
    for module in model.modules():
        if isinstance(module, Attention):
            _swap(module, "qkv", rank_attn, attn_adapters)
            _swap(module, "proj", rank_attn, attn_adapters)
        elif isinstance(module, Mlp):
            _swap(module, "fc1", rank_mlp, mlp_adapters)
            _swap(module, "fc2", rank_mlp, mlp_adapters)

    def _params(adapters):
        ps = []
        for a in adapters:
            ps += [a.A, a.B]
        return ps

    return _params(attn_adapters), _params(mlp_adapters)


def attach_shared_lora(model: MaskableDiT, rank: int = 8):
    """AB-2 variant: one shared pool over both branches (params merged)."""
    a, m = attach_branch_lora(model, rank, rank)
    return a + m
