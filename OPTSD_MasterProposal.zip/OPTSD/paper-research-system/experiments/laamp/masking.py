"""Dual differentiable mask for LAAMP (CONTRIB1 Section 2.1-2.2).

Each sub-block (layer, branch in {attn, mlp}) owns a 2-way categorical logit
[keep, drop]. We sample a *soft* keep-value with Gumbel-Softmax and pass a HARD
{0,1} forward using the straight-through estimator, so the compute graph sees a
binary gate while gradients still flow to the logits. Temperature anneals
tau0 -> tauT over the search.

There are 2*depth sub-blocks. `pack`/`unpack` convert between the flat 2*depth
vector and the per-branch (m_attn, m_mlp) vectors DiT.set_masks expects.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class DualMask(nn.Module):
    def __init__(self, depth: int, keep_bias: float = 3.0):
        """keep_bias > 0 initialises every sub-block biased toward *keep* so the
        search starts near the full model and prunes down (CONTRIB1 Section 6)."""
        super().__init__()
        self.depth = depth
        self.n = 2 * depth
        # logits[:, 0] = keep, logits[:, 1] = drop
        init = torch.zeros(self.n, 2)
        init[:, 0] = keep_bias
        self.logits = nn.Parameter(init)

    # -- probabilities -------------------------------------------------------
    def keep_prob(self) -> torch.Tensor:
        """p_{l,b} = softmax(logit)_keep, shape (2*depth,). Used for the smooth,
        low-variance FLOPs penalty (CONTRIB1 Section 2.3)."""
        return torch.softmax(self.logits, dim=-1)[:, 0]

    # -- differentiable hard sample -----------------------------------------
    def sample(self, tau: float, hard: bool = True) -> torch.Tensor:
        """Return a length-(2*depth) gate in {0,1} (hard) with STE gradients."""
        u = torch.rand_like(self.logits).clamp_(1e-10, 1.0 - 1e-6)
        g = -torch.log(-torch.log(u))  # Gumbel(0,1)
        y_soft = torch.softmax((self.logits + g) / tau, dim=-1)
        keep_soft = y_soft[:, 0]
        if not hard:
            return keep_soft
        keep_hard = (keep_soft > 0.5).float()
        # straight-through: forward=hard, backward=soft
        return keep_hard + (keep_soft - keep_soft.detach())

    # -- deterministic argmax mask (Phase A -> Phase B handoff) --------------
    def hard_mask(self) -> torch.Tensor:
        return (self.logits[:, 0] >= self.logits[:, 1]).float()

    # -- layout helpers ------------------------------------------------------
    def pack(self, flat: torch.Tensor):
        """(2*depth,) -> (m_attn[depth], m_mlp[depth]); order = [attn_l, mlp_l]."""
        v = flat.view(self.depth, 2)
        return v[:, 0], v[:, 1]

    def hardened_fraction(self, thresh: float = 0.95) -> float:
        p = self.keep_prob()
        conf = torch.maximum(p, 1 - p)
        return (conf > thresh).float().mean().item()


def anneal_tau(step: int, total: int, tau0: float = 2.0, tauT: float = 0.1) -> float:
    """Exponential temperature schedule (CONTRIB1 Section 2.2)."""
    if total <= 1:
        return tauT
    frac = min(step / (total - 1), 1.0)
    return tau0 * (tauT / tau0) ** frac
