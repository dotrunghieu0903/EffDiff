"""Per-sub-block FLOPs cost vector c in R^{2*depth} (CONTRIB1 Section 1.1).

We report the *analytic* cost (closed form in T, d, r) which is exact enough for
the differentiable budget penalty and iso-FLOPs bookkeeping, plus an optional
measured cross-check via a forward hook (no fvcore dependency required). Order
matches MaskableDiT.subblock_index(): [attn_0, mlp_0, attn_1, mlp_1, ...].
"""
from __future__ import annotations

import torch

from .dit import DiTConfig, MaskableDiT


def analytic_cost_vector(cfg: DiTConfig) -> torch.Tensor:
    """Return c (2*depth,). Attention has a quadratic-in-T term; MLP is linear.

        c_attn = 4*T*d^2 (QKVO proj) + 2*T^2*d (scores+context)
        c_mlp  = 2*r*T*d^2
    Multiplied by number of tokens implicitly through T. Units: MACs.
    """
    T = (cfg.input_size // cfg.patch_size) ** 2
    d = cfg.hidden_size
    r = cfg.mlp_ratio
    c_attn = 4 * T * d * d + 2 * T * T * d
    c_mlp = 2 * r * T * d * d
    per_layer = torch.tensor([float(c_attn), float(c_mlp)])
    return per_layer.repeat(cfg.depth)


def full_flops(cfg: DiTConfig) -> float:
    return float(analytic_cost_vector(cfg).sum())


def budget_from_ratio(cfg: DiTConfig, keep_ratio: float) -> float:
    """Target FLOPs B for the sub-block set = keep_ratio * full sub-block FLOPs.

    Note: this budgets only the maskable sub-blocks (attn+mlp compute), which is
    where all pruning acts. Embedders / final layer are fixed overhead and
    identical across every method, so excluding them keeps iso-FLOPs comparisons
    clean (every method is compared on the same maskable budget)."""
    return keep_ratio * full_flops(cfg)


@torch.no_grad()
def measured_cost_vector(model: MaskableDiT, x, t, y) -> torch.Tensor:
    """Cross-check via forward hooks counting Linear + attention MACs. Returns a
    (2*depth,) tensor. Used to validate analytic_cost_vector on real substrates."""
    import torch.nn as nn
    from .dit import Attention, Mlp

    costs = {}

    def lin_hook(name):
        def h(mod, inp, out):
            x0 = inp[0]
            macs = x0.shape[0] * x0.shape[1] * mod.in_features * mod.out_features
            costs[name] = costs.get(name, 0) + macs
        return h

    handles = []
    branch_of = {}
    for li, blk in enumerate(model.blocks):
        for sub, tag in ((blk.attn, "attn"), (blk.mlp, "mlp")):
            for mn, m in sub.named_modules():
                if isinstance(m, nn.Linear):
                    key = f"{li}:{tag}"
                    branch_of[id(m)] = key
                    handles.append(m.register_forward_hook(lin_hook(key)))

    was_training = model.training
    model.eval()
    model(x, t, y)
    model.train(was_training)
    for h in handles:
        h.remove()

    vec = []
    for li in range(model.cfg.depth):
        vec.append(costs.get(f"{li}:attn", 0.0))
        vec.append(costs.get(f"{li}:mlp", 0.0))
    return torch.tensor(vec, dtype=torch.float32)
