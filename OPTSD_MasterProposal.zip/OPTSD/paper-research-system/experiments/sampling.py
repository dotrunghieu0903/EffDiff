"""DDIM sampler for MaskableDiT with classifier-free guidance.

Matches the DDPM eps objective (diffusion.py: linear beta 1e-4..2e-2, T=1000).
Deterministic DDIM is used for speed/consistency across methods. To reproduce
DiT's *published* FID exactly you additionally need the learned-sigma variance
and 250-step ancestral DDPM; for method-vs-method comparison (our use) a fixed
DDIM schedule shared by every method is what matters.

CFG: DiT is class-conditional; we form eps = eps_uncond + w*(eps_cond-eps_uncond)
using the null-class token (LabelEmbedder index == num_classes).
"""
from __future__ import annotations

import torch


def _alpha_bar(T=1000, device="cpu"):
    betas = torch.linspace(1e-4, 2e-2, T, device=device)
    return torch.cumprod(1 - betas, dim=0)


@torch.no_grad()
def ddim_sample(model, n, y, cfg_scale=1.5, steps=50, T=1000,
                latent_shape=(4, 32, 32), device="cuda", eta=0.0):
    """Return latents (n,4,32,32). y: (n,) class labels. cfg_scale=1.0 disables CFG."""
    model.eval().to(device)
    ab = _alpha_bar(T, device)
    x = torch.randn(n, *latent_shape, device=device)
    ts = torch.linspace(T - 1, 0, steps, device=device).long()
    use_cfg = cfg_scale != 1.0
    null = torch.full_like(y, model.cfg.num_classes)

    for i, t in enumerate(ts):
        tb = torch.full((n,), int(t), device=device, dtype=torch.float32)
        if use_cfg:
            xin = torch.cat([x, x], 0)
            yin = torch.cat([y, null], 0)
            out = model(xin, torch.cat([tb, tb], 0), yin)
            eps = out[:, :latent_shape[0]]
            eps_c, eps_u = eps.chunk(2, 0)
            eps = eps_u + cfg_scale * (eps_c - eps_u)
        else:
            eps = model(x, tb, y)[:, :latent_shape[0]]

        a_t = ab[t]
        a_prev = ab[ts[i + 1]] if i + 1 < len(ts) else torch.tensor(1.0, device=device)
        x0 = (x - (1 - a_t).sqrt() * eps) / a_t.sqrt()
        x0 = x0.clamp(-4, 4)
        sigma = eta * ((1 - a_prev) / (1 - a_t)).sqrt() * (1 - a_t / a_prev).sqrt()
        dir_xt = (1 - a_prev - sigma ** 2).clamp_min(0).sqrt() * eps
        x = a_prev.sqrt() * x0 + dir_xt
        if eta > 0 and i + 1 < len(ts):
            x = x + sigma * torch.randn_like(x)
    return x


@torch.no_grad()
def decode_latents(vae, lat, device="cuda"):
    """SD-VAE decode -> uint8 images (N,3,H,W) in [0,255] for FID."""
    img = vae.decode(lat.to(device) / 0.18215).sample     # [-1,1]-ish
    img = ((img.clamp(-1, 1) + 1) * 127.5).round().to(torch.uint8)
    return img
