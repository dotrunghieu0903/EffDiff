"""Data iterators.

`synthetic_iter` builds a class-conditioned Gaussian-mixture "latent" dataset so
the whole LAAMP pipeline runs on CPU with no downloads (used by smoke_test.py and
unit checks). `latent_folder_iter` is the real-run path: pre-encoded VAE latents
(e.g. ImageNet-256 through the SD-VAE, DiT-XL/2 convention) stored as .pt shards.
"""
from __future__ import annotations

import itertools
from pathlib import Path

import torch


def synthetic_iter(batch=16, channels=4, size=8, num_classes=4, seed=0, device="cpu"):
    """Infinite iterator of (x0, y). Each class has a distinct mean pattern so a
    model must actually use the class conditioning -> pruning that hurts
    conditioning shows up in the denoise loss."""
    g = torch.Generator().manual_seed(seed)
    centers = torch.randn(num_classes, channels, size, size, generator=g)

    def gen():
        while True:
            y = torch.randint(0, num_classes, (batch,), generator=g)
            x0 = centers[y] + 0.5 * torch.randn(batch, channels, size, size, generator=g)
            yield x0.to(device), y.to(device)

    return gen()


def latent_folder_iter(path, batch=16, device="cpu", shuffle=True):
    """Iterate pre-encoded latents. Expects <path>/*.pt each a dict
    {"latent": (N,C,H,W) float, "label": (N,) long}. Loops forever."""
    shards = sorted(Path(path).glob("*.pt"))
    if not shards:
        raise FileNotFoundError(f"no .pt latent shards under {path}")

    def gen():
        buf_x, buf_y = [], []
        for shard in itertools.cycle(shards):
            d = torch.load(shard, map_location="cpu")
            lat, lab = d["latent"], d["label"]
            idx = torch.randperm(len(lat)) if shuffle else torch.arange(len(lat))
            for i in idx.tolist():
                buf_x.append(lat[i]); buf_y.append(lab[i])
                if len(buf_x) == batch:
                    yield (torch.stack(buf_x).to(device),
                           torch.tensor(buf_y).to(device))
                    buf_x, buf_y = [], []

    return gen()
