# Engine bring-up checklist (real CUDA engines — GPU box only)

Everything algorithm/logic in this repo is implemented and CPU-verified. The only
pieces that CANNOT be finished without a GPU + the external libraries are the
**real acceleration engines** — their integration API is external and version-
specific, so writing them blind would just need re-debugging on hardware. This is
the short, one-time bring-up to turn each scaffold into the real thing.

After bring-up, the same YAMLs (`configs/pipeline.yaml`, `stack/configs/stack.yaml`,
`configs/validate.yaml`) run unchanged — only the axis *implementations* change,
switched via `experiments.stack.adapters.use_backend(...)`.

## Order (close the riskiest first — PROPOSAL §9 P0a)

1. **SVDQuant / Nunchaku (quant axis)** — `stack/adapters/svdquant.py`
   - `pip install nunchaku` (Ada+; **verify on 3090/Ampere** — Nunchaku targets Ada).
   - Fill `apply(model, bits, quant_act)`: load the W4A4 SVDQuant backbone, expose
     `forward(x,t,y)`, return `(qmodel, measured_speedup)`.
   - Verify: `adapters.use_backend("quant","svdquant"); adapters.status()` → available=True;
     run `stack.evaluate_config` with `quant_bits=4` and confirm it runs + speedup measured.

2. **TaylorSeer / HiCache (cache axis)** — `stack/adapters/taylorseer.py`
   - Vendor the engine (usually not pip). Fill `cached_sample(model,x,y,steps,policy)`:
     register block-output feature-cache hooks; forecast at skipped steps.
   - Verify: cache-on run matches `sampler.flow_sample` interface; speedup = steps/computed.

3. **LAAMP mask (prune axis)** — `stack/adapters/laamp_axis.py` — **already usable**.
   - Just point `StackConfig.prune_mask` at an `m_star` from Contribution 1
     (`results/<run>/pruned/*.pt`) and `use_backend("prune","laamp")`.

4. **DMD2 / Phased-DMD (distilled regime)** — `stack/adapters/dmd2.py`
   - Provide a distilled checkpoint; fill `sample(model,x,y,steps)` at native NFE.
   - Verify: distilled error/speedup replaces the `regime_plan('distilled')` stand-in.

5. **RF-Solver (solver regime)** — `stack/adapters/rf_solver.py`
   - Fill `sample(...)` with the higher-order update; replaces the half-steps stand-in.

6. **Otil / DistriFusion (multi-GPU)** — currently a latency model (no output error).
   - Wire only if actually using 2 cards; needs the heterogeneous-GPU load balancer
     (STADI-style) since Otil assumes homogeneous (PROPOSAL §6, note 3).

7. **SANA backbone (substrate)** — `stack/adapters/sana.py`
   - Load real SANA/SANA-1.5 exposing `forward(x,t,y)`; replaces `backbones build_backbone('sana')`
     fewer-token stand-in. Avoid SANA-Sprint as substrate (already distilled, §3d).

## Per-engine verification gate

For each engine, before trusting sweep numbers:
- [ ] `adapters.status()` shows it available.
- [ ] a single `evaluate_config` with only that axis on RUNS without error.
- [ ] its **measured** speedup is reported (never hardcode paper numbers — §6).
- [ ] error vs the un-accelerated reference is finite and sane.

## Then: run the real experiments

- Contribution 1: `python -m experiments.run_pipeline --config configs/pipeline.yaml`
  (DiT-XL/2, real FID via `eval.metric: fid`), + `baselines_official/run_tinyfusion.sh`.
- Contribution 2: `python -m experiments.stack.run_stack --config stack/configs/stack.yaml`
  (after `use_backend` for quant/cache), interaction matrix + orchestrator on real axes.
- Both hypotheses: `python -m experiments.validate --config configs/validate.yaml`
  with `mode: dit_xl` → real RQ0a/RQ0b/H1/RQ4 verdicts.
