"""End-to-end CPU smoke test for the LAAMP pipeline (no downloads, no GPU).

Verifies the *logic* of every moving part before you commit GPU hours:
  1. maskable DiT forward + independent attn/mlp masking + physical removal
  2. FLOPs cost vector (analytic vs measured cross-check)
  3. Phase-A dual-mask search hits the FLOPs budget and hardens
  4. TN-1 recoverability profiling produces an L x {attn,mlp} heatmap
  5. Phase-B physical prune + recovery runs
  6. latency / param-count harness works

Run:  python -m experiments.smoke_test
"""
from __future__ import annotations

import copy

import torch

from .laamp import (DiTConfig, build_model, build_objective, SearchConfig,
                    run_search, apply_hard_mask, recover, asymmetry_index,
                    kept_counts, baselines)
from .laamp.flops import analytic_cost_vector, measured_cost_vector, full_flops
from .laamp import profiling
from .harness import latency
from .data import synthetic_iter

torch.manual_seed(0)
DEVICE = "cpu"


def banner(s):
    print("\n" + "=" * 60 + f"\n{s}\n" + "=" * 60)


def main():
    cfg = DiTConfig.tiny()
    obj = build_objective("flow", DEVICE)
    data = lambda seed=0: synthetic_iter(batch=8, channels=cfg.in_channels,
                                         size=cfg.input_size, num_classes=cfg.num_classes,
                                         seed=seed, device=DEVICE)

    banner("1. maskable DiT + independent attn/mlp masking")
    model = build_model(cfg).to(DEVICE)
    x0, y = next(data())
    t = torch.rand(x0.shape[0]) * 999
    out_full = model(x0, t, y)
    print(f"forward ok, out shape = {tuple(out_full.shape)}, depth={cfg.depth}")
    # drop only attn of layer 0 -> output must change; graph must still run
    model.blocks[0].alive_attn = False
    out_dropped = model(x0, t, y)
    print(f"drop attn[0]: output changed = {not torch.allclose(out_full, out_dropped)}")
    model.reset_masks()

    banner("2. FLOPs cost vector (analytic vs measured)")
    c = analytic_cost_vector(cfg)                      # per-sample MACs
    c_meas = measured_cost_vector(model, x0, t, y) / x0.shape[0]  # de-batch
    # measured counts only Linear MACs (no attention scores term) -> proj part should align
    print(f"analytic full = {c.sum():.3e} MACs/sample, measured(linear-only) = {c_meas.sum():.3e}")
    print(f"analytic per-subblock[0:4] = {c[:4].tolist()}")

    banner("3. Phase-A dual-mask search @ 50% FLOPs")
    scfg = SearchConfig(keep_ratio=0.5, n_steps=200, log_every=40, lam_budget=50.0)
    res = run_search(copy.deepcopy(model), obj, data(1), scfg, DEVICE, verbose=True)
    m_star = res["m_star"]
    print(f"achieved FLOPs frac = {res['achieved_flops']:.3f} (target 0.50)")
    print(f"mask asymmetry A = {asymmetry_index(m_star, cfg.depth):.3f}  "
          f"kept = {kept_counts(m_star, cfg.depth)}")

    banner("4. TN-1 recoverability profiling (heatmap)")
    # quick pretrain so recoverability deltas are meaningful
    base = build_model(cfg).to(DEVICE)
    opt = torch.optim.AdamW(base.parameters(), lr=1e-3)
    it = data(2)
    for _ in range(150):
        l = obj.loss(base, *next(it)); opt.zero_grad(); l.backward(); opt.step()
    delta = profiling.profile_recoverability(
        lambda: build_model(cfg), base.state_dict(), cfg, obj,
        lambda: data(3), k_recover=15, n_eval=4, device=DEVICE, verbose=False)
    summ = profiling.summarize(delta)
    print("recoverability delta[layer, (attn,mlp)]:")
    for l in range(cfg.depth):
        print(f"  L{l}: attn={delta[l,0]:+.4f}  mlp={delta[l,1]:+.4f}")
    print(f"summary: {summ}")
    path = profiling.render_heatmap(delta, "experiments/results/tn1_heatmap")
    print(f"heatmap written -> {path}")

    banner("5. Phase-B prune + recover + baseline comparison")
    def build_pruned(mask):
        m = build_model(cfg).to(DEVICE)
        m.load_state_dict(base.state_dict())
        apply_hard_mask(m, mask)
        recover(m, obj, data(4), n_steps=80, lr=5e-4, device=DEVICE, verbose=False)
        from .harness import metrics
        return metrics.denoise_proxy(m, obj, data(5), n_batches=8), m

    q_laamp, m_laamp = build_pruned(m_star)
    m_rand = baselines.select("random", base, 0.5, seed=0)
    q_rand, _ = build_pruned(m_rand)
    m_coup = baselines.select("coupled", base, 0.5)
    q_coup, _ = build_pruned(m_coup)
    print(f"quality proxy (lower=better): LAAMP={q_laamp:.4f}  "
          f"coupled={q_coup:.4f}  random={q_rand:.4f}")

    banner("6. latency / param harness")
    sample_fn = lambda: (x0, t, y)
    lat = latency.measure_latency(m_laamp, sample_fn, DEVICE, warmup=2, iters=5)
    print(f"latency = {lat['ms_mean']:.2f} +/- {lat['ms_std']:.2f} ms")
    print(f"alive params = {latency.param_count(m_laamp):,} / "
          f"full = {latency.param_count(build_model(cfg), only_alive=False):,}")

    banner("SMOKE TEST PASSED")
    print("All pipeline stages ran. Logic verified on CPU; scale up on 4090 via")
    print("  python -m experiments.run_contrib1 --config dit_xl --latents <dir> ...")


if __name__ == "__main__":
    main()
