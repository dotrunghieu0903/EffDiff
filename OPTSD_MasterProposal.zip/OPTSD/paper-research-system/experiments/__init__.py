"""Thesis experiments: LAAMP (Contribution 1) + error-aware stack (Contribution 2)."""
