"""Sample-image rendering for the demo (before/after quality check).

The demo backbones emit *latents*, not RGB (there is no VAE on the CPU box), so
`render_latent_png` visualises the first channels of a sampled latent as an image.
This is a QUALITY PROXY, labelled as such in the UI — it lets you SEE that the
optimized model's output stays close to the base model's, without claiming to be
VAE-decoded photographs. On GPU with a real diffusers VAE this function is where a
true decode would slot in.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from PIL import Image


@torch.no_grad()
def render_latent_png(x0: torch.Tensor, path: str, upscale_to: int = 192) -> str:
    """x0: (B,C,H,W). Renders sample 0 (first up-to-3 channels) to a PNG."""
    t = x0[0].detach().float().cpu()
    c = t.shape[0]
    if c >= 3:
        img = t[:3]
    elif c == 1:
        img = t.repeat(3, 1, 1)
    else:  # 2 channels -> pad
        img = torch.cat([t, t[:1]], dim=0)[:3]
    img = img - img.amin()
    img = img / (img.amax() + 1e-8)
    arr = (img.permute(1, 2, 0).numpy() * 255).astype(np.uint8)
    im = Image.fromarray(arr, mode="RGB")
    if upscale_to and im.width < upscale_to:
        im = im.resize((upscale_to, upscale_to), Image.NEAREST)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    im.save(path)
    return path


def latent_delta(a: torch.Tensor, b: torch.Tensor) -> float:
    """Normalised L2 distance between two latents — a cheap 'how much did quality
    move' scalar for the before/after panel (lower = closer to the base output)."""
    a, b = a.float(), b.float()
    return float((a - b).norm() / (a.norm() + 1e-8))
