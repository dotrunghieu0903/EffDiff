"""Resolve a user-supplied model source into something the demo can analyze.

Three input sources, one downstream flow (analyze -> recommend -> apply -> export):

    preset : a built-in DiT backbone (tiny / sana / dit_xl)      -> runs for real
    local  : a local .pt/.safetensors file OR a diffusers folder -> inspected
    hf     : a HuggingFace repo id or hub URL                     -> inspected

For `local`/`hf` we INSPECT the checkpoint (safetensors header / torch state-dict
keys / diffusers config.json) to report the *detected* architecture, then pick the
closest built-in backbone to actually run the CPU study on.

This detected-vs-proxy split is deliberate and surfaced to the user, never hidden:
the real W4A4 / forecast engines only exist as GPU adapters (stack/adapters/*), so
a full FLUX/SDXL cannot be *optimized* on a CPU demo box. What the app proves on
CPU is the FLOW and the Contribution-2 brain (the error-interaction map + the
recommender); the real per-axis numbers come from the GPU runbook.

Lives entirely under ui/ and only READS core modules.
"""
from __future__ import annotations

import json
import re
import struct
from pathlib import Path

from ..stack.backbones import BACKBONES

_ST_EXT = {".safetensors"}
_PT_EXT = {".pt", ".pth", ".ckpt", ".bin"}


# --------------------------------------------------------------------------
# low-level inspectors (dependency-light; safetensors header is pure stdlib)
# --------------------------------------------------------------------------
def _safetensors_header(path: Path) -> dict:
    """{tensor_name: shape} from a .safetensors header, without loading tensors."""
    with open(path, "rb") as f:
        n = struct.unpack("<Q", f.read(8))[0]
        hdr = json.loads(f.read(n).decode("utf-8"))
    hdr.pop("__metadata__", None)
    return {k: v.get("shape", []) for k, v in hdr.items()}


def _torch_state_shapes(path: Path) -> dict:
    """Load a torch checkpoint on CPU and return {tensor_name: shape}."""
    import torch
    obj = torch.load(path, map_location="cpu")
    for key in ("state_dict", "model", "module", "ema"):
        if isinstance(obj, dict) and key in obj and isinstance(obj[key], dict):
            obj = obj[key]
            break
    shapes = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            if hasattr(v, "shape"):
                shapes[k] = list(v.shape)
    return shapes


def _infer_arch(shapes: dict) -> dict:
    """Best-effort architecture summary from a {name: shape} map."""
    names = list(shapes.keys())
    depth = 0
    for k in names:
        m = re.search(r"(?:blocks|layers|transformer_blocks|single_transformer_blocks)\.(\d+)\.", k)
        if m:
            depth = max(depth, int(m.group(1)) + 1)
    hidden = None
    for k, sh in shapes.items():
        if len(sh) == 2 and ("attn" in k or "attention" in k or "qkv" in k) and sh[0] and sh[1]:
            hidden = min(sh)
            break
    if hidden is None:  # fall back to any embedding-like square-ish weight
        for k, sh in shapes.items():
            if len(sh) == 2 and "embed" in k.lower():
                hidden = sh[-1]
                break
    if any("transformer_blocks" in k or "single_transformer_blocks" in k for k in names):
        kind = "MMDiT / diffusion transformer"
    elif any(re.search(r"blocks\.\d+", k) for k in names):
        kind = "DiT (blocks.*)"
    elif any("down_blocks" in k or "up_blocks" in k for k in names):
        kind = "UNet"
    else:
        kind = "unknown"
    return dict(kind=kind, depth=(depth or None), hidden=hidden,
                n_tensors=len(names))


def _config_arch(cfg: dict) -> dict:
    """Architecture summary from a diffusers/transformers config.json."""
    depth = cfg.get("num_layers") or cfg.get("num_hidden_layers") or \
        cfg.get("depth") or cfg.get("layers_per_block")
    hidden = cfg.get("hidden_size") or cfg.get("d_model") or \
        cfg.get("cross_attention_dim") or cfg.get("num_attention_heads")
    kind = cfg.get("_class_name") or cfg.get("model_type") or "diffusers config"
    return dict(kind=str(kind), depth=depth, hidden=hidden, n_tensors=None)


# --------------------------------------------------------------------------
# choose the CPU backbone that best stands in for a detected architecture
# --------------------------------------------------------------------------
def _pick_backbone(detected: dict, src_path: Path | None):
    """Return (backbone_name, base_path_or_None, proxy_bool)."""
    depth = detected.get("depth") or 0
    hidden = detected.get("hidden") or 0
    # A real DiT-XL/2 checkpoint (28 blocks, hidden 1152) can be loaded as-is.
    if detected.get("kind", "").startswith("DiT") and depth >= 20 and src_path and \
            src_path.is_file() and src_path.suffix in _PT_EXT:
        return "dit_xl", str(src_path), False
    # Otherwise run the analysis on a light proxy. Fewer tokens (SANA-like) if the
    # detected model is very wide/large; the plain tiny DiT for everything else.
    if hidden and hidden >= 1024:
        return "sana", None, True
    return "tiny", None, True


# --------------------------------------------------------------------------
# public entry point
# --------------------------------------------------------------------------
def _hf_repo_id(value: str) -> str:
    v = value.strip().rstrip("/")
    m = re.search(r"huggingface\.co/(?:models/)?([^/]+/[^/?#]+)", v)
    return m.group(1) if m else v


def resolve(kind: str, value: str) -> dict:
    """kind in {preset, local, hf}. Returns a dict the server caches + shows:

        {backbone, base_path, proxy, detected:{kind,depth,hidden,...},
         source, note, ok, error?}
    """
    kind = (kind or "preset").lower()
    value = (value or "").strip()

    # ---- preset -----------------------------------------------------------
    if kind == "preset":
        name = value if value in BACKBONES else "tiny"
        return dict(ok=True, backbone=name, base_path=None, proxy=False,
                    detected=dict(kind="built-in preset", depth=None, hidden=None),
                    source=f"preset:{name}",
                    note="Built-in backbone — runs the full CPU flow for real.")

    # ---- local ------------------------------------------------------------
    if kind == "local":
        p = Path(value)
        if not p.exists():
            return dict(ok=False, error=f"Path not found: {value}")
        try:
            if p.is_dir():
                cfgs = list(p.glob("**/config.json"))[:1] + list(p.glob("**/*config*.json"))[:1]
                if cfgs:
                    detected = _config_arch(json.loads(cfgs[0].read_text(encoding="utf-8")))
                    src_file = None
                else:
                    sts = list(p.glob("**/*.safetensors"))
                    if not sts:
                        return dict(ok=False, error="No config.json or .safetensors in folder.")
                    detected = _infer_arch(_safetensors_header(sts[0]))
                    src_file = sts[0]
            elif p.suffix in _ST_EXT:
                detected = _infer_arch(_safetensors_header(p)); src_file = p
            elif p.suffix in _PT_EXT:
                detected = _infer_arch(_torch_state_shapes(p)); src_file = p
            else:
                return dict(ok=False, error=f"Unsupported file type: {p.suffix}")
        except Exception as e:  # inspection is best-effort; never crash the app
            return dict(ok=False, error=f"Could not inspect model: {e}")
        backbone, base_path, proxy = _pick_backbone(detected, src_file)
        note = (f"Loaded real DiT-XL checkpoint from {p.name}."
                if not proxy else
                f"Detected {detected['kind']} (depth={detected.get('depth')}, "
                f"hidden={detected.get('hidden')}). CPU demo runs the analysis on a "
                f"compatible '{backbone}' proxy; real W4A4/forecast engines activate "
                f"on GPU (see stack/ADAPTERS.md).")
        return dict(ok=True, backbone=backbone, base_path=base_path, proxy=proxy,
                    detected=detected, source=f"local:{p.name}", note=note)

    # ---- huggingface ------------------------------------------------------
    if kind == "hf":
        repo = _hf_repo_id(value)
        if not repo or "/" not in repo:
            return dict(ok=False, error=f"Not a valid HF repo id / URL: {value}")
        detected, hub_note = dict(kind="unknown", depth=None, hidden=None), ""
        try:
            from huggingface_hub import hf_hub_download
            got = None
            for cand in ("transformer/config.json", "config.json",
                         "unet/config.json", "model_index.json"):
                try:
                    got = hf_hub_download(repo_id=repo, filename=cand)
                    break
                except Exception:
                    continue
            if got:
                detected = _config_arch(json.loads(Path(got).read_text(encoding="utf-8")))
            else:
                hub_note = " (config.json not found on hub — arch unknown)"
        except Exception as e:
            hub_note = f" (hub unreachable/offline: {e})"
        backbone, base_path, proxy = _pick_backbone(detected, None)
        note = (f"Resolved HF repo '{repo}'{hub_note}. CPU demo runs the analysis on a "
                f"compatible '{backbone}' proxy — downloading + optimizing the real "
                f"weights runs on GPU via the adapters (stack/ADAPTERS.md).")
        return dict(ok=True, backbone=backbone, base_path=None, proxy=True,
                    detected=detected, source=f"hf:{repo}", note=note)

    return dict(ok=False, error=f"Unknown source kind: {kind}")
