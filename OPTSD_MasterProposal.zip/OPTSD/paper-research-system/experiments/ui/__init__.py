"""OPTSD demo application (UI layer).

Everything the *demo app* needs lives under this package: a self-contained HTTP
backend (`server.py`), a model-source resolver (`model_loader.py`), sample-image
rendering (`imaging.py`) and an extended HTML report (`report_ext.py`).

Design rule (thesis constraint): this layer only *imports and calls* the core
modules (`laamp/`, `stack/`, `harness/`) — it never modifies them. The demo can be
deleted wholesale without touching the scientific contributions.
"""
