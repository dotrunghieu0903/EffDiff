// OPTSD demo-app front-end. Talks to ui/server.py (same origin) which calls the
// Contribution-1 (LAAMP) + Contribution-2 (error-aware stack) core in-process.
// Flow: Load model (preset/local/HF) -> Analyze (real error-interaction map) ->
// Optimize (apply + MEASURED latency/VRAM + sample images) -> export folder.

const $ = (id) => document.getElementById(id);
const BASE = "";

const el = {
  device: $("device-select"), deviceLabel: $("selected-device-label"),
  deviceSummary: $("selected-device-summary"), sysInfo: $("system-info-list"),
  // model source
  sourceKind: $("source-kind"), srcPreset: $("src-preset"), srcLocal: $("src-local"),
  srcHf: $("src-hf"), modelConfig: $("model-config-select"),
  localPath: $("local-path-input"), hfInput: $("hf-input"),
  loadBtn: $("loadBtn"), loadHint: $("loadHint"), loadNote: $("load-note"),
  target: $("target-input"),
  // axes
  prune: $("prune-toggle"), pruneWrap: $("prune-knob-wrap"), pruneKeep: $("prune-keep"),
  quant: $("quant-toggle"), quantWrap: $("quant-knob-wrap"), quantBits: $("quant-bits"),
  cache: $("cache-toggle"), cacheWrap: $("cache-knob-wrap"), cacheInterval: $("cache-interval"),
  dist: $("dist-toggle"), regimeNote: $("regime-note"), techNote: $("techniqueSuggestionNote"),
  // config panel
  sourceValue: $("model-source-value"), validationValue: $("model-validation-value"),
  archValue: $("model-architecture-value"), techValue: $("model-techniques-value"),
  configChip: $("config-chip"), analysisChip: $("analysis-chip"),
  interBody: $("interaction-body"), rationaleBlock: $("rationale-block"),
  rationaleList: $("rationale-list"),
  analyzeBtn: $("analyzeBtn"), analysisHint: $("analysisHint"),
  // result
  resultPanel: $("result-panel"), metricRow: $("metric-row"), sampleWrap: $("sample-wrap"),
  imgBefore: $("img-before"), imgAfter: $("img-after"), qualityNote: $("quality-note"),
  optimizeBtn: $("optimizeBtn"), runStatus: $("runStatus"), reportLink: $("reportLink"),
  progress: $("optimize-progress"), progressLabel: $("progress-label"),
  progressPercent: $("progress-percent"), progressFill: $("progress-fill"),
  toast: $("toast"),
};

const state = { loaded: false, analyzed: false };

function toast(msg) {
  el.toast.textContent = msg; el.toast.classList.add("show");
  clearTimeout(toast.t); toast.t = setTimeout(() => el.toast.classList.remove("show"), 2600);
}
function esc(v) {
  return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
async function apiGet(path) { return (await fetch(BASE + path)).json(); }
async function apiPost(path, body) {
  const r = await fetch(BASE + path, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.json();
}

// ---- config helpers -------------------------------------------------------
function currentRegime() {
  return document.querySelector('input[name="regime"]:checked')?.value || "full";
}
function currentKnobs() {
  const distilled = currentRegime() === "distilled";
  return {
    prune_keep: el.prune.checked ? parseFloat(el.pruneKeep.value) : 1.0,
    quant_bits: el.quant.checked ? parseInt(el.quantBits.value, 10) : 16,
    cache_interval: (el.cache.checked && !distilled) ? parseInt(el.cacheInterval.value, 10) : 1,
    dist_gpus: el.dist.checked ? 2 : 1,
  };
}
function syncKnobVisibility() {
  el.pruneWrap.classList.toggle("hidden", !el.prune.checked);
  el.quantWrap.classList.toggle("hidden", !el.quant.checked);
  el.cacheWrap.classList.toggle("hidden", !el.cache.checked);
}
function syncRegime() {
  const r = currentRegime(), distilled = r === "distilled";
  el.cache.disabled = distilled;
  if (distilled) el.cache.checked = false;
  syncKnobVisibility();
  el.regimeNote.textContent = distilled
    ? "Distilled few-step: caching disabled (compounds error — DisCa, §3b)."
    : r === "solver" ? "RF-Solver: fewer ODE steps at full-compute; composes with axes."
    : "Full-step: all axes available.";
}
function applyRecommendation(knobs) {
  el.prune.checked = (knobs.prune ?? 1.0) < 1.0;
  if (el.prune.checked) el.pruneKeep.value = String(knobs.prune);
  el.quant.checked = (knobs.quant ?? 16) < 16;
  if (el.quant.checked) el.quantBits.value = String(knobs.quant);
  el.cache.checked = (knobs.cache ?? 1) > 1;
  if (el.cache.checked) el.cacheInterval.value = String(knobs.cache);
  syncKnobVisibility();
}

// ---- device / system ------------------------------------------------------
async function initDevices() {
  let data;
  try { data = await apiGet("/api/device-resources"); } catch { data = null; }
  if (!data || !data.success) {
    el.deviceLabel.textContent = "Backend offline — start ui/server.py";
    el.sysInfo.innerHTML = "<li><span>Status</span><strong>Backend not reachable</strong></li>";
    return;
  }
  el.device.innerHTML = data.devices
    .map((d) => `<option value="${esc(d.id)}">${esc(d.name)} (${d.type})</option>`).join("");
  const first = data.devices[0];
  const label = first ? `${first.name} (${first.type})` : "Unknown";
  el.deviceLabel.textContent = `Using ${label}`;
  el.deviceSummary.textContent = label;

  const rows = [];
  data.devices.filter((d) => d.type === "GPU").forEach((g, i) => {
    rows.push(`<li><span>GPU ${i}</span><strong>${esc(g.name)}</strong></li>`);
    if (g.memoryGB) rows.push(`<li><span>GPU ${i} RAM</span><strong>${g.memoryGB} GB</strong></li>`);
  });
  if (data.cpuCores) rows.push(`<li><span>CPU cores</span><strong>${data.cpuCores}</strong></li>`);
  if (data.host?.os) rows.push(`<li><span>OS</span><strong>${esc(data.host.os)}</strong></li>`);
  rows.push(`<li><span>Source</span><strong>${esc(data.dataSource)}</strong></li>`);
  el.sysInfo.innerHTML = rows.join("");
}

// ---- load model -----------------------------------------------------------
function sourceKind() { return el.sourceKind.value; }
function sourceValue() {
  if (sourceKind() === "preset") return el.modelConfig.value;
  if (sourceKind() === "local") return el.localPath.value.trim();
  return el.hfInput.value.trim();
}
function syncSource() {
  const k = sourceKind();
  el.srcPreset.classList.toggle("hidden", k !== "preset");
  el.srcLocal.classList.toggle("hidden", k !== "local");
  el.srcHf.classList.toggle("hidden", k !== "hf");
}
async function loadModel() {
  const value = sourceValue();
  if (sourceKind() !== "preset" && !value) { toast("Enter a path or repo id first."); return; }
  el.loadBtn.disabled = true; el.loadBtn.textContent = "Loading…";
  el.runStatus.textContent = "Loading model: inspecting + preparing base…";
  try {
    const res = await apiPost("/api/load-model", { kind: sourceKind(), value });
    if (!res.success) throw new Error(res.error || "load failed");
    state.loaded = true; state.analyzed = false;
    el.sourceValue.textContent = res.source + (res.proxy ? " (proxy)" : "");
    el.archValue.textContent = res.architecture;
    el.validationValue.textContent = "Loaded";
    el.loadNote.textContent = res.note || "";
    el.analyzeBtn.disabled = false;
    el.resultPanel.classList.add("hidden");
    el.runStatus.textContent = "Model loaded. Analyze to measure the error-interaction map.";
    toast("Model loaded — ready to analyze.");
  } catch (e) {
    state.loaded = false; el.analyzeBtn.disabled = true;
    el.runStatus.textContent = "Load failed: " + e.message; toast(e.message);
  } finally {
    el.loadBtn.disabled = false; el.loadBtn.textContent = "Load Model";
  }
}

// ---- analyze --------------------------------------------------------------
async function analyze() {
  if (!state.loaded) { toast("Load a model first."); return; }
  el.analyzeBtn.disabled = true; el.analyzeBtn.textContent = "Analyzing…";
  el.analysisChip.textContent = "Profiling…";
  el.runStatus.textContent = "Analyzing model: profiling axes + measuring interactions…";
  try {
    const res = await apiPost("/api/analyze", {
      target: parseFloat(el.target.value) || 4.0, regime: currentRegime(),
    });
    if (!res.success) throw new Error(res.error || "analyze failed");
    el.validationValue.textContent = "Analyzed";
    el.techValue.textContent = res.suggested.join(", ");
    el.techNote.textContent = `Recommended for target ${el.target.value}×: ${res.suggested.join(", ")}.`;
    renderInteraction(res.interaction);
    renderRationale(res.recommendation.rationale);
    applyRecommendation(res.recommendation.knobs);
    el.analysisChip.textContent = "Done"; state.analyzed = true;
    el.runStatus.textContent = "Analysis complete. Review the map, then Start Optimization.";
    toast("Analysis complete — recommendation applied.");
  } catch (e) {
    el.analysisChip.textContent = "Error";
    el.runStatus.textContent = "Analysis failed: " + e.message; toast(e.message);
  } finally {
    el.analyzeBtn.disabled = false; el.analyzeBtn.textContent = "Analyze Model";
  }
}
function renderInteraction(pairs) {
  if (!pairs?.length) {
    el.interBody.innerHTML = `<tr><td colspan="7" class="muted">No pairs.</td></tr>`; return;
  }
  el.interBody.innerHTML = pairs.map((p) => `
    <tr>
      <td>${esc(p.axisA)} × ${esc(p.axisB)}</td>
      <td>${p.e_A.toFixed(4)}</td><td>${p.e_B.toFixed(4)}</td><td>${p.e_AB.toFixed(4)}</td>
      <td>${p.delta >= 0 ? "+" : ""}${p.delta.toFixed(4)}</td>
      <td>${p.rho >= 0 ? "+" : ""}${p.rho.toFixed(2)}</td>
      <td><span class="pill ${p.verdict}">${esc(p.verdict)}</span></td>
    </tr>`).join("");
}
function renderRationale(lines) {
  el.rationaleBlock.classList.remove("hidden");
  el.rationaleList.innerHTML = (lines || []).map((l) => `<li>${esc(l)}</li>`).join("");
}

// ---- optimize -------------------------------------------------------------
let progTimer = null;
function setProgress(pct, label) {
  const c = Math.max(0, Math.min(100, pct));
  el.progressFill.style.width = `${c}%`;
  el.progressPercent.textContent = `${Math.round(c)}%`;
  if (label) el.progressLabel.textContent = label;
}
function startProgress(steps) {
  clearInterval(progTimer);
  el.progress.classList.remove("hidden", "done", "error");
  setProgress(0, steps[0] || "Preparing…");
  let cur = 0;
  progTimer = setInterval(() => {
    if (cur >= 92) return;
    cur = Math.min(92, cur + Math.random() * 5 + 2);
    setProgress(cur, steps[Math.min(steps.length - 1, Math.floor((cur / 92) * steps.length))]);
  }, 350);
}
function finishProgress(label, ok = true) {
  clearInterval(progTimer);
  el.progress.classList.add(ok ? "done" : "error");
  setProgress(ok ? 100 : 0, label);
  setTimeout(() => el.progress.classList.add("hidden"), 3200);
}
function metricTile(label, value, sub) {
  return `<div class="metric-tile"><div class="metric-label">${esc(label)}</div>
    <div class="metric-value">${esc(value)}</div>
    <div class="metric-sub">${esc(sub || "")}</div></div>`;
}
function renderResult(res) {
  const m = res.measured || {}, meta = res.metadata || {};
  const tiles = [
    metricTile("params", meta.after_params?.toLocaleString() ?? "—",
               `was ${meta.before_params?.toLocaleString() ?? "—"}`),
  ];
  if (m.ms_before && m.ms_after)
    tiles.push(metricTile("latency / fwd", `${m.ms_after.toFixed(1)} ms`,
      `was ${m.ms_before.toFixed(1)} ms · ${(m.latency_speedup || 0).toFixed(2)}× measured`));
  if (m.vram_before_mb != null && m.vram_after_mb != null)
    tiles.push(metricTile("peak VRAM", `${Math.round(m.vram_after_mb)} MB`,
      `was ${Math.round(m.vram_before_mb)} MB`));
  else tiles.push(metricTile("peak VRAM", "n/a (CPU)", `device: ${meta.device || "cpu"}`));
  tiles.push(metricTile("speedup (FLOPs)", `${meta.achieved_speedup ?? "—"}×`,
    `target ${el.target.value}×`));
  el.metricRow.innerHTML = tiles.join("");

  if (res.images?.length === 2) {
    el.sampleWrap.classList.remove("hidden");
    const bust = "?t=" + Date.now();
    el.imgBefore.src = res.images[0].url + bust;
    el.imgAfter.src = res.images[1].url + bust;
    el.qualityNote.textContent = (res.quality != null)
      ? `Output drift base→optimized: ${res.quality.toFixed(4)} (normalised L2; lower = closer). `
        + "Latent visualisation proxy (no VAE on CPU)."
      : "";
  } else {
    el.sampleWrap.classList.add("hidden");
    el.qualityNote.textContent = "Sample images unavailable for this backbone.";
  }
  el.resultPanel.classList.remove("hidden");
}

async function optimize() {
  if (!state.analyzed) { toast("Analyze the model first."); return; }
  const knobs = currentKnobs(), regime = currentRegime();
  const steps = [];
  if (knobs.prune_keep < 1.0) steps.push("Pruning (LAAMP mask)");
  if (knobs.quant_bits < 16) steps.push(`Quantization W${knobs.quant_bits}`);
  if (knobs.cache_interval > 1) steps.push(`Caching interval ${knobs.cache_interval}`);
  if (knobs.dist_gpus > 1) steps.push("Multi-GPU");
  if (regime === "solver") steps.push("RF-Solver (fewer steps)");
  if (regime === "distilled") steps.push("DMD2 few-step");
  if (!steps.length) { toast("Enable at least one axis or regime."); return; }
  steps.push("Measuring latency/VRAM", "Rendering sample + report");

  el.optimizeBtn.disabled = true; el.optimizeBtn.textContent = "Optimizing…";
  el.runStatus.textContent = `Optimizing with ${steps.slice(0, -2).join(", ")}…`;
  startProgress(steps);
  try {
    const res = await apiPost("/api/optimize", {
      knobs, target: parseFloat(el.target.value) || 4.0, regime,
    });
    if (!res.success) throw new Error(res.error || "optimize failed");
    finishProgress("Optimization complete.");
    renderResult(res);
    const m = res.metadata;
    el.runStatus.textContent =
      `Done — ~${m.achieved_speedup}× · params ${m.before_params.toLocaleString()} → ${m.after_params.toLocaleString()}.`;
    el.reportLink.classList.remove("hidden");
    el.reportLink.innerHTML =
      `Exported to <code>${esc(res.files.folder)}</code> · ` +
      `<a href="${res.files.report.url}" target="_blank">report.html</a> · ` +
      `<code>${esc(res.files.optimizedModel.name)}</code>`;
    toast("Optimized model + report exported.");
  } catch (e) {
    finishProgress("Optimization failed.", false);
    el.runStatus.textContent = "Optimization failed: " + e.message; toast(e.message);
  } finally {
    el.optimizeBtn.disabled = false; el.optimizeBtn.textContent = "Start Optimization";
  }
}

// ---- wiring ---------------------------------------------------------------
el.sourceKind.addEventListener("change", () => { syncSource(); state.loaded = false;
  state.analyzed = false; el.analyzeBtn.disabled = true; });
[el.prune, el.quant, el.cache].forEach((c) => c.addEventListener("change", syncKnobVisibility));
document.querySelectorAll('input[name="regime"]').forEach((r) =>
  r.addEventListener("change", () => { syncRegime(); state.analyzed = false; }));
el.device.addEventListener("change", () => {
  const t = el.device.options[el.device.selectedIndex]?.text || "";
  el.deviceLabel.textContent = `Using ${t}`; el.deviceSummary.textContent = t;
});
el.loadBtn.addEventListener("click", loadModel);
el.analyzeBtn.addEventListener("click", analyze);
el.optimizeBtn.addEventListener("click", optimize);

initDevices();
syncSource();
syncRegime();
syncKnobVisibility();
