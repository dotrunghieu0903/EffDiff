"""Extended standalone HTML report for the demo app.

Superset of stack/report.py (which stays untouched): adds the MEASURED
latency/VRAM before->after, the sample before/after images, and the detected
source. Self-contained (inline CSS, images referenced by relative path under
results/tool_web/), so the exported folder opens anywhere.
"""
from __future__ import annotations

import html
import json
from datetime import datetime

_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#0f1420;color:#e6e9ef}
.wrap{max-width:960px;margin:0 auto;padding:32px}
h1{font-size:22px;margin:0 0 4px}.sub{color:#8b95a7;font-size:13px;margin-bottom:24px}
.card{background:#171d2b;border:1px solid #232b3d;border-radius:12px;padding:20px;margin:16px 0}
.card h2{font-size:15px;margin:0 0 12px;color:#9fb4ff;text-transform:uppercase;letter-spacing:.05em}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #232b3d}
th{color:#8b95a7;font-weight:600}
.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
.orthogonal{background:#123524;color:#4ade80}.compounding{background:#3a1520;color:#f87171}
.sub-additive{background:#1a2740;color:#60a5fa}
.big{font-size:26px;font-weight:700;color:#fff}.unit{font-size:13px;color:#8b95a7}
.grid{display:flex;gap:16px;flex-wrap:wrap}.grid>div{flex:1;min-width:150px}
.rat{margin:6px 0;padding-left:14px;border-left:3px solid #2f3b55;color:#c7cfdd;font-size:13px}
code{background:#0f1420;padding:2px 6px;border-radius:6px;color:#9fb4ff;font-size:12px}
.imgs{display:flex;gap:16px;flex-wrap:wrap}.imgs figure{margin:0;text-align:center}
.imgs img{width:192px;height:192px;image-rendering:pixelated;border-radius:8px;border:1px solid #232b3d}
figcaption{color:#8b95a7;font-size:12px;margin-top:6px}
.note{color:#f0b866;font-size:12px;margin-top:8px}
"""


def _pill(v):
    return f'<span class="pill {v}">{v}</span>'


def _metric(label, value, unit=""):
    return (f'<div><div class="unit">{html.escape(label)}</div>'
            f'<div class="big">{value}</div>'
            f'<div class="unit">{html.escape(unit)}</div></div>')


def render(path, *, model_name, source, detected, proxy, target, achieved_proxy,
           interaction_pairs, recommendation, before, after, images=None,
           measured=None, quality=None):
    rows = ""
    for p in interaction_pairs:
        rows += (f"<tr><td>{p['axisA']} × {p['axisB']}</td><td>{p['e_A']:.4f}</td>"
                 f"<td>{p['e_B']:.4f}</td><td>{p['e_AB']:.4f}</td>"
                 f"<td>{p['delta']:+.4f}</td><td>{p['rho']:+.2f}</td>"
                 f"<td>{_pill(p['verdict'])}</td></tr>")
    rats = "".join(f'<div class="rat">{html.escape(r)}</div>' for r in recommendation["rationale"])
    knobs = html.escape(json.dumps(recommendation["knobs"]))

    # measured metrics block (latency always; VRAM only when CUDA measured it)
    m = measured or {}
    mrows = [_metric("params (alive)", f"{after['params']:,}", f"was {before['params']:,}")]
    if m.get("ms_before") and m.get("ms_after"):
        mrows.append(_metric("latency / fwd", f"{m['ms_after']:.1f} ms",
                             f"was {m['ms_before']:.1f} ms · {m.get('latency_speedup', 0):.2f}× measured"))
    if m.get("vram_before_mb") is not None and m.get("vram_after_mb") is not None:
        mrows.append(_metric("peak VRAM", f"{m['vram_after_mb']:.0f} MB",
                             f"was {m['vram_before_mb']:.0f} MB"))
    else:
        mrows.append(_metric("peak VRAM", "n/a (CPU)", "run on 3090/4090 for VRAM"))
    mrows.append(_metric("speedup (FLOPs proxy)", f"{achieved_proxy:.1f}×", f"target {target:.1f}×"))

    imgs_html = ""
    if images:
        figs = "".join(
            f'<figure><img src="{html.escape(src)}" alt="{html.escape(cap)}">'
            f'<figcaption>{html.escape(cap)}</figcaption></figure>'
            for cap, src in images)
        q = (f'<div class="note">Output drift base→optimized: '
             f'{quality:.4f} (normalised L2; lower = closer to base).</div>'
             if quality is not None else "")
        imgs_html = (f'<div class="card"><h2>Sample output — quality check</h2>'
                     f'<div class="imgs">{figs}</div>{q}'
                     f'<div class="note">Latent visualisation proxy (no VAE on CPU) — '
                     f'shows the optimized model tracks the base output.</div></div>')

    proxy_note = (f'<div class="note">Analysis ran on a compatible proxy backbone '
                  f'(detected: {html.escape(str(detected.get("kind")))}, '
                  f'depth={detected.get("depth")}). Real per-axis engines run on GPU.</div>'
                  if proxy else "")

    doc = f"""<!doctype html><html><head><meta charset="utf-8">
<title>Optimization report — {html.escape(model_name)}</title><style>{_CSS}</style></head>
<body><div class="wrap">
<h1>Error-Aware Optimization Report</h1>
<div class="sub">source: <b>{html.escape(source)}</b> · generated {datetime.now():%Y-%m-%d %H:%M} ·
target {target:.1f}× · FLOPs-proxy {achieved_proxy:.1f}×</div>
{proxy_note}

<div class="card"><h2>Recommendation</h2>
<div>Selected config: <code>{knobs}</code></div>
{rats}
</div>

<div class="card"><h2>Before → After (measured)</h2><div class="grid">{''.join(mrows)}</div></div>

{imgs_html}

<div class="card"><h2>Error-interaction map</h2>
<table><tr><th>pair</th><th>e_A</th><th>e_B</th><th>e_AB</th><th>Δ</th><th>ρ</th><th>verdict</th></tr>
{rows}</table>
<div class="sub" style="margin-top:12px">ρ = Δ/(e_A+e_B). &gt;0 compounding (conflict) ·
≈0 orthogonal (safe to stack) · &lt;0 sub-additive. The recommendation is derived
from this measured map, not a fixed rule.</div>
</div>

</div></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
    return path
