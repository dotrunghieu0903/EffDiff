# OPTSD demo app (UI layer)

The **demo application** of the thesis: input a model, get an optimized model.
Everything here lives under `ui/` and only *calls* the core (`laamp/`, `stack/`,
`harness/`) — it never modifies it, so deleting this folder leaves the scientific
contributions untouched.

## Run

```bash
python -m experiments.ui.server --open        # http://127.0.0.1:7860
```

(The older `python -m experiments.stack.serve` is the minimal bridge and still
works; `ui/server.py` is the full app that supersedes it.)

## Flow (what the app does)

1. **Load model** — three sources:
   - **preset** — built-in `tiny` / `sana` / `dit_xl` (runs the full CPU flow for real);
   - **local** — a `.pt` / `.safetensors` file or a diffusers folder (inspected + auto-detected);
   - **hf** — a HuggingFace repo id or URL (config inspected via `huggingface_hub`).
   `model_loader.py` auto-detects the architecture (depth / hidden / kind) and picks a
   compatible backbone for the CPU study.
2. **Analyze** — measures the **real error-interaction map** and derives a
   recommendation from it (Contribution 2 brain — `stack/analyze.py`), not a fixed rule.
3. **Optimize** — applies the config (Contribution 1 LAAMP pruning + quant + cache),
   then **measures latency + peak VRAM** (`harness/latency.py`) and renders **sample
   before/after images** (quality proxy). Exports `optimized_model.pt` + `report.html`
   to `results/tool_web/`.

## Honesty notes (for the defense)

- On a **CPU** box VRAM is `n/a` and full FLUX/SDXL weights are **not** optimized —
  the app runs the analysis on a compatible proxy backbone and says so. The real
  per-axis W4A4 / forecast engines activate on GPU via `stack/adapters/*`
  (see `stack/ADAPTERS.md`). What CPU proves is the **flow** + the **error-aware brain**.
- Sample images are a **latent-visualisation proxy** (no VAE on CPU), labelled in the UI
  and report. A real diffusers VAE decode slots into `imaging.render_latent_png`.

## Files (all UI-only)

| File | Role |
|---|---|
| `server.py` | stdlib HTTP backend; `/api/load-model`, `/api/analyze`, `/api/optimize` |
| `model_loader.py` | resolve preset / local / HF → detected arch + proxy backbone |
| `imaging.py` | sample latent → PNG (quality proxy) + drift metric |
| `report_ext.py` | extended standalone HTML report (images + measured latency/VRAM) |
| `index.html` / `app.js` / `styles.css` | the front-end |
