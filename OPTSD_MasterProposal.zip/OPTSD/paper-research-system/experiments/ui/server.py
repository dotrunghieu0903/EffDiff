"""Demo-app backend — the full 'application' the thesis needs (UI layer only).

A ~zero-dependency stdlib http.server that (1) serves the static UI and (2) exposes
/api endpoints wiring the user flow:

    load model (preset / local file / HuggingFace)  ->  /api/load-model
    analyze  (real error-interaction map + brain)   ->  /api/analyze
    optimize (apply + MEASURE latency/VRAM + sample) ->  /api/optimize   -> exports a folder

It CALLS the Contribution-1 (LAAMP) + Contribution-2 (stack/analyze, orchestrator)
core in-process; it never modifies them. Everything new lives under ui/.

Run:
    python -m experiments.ui.server --open           # http://127.0.0.1:7860

(Port 7860 chosen because browsers block "unsafe" ports like 5060/5061 with
ERR_UNSAFE_PORT — those are SIP ports on Chrome/Firefox's hard-blocked list.)
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import torch

from ..laamp import build_model, build_objective
from ..data import synthetic_iter
from ..harness import latency as lat_h
from ..stack import analyze as A
from ..stack.axes import StackConfig, build_accelerated_model, cache_policy
from ..stack.backbones import build_backbone
from ..stack.orchestrator import config_speedup
from ..stack.sampler import flow_sample
from . import imaging, report_ext
from .model_loader import resolve

BASE_DIR = Path(__file__).resolve().parents[1]      # experiments/
UI_DIR = BASE_DIR / "ui"
OUT_DIR = BASE_DIR / "results" / "tool_web"
OUT_DIR.mkdir(parents=True, exist_ok=True)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

_STATE = {"resolved": None, "base": None, "mcfg": None, "objective": None,
          "x_init": None, "y": None, "data_iter": None, "profile": None,
          "interaction": None, "steps": 12}


# --------------------------------------------------------------------------
def _build_base(resolved, steps, n_probe):
    """Build/pretrain the base model for the resolved source; cache in _STATE."""
    backbone, base_path = resolved["backbone"], resolved.get("base_path")
    mcfg, obj_name = build_backbone(backbone)
    objective = build_objective(obj_name, DEVICE)
    model = build_model(mcfg).to(DEVICE)
    demo = backbone in ("tiny", "sana")
    if base_path and Path(base_path).exists():
        sd = torch.load(base_path, map_location=DEVICE)
        model.load_state_dict(sd.get("state_dict", sd), strict=False)
    elif demo:
        it = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                            num_classes=mcfg.num_classes, device=DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=1e-3); model.train()
        for _ in range(300):
            loss = objective.loss(model, *next(it)); opt.zero_grad(); loss.backward(); opt.step()
    data_iter = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                               num_classes=mcfg.num_classes, device=DEVICE) if demo else None
    x_init = torch.randn(n_probe, mcfg.in_channels, mcfg.input_size, mcfg.input_size, device=DEVICE)
    y = torch.randint(0, mcfg.num_classes, (n_probe,), device=DEVICE)
    _STATE.update(resolved=resolved, base=model, mcfg=mcfg, objective=objective,
                  x_init=x_init, y=y, data_iter=data_iter, profile=None, interaction=None,
                  steps=steps)


def _sample_fn(mcfg, batch=2):
    def fn():
        x = torch.randn(batch, mcfg.in_channels, mcfg.input_size, mcfg.input_size, device=DEVICE)
        t = torch.full((batch,), 500.0, device=DEVICE)
        y = torch.randint(0, mcfg.num_classes, (batch,), device=DEVICE)
        return (x, t, y)
    return fn


# --------------------------------------------------------------------------
def api_device_resources():
    devices, gpus = [], []
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            p = torch.cuda.get_device_properties(i)
            devices.append(dict(id=f"gpu-{i}", name=p.name, type="GPU",
                                memoryGB=round(p.total_memory / 1024**3, 1)))
            gpus.append(p.name)
    devices.append(dict(id="cpu-0", name=f"System CPU ({os.cpu_count()} cores)", type="CPU"))
    return dict(success=True, devices=devices, cpuCores=os.cpu_count(),
                availableProviders=(["CUDA"] if gpus else ["CPU"]),
                host=dict(hostname=platform.node(), os=f"{platform.system()} {platform.release()}"),
                dataSource="optsd-demo (torch)")


def api_load_model(body):
    resolved = resolve(body.get("kind", "preset"), body.get("value", "tiny"))
    if not resolved.get("ok"):
        return dict(success=False, error=resolved.get("error", "resolve failed"))
    steps = int(body.get("steps", 12))
    _build_base(resolved, steps, int(body.get("n_probe", 8)))
    d = resolved["detected"]
    return dict(success=True, source=resolved["source"], proxy=resolved["proxy"],
                note=resolved["note"], detected=d,
                architecture=(f"{d.get('kind')} · runs as "
                              f"{_STATE['mcfg'].depth}-block {_STATE['resolved']['backbone']}"
                              + (" (proxy)" if resolved["proxy"] else "")))


def _interaction_pairs():
    from ..stack.interaction import interaction_matrix
    return interaction_matrix(_STATE["base"], _STATE["x_init"], _STATE["y"], _STATE["steps"],
                              knobs={"prune": 0.5, "quant": 4, "cache": 4},
                              objective=_STATE["objective"], data_iter=_STATE["data_iter"],
                              device=DEVICE, verbose=False)["pairs"]


def _cfg_to_techniques(knobs, regime):
    out = []
    if knobs.get("prune", 1.0) < 1.0: out.append(f"Pruning/LAAMP (keep {knobs['prune']})")
    if knobs.get("quant", 16) < 16: out.append(f"Quantization (W{knobs['quant']})")
    if knobs.get("cache", 1) > 1: out.append(f"Caching (interval {knobs['cache']})")
    if regime == "solver": out.append("RF-Solver (fewer steps)")
    if regime == "distilled": out.append("DMD2 few-step (cache off)")
    return out or ["none"]


def api_analyze(body):
    if _STATE["base"] is None:
        return dict(success=False, error="Load a model first.")
    steps = _STATE["steps"]
    target = float(body.get("target", 4.0))
    report = A.analyze_model(_STATE["base"], _STATE["x_init"], _STATE["y"], steps,
                             objective=_STATE["objective"], data_iter=_STATE["data_iter"],
                             device=DEVICE, verbose=False)
    _STATE["profile"] = report["profile"]
    pairs = _interaction_pairs()
    _STATE["interaction"] = pairs
    rec = A.recommend(report, steps, target)
    return dict(success=True, architecture=_STATE["resolved"]["source"],
                interaction=[dict(axisA=p["axisA"], axisB=p["axisB"], e_A=p["e_A"], e_B=p["e_B"],
                                  e_AB=p["e_AB"], delta=p["delta"], rho=p["rho"], verdict=p["verdict"])
                             for p in pairs],
                recommendation=dict(knobs=rec.knobs, rationale=rec.rationale,
                                    predicted_error=rec.predicted_error, achieved=rec.achieved_speedup),
                suggested=_cfg_to_techniques(rec.knobs, body.get("regime", "full")))


class _RecShim:
    def __init__(self, cfg): self.config = cfg


def _try_sample(model):
    """Return a latent x0 for the quality panel; None if sampling doesn't apply."""
    try:
        return flow_sample(model, _STATE["x_init"][:1], _STATE["y"][:1],
                           steps=_STATE["steps"])
    except Exception:
        return None


def api_optimize(body):
    if _STATE["base"] is None:
        return dict(success=False, error="Run Analyze first.")
    steps = _STATE["steps"]
    target = float(body.get("target", 4.0))
    k = body.get("knobs", {})
    regime = body.get("regime", "full")
    ci = 1 if regime == "distilled" else int(k.get("cache_interval", 1))  # §3b DisCa
    cfg = StackConfig(prune_keep=float(k.get("prune_keep", 1.0)),
                      quant_bits=int(k.get("quant_bits", 16)), cache_interval=ci,
                      dist_gpus=int(k.get("dist_gpus", 1)), regime=regime)

    base = _STATE["base"]
    before = lat_h.param_count(base, only_alive=False)
    result = A.apply(base, _RecShim(cfg), _STATE["objective"], _STATE["data_iter"], DEVICE)
    opt_model = result["model"]
    after = lat_h.param_count(opt_model, only_alive=True)

    # --- MEASURED latency + VRAM (real, on whatever device we're on) --------
    mcfg = _STATE["mcfg"]
    sf = _sample_fn(mcfg)
    measured = {}
    try:
        lb = lat_h.measure_latency(base, sf, DEVICE, warmup=2, iters=8)
        la = lat_h.measure_latency(opt_model, sf, DEVICE, warmup=2, iters=8)
        measured["ms_before"], measured["ms_after"] = lb["ms_mean"], la["ms_mean"]
        measured["latency_speedup"] = lb["ms_mean"] / max(la["ms_mean"], 1e-6)
        measured["vram_before_mb"] = lat_h.measure_peak_memory(base, sf, DEVICE)
        measured["vram_after_mb"] = lat_h.measure_peak_memory(opt_model, sf, DEVICE)
    except Exception as e:
        measured["error"] = str(e)

    # --- sample images (quality proxy) --------------------------------------
    images, quality = [], None
    x0_b, x0_a = _try_sample(base), _try_sample(opt_model)
    if x0_b is not None and x0_a is not None:
        imaging.render_latent_png(x0_b, str(OUT_DIR / "sample_before.png"))
        imaging.render_latent_png(x0_a, str(OUT_DIR / "sample_after.png"))
        quality = imaging.latent_delta(x0_b, x0_a)
        images = [("base", "sample_before.png"), ("optimized", "sample_after.png")]

    # --- export: optimized model + report ----------------------------------
    torch.save({"state_dict": opt_model.state_dict(), "config": vars(cfg),
                "cache_interval": result["cache_policy"].interval},
               OUT_DIR / "optimized_model.pt")
    achieved = config_speedup(cfg, steps)
    report_ext.render(
        str(OUT_DIR / "report.html"),
        model_name=_STATE["resolved"]["source"], source=_STATE["resolved"]["source"],
        detected=_STATE["resolved"]["detected"], proxy=_STATE["resolved"]["proxy"],
        target=target, achieved_proxy=achieved,
        interaction_pairs=_STATE["interaction"] or [],
        recommendation=dict(knobs=dict(prune=cfg.prune_keep, quant=cfg.quant_bits,
                                        cache=cfg.cache_interval),
                            rationale=[f"Applied config at ~{achieved:.1f}× (FLOPs proxy)."],
                            predicted_error=0.0),
        before={"params": before}, after={"params": after},
        images=images, measured=measured, quality=quality)

    return dict(success=True,
                files=dict(optimizedModel=dict(name="optimized_model.pt",
                                               path=str(OUT_DIR / "optimized_model.pt")),
                           report=dict(name="report.html", path=str(OUT_DIR / "report.html"),
                                       url="/results/tool_web/report.html"),
                           folder=str(OUT_DIR)),
                images=[dict(label=c, url=f"/results/tool_web/{s}") for c, s in images],
                quality=quality, measured=measured,
                metadata=dict(before_params=before, after_params=after,
                              achieved_speedup=round(achieved, 2),
                              device=DEVICE))


# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, payload, ctype="application/json"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload, default=float).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/api/device-resources"):
            return self._send(200, api_device_resources())
        rel = self.path.split("?")[0].lstrip("/") or "index.html"
        root = BASE_DIR if rel.startswith("results/") else UI_DIR
        fp = (root / rel).resolve()
        if str(fp).startswith(str(root)) and fp.is_file():
            ctype = {"html": "text/html", "css": "text/css", "js": "application/javascript",
                     "json": "application/json", "png": "image/png"}.get(fp.suffix[1:], "text/plain")
            return self._send(200, fp.read_bytes(), f"{ctype}; charset=utf-8")
        return self._send(404, {"error": "not found", "path": rel})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        try:
            if self.path.startswith("/api/load-model"):
                return self._send(200, api_load_model(body))
            if self.path.startswith("/api/analyze"):
                return self._send(200, api_analyze(body))
            if self.path.startswith("/api/optimize"):
                return self._send(200, api_optimize(body))
        except Exception as e:
            import traceback; traceback.print_exc()
            return self._send(200, {"success": False, "error": str(e)})
        return self._send(404, {"error": "not found"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=7860)
    ap.add_argument("--open", action="store_true")
    args = ap.parse_args()
    srv = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    url = f"http://127.0.0.1:{args.port}/index.html"
    print(f"OPTSD demo app at {url}  (device={DEVICE}) — Ctrl+C to stop")
    if args.open:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()
