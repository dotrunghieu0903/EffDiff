# Official baseline wrappers

Scripts that run the **original authors' repos** to obtain their **published**
numbers on our setup — for the *absolute* head-to-head. These are distinct from
our in-code reproductions (which give the *controlled* comparison that isolates
one variable at iso-FLOPs / shared recovery).

| Script | Repo | Gives | Our controlled counterpart |
|---|---|---|---|
| `run_tinyfusion.sh` | [VainF/TinyFusion](https://github.com/VainF/TinyFusion) | TinyFusion FID on DiT-XL/2→D14 (pub. 2.86) | method `tinyfusion` in `run_pipeline`/`run_contrib1` |

## Why two comparisons

- **Controlled (in-code):** `tinyfusion` = LAAMP machinery + coupled constraint.
  Same search/LoRA/recovery/iso-FLOPs as LAAMP, so a FID gap is attributable to
  *asymmetry alone* (RQ0a). Best for the scientific claim.
- **Absolute (this folder):** the authors' own pipeline + their Masked-KD recipe
  + ADM evaluator. Best for the headline "LAAMP X vs TinyFusion 2.86" claim.
  Report LAAMP through the SAME ADM evaluator (`eval_fid --mode adm-npz`) so both
  use `VIRTUAL_imagenet256_labeled.npz`.

## Run (GPU only)

```bash
# fast: released TinyDiT-D14 checkpoint -> sample + FID (no 100-epoch retrain)
GPUS=2 IMAGENET_TRAIN=/data/imagenet/train \
  bash experiments/baselines_official/run_tinyfusion.sh released

# full reproduce: extract features -> learned prune -> 100-epoch Masked-KD -> FID
GPUS=8 bash experiments/baselines_official/run_tinyfusion.sh reproduce
```

⚠️ **Not runnable/verifiable on the CPU dev box.** Commands mirror the repo README
(verified 2026-07-24). Before a real run, re-check script/flag names against the
freshly cloned repo — upstream may rename things. The full-reproduce path is
expensive (100 epochs on ImageNet); prefer `released` unless you must reproduce
the pruning itself.
