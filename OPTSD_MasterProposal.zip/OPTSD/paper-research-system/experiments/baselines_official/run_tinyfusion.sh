#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Official TinyFusion head-to-head wrapper (Contribution 1, absolute number).
#
# Runs the ORIGINAL VainF/TinyFusion repo to get TinyFusion's own FID on
# DiT-XL/2 -> TinyDiT-D14, so LAAMP can be compared to the published yardstick
# (FID 2.86 @ 14 layers). This is the "absolute" comparison; the CONTROLLED
# internal one (isolating asymmetry) is the `tinyfusion` method in our own code
# (experiments.run_pipeline / run_contrib1).
#
# GPU-ONLY. Cannot be tested on the CPU dev box -- verify paths against the freshly
# cloned repo before trusting a run. Commands mirror the repo README (verified
# 2026-07-24): extract_features.py / prune_by_learning.py / train_masked_kd.py /
# sample_ddp.py / evaluator.py.
#
# Usage:
#   bash run_tinyfusion.sh released   # FAST: use released TinyDiT-D14 ckpt -> sample+FID only
#   bash run_tinyfusion.sh reproduce  # FULL: prune + 100-epoch Masked-KD + sample+FID (expensive)
#
# Edit the vars below for your box.
# ---------------------------------------------------------------------------
set -euo pipefail

MODE="${1:-released}"                       # released | reproduce
GPUS="${GPUS:-8}"                            # match your node (e.g. 2 for 3090+4090)
IMAGENET_TRAIN="${IMAGENET_TRAIN:-data/imagenet/train}"   # ImageFolder root
WORK="${WORK:-experiments/results/tinyfusion_official}"
TF_DIR="${TF_DIR:-$WORK/TinyFusion}"        # where to clone the repo
REF_NPZ="${REF_NPZ:-data/VIRTUAL_imagenet256_labeled.npz}"  # ADM reference stats
NUM_SAMPLES="${NUM_SAMPLES:-50000}"

mkdir -p "$WORK"

# ---- 0. clone + install ---------------------------------------------------
if [ ! -d "$TF_DIR" ]; then
  echo "[tf] cloning VainF/TinyFusion -> $TF_DIR"
  git clone https://github.com/VainF/TinyFusion.git "$TF_DIR"
fi
cd "$TF_DIR"
pip install -r requirements.txt

# ---- 1. pretrained weights ------------------------------------------------
mkdir -p pretrained
[ -f pretrained/DiT-XL-2-256x256.pt ] || \
  wget -O pretrained/DiT-XL-2-256x256.pt \
    https://dl.fbaipublicfiles.com/DiT/models/DiT-XL-2-256x256.pt

# ---- ref stats reminder ---------------------------------------------------
if [ ! -f "$REF_NPZ" ]; then
  echo "[tf][WARN] ADM reference stats $REF_NPZ not found."
  echo "         Get VIRTUAL_imagenet256_labeled.npz from openai/guided-diffusion/evaluations"
fi

if [ "$MODE" = "released" ]; then
  # ---- FAST PATH: use the released Masked-KD checkpoint (skip 100-epoch train)
  echo "[tf] FAST path: released TinyDiT-D14-MaskedKD-500K"
  [ -f pretrained/TinyDiT-D14-MaskedKD-500K.pt ] || \
    wget -O pretrained/TinyDiT-D14-MaskedKD-500K.pt \
      https://github.com/VainF/TinyFusion/releases/download/v1.0.0/TinyDiT-D14-MaskedKD-500K.pt
  CKPT="pretrained/TinyDiT-D14-MaskedKD-500K.pt"

else
  # ---- FULL REPRODUCE: features -> learned prune -> masked-KD finetune ------
  echo "[tf] FULL reproduce path (expensive: feature extract + prune + 100ep KD)"
  torchrun --nnodes=1 --nproc_per_node="$GPUS" extract_features.py \
    --model DiT-XL/2 --data-path "$IMAGENET_TRAIN" --features-path data/imagenet_encoded

  torchrun --nnodes=1 --nproc_per_node="$GPUS" prune_by_learning.py \
    --model DiT-XL-1-2 --load-weight pretrained/DiT-XL-2-256x256.pt \
    --data-path data/imagenet_encoded --epochs 1 --global-batch-size 128 \
    --delta-w --lora --save-model outputs/pruned/DiT-D14-Learned.pt

  torchrun --nnodes=1 --nproc_per_node="$GPUS" train_masked_kd.py \
    --model DiT-D14/2 --load-weight outputs/pruned/DiT-D14-Learned.pt \
    --data-path data/imagenet_encoded --epochs 100 \
    --prefix D14-Learned-RepKD --teacher DiT-XL/2 \
    --load-teacher pretrained/DiT-XL-2-256x256.pt
  # NOTE: verify the produced checkpoint path in outputs/ (repo names it by prefix/steps)
  CKPT="$(ls -t outputs/*D14*Learned*/checkpoints/*.pt 2>/dev/null | head -1)"
  echo "[tf] finetuned checkpoint: $CKPT"
fi

# ---- 2. sample 50k + FID via ADM evaluator --------------------------------
echo "[tf] sampling $NUM_SAMPLES images from $CKPT"
torchrun --nnodes=1 --nproc_per_node="$GPUS" sample_ddp.py \
  --model DiT-D14/2 --ckpt "$CKPT" --num-fid-samples "$NUM_SAMPLES"
# sample_ddp.py writes an .npz of samples; grab the newest one:
SAMPLE_NPZ="$(ls -t samples/*.npz 2>/dev/null | head -1)"
echo "[tf] samples: $SAMPLE_NPZ"

echo "[tf] computing FID vs $REF_NPZ"
python evaluator.py "$REF_NPZ" "$SAMPLE_NPZ" | tee "$OLDPWD/$WORK/tinyfusion_fid.txt"

echo "[tf] DONE. FID written to $WORK/tinyfusion_fid.txt"
echo "[tf] For apples-to-apples: run LAAMP through the SAME evaluator via"
echo "     experiments.eval_fid --mode adm-npz (GPU_RUNBOOK step 6b), same $REF_NPZ."
