"""End-to-end error of an accelerated config vs the un-accelerated reference.

error(config) = distance( sample(prune∘quant model, cache sampler),  x_ref )

where x_ref is the full-precision, full-step, un-pruned model's sample from the
SAME initial noise (so the difference is purely approximation error, not sampling
variance). This single scalar is what interaction.py and orchestrator.py optimise
against. On the real GPU run, swap `sample_distance` for LPIPS/FID vs the base
model's images (harness/metrics.py) -- the interfaces are identical.
"""
from __future__ import annotations

import torch

from .axes import StackConfig, build_accelerated_model, cache_policy, dist_speedup
from .regime import regime_plan
from .sampler import flow_sample, CachePolicy


@torch.no_grad()
def normalized_rmse(a, b):
    return float((a - b).pow(2).mean().sqrt() / (b.pow(2).mean().sqrt() + 1e-8))


# The error DISTANCE is configurable process-wide (one choke point: evaluate_config
# uses this unless a call passes its own). Default = latent RMSE (CPU, no VAE).
# On GPU, set_distance(build_distance("lpips"/"psnr", vae)) to measure perceptual
# degradation on DECODED images vs the un-accelerated reference.
_ACTIVE_DISTANCE = normalized_rmse


def set_distance(fn):
    global _ACTIVE_DISTANCE
    _ACTIVE_DISTANCE = fn or normalized_rmse


def build_distance(name, vae=None, device="cpu"):
    """name: 'rmse' (latent, default) | 'lpips' | 'psnr' (decoded image vs ref).
    lpips/psnr need a VAE to decode latents -> images (GPU/real substrate)."""
    if name in (None, "rmse"):
        return normalized_rmse
    assert vae is not None, f"metric '{name}' needs a VAE to decode latents (GPU/real run)"

    def _decode(x):
        img = vae.decode(x.to(device) / 0.18215).sample     # [-1,1]-ish
        return img.clamp(-1, 1)

    if name == "psnr":
        import math
        @torch.no_grad()
        def dist(x_hat, x_ref):
            mse = (_decode(x_hat) - _decode(x_ref)).pow(2).mean().item()
            psnr = -10.0 * math.log10(mse + 1e-12)   # higher = better
            return -psnr                              # return error (lower = better)
        return dist

    if name == "lpips":
        import lpips as _lp
        net = _lp.LPIPS(net="alex").to(device)
        @torch.no_grad()
        def dist(x_hat, x_ref):
            return float(net(_decode(x_hat), _decode(x_ref)).mean())
        return dist

    raise ValueError(f"unknown metric {name}")


@torch.no_grad()
def reference_sample(base_model, x_init, y, steps):
    return flow_sample(base_model, x_init, y, steps=steps, cache=None)


@torch.no_grad()
def evaluate_config(base_model, cfg: StackConfig, x_init, y, x_ref, steps,
                    objective=None, data_iter=None, device="cpu",
                    distance=None):
    """Return dict(error, speedup, ...). `steps` is the FULL reference resolution;
    the regime may sample at fewer steps (that reduction is part of the error).
    `distance` defaults to the process-wide active metric (set_distance)."""
    distance = distance or _ACTIVE_DISTANCE
    model, sp_model = build_accelerated_model(base_model, cfg, objective, data_iter, device)
    steps_cfg, sp_regime, cache_ok = regime_plan(cfg.regime, steps)
    pol = cache_policy(cfg) if cache_ok else CachePolicy(enabled=False)  # distilled: no cache
    x_hat = flow_sample(model, x_init, y, steps=steps_cfg, cache=pol)
    err = distance(x_hat, x_ref)
    sp_sampler = pol.speedup(steps_cfg)
    sp_dist = dist_speedup(cfg.dist_gpus)
    return dict(error=err, speedup=sp_model * sp_sampler * sp_regime * sp_dist,
                model_speedup=sp_model, sampler_speedup=sp_sampler, regime_speedup=sp_regime,
                dist_speedup=sp_dist, axes_on=cfg.axes_on())
