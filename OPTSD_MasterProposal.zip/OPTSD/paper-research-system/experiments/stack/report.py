"""Self-contained HTML optimization report (no external deps).

Renders the analyze->recommend->apply result as a single standalone .html file
(inline CSS, no JS/CDN) suitable as a thesis demo artifact. Kept dependency-free
on purpose so it works anywhere the tool runs.
"""
from __future__ import annotations

import html
import json
from datetime import datetime


_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#0f1420;color:#e6e9ef}
.wrap{max-width:900px;margin:0 auto;padding:32px}
h1{font-size:22px;margin:0 0 4px}.sub{color:#8b95a7;font-size:13px;margin-bottom:24px}
.card{background:#171d2b;border:1px solid #232b3d;border-radius:12px;padding:20px;margin:16px 0}
.card h2{font-size:15px;margin:0 0 12px;color:#9fb4ff;text-transform:uppercase;letter-spacing:.05em}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #232b3d}
th{color:#8b95a7;font-weight:600}
.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
.orthogonal{background:#123524;color:#4ade80}.compounding{background:#3a1520;color:#f87171}
.sub-additive{background:#1a2740;color:#60a5fa}
.big{font-size:28px;font-weight:700;color:#fff}.unit{font-size:14px;color:#8b95a7}
.grid{display:flex;gap:16px}.grid>div{flex:1}
.rat{margin:6px 0;padding-left:14px;border-left:3px solid #2f3b55;color:#c7cfdd;font-size:13px}
code{background:#0f1420;padding:2px 6px;border-radius:6px;color:#9fb4ff;font-size:12px}
"""


def _verdict_pill(v):
    return f'<span class="pill {v}">{v}</span>'


def render_html(model_name, target, achieved, interaction_pairs, recommendation,
                before, after, path):
    rows = ""
    for p in interaction_pairs:
        rows += (f"<tr><td>{p['axisA']} × {p['axisB']}</td><td>{p['e_A']:.4f}</td>"
                 f"<td>{p['e_B']:.4f}</td><td>{p['e_AB']:.4f}</td>"
                 f"<td>{p['delta']:+.4f}</td><td>{p['rho']:+.2f}</td>"
                 f"<td>{_verdict_pill(p['verdict'])}</td></tr>")
    rats = "".join(f'<div class="rat">{html.escape(r)}</div>' for r in recommendation["rationale"])
    knobs = html.escape(json.dumps(recommendation["knobs"]))

    doc = f"""<!doctype html><html><head><meta charset="utf-8">
<title>Optimization report — {html.escape(model_name)}</title><style>{_CSS}</style></head>
<body><div class="wrap">
<h1>Error-Aware Optimization Report</h1>
<div class="sub">model: <b>{html.escape(model_name)}</b> · generated {datetime.now():%Y-%m-%d %H:%M} ·
target {target:.1f}× · achieved {achieved:.1f}×</div>

<div class="card"><h2>Recommendation</h2>
<div>Selected config: <code>{knobs}</code></div>
{rats}
</div>

<div class="card"><h2>Before → After</h2><div class="grid">
<div><div class="unit">params (alive)</div><div class="big">{after['params']:,}</div>
<div class="unit">was {before['params']:,}</div></div>
<div><div class="unit">predicted speedup</div><div class="big">{achieved:.1f}×</div></div>
<div><div class="unit">predicted error</div><div class="big">{recommendation['predicted_error']:.4f}</div>
<div class="unit">vs un-accelerated</div></div>
</div></div>

<div class="card"><h2>Error-interaction map</h2>
<table><tr><th>pair</th><th>e_A</th><th>e_B</th><th>e_AB</th><th>Δ</th><th>ρ</th><th>verdict</th></tr>
{rows}</table>
<div class="sub" style="margin-top:12px">ρ = Δ/(e_A+e_B). &gt;0 compounding (conflict) ·
≈0 orthogonal (safe to stack) · &lt;0 sub-additive. The recommendation is derived
from this measured map, not a fixed rule.</div>
</div>

</div></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
    return path
