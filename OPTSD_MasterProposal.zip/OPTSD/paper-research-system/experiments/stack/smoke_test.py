"""CPU smoke test for the error-aware stack (Contribution 2). No GPU/downloads.

Verifies: forecast-cache sampler, per-axis error, pairwise interaction matrix,
error-aware vs naive orchestrator, and analyze->recommend->apply. Run:
    python -m experiments.stack.smoke_test
"""
from __future__ import annotations

import torch

from ..laamp import DiTConfig, build_model, build_objective
from ..data import synthetic_iter
from .axes import StackConfig
from .errormodel import evaluate_config, reference_sample
from . import interaction as I, orchestrator as O, analyze as A

torch.manual_seed(0)
DEV = "cpu"


def banner(s): print("\n" + "=" * 56 + f"\n{s}\n" + "=" * 56)


def main():
    mcfg = DiTConfig.tiny()
    obj = build_objective("flow", DEV)
    it = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                        num_classes=mcfg.num_classes, device=DEV)
    model = build_model(mcfg).to(DEV)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3); model.train()
    for _ in range(300):
        loss = obj.loss(model, *next(it)); opt.zero_grad(); loss.backward(); opt.step()

    steps = 20
    x_init = torch.randn(16, mcfg.in_channels, mcfg.input_size, mcfg.input_size)
    y = torch.randint(0, mcfg.num_classes, (16,))
    x_ref = reference_sample(model, x_init, y, steps)

    banner("1. single-axis errors (each approximation vs reference)")
    for name, c in [("prune .5", StackConfig(prune_keep=0.5)),
                    ("quant 4b", StackConfig(quant_bits=4)),
                    ("cache i4", StackConfig(cache_interval=4))]:
        r = evaluate_config(model, c, x_init, y, x_ref, steps, obj, it, DEV)
        print(f"  {name}: error={r['error']:.4f} speedup={r['speedup']:.2f}x axes={r['axes_on']}")

    banner("2. error-interaction matrix (PROPOSAL 3c)")
    mat = I.interaction_matrix(model, x_init, y, steps, objective=obj, data_iter=it, device=DEV)

    banner("3. orchestrator: error-aware vs naive")
    prof = O.profile(model, x_init, y, steps, objective=obj, data_iter=it, device=DEV, verbose=False)
    for target in (2.0, 4.0):
        cmp = O.compare_planners(model, prof, x_init, y, steps, target, obj, it, DEV)
        na, ea = cmp.get("naive", {}), cmp.get("error_aware", {})
        if na.get("feasible") and ea.get("feasible"):
            print(f"  target {target}x: naive err={na['measured_error']:.4f} {na['axes_on']} | "
                  f"aware err={ea['measured_error']:.4f} {ea['axes_on']} | "
                  f"aware better by {cmp.get('error_aware_better_by',0):+.4f}")

    banner("4. analyze -> recommend -> apply (tool brain)")
    report = {"profile": prof, "efficiency": A.efficiency_from_profile(prof)}
    rec = A.recommend(report, steps, target_speedup=4.0)
    for line in rec.rationale:
        print("  " + line)
    opt_out = A.apply(model, rec, obj, it, DEV)
    print(f"  applied -> optimized model speedup {opt_out['model_speedup']:.2f}x, "
          f"cache {opt_out['cache_policy'].interval}")

    banner("STACK SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
