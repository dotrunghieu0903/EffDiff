"""Step-count REGIME (the contested axis: Solvers / Distillation).

Extracted from axes.py so the four ORTHOGONAL stackable axes stay isolated from
this mutually-exclusive MODE. A regime replaces/reduces the sampling steps; it is
NOT stacked with the other regimes, and 'distilled' is incompatible with caching
(PROPOSAL §3b / DisCa).

  full      : full sampler steps (regime off)
  solver    : fewer ODE steps, higher-order integrator (real: RF-Solver)     -> adapters/rf_solver
  distilled : few-step model (real: DMD2/Phased-DMD); cache disabled          -> adapters/dmd2

`StackConfig.regime` (the field) stays in axes.py; this module holds the logic.
"""
from __future__ import annotations


def regime_plan(regime: str, base_steps: int):
    """Return (sampler_steps, extra_speedup, cache_allowed) for a regime."""
    if regime == "full":
        return base_steps, 1.0, True
    if regime == "solver":                       # fewer ODE steps, better integrator
        s = max(2, base_steps // 2)
        return s, base_steps / s, True
    if regime == "distilled":                    # few-step model; caching pointless/harmful
        s = max(1, min(4, base_steps))
        return s, base_steps / s, False
    raise ValueError(f"unknown regime {regime}")
