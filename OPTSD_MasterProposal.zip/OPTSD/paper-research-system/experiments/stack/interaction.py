"""Error-interaction harness -- the scientific core of Contribution 2 (PROPOSAL 3c).

For a pair of axes (A, B) at fixed knobs we measure:
    e_A   = error of A alone
    e_B   = error of B alone
    e_AB  = error of A and B together
    delta = e_AB - (e_A + e_B)          # excess error beyond additive

    delta ~ 0   -> ORTHOGONAL  (errors add; safe to stack, the >10x hope)
    delta > 0   -> COMPOUNDING (conflict; naive stacking loses more than the sum)
    delta < 0   -> SUB-ADDITIVE (errors partially cancel)

We also report a normalised coefficient rho = delta / (e_A + e_B + eps) so pairs
with different magnitudes are comparable. The full L x L matrix is the "map of
which axes compose" that the proposal promises, and the input the orchestrator
uses instead of assuming additivity.
"""
from __future__ import annotations

import itertools

import torch

from .axes import StackConfig, AXIS_OFF
from .errormodel import evaluate_config, reference_sample


def _cfg_with(**knobs) -> StackConfig:
    """Build a StackConfig with only the named axes set, rest OFF."""
    c = StackConfig()
    if "prune" in knobs: c.prune_keep = knobs["prune"]
    if "quant" in knobs: c.quant_bits = knobs["quant"]
    if "cache" in knobs: c.cache_interval = knobs["cache"]
    return c


def measure_pair(base_model, axisA, knobA, axisB, knobB, x_init, y, x_ref, steps,
                 objective=None, data_iter=None, device="cpu"):
    eA = evaluate_config(base_model, _cfg_with(**{axisA: knobA}), x_init, y, x_ref,
                         steps, objective, data_iter, device)
    eB = evaluate_config(base_model, _cfg_with(**{axisB: knobB}), x_init, y, x_ref,
                         steps, objective, data_iter, device)
    eAB = evaluate_config(base_model, _cfg_with(**{axisA: knobA, axisB: knobB}),
                          x_init, y, x_ref, steps, objective, data_iter, device)
    delta = eAB["error"] - (eA["error"] + eB["error"])
    rho = delta / (eA["error"] + eB["error"] + 1e-8)
    return dict(axisA=axisA, knobA=knobA, axisB=axisB, knobB=knobB,
                e_A=eA["error"], e_B=eB["error"], e_AB=eAB["error"],
                delta=delta, rho=rho, speedup_AB=eAB["speedup"],
                verdict=("compounding" if rho > 0.15 else
                         "sub-additive" if rho < -0.15 else "orthogonal"))


def interaction_matrix(base_model, x_init, y, steps, knobs=None, axes=("prune", "quant", "cache"),
                       objective=None, data_iter=None, device="cpu", verbose=True):
    """Measure delta/rho for every axis pair at a representative knob each."""
    knobs = knobs or {"prune": 0.5, "quant": 4, "cache": 4}
    x_ref = reference_sample(base_model, x_init, y, steps)
    rows = []
    for axisA, axisB in itertools.combinations(axes, 2):
        r = measure_pair(base_model, axisA, knobs[axisA], axisB, knobs[axisB],
                         x_init, y, x_ref, steps, objective, data_iter, device)
        rows.append(r)
        if verbose:
            print(f"[interaction] {axisA:5s}x{axisB:5s}: e_A={r['e_A']:.4f} e_B={r['e_B']:.4f} "
                  f"e_AB={r['e_AB']:.4f} delta={r['delta']:+.4f} rho={r['rho']:+.2f} "
                  f"-> {r['verdict']}")
    return dict(knobs=knobs, pairs=rows,
                singles=single_axis_errors(base_model, x_init, y, x_ref, steps, knobs,
                                           axes, objective, data_iter, device))


def single_axis_errors(base_model, x_init, y, x_ref, steps, knobs, axes,
                       objective, data_iter, device):
    out = {}
    for a in axes:
        r = evaluate_config(base_model, _cfg_with(**{a: knobs[a]}), x_init, y, x_ref,
                            steps, objective, data_iter, device)
        out[a] = dict(error=r["error"], speedup=r["speedup"])
    return out
