"""Substrate / backbone selection for the stack (Arch group, e.g. SANA).

Kept in the STACK package, not in laamp: the backbone is a stack-level substrate
choice, and the LAAMP algorithm package must stay pure (it only knows its own
`DiTConfig.tiny()` / `dit_xl_2()` presets). SANA is a *substrate*, not a toggle —
changing it shrinks every axis's ROI (PROPOSAL §3d). Real SANA -> adapters/sana.

  build_backbone(name) -> (DiTConfig, objective_name)
"""
from __future__ import annotations

from ..laamp.dit import DiTConfig


def build_backbone(name: str):
    if name == "tiny":
        return DiTConfig.tiny(), "flow"
    if name == "sana":
        # SANA-like demo: FEWER tokens (larger patch -> grid 2x2 = 4 tokens vs
        # tiny's 16), reflecting §3d "fewer tokens shrink every axis's ROI".
        return DiTConfig(input_size=8, patch_size=4, in_channels=4, hidden_size=64,
                         depth=6, num_heads=4, num_classes=4, learn_sigma=False), "flow"
    if name == "dit_xl":
        return DiTConfig.dit_xl_2(), "ddpm"
    raise ValueError(f"unknown backbone {name}")


BACKBONES = ("tiny", "sana", "dit_xl")
