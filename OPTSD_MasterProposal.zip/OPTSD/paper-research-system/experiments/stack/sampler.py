"""Flow-matching sampler with forecast caching (Contribution 2, axis #3).

This is the *temporal* axis: instead of calling the model at every sampling step,
a TaylorSeer-style cache computes the model output only every `interval` steps and
FORECASTS it (Taylor/finite-difference extrapolation) in between. The forecast is
accurate only while the output trajectory over time is smooth -- which is exactly
the assumption pruning and quantization can break (PROPOSAL 3c), so caching error
INTERACTS with the other axes. That interaction is what interaction.py measures.

Kept separate from experiments/sampling.py (which is the DiT-XL DDIM sampler for
Contribution 1's FID): this one is the composable, instrumented axis.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class CachePolicy:
    interval: int = 1          # compute the model every `interval` steps; forecast the rest
    order: int = 1             # forecast order: 0 hold-last, 1 linear, 2 quadratic
    enabled: bool = True

    def speedup(self, total_steps: int) -> float:
        if not self.enabled or self.interval <= 1:
            return 1.0
        computed = len(range(0, total_steps, self.interval))
        return total_steps / max(computed, 1)


def _forecast(history_t, history_v, t_query, order):
    """Extrapolate v at t_query from the last (order+1) computed (t, v) pairs."""
    k = min(order + 1, len(history_v))
    ts = history_t[-k:]
    vs = history_v[-k:]
    if k == 1:
        return vs[-1]
    if k == 2:                                  # linear
        (t0, v0), (t1, v1) = (ts[0], vs[0]), (ts[1], vs[1])
        w = (t_query - t0) / (t1 - t0 + 1e-8)
        return v0 + w * (v1 - v0)
    # k == 3: quadratic Lagrange
    (t0, t1, t2) = ts
    (v0, v1, v2) = vs
    def L(a, b, c):
        return (t_query - b) * (t_query - c) / ((a - b) * (a - c) + 1e-8)
    return L(t0, t1, t2) * v0 + L(t1, t0, t2) * v1 + L(t2, t0, t1) * v2


@torch.no_grad()
def flow_sample(model, x_init, y, steps=50, cache: CachePolicy | None = None,
                record=False):
    """Euler-integrate the flow ODE from t=1 (noise=x_init) to t=0 (data).

    Returns x0 (B,C,H,W). If cache is given, model calls at non-anchor steps are
    replaced by a forecast. `record` also returns per-step (was_computed) flags.
    """
    model.eval()
    B = x_init.shape[0]
    device = x_init.device
    ts = torch.linspace(1.0, 0.0, steps + 1, device=device)
    x = x_init.clone()
    hist_t, hist_v, computed_flags = [], [], []
    cache = cache or CachePolicy(interval=1, enabled=False)

    for i in range(steps):
        t = ts[i]
        dt = ts[i] - ts[i + 1]                  # positive
        anchor = (not cache.enabled) or (i % max(cache.interval, 1) == 0) or (len(hist_v) == 0)
        if anchor:
            tb = torch.full((B,), float(t) * 999.0, device=device)
            out = model(x, tb, y)
            v = out[:, : x.shape[1]]            # velocity = eps - x0 in our FlowMatching
            hist_t.append(float(t)); hist_v.append(v)
            computed_flags.append(True)
        else:
            v = _forecast(hist_t, hist_v, float(t), cache.order)
            computed_flags.append(False)
        x = x - dt * v                          # Euler step toward data
    if record:
        return x, computed_flags
    return x
