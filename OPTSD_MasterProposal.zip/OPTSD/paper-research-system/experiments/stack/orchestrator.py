"""Error-aware orchestrator (Contribution 2 "brain") vs naive sequential stacking.

Profiling gives a second-order error model:
    e_pred(config) = sum_axis  e_single[axis, knob]        (additive term)
                   + sum_pairs delta[pair, knobs]          (interaction term)

Two planners choose a config that meets a target speedup over the knob grid:
  * naive   : uses ONLY the additive term (assumes axes are orthogonal) -> the
              "ghep tuan tu ngay tho" the proposal warns about.
  * error_aware : uses additive + interaction terms, and may DROP an axis whose
              interaction makes it not worth it (Framing B selection).

We then MEASURE both chosen configs. H1 is supported when error_aware achieves
lower measured error at equal-or-higher speedup than naive.
"""
from __future__ import annotations

import itertools

import torch

from .axes import StackConfig, KNOB_GRID, cache_policy, dist_speedup
from .axes import apply_prune, apply_quant  # noqa: F401 (documented axes)
from .errormodel import evaluate_config, reference_sample
from .interaction import _cfg_with, measure_pair


# ---------------------------------------------------------------------------
# profiling: singles at each knob + pairwise deltas at each knob combo
# ---------------------------------------------------------------------------
def profile(base_model, x_init, y, steps, axes=("prune", "quant", "cache"),
            objective=None, data_iter=None, device="cpu", verbose=True):
    x_ref = reference_sample(base_model, x_init, y, steps)
    singles = {a: {} for a in axes}
    for a in axes:
        for k in KNOB_GRID[a]:
            r = evaluate_config(base_model, _cfg_with(**{a: k}), x_init, y, x_ref,
                                steps, objective, data_iter, device)
            singles[a][k] = dict(error=r["error"], speedup=r["speedup"])
    deltas = {}
    for a, b in itertools.combinations(axes, 2):
        for ka in KNOB_GRID[a]:
            for kb in KNOB_GRID[b]:
                if ka == _off(a) or kb == _off(b):
                    deltas[(a, ka, b, kb)] = 0.0
                    continue
                r = measure_pair(base_model, a, ka, b, kb, x_init, y, x_ref, steps,
                                 objective, data_iter, device)
                deltas[(a, ka, b, kb)] = r["delta"]
    if verbose:
        print(f"[profile] {sum(len(v) for v in singles.values())} singles, {len(deltas)} pair-cells")
    return dict(x_ref=x_ref, singles=singles, deltas=deltas, axes=axes)


def _off(axis):
    from .axes import AXIS_OFF
    return AXIS_OFF[axis]


def config_speedup(cfg: StackConfig, steps: int) -> float:
    from .regime import regime_plan
    sp = 1.0
    if cfg.prune_keep < 1.0: sp *= 1.0 / cfg.prune_keep
    if cfg.quant_bits < 16: sp *= 16.0 / cfg.quant_bits
    steps_cfg, sp_regime, cache_ok = regime_plan(cfg.regime, steps)
    if cache_ok:
        sp *= cache_policy(cfg).speedup(steps_cfg)
    sp *= sp_regime
    sp *= dist_speedup(cfg.dist_gpus)
    return sp


def _enumerate(axes):
    grids = [KNOB_GRID[a] for a in axes]
    for combo in itertools.product(*grids):
        yield dict(zip(axes, combo))


def _to_cfg(knobs) -> StackConfig:
    return _cfg_with(**{a: k for a, k in knobs.items() if k != _off(a)})


def predict_error(prof, knobs, use_interactions: bool) -> float:
    axes = prof["axes"]
    e = 0.0
    for a, k in knobs.items():
        if k != _off(a):
            e += prof["singles"][a][k]["error"]
    if use_interactions:
        for a, b in itertools.combinations(axes, 2):
            ka, kb = knobs[a], knobs[b]
            if ka != _off(a) and kb != _off(b):
                e += prof["deltas"].get((a, ka, b, kb), 0.0)
    return e


def plan(prof, steps, target_speedup, use_interactions):
    best, best_e = None, float("inf")
    for knobs in _enumerate(prof["axes"]):
        cfg = _to_cfg(knobs)
        if config_speedup(cfg, steps) < target_speedup:
            continue
        e = predict_error(prof, knobs, use_interactions)
        if e < best_e:
            best_e, best = e, knobs
    return best, best_e


# ---------------------------------------------------------------------------
# §5.2 orchestrator MECHANISMS (error-aware coordination, not just selection).
# These use the MEASURED interaction map to coordinate axes that a naive stack
# would let compound. Light stand-ins for the real proposal mechanisms.
# ---------------------------------------------------------------------------
def shared_anchor_schedule(steps: int, interval: int):
    """(§5.2 iii) The single anchor-step schedule that caching (and, on multi-GPU,
    DistriFusion's displaced reuse) share, so both 'borrow' features at the SAME
    steps instead of fighting. Returns the anchor step indices."""
    if interval <= 1:
        return list(range(steps))
    return list(range(0, steps, interval))


def _pair_rho(prof, a, ka, b, kb):
    d = prof["deltas"].get((a, ka, b, kb), prof["deltas"].get((b, kb, a, ka), 0.0))
    eA = prof["singles"][a].get(ka, {}).get("error", 0.0)
    eB = prof["singles"][b].get(kb, {}).get("error", 0.0)
    return d / (eA + eB + 1e-8)


def _less_aggressive(axis, knob):
    grid = KNOB_GRID[axis]                       # ordered off -> aggressive
    i = grid.index(knob)
    return grid[max(0, i - 1)]


def coordinate(knobs, prof, rho_conflict=0.15):
    """(§5.2 i+ii) Back off the compounding axis using the measured map:
      (i)  adaptive cache: if quant×cache compounds, lower the cache interval
           (noisy quant features -> forecast less aggressively, RQ1).
      (ii) cache-aware pruning: if prune×cache compounds, prune LESS (keep the
           feature trajectory smooth enough to stay forecastable, RQ2).
    Returns (adjusted_knobs, notes)."""
    k = dict(knobs)
    notes = []
    on = lambda a: k.get(a, _off(a)) != _off(a)
    if on("quant") and on("cache") and _pair_rho(prof, "quant", k["quant"], "cache", k["cache"]) > rho_conflict:
        new = _less_aggressive("cache", k["cache"])
        if new != k["cache"]:
            notes.append(f"adaptive-cache: quant×cache compounds → cache {k['cache']}→{new} (RQ1)")
            k["cache"] = new
    if on("prune") and on("cache") and _pair_rho(prof, "prune", k["prune"], "cache", k["cache"]) > rho_conflict:
        new = _less_aggressive("prune", k["prune"])
        if new != k["prune"]:
            notes.append(f"cache-aware-prune: prune×cache compounds → keep {k['prune']}→{new} (RQ2)")
            k["prune"] = new
    return k, notes


def compare_planners(base_model, prof, x_init, y, steps, target_speedup,
                     objective=None, data_iter=None, device="cpu"):
    x_ref = prof["x_ref"]
    out = {}

    def _measure(knobs, pred=None, notes=None):
        cfg = _to_cfg(knobs)
        m = evaluate_config(base_model, cfg, x_init, y, x_ref, steps,
                            objective, data_iter, device)
        return dict(feasible=True, knobs=knobs, predicted_error=pred,
                    measured_error=m["error"], speedup=m["speedup"],
                    axes_on=m["axes_on"], notes=notes or [])

    for name, use_int in (("naive", False), ("error_aware", True)):
        knobs, pred = plan(prof, steps, target_speedup, use_int)
        out[name] = dict(feasible=False) if knobs is None else _measure(knobs, pred)

    # §5.2 coordinated: start from the naive pick, then apply the coordination
    # mechanisms (adaptive-cache + cache-aware-prune). Demonstrates that error-aware
    # coordination beats naive stacking at (near-)equal speedup (H1).
    if out["naive"].get("feasible"):
        ck, notes = coordinate(out["naive"]["knobs"], prof)
        anchors = shared_anchor_schedule(steps, ck.get("cache", 1))
        notes.append(f"shared anchor-steps: {anchors[:6]}{'…' if len(anchors) > 6 else ''} (§5.2 iii)")
        out["coordinated"] = _measure(ck, notes=notes)

    if out["naive"].get("feasible") and out.get("error_aware", {}).get("feasible"):
        out["error_aware_better_by"] = out["naive"]["measured_error"] - out["error_aware"]["measured_error"]
    if out["naive"].get("feasible") and out.get("coordinated", {}).get("feasible"):
        out["coordinated_better_by"] = out["naive"]["measured_error"] - out["coordinated"]["measured_error"]
    return out
