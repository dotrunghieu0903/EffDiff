"""Contribution 2 -- Error-Aware Unified Acceleration Stack (the tool's brain).

SEPARATE from experiments/laamp (Contribution 1) to avoid confusion. This package
CONSUMES laamp as acceleration axis #1 (pruning) and reuses experiments/harness.

  sampler.py      : flow sampler with Taylor forecast caching (axis #3)
  axes.py         : the 4 axes as composable approximations + StackConfig
  errormodel.py   : end-to-end error of a config vs the un-accelerated reference
  interaction.py  : pairwise error-interaction matrix (PROPOSAL 3c) -- the science
  orchestrator.py : error-aware planner vs naive-sequential (H1)
  analyze.py      : analyze -> recommend -> apply (the product front-end)
"""
from .axes import StackConfig, KNOB_GRID, build_accelerated_model, cache_policy
from .sampler import CachePolicy, flow_sample
from .errormodel import (evaluate_config, reference_sample, normalized_rmse,
                         set_distance, build_distance)
from .regime import regime_plan
from .backbones import build_backbone, BACKBONES
from . import interaction, orchestrator, analyze

__all__ = [
    "StackConfig", "KNOB_GRID", "build_accelerated_model", "cache_policy",
    "CachePolicy", "flow_sample", "evaluate_config", "reference_sample",
    "normalized_rmse", "set_distance", "build_distance", "regime_plan",
    "build_backbone", "BACKBONES", "interaction", "orchestrator", "analyze",
]
