"""One-command runner for Contribution 2 (error-aware stack).

YAML-driven, same spirit as experiments/run_pipeline.py (Contribution 1) but for
the stack. Stages:
    base -> interaction_matrix -> orchestrator (naive vs error-aware) -> recommend

Run:
    python -m experiments.stack.run_stack --config experiments/stack/configs/stack_tiny.yaml
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
import yaml

from ..laamp import DiTConfig, build_model, build_objective
from ..data import synthetic_iter, latent_folder_iter
from . import interaction as I
from . import orchestrator as O
from . import analyze as A
from . import errormodel as stack_errmodel


def g(d, path, default=None):
    cur = d
    for k in path.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def log(m): print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)
def banner(s): print("\n" + "=" * 64 + f"\n== {s}\n" + "=" * 64, flush=True)


def get_base_model(cfg, mcfg, objective, device, out):
    """tiny: pretrain quickly; dit_xl: load a base_state.pt (from Contribution 1)."""
    if g(cfg, "mode") == "dit_xl":
        state = torch.load(g(cfg, "base_state"), map_location=device)
        m = build_model(mcfg).to(device); m.load_state_dict(state, strict=False)
        return m
    m = build_model(mcfg).to(device)
    it = synthetic_iter(batch=g(cfg, "data.batch", 8), channels=mcfg.in_channels,
                        size=mcfg.input_size, num_classes=mcfg.num_classes, device=device)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3); m.train()
    for _ in range(g(cfg, "pretrain_steps", 300)):
        loss = objective.loss(m, *next(it)); opt.zero_grad(); loss.backward(); opt.step()
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text())

    device = "cuda" if torch.cuda.is_available() and g(cfg, "device") != "cpu" else "cpu"
    out = Path(g(cfg, "output_dir", "experiments/results/stack")); out.mkdir(parents=True, exist_ok=True)
    mcfg = DiTConfig.tiny() if g(cfg, "mode") == "tiny" else DiTConfig.dit_xl_2()
    objective = build_objective(g(cfg, "objective", "flow"), device)
    steps = g(cfg, "sampler_steps", 20)
    B = g(cfg, "n_probe", 16)

    torch.manual_seed(g(cfg, "seed", 0))
    # error metric: rmse (latent, default) | lpips | psnr (decoded images, need VAE)
    metric = g(cfg, "metric", "rmse")
    if metric != "rmse":
        vae = None
        if g(cfg, "mode") != "tiny":
            from ..eval_fid import load_vae
            vae = load_vae(g(cfg, "vae", "stabilityai/sd-vae-ft-ema"), device)
        stack_errmodel.set_distance(stack_errmodel.build_distance(metric, vae, device))
        log(f"error metric = {metric}")
    else:
        stack_errmodel.set_distance(stack_errmodel.normalized_rmse)

    log(f"mode={g(cfg,'mode')} device={device} steps={steps} metric={metric} out={out}")
    base = get_base_model(cfg, mcfg, objective, device, out)
    x_init = torch.randn(B, mcfg.in_channels, mcfg.input_size, mcfg.input_size, device=device)
    y = torch.randint(0, mcfg.num_classes, (B,), device=device)
    data_iter = None
    if g(cfg, "mode") == "tiny":
        data_iter = synthetic_iter(batch=g(cfg, "data.batch", 8), channels=mcfg.in_channels,
                                   size=mcfg.input_size, num_classes=mcfg.num_classes, device=device)

    result = {}

    banner("STAGE 1  error-interaction matrix (PROPOSAL 3c)")
    mat = I.interaction_matrix(base, x_init, y, steps, objective=objective,
                               data_iter=data_iter, device=device)
    result["interaction"] = dict(knobs=mat["knobs"], pairs=mat["pairs"],
                                 singles=mat["singles"])

    banner("STAGE 2  profiling (singles + pairwise deltas over knob grid)")
    prof = O.profile(base, x_init, y, steps, objective=objective, data_iter=data_iter, device=device)

    banner("STAGE 3  orchestrator: error-aware vs naive sequential (H1)")
    orch = {}
    for target in g(cfg, "targets", [3.0, 6.0]):
        cmp = O.compare_planners(base, prof, x_init, y, steps, target,
                                 objective=objective, data_iter=data_iter, device=device)
        orch[str(target)] = cmp
        na, ea = cmp.get("naive", {}), cmp.get("error_aware", {})
        if na.get("feasible") and ea.get("feasible"):
            log(f"target {target}x | naive err={na['measured_error']:.4f} axes={na['axes_on']} "
                f"({na['speedup']:.1f}x) | error_aware err={ea['measured_error']:.4f} "
                f"axes={ea['axes_on']} ({ea['speedup']:.1f}x) | "
                f"aware better by {cmp.get('error_aware_better_by', 0):+.4f}")
    result["orchestrator"] = orch

    banner("STAGE 4  analyze -> recommend (tool brain / Framing B)")
    # reuse the profiling already done; the recommender reasons over it
    report = {"profile": prof, "efficiency": A.efficiency_from_profile(prof)}
    recos = {}
    for target in g(cfg, "targets", [3.0, 6.0]):
        rec = A.recommend(report, steps, target)
        recos[str(target)] = dict(knobs=rec.knobs, achieved=rec.achieved_speedup,
                                  predicted_error=rec.predicted_error, rationale=rec.rationale)
        print(f"\n-- recommendation @ {target}x --")
        for line in rec.rationale:
            print("   " + line)
    result["recommendations"] = recos

    (out / "stack_results.json").write_text(json.dumps(result, indent=2, default=float), encoding="utf-8")
    write_summary(out, result)
    banner("STACK RUN DONE"); log(f"artifacts under {out}")


def write_summary(out, r):
    L = ["# Error-Aware Stack — summary", "", "## Interaction matrix (rho: +compounding / 0 orthogonal / - sub-additive)", "",
         "| pair | e_A | e_B | e_AB | delta | rho | verdict |", "|---|---|---|---|---|---|---|"]
    for p in r["interaction"]["pairs"]:
        L.append(f"| {p['axisA']}×{p['axisB']} | {p['e_A']:.4f} | {p['e_B']:.4f} | "
                 f"{p['e_AB']:.4f} | {p['delta']:+.4f} | {p['rho']:+.2f} | {p['verdict']} |")
    L += ["", "## Orchestrator: naive vs error-aware", "",
          "| target | naive err (axes) | error-aware err (axes) | aware better by |",
          "|---|---|---|---|"]
    for t, c in r["orchestrator"].items():
        na, ea = c.get("naive", {}), c.get("error_aware", {})
        if na.get("feasible") and ea.get("feasible"):
            L.append(f"| {t}x | {na['measured_error']:.4f} {na['axes_on']} | "
                     f"{ea['measured_error']:.4f} {ea['axes_on']} | "
                     f"{c.get('error_aware_better_by',0):+.4f} |")
    L += ["", "## Recommendations (tool brain)", ""]
    for t, rec in r["recommendations"].items():
        L.append(f"**@ {t}x** (achieved {rec['achieved']:.1f}x): `{rec['knobs']}`")
        for line in rec["rationale"]:
            L.append(f"- {line}")
        L.append("")
    (out / "SUMMARY.md").write_text("\n".join(L), encoding="utf-8")
    log(f"summary -> {out/'SUMMARY.md'}")


if __name__ == "__main__":
    main()
