"""OPTSD tool — the demo front-end of the thesis.

Realises the product vision literally:

    load model  ->  analyze  ->  recommend techniques  ->  (confirm / start)
                ->  apply     ->  output optimized model + report

The recommendation is produced by the error-aware orchestrator (analyze.py),
which reasons over the measured error-interaction map -- so this front-end is a
thin shell over the Contribution-2 science, not a rule engine.

Usage:
    # demo on the tiny model (CPU, no downloads)
    python -m experiments.stack.tool --config tiny --target 4 --yes

    # real model produced by Contribution 1's pipeline
    python -m experiments.stack.tool --config dit_xl \
        --base experiments/results/ditxl/base_state.pt --target 6 --yes
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

from ..laamp import DiTConfig, build_model, build_objective
from ..data import synthetic_iter
from ..harness import latency as lat_h
from . import analyze as A, orchestrator as O
from .report import render_html


def load_model(config, base, objective, device):
    mcfg = DiTConfig.tiny() if config == "tiny" else DiTConfig.dit_xl_2()
    model = build_model(mcfg).to(device)
    if base:
        model.load_state_dict(torch.load(base, map_location=device), strict=False)
        print(f"[tool] loaded weights from {base}")
    elif config == "tiny":
        print("[tool] no --base given: pretraining a tiny demo model")
        it = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                            num_classes=mcfg.num_classes, device=device)
        opt = torch.optim.AdamW(model.parameters(), lr=1e-3); model.train()
        for _ in range(300):
            loss = objective.loss(model, *next(it)); opt.zero_grad(); loss.backward(); opt.step()
    else:
        print("[tool][WARN] dit_xl with random init — pass --base for a real model")
    return model, mcfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", choices=["tiny", "dit_xl"], default="tiny")
    ap.add_argument("--base", default=None, help="base_state.pt (from Contribution 1)")
    ap.add_argument("--target", type=float, default=4.0, help="desired end-to-end speedup")
    ap.add_argument("--steps", type=int, default=20, help="sampler steps for probing")
    ap.add_argument("--n_probe", type=int, default=16)
    ap.add_argument("--yes", action="store_true", help="skip the confirm prompt (auto-start)")
    ap.add_argument("--out", default="experiments/results/tool_run")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    objective = build_objective("flow" if args.config == "tiny" else "ddpm", device)

    # ---- 1. LOAD -------------------------------------------------------
    print("\n=== 1. LOAD MODEL ===")
    model, mcfg = load_model(args.config, args.base, objective, device)
    x_init = torch.randn(args.n_probe, mcfg.in_channels, mcfg.input_size,
                         mcfg.input_size, device=device)
    y = torch.randint(0, mcfg.num_classes, (args.n_probe,), device=device)
    data_iter = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                               num_classes=mcfg.num_classes, device=device) if args.config == "tiny" else None
    before_params = lat_h.param_count(model, only_alive=False)

    # ---- 2. ANALYZE ----------------------------------------------------
    print("\n=== 2. ANALYZE (error-interaction profiling) ===")
    report = A.analyze_model(model, x_init, y, args.steps, objective=objective,
                             data_iter=data_iter, device=device, verbose=True)
    prof = report["profile"]

    # ---- 3. RECOMMEND --------------------------------------------------
    print(f"\n=== 3. RECOMMEND (target {args.target:.1f}x) ===")
    rec = A.recommend(report, args.steps, args.target)
    for line in rec.rationale:
        print("  " + line)
    if not rec.knobs:
        print("[tool] no feasible config; aborting."); sys.exit(1)

    # ---- 4. CONFIRM / START -------------------------------------------
    if not args.yes:
        if not sys.stdin.isatty():
            print("\n[tool] non-interactive; pass --yes to start optimization. Aborting.")
            sys.exit(2)
        if input(f"\nStart optimization with {rec.knobs}? [y/N] ").strip().lower() != "y":
            print("[tool] cancelled."); sys.exit(0)

    # ---- 5. APPLY ------------------------------------------------------
    print("\n=== 5. APPLY (optimizing) ===")
    result = A.apply(model, rec, objective, data_iter, device)
    opt_model = result["model"]
    after_params = lat_h.param_count(opt_model, only_alive=True)
    torch.save({"state_dict": opt_model.state_dict(),
                "config": vars(rec.config) if hasattr(rec.config, "__dict__") else str(rec.config),
                "cache_interval": result["cache_policy"].interval,
                "cache_order": result["cache_policy"].order},
               out / "optimized_model.pt")

    # ---- 6. OUTPUT / REPORT -------------------------------------------
    print("\n=== 6. OUTPUT ===")
    mat_pairs = [dict(axisA=p["axisA"], axisB=p["axisB"], e_A=p["e_A"], e_B=p["e_B"],
                      e_AB=p["e_AB"], delta=p["delta"], rho=p["rho"], verdict=p["verdict"])
                 for p in _pairs_from_profile(prof, model, x_init, y, args.steps,
                                              objective, data_iter, device)]
    rec_d = dict(knobs=rec.knobs, rationale=rec.rationale, predicted_error=rec.predicted_error)
    html_path = render_html(
        model_name=f"{args.config} DiT", target=args.target, achieved=rec.achieved_speedup,
        interaction_pairs=mat_pairs, recommendation=rec_d,
        before={"params": before_params}, after={"params": after_params},
        path=str(out / "report.html"))
    (out / "report.json").write_text(json.dumps(
        dict(model=args.config, target=args.target, achieved=rec.achieved_speedup,
             knobs=rec.knobs, rationale=rec.rationale, predicted_error=rec.predicted_error,
             before_params=before_params, after_params=after_params,
             interaction=mat_pairs), indent=2, default=float), encoding="utf-8")

    print(f"  optimized model -> {out/'optimized_model.pt'}")
    print(f"  report          -> {html_path}")
    print(f"  achieved ~{rec.achieved_speedup:.1f}x  params {before_params:,} -> {after_params:,}")
    print("\nDONE.")


def _pairs_from_profile(prof, model, x_init, y, steps, objective, data_iter, device):
    """Reuse the interaction matrix at the profile's representative knobs."""
    from .interaction import interaction_matrix
    knobs = {"prune": 0.5, "quant": 4, "cache": 4}
    return interaction_matrix(model, x_init, y, steps, knobs=knobs,
                              objective=objective, data_iter=data_iter,
                              device=device, verbose=False)["pairs"]


if __name__ == "__main__":
    main()
