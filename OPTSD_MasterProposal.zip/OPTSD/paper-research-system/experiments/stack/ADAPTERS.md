# Real-axis adapters (Contribution 2, Part B)

The stack's error/interaction/orchestrator/analyze layers are **engine-agnostic**.
Each axis has a light CPU stand-in (default) and a real backend you switch on for
the GPU study — without changing anything above `axes.py`.

| axis | light (default, CPU) | real backend | module | status |
|---|---|---|---|---|
| prune | magnitude / coupled mask | **LAAMP learned mask** (Contrib 1) | `adapters/laamp_axis.py` | ✅ full, CPU-ok |
| quant | fake-quant (per-channel) | **SVDQuant / Nunchaku** W4A4 | `adapters/svdquant.py` | 🧩 scaffold, GPU |
| cache | Taylor forecast (`sampler.py`) | **TaylorSeer / HiCache** | `adapters/taylorseer.py` | 🧩 scaffold, GPU |

## Switching backends

```python
from experiments.stack import adapters
adapters.status()                       # what's active + available on this machine
adapters.use_backend("prune", "laamp")  # real learned mask (works on CPU)
adapters.use_backend("quant", "svdquant")  # raises on CPU; ok on the 4090
```

Default is `light` for every axis, so the CPU interaction study and the demo tool
keep working with no engines installed.

## prune → LAAMP (already usable)

Pass the `m_star` produced by Contribution 1's search (run_pipeline saves pruned
masks under `results/<run>/pruned/`) via `StackConfig.prune_mask`, and activate
the backend:

```python
adapters.use_backend("prune", "laamp")
cfg = StackConfig(prune_keep=0.5, prune_mask=m_star)   # m_star: (2*depth,) {0,1}
```

Speedup is computed from the analytic sub-block FLOPs of the kept branches.

## quant → SVDQuant / Nunchaku (GPU TODO)

`pip install nunchaku` on the 4090 (Ada+; verify on 3090/Ampere per PROPOSAL §9),
then fill the `apply()` TODO in `svdquant.py`:
load the W4A4 SVDQuant backbone, expose `forward(x,t,y)`, and report **measured**
latency/memory (never the paper numbers). This gives the interaction study genuine
4-bit noise — the source of the quant×cache compounding in RQ1.

## cache → TaylorSeer / HiCache (GPU TODO)

Vendor the engine, then fill `cached_sample()` in `taylorseer.py`: register
feature-cache hooks on the real DiT blocks and forecast at skipped steps.
HiCache's Hermite basis assumes "derivatives ~ Gaussian" — the assumption W4A4
noise may break (RQ1), which is why the *real* cache is needed to measure the
interaction faithfully.

## Why this design

The scientific result (the error-interaction map + the orchestrator's advantage)
must be measured with the **real** approximations. Keeping the adapters behind a
registry means the exact same `interaction.py` / `orchestrator.py` / `analyze.py`
code that we validated on CPU produces the paper numbers on GPU — only the axis
implementations change.
