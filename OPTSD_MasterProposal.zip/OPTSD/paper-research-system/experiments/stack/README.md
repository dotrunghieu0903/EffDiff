# Experiments — Contribution 2 (Error-Aware Unified Acceleration Stack)

The **brain** of the tool. **Separate package** from `experiments/laamp/`
(Contribution 1) on purpose — this one *consumes* LAAMP as acceleration axis #1
and reuses `experiments/harness/`. Proposal: [../../PROPOSAL.md](../../PROPOSAL.md)
§3–§5; thesis structure (tool = demo, this = Paper 2 science) is in the notes.

## The scientific claim

Four axes are orthogonal in **FLOPs** but interact in **error** (H1). The
contribution is *not* wiring them together — it is:

1. **Error-interaction map** (`interaction.py`, PROPOSAL §3c): for each axis pair,
   `delta = e_AB - (e_A + e_B)` and `rho = delta/(e_A+e_B)`.
   `rho≈0` orthogonal · `rho>0` compounding (conflict) · `rho<0` sub-additive.
2. **Error-aware orchestrator** (`orchestrator.py`, H1): a planner that uses the
   interaction terms (not just the additive assumption) to choose a config —
   and may *drop* an axis whose interaction outweighs its speedup.
3. **analyze → recommend → apply** (`analyze.py`): the product front-end. The
   recommendation is derived from the measured map, **not** a hand rule — that is
   what makes the tool a scientific contribution and not plumbing.

## The four axes (`axes.py`)

| # | axis | knob | this repo (light) | real engine (GPU) |
|---|---|---|---|---|
| 1 | depth/structure | `prune_keep` | LAAMP / magnitude mask (reuses Contrib 1) | LAAMP |
| 2 | precision | `quant_bits` | fake-quant W(+A) | SVDQuant / Nunchaku |
| 3 | time/forecast | `cache_interval` | Taylor forecast in `sampler.py` | TaylorSeer / HiCache |
| 4 | multi-GPU | `dist_gpus` | latency model only (no output error) | Otil / DistriFusion |

## Representing all 7 survey groups (faithful, not 7 co-equal toggles)

Only the 4 axes above STACK multiplicatively (the thesis finding). The other 3
groups are represented by their true role, NOT as extra stackable checkboxes:

| group | role in tool | how | light / real |
|---|---|---|---|
| Distillation (DMD2/Phased-DMD) | **step-count regime** (`StackConfig.regime="distilled"`) — mutually exclusive, **forces cache off** (§3b/DisCa) | `regime_plan` (few-step) | `adapters/dmd2.py` |
| Solvers (RF-Solver) | **step-count regime** (`regime="solver"`) — fewer ODE steps, composes with the 4 axes | `regime_plan` (half-steps) | `adapters/rf_solver.py` |
| Arch (SANA) | **substrate / backbone** (not a toggle) — shrinks every axis's ROI (§3d) | `DiTConfig.sana_tiny()` (fewer tokens) | `adapters/sana.py` |

The regime is a radio (Full / RF-Solver / DMD2) in the UI; picking DMD2 disables
the caching axis. This keeps the tool faithful: it does not pretend distillation
stacks orthogonally with caching.

The fake-quant / Taylor-cache are faithful-but-light stand-ins so the
**interaction study runs without the CUDA engines**. Swapping in the real
adapters does not change any interface above them (`errormodel`, `interaction`,
`orchestrator`, `analyze` are engine-agnostic).

## Run

```bash
# CPU dry-run (validate the whole flow; no GPU/downloads)
python -m experiments.stack.smoke_test
python -m experiments.stack.run_stack --config experiments/stack/configs/stack_tiny.yaml

# real run: consumes Contribution 1's base_state.pt (run_pipeline first)
python -m experiments.stack.run_stack --config experiments/stack/configs/stack.yaml
```

Outputs `SUMMARY.md` + `stack_results.json`: the interaction matrix, the
naive-vs-error-aware comparison at each target speedup, and the recommendations.

## Demo tool (thesis artifact)

Two front-ends over the same analyze→recommend→apply core:

**Browser UI** (`serve.py` + `../ui/index.html`,`../ui/styles.css`,`../ui/app.js`) — a
zero-dependency stdlib launcher that serves the UI and calls the stack modules
in-process (browsers can't run PyTorch, so this shim is the bridge — not a
framework backend):

```bash
python -m experiments.stack.serve --open      # http://127.0.0.1:5050
```

Pick backbone (Tiny demo / DiT-XL + base .pt) → **Analyze Model** (runs the REAL
error-interaction matrix and auto-applies the recommendation) → **Start
Optimization** → writes `results/tool_web/optimized_model.pt` + `report.html`.
The technique toggles are the four thesis axes (Pruning/LAAMP, Quantization,
Caching-forecast, Multi-GPU) — no filename-keyword heuristics; the recommendation
comes from the measured map.

**CLI** (`tool.py`) — same flow, headless, emits a standalone `report.html`:

```bash
python -m experiments.stack.tool --config tiny --target 4 --yes
# real: --config dit_xl --base experiments/results/ditxl/base_state.pt
```

## Real axes (SVDQuant / TaylorSeer / LAAMP)

The light quant/cache here are stand-ins. Swap in the real CUDA engines via the
adapter registry (default stays `light`, so CPU keeps working) — see
[ADAPTERS.md](ADAPTERS.md). The LAAMP pruning adapter is already fully usable.

## Reading the toy output (important)

On the tiny/synthetic model the pairs come out orthogonal/sub-additive, so the
error-aware planner picks the **same** config as naive (`aware better by +0.000`).
That is correct and honest: **there is no compounding to exploit in a 6-layer
random-data toy**, so the two planners agree. The gap opens on the real substrate
where quantization noise degrades the cache's forecastability (PROPOSAL RQ1) —
that is precisely the compounding `rho>0` cell the orchestrator is built to route
around. The toy proves the *machinery*; the *finding* comes from `stack.yaml` on
DiT-XL with the real axes.

## From proxy to real quality error

`errormodel.normalized_rmse` compares latents. For paper numbers, swap it for
LPIPS/FID vs the base model's decoded images (`harness/metrics.py`) — the
`distance` argument of `evaluate_config` is the single wiring point.

## Map to PROPOSAL

- `interaction.py` measured cells ↔ the friction pairs in §3c
  (quant×cache, prune×cache, quant×kernel-outliers/RQ1b).
- `orchestrator.py` ↔ the "Error-Aware Orchestrator" of §5.2 and H1.
- `analyze.py` ↔ the tool's "analyze → recommend which axes" vision (Framing B).
