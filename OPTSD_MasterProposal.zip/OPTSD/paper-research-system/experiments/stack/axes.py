"""The four orthogonal acceleration axes as composable, instrumented objects.

Each axis is an *approximation* with (a) a knob, (b) an apply step, (c) a speedup
factor (FLOPs/step proxy). Contribution 2 studies how their ERRORS interact, not
the axes themselves -- so the implementations here are faithful-but-light
(fake-quant, magnitude/LAAMP prune, Taylor cache) with real-engine adapters
documented for the GPU run.

  #1 depth/structure : PruningAxis  (consumes Contribution 1 / LAAMP; knob=keep_ratio)
  #2 precision       : QuantAxis    (fake W(-A) quant; knob=bits)          [real: SVDQuant]
  #3 time/forecast   : CacheAxis    (Taylor forecast in sampler; knob=interval) [real: TaylorSeer/HiCache]
  #4 multi-GPU       : DistAxis      (execution only -> no output error in sim) [real: Otil/DistriFusion]
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field

import torch
import torch.nn as nn

from ..laamp import build_model, baselines, apply_hard_mask
from ..laamp.dit import DiTConfig
from .sampler import CachePolicy


# ---------------------------------------------------------------------------
# a full stack configuration (a point the orchestrator chooses)
# ---------------------------------------------------------------------------
@dataclass
class StackConfig:
    prune_keep: float = 1.0          # 1.0 = axis off
    prune_method: str = "magnitude"  # or a provided LAAMP mask (see prune_mask)
    prune_mask: torch.Tensor | None = None
    quant_bits: int = 16             # 16 = off (bf16); 8 / 4 = active
    quant_act: bool = False          # also fake-quant activations (RQ1 realism)
    cache_interval: int = 1          # 1 = off
    cache_order: int = 1
    dist_gpus: int = 1               # 1 = off (execution axis, no error in sim)
    regime: str = "full"             # step-count MODE (mutually exclusive, NOT a
                                     # stackable axis): full | solver | distilled.
                                     # 'distilled' conflicts with caching (§3b/DisCa).

    def axes_on(self):
        on = []
        if self.prune_keep < 1.0: on.append("prune")
        if self.quant_bits < 16: on.append("quant")
        if self.cache_interval > 1: on.append("cache")
        if self.dist_gpus > 1: on.append("dist")
        if self.regime != "full": on.append(self.regime)
        return on


# NB: the step-count regime LOGIC lives in stack/regime.py (regime_plan) so this
# file stays exactly the four orthogonal, stackable axes. Only the config FIELD
# (StackConfig.regime) is defined here.


# ---------------------------------------------------------------------------
# axis #2 : quantization (fake-quant)
# ---------------------------------------------------------------------------
def _fake_quant_tensor(w: torch.Tensor, bits: int, per_channel_dim=0) -> torch.Tensor:
    if bits >= 16:
        return w
    qmax = 2 ** (bits - 1) - 1
    dims = [d for d in range(w.dim()) if d != per_channel_dim]
    scale = w.abs().amax(dim=dims, keepdim=True).clamp_min(1e-8) / qmax
    return (torch.clamp(torch.round(w / scale), -qmax - 1, qmax) * scale)


def _act_quant_hook(bits):
    def hook(module, inp):
        x = inp[0]
        return (_fake_quant_tensor(x, bits, per_channel_dim=0),) + inp[1:]
    return hook


def apply_quant(model, bits: int, quant_act=False):
    """Fake-quant of all Linear weights (+ optional activations), OR delegate to a
    real backend (SVDQuant) if one was activated via adapters.use_backend."""
    if bits >= 16:
        return model, 1.0
    from . import adapters
    active = adapters.active("quant")
    if active != "light":
        return adapters.backend_module("quant", active).apply(model, bits, quant_act)
    for m in model.modules():
        if isinstance(m, nn.Linear):
            m.weight.data = _fake_quant_tensor(m.weight.data, bits, per_channel_dim=0)
            if quant_act:
                m.register_forward_pre_hook(_act_quant_hook(bits))
    speedup = 16.0 / bits          # W4 -> ~4x (memory/compute proxy)
    return model, speedup


# ---------------------------------------------------------------------------
# axis #1 : pruning (consumes Contribution 1)
# ---------------------------------------------------------------------------
def apply_prune(model, cfg: StackConfig, objective=None, data_iter=None, device="cpu"):
    if cfg.prune_keep >= 1.0:
        return model, 1.0
    from . import adapters
    active = adapters.active("prune")
    if active == "laamp" and cfg.prune_mask is not None:
        return adapters.backend_module("prune", "laamp").apply(
            model, m_star=cfg.prune_mask, device=device)
    if cfg.prune_mask is not None:
        m_star = cfg.prune_mask
    else:
        m_star = baselines.select(cfg.prune_method, model, cfg.prune_keep,
                                  objective=objective, data_iter=data_iter, device=device)
    apply_hard_mask(model, m_star)
    speedup = 1.0 / cfg.prune_keep
    return model, speedup


# ---------------------------------------------------------------------------
# compose the model-level axes (prune then quant)
# ---------------------------------------------------------------------------
def build_accelerated_model(base_model, cfg: StackConfig, objective=None,
                            data_iter=None, device="cpu"):
    """Return (accelerated_model_copy, model_speedup). Order = prune -> quant
    (§3c: prune first changes what quant sees; the orchestrator can also test the
    reverse via cfg ordering hooks)."""
    m = copy.deepcopy(base_model).to(device)
    m, sp_p = apply_prune(m, cfg, objective, data_iter, device)
    m, sp_q = apply_quant(m, cfg.quant_bits, cfg.quant_act)
    return m, sp_p * sp_q


# ---------------------------------------------------------------------------
# axis #3 : caching policy (applied in the sampler)
# ---------------------------------------------------------------------------
def cache_policy(cfg: StackConfig) -> CachePolicy:
    return CachePolicy(interval=cfg.cache_interval, order=cfg.cache_order,
                       enabled=cfg.cache_interval > 1)


# ---------------------------------------------------------------------------
# axis #4 : multi-GPU (execution only). No output error in single-GPU sim;
# it contributes a wall-clock speedup with communication overhead, modelled here
# so the orchestrator can trade it off. Real engine: Otil / DistriFusion.
# ---------------------------------------------------------------------------
def dist_speedup(n_gpus: int, comm_overhead=0.15) -> float:
    if n_gpus <= 1:
        return 1.0
    return n_gpus * (1.0 - comm_overhead)      # Amdahl-ish; Otil lowers overhead


# knob grids used by interaction sweep / orchestrator search
KNOB_GRID = {
    "prune": [1.0, 0.75, 0.5],          # keep_ratio
    "quant": [16, 8, 4],                # bits
    "cache": [1, 2, 4],                 # interval
}
AXIS_OFF = {"prune": 1.0, "quant": 16, "cache": 1}
