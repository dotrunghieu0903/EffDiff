"""The tool "brain": analyze a model -> recommend axes+knobs -> apply -> output.

This is the front-end the demo tool calls, and the embodiment of Contribution 2:
the recommendation is NOT a hand-written rule -- it is derived from the measured
error-interaction map (interaction.py / orchestrator.profile). That is what keeps
the tool a scientific contribution rather than plumbing (see thesis notes:
recommend engine == error-aware orchestrator, not if-else).

Flow (matches the product vision):
    analyze_model(model)  -> AnalysisReport (per-axis efficiency + interactions)
    recommend(report, target_speedup) -> Recommendation (config + rationale)
    apply(model, recommendation)       -> optimized model (+ cache policy)
"""
from __future__ import annotations

from dataclasses import dataclass, field

import torch

from .axes import StackConfig, KNOB_GRID, AXIS_OFF, build_accelerated_model, cache_policy
from .orchestrator import profile, plan, config_speedup, _to_cfg, _off
from .interaction import _cfg_with


@dataclass
class Recommendation:
    config: StackConfig
    knobs: dict
    target_speedup: float
    achieved_speedup: float
    predicted_error: float
    rationale: list = field(default_factory=list)


def analyze_model(base_model, x_init, y, steps, objective=None, data_iter=None,
                  device="cpu", verbose=True):
    """Profile the model on every axis + pairwise interaction. Returns the map the
    recommender reasons over (this IS the analysis step of the tool)."""
    prof = profile(base_model, x_init, y, steps, objective=objective,
                   data_iter=data_iter, device=device, verbose=verbose)
    return dict(profile=prof, efficiency=efficiency_from_profile(prof))


def efficiency_from_profile(prof):
    """Per-axis error-efficiency at the strongest knob: speedup per unit error."""
    eff = {}
    for a in prof["axes"]:
        strong = _strongest_knob(a)
        s = prof["singles"][a][strong]
        eff[a] = dict(knob=strong, error=s["error"], speedup=s["speedup"],
                      efficiency=(s["speedup"] - 1) / (s["error"] + 1e-6))
    return eff


def _strongest_knob(axis):
    grid = KNOB_GRID[axis]
    if axis == "cache":
        return max(grid)          # largest interval = most aggressive
    return min(grid)              # smallest keep_ratio / bits = most aggressive


def recommend(report, steps, target_speedup, rho_conflict=0.15) -> Recommendation:
    prof = report["profile"]
    knobs, pred = plan(prof, steps, target_speedup, use_interactions=True)
    rationale = []
    if knobs is None:
        rationale.append(f"No config on the grid reaches {target_speedup:.1f}x; "
                         f"loosen the grid or lower the target.")
        return Recommendation(StackConfig(), {}, target_speedup, 1.0, float("inf"), rationale)

    cfg = _to_cfg(knobs)
    on = cfg.axes_on()
    rationale.append(f"Target {target_speedup:.1f}x -> enabled axes: {on or ['none']}.")

    # explain enabled axes by efficiency
    for a in on:
        e = report["efficiency"].get(a)
        if e:
            rationale.append(f"  '{a}' @ {knobs[a]}: +{e['speedup']:.1f}x for error "
                             f"{prof['singles'][a][knobs[a]]['error']:.4f}.")
    # explain any axis LEFT OFF because of a compounding interaction (Framing B)
    for a in prof["axes"]:
        if a in on:
            continue
        conflicts = _conflicts_with(prof, a, knobs, rho_conflict)
        if conflicts:
            rationale.append(f"  dropped '{a}': compounding with {conflicts} "
                             f"(interaction would inflate error beyond its speedup benefit).")

    return Recommendation(cfg, knobs, target_speedup, config_speedup(cfg, steps),
                          pred, rationale)


def _conflicts_with(prof, axis, chosen_knobs, rho_conflict):
    """Which enabled axes does `axis` compound with (positive delta)?"""
    import itertools
    out = []
    strong = _strongest_knob(axis)
    for b in prof["axes"]:
        if b == axis or chosen_knobs.get(b, _off(b)) == _off(b):
            continue
        kb = chosen_knobs[b]
        key = (axis, strong, b, kb) if (axis, strong, b, kb) in prof["deltas"] else (b, kb, axis, strong)
        d = prof["deltas"].get(key, 0.0)
        eA = prof["singles"][axis][strong]["error"]
        eB = prof["singles"][b][kb]["error"]
        if d / (eA + eB + 1e-8) > rho_conflict:
            out.append(b)
    return out


def apply(base_model, rec: Recommendation, objective=None, data_iter=None, device="cpu"):
    """Produce the OPTIMIZED model (the tool's output). Caching is a sampler
    policy, so we return it alongside the model."""
    model, sp = build_accelerated_model(base_model, rec.config, objective, data_iter, device)
    return dict(model=model, cache_policy=cache_policy(rec.config),
                model_speedup=sp, config=rec.config)
