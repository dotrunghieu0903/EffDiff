"""Launcher for the OPTSD demo tool — a ~zero-dependency stdlib shim.

This is NOT a web framework: it is a thin http.server that (1) serves the static
UI (index.html/styles.css/app.js) and (2) exposes /api endpoints that call the
Contribution-2 modules IN-PROCESS (stack.analyze / recommend / apply). The browser
cannot run PyTorch, so this shim is the only bridge — it just forwards to the same
functions the CLI uses.

Run:
    python -m experiments.stack.serve            # opens http://127.0.0.1:5050
    python -m experiments.stack.serve --port 5050 --open

Endpoints:
    GET  /api/device-resources     -> devices + system info (for the sidebar)
    POST /api/analyze  {config,...} -> real error-interaction matrix + recommendation
    POST /api/optimize {config,knobs,target} -> apply, save model + report.html
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import torch

from ..laamp import build_model, build_objective
from ..data import synthetic_iter
from ..harness import latency as lat_h
from . import analyze as A
from .axes import StackConfig
from .backbones import build_backbone
from .report import render_html

BASE_DIR = Path(__file__).resolve().parents[1]          # experiments/
UI_DIR = BASE_DIR / "ui"                                # index.html/styles.css/app.js live here
OUT_DIR = BASE_DIR / "results" / "tool_web"
OUT_DIR.mkdir(parents=True, exist_ok=True)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# in-process cache so /api/optimize can reuse what /api/analyze built
_STATE = {"config": None, "base": None, "mcfg": None, "objective": None,
          "x_init": None, "y": None, "data_iter": None, "profile": None,
          "interaction": None, "report": None}


# --------------------------------------------------------------------------
def _build_base(config, base_path, steps, n_probe):
    """Load/pretrain the base model + probe tensors; cache in _STATE."""
    if _STATE["config"] == (config, base_path) and _STATE["base"] is not None:
        return
    mcfg, obj_name = build_backbone(config)
    objective = build_objective(obj_name, DEVICE)
    model = build_model(mcfg).to(DEVICE)
    demo = config in ("tiny", "sana")     # light backbones -> pretrain on synthetic
    if base_path and Path(base_path).exists():
        model.load_state_dict(torch.load(base_path, map_location=DEVICE), strict=False)
    elif demo:
        it = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                            num_classes=mcfg.num_classes, device=DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=1e-3); model.train()
        for _ in range(300):
            loss = objective.loss(model, *next(it)); opt.zero_grad(); loss.backward(); opt.step()
    data_iter = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                               num_classes=mcfg.num_classes, device=DEVICE) if demo else None
    x_init = torch.randn(n_probe, mcfg.in_channels, mcfg.input_size, mcfg.input_size, device=DEVICE)
    y = torch.randint(0, mcfg.num_classes, (n_probe,), device=DEVICE)
    _STATE.update(config=(config, base_path), base=model, mcfg=mcfg, objective=objective,
                  x_init=x_init, y=y, data_iter=data_iter, profile=None, interaction=None)


def api_device_resources():
    devices, gpus = [], []
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            p = torch.cuda.get_device_properties(i)
            devices.append(dict(id=f"gpu-{i}", name=p.name, type="GPU",
                                memoryGB=round(p.total_memory / 1024**3, 1)))
            gpus.append(p.name)
    devices.append(dict(id="cpu-0", name=f"System CPU ({os.cpu_count()} cores)", type="CPU"))
    return dict(success=True, devices=devices, cpuCores=os.cpu_count(),
                availableProviders=(["CUDA"] if gpus else ["CPU"]),
                host=dict(hostname=platform.node(), os=f"{platform.system()} {platform.release()}"),
                dataSource="optsd-backend (torch)")


def _interaction_pairs(model, mcfg, objective, x_init, y, data_iter, steps):
    from .interaction import interaction_matrix
    knobs = {"prune": 0.5, "quant": 4, "cache": 4}
    return interaction_matrix(model, x_init, y, steps, knobs=knobs, objective=objective,
                              data_iter=data_iter, device=DEVICE, verbose=False)["pairs"]


def api_analyze(body):
    config = body.get("config", "tiny")
    base_path = body.get("base_path") or None
    steps = int(body.get("steps", 12))
    n_probe = int(body.get("n_probe", 8))
    target = float(body.get("target", 4.0))
    _build_base(config, base_path, steps, n_probe)

    report = A.analyze_model(_STATE["base"], _STATE["x_init"], _STATE["y"], steps,
                             objective=_STATE["objective"], data_iter=_STATE["data_iter"],
                             device=DEVICE, verbose=False)
    _STATE["profile"] = report["profile"]
    pairs = _interaction_pairs(_STATE["base"], _STATE["mcfg"], _STATE["objective"],
                               _STATE["x_init"], _STATE["y"], _STATE["data_iter"], steps)
    _STATE["interaction"] = pairs
    rec = A.recommend(report, steps, target)

    return dict(success=True,
                architecture=f"DiT ({'ddpm' if config=='dit_xl' else 'flow'}) · {_STATE['mcfg'].depth} blocks",
                interaction=[dict(axisA=p["axisA"], axisB=p["axisB"], e_A=p["e_A"], e_B=p["e_B"],
                                  e_AB=p["e_AB"], delta=p["delta"], rho=p["rho"], verdict=p["verdict"])
                             for p in pairs],
                recommendation=dict(knobs=rec.knobs, rationale=rec.rationale,
                                    predicted_error=rec.predicted_error, achieved=rec.achieved_speedup),
                suggested=cfg_to_techniques(rec.knobs, body.get("regime", "full")))


def cfg_to_techniques(knobs, regime="full"):
    out = []
    if knobs.get("prune", 1.0) < 1.0: out.append(f"Pruning (keep {knobs['prune']})")
    if knobs.get("quant", 16) < 16: out.append(f"Quantization (W{knobs['quant']})")
    if knobs.get("cache", 1) > 1: out.append(f"Caching (interval {knobs['cache']})")
    if regime == "solver": out.append("RF-Solver (fewer steps)")
    if regime == "distilled": out.append("DMD2 few-step (cache off)")
    return out or ["none"]


def api_optimize(body):
    if _STATE["base"] is None:
        return dict(success=False, error="Run Analyze first.")
    steps = int(body.get("steps", 12))
    target = float(body.get("target", 4.0))
    k = body.get("knobs", {})
    regime = body.get("regime", "full")
    # §3b: distilled regime is incompatible with caching -> force cache off
    ci = int(k.get("cache_interval", 1))
    if regime == "distilled":
        ci = 1
    cfg = StackConfig(prune_keep=float(k.get("prune_keep", 1.0)),
                      quant_bits=int(k.get("quant_bits", 16)),
                      cache_interval=ci,
                      dist_gpus=int(k.get("dist_gpus", 1)),
                      regime=regime)
    before = lat_h.param_count(_STATE["base"], only_alive=False)
    result = A.apply(_STATE["base"], _RecShim(cfg), _STATE["objective"], _STATE["data_iter"], DEVICE)
    after = lat_h.param_count(result["model"], only_alive=True)

    torch.save({"state_dict": result["model"].state_dict(),
                "config": vars(cfg), "cache_interval": result["cache_policy"].interval},
               OUT_DIR / "optimized_model.pt")
    from .orchestrator import config_speedup
    achieved = config_speedup(cfg, steps)
    render_html(model_name=str(_STATE["config"][0]), target=target, achieved=achieved,
                interaction_pairs=_STATE["interaction"] or [],
                recommendation=dict(knobs=dict(prune=cfg.prune_keep, quant=cfg.quant_bits,
                                               cache=cfg.cache_interval),
                                    rationale=[f"Applied user/recommended config at ~{achieved:.1f}x."],
                                    predicted_error=0.0),
                before={"params": before}, after={"params": after},
                path=str(OUT_DIR / "report.html"))
    return dict(success=True,
                files=dict(optimizedModel=dict(name="optimized_model.pt",
                                               path=str(OUT_DIR / "optimized_model.pt")),
                           report=dict(name="report.html", path=str(OUT_DIR / "report.html"),
                                       url="/results/tool_web/report.html")),
                metadata=dict(before_params=before, after_params=after,
                              achieved_speedup=round(achieved, 2),
                              runtimeNotes=[f"params {before:,} -> {after:,}",
                                            f"~{achieved:.1f}x (FLOPs proxy)"]))


class _RecShim:
    """Adapt a StackConfig into what analyze.apply expects (.config)."""
    def __init__(self, cfg): self.config = cfg


# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # quieter
        pass

    def _send(self, code, payload, ctype="application/json"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload, default=float).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/api/device-resources"):
            return self._send(200, api_device_resources())
        # static files: UI assets from ui/, generated artifacts from results/
        rel = self.path.split("?")[0].lstrip("/") or "index.html"
        root = BASE_DIR if rel.startswith("results/") else UI_DIR
        fp = (root / rel).resolve()
        if str(fp).startswith(str(root)) and fp.is_file():
            ctype = {"html": "text/html", "css": "text/css", "js": "application/javascript",
                     "json": "application/json", "png": "image/png"}.get(fp.suffix[1:], "text/plain")
            return self._send(200, fp.read_bytes(), f"{ctype}; charset=utf-8")
        return self._send(404, {"error": "not found", "path": rel})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        try:
            if self.path.startswith("/api/analyze"):
                return self._send(200, api_analyze(body))
            if self.path.startswith("/api/optimize"):
                return self._send(200, api_optimize(body))
        except Exception as e:
            import traceback; traceback.print_exc()
            return self._send(200, {"success": False, "error": str(e)})
        return self._send(404, {"error": "not found"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=5050)
    ap.add_argument("--open", action="store_true", help="open the browser")
    args = ap.parse_args()
    srv = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    url = f"http://127.0.0.1:{args.port}/index.html"
    print(f"OPTSD tool serving at {url}  (device={DEVICE}) — Ctrl+C to stop")
    if args.open:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()
