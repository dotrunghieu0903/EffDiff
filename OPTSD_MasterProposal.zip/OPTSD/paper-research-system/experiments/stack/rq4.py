"""RQ4 — the NFE boundary k* where distillation beats many-step + caching.

PROPOSAL §4 RQ4: "where does distillation (DMD2) overtake the many-step-with-
caching regime?" We trace two error-vs-speedup curves at a fixed reference
quality and report their crossover k* (the speedup beyond which the distilled
few-step regime has lower error than the best many-step+cache config).

  many-step curve : regime='full', vary cache interval (± quant)   -> (speedup, error)
  distilled curve : regime='distilled', vary quant bits            -> (speedup, error)

Light stand-in (real engines via adapters/dmd2 + adapters/taylorseer on GPU).
"""
from __future__ import annotations

from .axes import StackConfig
from .errormodel import evaluate_config, reference_sample


def _curve(base_model, x_init, y, x_ref, steps, configs, objective, data_iter, device):
    pts = []
    for cfg in configs:
        m = evaluate_config(base_model, cfg, x_init, y, x_ref, steps,
                            objective, data_iter, device)
        pts.append((m["speedup"], m["error"]))
    return sorted(pts)


def find_kstar(base_model, x_init, y, steps, objective=None, data_iter=None,
               device="cpu", verbose=True):
    x_ref = reference_sample(base_model, x_init, y, steps)

    many = _curve(base_model, x_init, y, x_ref, steps, [
        StackConfig(regime="full"),
        StackConfig(regime="full", cache_interval=2),
        StackConfig(regime="full", cache_interval=4),
        StackConfig(regime="full", cache_interval=4, quant_bits=8),
    ], objective, data_iter, device)

    distilled = _curve(base_model, x_init, y, x_ref, steps, [
        StackConfig(regime="distilled"),
        StackConfig(regime="distilled", quant_bits=8),
        StackConfig(regime="distilled", quant_bits=4),
    ], objective, data_iter, device)

    # crossover: smallest speedup where distilled error < interpolated many-step error
    def interp(curve, s):
        if s <= curve[0][0]: return curve[0][1]
        if s >= curve[-1][0]: return curve[-1][1]
        for (s0, e0), (s1, e1) in zip(curve, curve[1:]):
            if s0 <= s <= s1:
                w = (s - s0) / (s1 - s0 + 1e-9)
                return e0 + w * (e1 - e0)
        return curve[-1][1]

    kstar = None
    for s, e in distilled:
        if e < interp(many, s):
            kstar = s
            break

    if verbose:
        print(f"[RQ4] many-step+cache curve (speedup,error): "
              f"{[(round(s,1), round(e,4)) for s, e in many]}")
        print(f"[RQ4] distilled curve: {[(round(s,1), round(e,4)) for s, e in distilled]}")
        print(f"[RQ4] k* (distilled overtakes) = "
              f"{f'{kstar:.1f}x' if kstar else 'no crossover in range'}")
    return dict(many_step=many, distilled=distilled, kstar=kstar)
