"""Distillation regime backed by DMD2 / Phased-DMD (SCAFFOLD — needs GPU + a
distilled checkpoint).

The 'distilled' regime is a step-count MODE, not a stackable axis: a few-step
model that REPLACES the sampling loop. Per PROPOSAL §3b (DisCa) it must NOT be
combined with caching -- the light stand-in in regime.regime_plan already forces
cache off and uses ~4 steps. This adapter swaps that stand-in for a real distilled
model (DMD2 1-step, or Phased-DMD few-step).

References (PROPOSAL §2b): DMD2 (2405.14867), Phased-DMD (2510.27684).
Real integration: load the distilled UNet/DiT and sample at its native NFE.
"""
from __future__ import annotations


def is_available() -> bool:
    return False  # requires a distilled checkpoint + the DMD2 sampling code


def sample(model, x_init, y, steps=4):
    if not is_available():
        raise RuntimeError(
            "DMD2/Phased-DMD not wired. Provide a distilled checkpoint on the GPU box; "
            "the CPU stand-in (regime.regime_plan 'distilled', ~4 steps, cache off) is used "
            "meanwhile.")
    # TODO(GPU): load distilled model, sample at native NFE (1 for DMD2). Report the
    # k* boundary where distilled beats many-step+caching (PROPOSAL RQ4).
    raise NotImplementedError("wire DMD2/Phased-DMD sampling here; see PROPOSAL §2b/RQ4.")
