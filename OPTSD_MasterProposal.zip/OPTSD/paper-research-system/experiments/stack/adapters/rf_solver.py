"""Solver regime backed by RF-Solver (SCAFFOLD — needs the real solver).

The 'solver' regime reduces the number of ODE steps using a higher-order
integrator (RF-Solver, ICML 2025), applied only at full-compute steps. It is a
complementary step-count mode (not a stackable axis) that CAN coexist with the
model-level axes but shares the contested step-count with caching/distillation.

Light stand-in: regime.regime_plan 'solver' just halves the sampler steps. This
adapter swaps in the real RF-Solver update rule for faithful error.

Reference (PROPOSAL §2/§2b): RF-Solver (2411.04746, ICML 2025).
"""
from __future__ import annotations


def is_available() -> bool:
    return False


def sample(model, x_init, y, steps):
    if not is_available():
        raise RuntimeError(
            "RF-Solver not wired. Use the CPU stand-in (regime.regime_plan 'solver', "
            "half-steps Euler) meanwhile; add the real solver update on the GPU box.")
    # TODO(GPU): implement the RF-Solver higher-order update (Taylor on velocity).
    raise NotImplementedError("wire RF-Solver update here; see PROPOSAL §2b.")
