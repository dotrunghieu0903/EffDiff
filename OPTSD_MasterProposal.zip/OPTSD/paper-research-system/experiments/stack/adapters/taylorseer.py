"""Caching axis backed by TaylorSeer / HiCache (SCAFFOLD — needs the real engine).

Replaces the light Taylor-forecast cache in sampler.py with the real
feature-forecast caching (TaylorSeer = Taylor basis; HiCache = Hermite,
plug-in 0-FLOPs on top). Its "derivatives ~ Gaussian" assumption under W4A4 is
the exact knob PROPOSAL RQ1 probes -- which is why the real engine matters for
the interaction study. Not runnable on this CPU session.

References (PROPOSAL §2b):
    TaylorSeer  arXiv 2503.06923   HiCache arXiv 2508.16984
Both ship code operating on FLUX/HunyuanVideo DiTs; integrate at the sampler
level (feature cache across timesteps), not the module level.

Integration contract:
    cached_sampler(model, x_init, y, steps, policy) -> x0   # mirrors sampler.flow_sample
    speedup(policy, steps) -> float                          # forecast steps skipped
"""
from __future__ import annotations


def is_available() -> bool:
    # TaylorSeer/HiCache are usually vendored, not pip packages; detect a marker.
    try:
        import taylorseer  # noqa: F401
        return True
    except Exception:
        return False


def cached_sample(model, x_init, y, steps, policy):
    if not is_available():
        raise RuntimeError(
            "TaylorSeer/HiCache engine not found. Vendor it on the GPU box, or keep "
            "backend='light' (sampler.flow_sample cache) for the CPU study.")
    # ---- TODO (GPU) --------------------------------------------------------
    # 1. Register feature-cache hooks on the real DiT blocks (TaylorSeer caches
    #    block-output features; HiCache adds the Hermite basis on top).
    # 2. Run the real DDIM/flow loop; at forecast steps reuse the Taylor/Hermite
    #    extrapolation instead of a full model call.
    # 3. Return the final latent; speedup = total_steps / computed_steps.
    raise NotImplementedError("wire TaylorSeer/HiCache here; see PROPOSAL §2b.")
