"""SANA backbone/substrate (SCAFFOLD — needs the real SANA model).

SANA is NOT a technique toggle — it is a SUBSTRATE choice (the model you start
from). Changing backbone shrinks the ROI of every axis (§3d: linear attention →
weaker outlier premise for quant; fewer tokens → less pruning benefit; 14-20
steps → smaller caching budget). The demo uses backbones.build_backbone('sana') (fewer
tokens) as a light stand-in; this adapter would load the real SANA/SANA-1.5.

Reference (PROPOSAL §2/§3d): SANA (2410.10629). Avoid SANA-Sprint as substrate
(already distilled → no headroom, §3d note).
"""
from __future__ import annotations


def is_available() -> bool:
    return False


def load(variant="sana-1.5"):
    if not is_available():
        raise RuntimeError(
            "Real SANA not wired. The demo uses backbones.build_backbone('sana') (fewer-token "
            "stand-in). Load the real SANA backbone on the GPU box here.")
    # TODO(GPU): load SANA / SANA-1.5 (linear attention, deep-compression VAE),
    # expose forward(x,t,y) matching MaskableDiT so the axes apply unchanged.
    raise NotImplementedError("wire real SANA backbone here; see PROPOSAL §3d.")
