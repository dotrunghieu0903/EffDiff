"""Pruning axis backed by a LEARNED LAAMP mask from Contribution 1 (full impl).

This is the real axis #1: instead of a magnitude/coupled heuristic, load the
m_star produced by experiments/laamp search (run_pipeline saves pruned masks) and
apply it. This is our own code, so it works on CPU/GPU alike -- no external lib.
"""
from __future__ import annotations

import torch

from ...laamp import apply_hard_mask
from ...laamp.flops import analytic_cost_vector, full_flops


def is_available() -> bool:
    return True


def apply(model, mask_path=None, m_star=None, device="cpu"):
    """Apply a LAAMP mask. Provide either a saved mask file or the tensor.
    Returns (model, speedup) where speedup = full / kept sub-block FLOPs."""
    if m_star is None:
        assert mask_path is not None, "laamp axis needs mask_path or m_star"
        obj = torch.load(mask_path, map_location=device)
        m_star = obj["m_star"] if isinstance(obj, dict) and "m_star" in obj else obj
    m_star = m_star.to(device).float()
    apply_hard_mask(model, m_star)
    c = analytic_cost_vector(model.cfg).to(device)
    kept = (m_star * c).sum().item()
    speedup = full_flops(model.cfg) / max(kept, 1e-6)
    return model, speedup
