"""Quantization axis backed by SVDQuant / Nunchaku (SCAFFOLD — needs GPU + CUDA).

Replaces the fake-quant stand-in with the real W4A4 SVDQuant engine so the
error-interaction study uses genuine 4-bit noise (the source of the quant×cache
compounding hypothesis, PROPOSAL RQ1). CANNOT run/verify on this CPU session;
implement + test on the 4090 (Nunchaku is Ada+; verify on 3090/Ampere per §9).

Install (GPU box):
    pip install nunchaku            # https://github.com/mit-han-lab/nunchaku
Model support: FLUX / SDXL / (PixArt) via Nunchaku's quantized checkpoints.

Integration contract (must match axes.apply_quant):
    apply(model, bits, quant_act=False) -> (quantized_model, speedup_factor)
"""
from __future__ import annotations


def is_available() -> bool:
    try:
        import nunchaku  # noqa: F401
        return True
    except Exception:
        return False


def apply(model, bits: int, quant_act: bool = False):
    if not is_available():
        raise RuntimeError(
            "SVDQuant/Nunchaku not installed. `pip install nunchaku` on the GPU box, "
            "or keep backend='light' (fake-quant) for the CPU interaction study.")
    # ---- TODO (GPU) --------------------------------------------------------
    # 1. Load the Nunchaku SVDQuant version of the backbone (W4A4 + low-rank branch).
    # 2. Return the quantized module wrapped to expose the same forward(x,t,y).
    # 3. speedup: report MEASURED (Nunchaku ~3x latency / ~3.5x memory on FLUX);
    #    do NOT hardcode paper numbers -- measure on 4090 (PROPOSAL §6).
    # Nunchaku sketch:
    #   from nunchaku import NunchakuFluxTransformer2dModel
    #   qmodel = NunchakuFluxTransformer2dModel.from_pretrained("<svdquant-int4-ckpt>")
    raise NotImplementedError(
        "wire Nunchaku SVDQuant here; see the sketch above + PROPOSAL §2b/§6.")
