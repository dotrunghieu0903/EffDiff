"""Real-axis adapter registry (Contribution 2, Part B).

Lets the light CPU stand-ins in axes.py be transparently swapped for the real
CUDA engines when present, without touching errormodel/interaction/orchestrator/
analyze. Default backend for every axis is "light" so the CPU study keeps working.

  axis    light (default)        real backend        module
  prune   magnitude/coupled      LAAMP learned mask  laamp_axis   (full, CPU-ok)
  quant   fake-quant             SVDQuant/Nunchaku   svdquant     (scaffold, GPU)
  cache   Taylor forecast        TaylorSeer/HiCache  taylorseer   (scaffold, GPU)

Usage:
    from experiments.stack import adapters
    adapters.use_backend("quant", "svdquant")   # on the GPU box
    adapters.status()                             # what's active + available
"""
from __future__ import annotations

from . import laamp_axis, svdquant, taylorseer, dmd2, rf_solver, sana

_ACTIVE = {"prune": "light", "quant": "light", "cache": "light",
           "solver": "light", "distilled": "light", "backbone": "light"}

_REGISTRY = {
    "prune": {"laamp": laamp_axis},
    "quant": {"svdquant": svdquant},
    "cache": {"taylorseer": taylorseer},
    "solver": {"rf_solver": rf_solver},     # step-count regime (real engine)
    "distilled": {"dmd2": dmd2},            # step-count regime (real engine)
    "backbone": {"sana": sana},            # substrate (real model)
}


def use_backend(axis: str, name: str):
    assert axis in _ACTIVE, f"unknown axis {axis}"
    if name != "light":
        assert name in _REGISTRY[axis], f"no backend '{name}' for axis '{axis}'"
        if not _REGISTRY[axis][name].is_available():
            raise RuntimeError(f"backend '{name}' for '{axis}' not available on this machine")
    _ACTIVE[axis] = name


def active(axis: str) -> str:
    return _ACTIVE[axis]


def backend_module(axis: str, name: str):
    return _REGISTRY[axis][name]


def status():
    rows = []
    for axis, backs in _REGISTRY.items():
        for name, mod in backs.items():
            rows.append(dict(axis=axis, backend=name, available=mod.is_available(),
                             active=(_ACTIVE[axis] == name)))
    return dict(active=_ACTIVE.copy(), backends=rows)
