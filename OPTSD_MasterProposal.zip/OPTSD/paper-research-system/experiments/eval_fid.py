"""Generate images from a (pruned) MaskableDiT and compute FID.

Two reference modes:
  * torchmetrics  : FID vs a folder/loader of real images you provide. Simplest;
                    good for internal method-vs-method comparison.
  * adm-npz       : match DiT's PUBLISHED numbers -- feed the ADM/guided-diffusion
                    reference stats `VIRTUAL_imagenet256_labeled.npz` and use their
                    evaluator. Needed only for a headline "FID 2.86 vs 2.27" claim.

For the thesis, internal comparison at a FIXED sampler config across all methods
is what backs RQ0a/RQ0b; the ADM path is for the one absolute head-to-head vs
TinyFusion's reported number.

Run:
  python -m experiments.eval_fid --ckpt pruned.pt --n 50000 --cfg 1.5 --steps 50 \\
    --vae stabilityai/sd-vae-ft-ema --real_dir /data/imagenet256_val_images
"""
from __future__ import annotations

import argparse

import torch

from .laamp.dit import DiTConfig, build_model
from .sampling import ddim_sample, decode_latents


def load_vae(name="stabilityai/sd-vae-ft-ema", device="cuda"):
    from diffusers.models import AutoencoderKL
    return AutoencoderKL.from_pretrained(name).to(device).eval()


_REAL_FID_CACHE = {}   # real_dir -> FID module with the reference set already ingested


@torch.no_grad()
def fid_torchmetrics(model, vae, real_dir, n, cfg_scale, steps, batch, device):
    """Compute FID of `model`'s samples vs images in `real_dir`.

    Robust across torchmetrics versions: we ingest the reference set once into a
    FID module, then `copy.deepcopy` it per evaluation and add only the fake side
    (no reliance on internal buffer names). A sweep of many pruned models thus
    ingests the reference only once."""
    import copy
    from torchmetrics.image.fid import FrechetInceptionDistance
    import torchvision.transforms as T
    from torchvision.datasets import ImageFolder
    from torch.utils.data import DataLoader

    key = (real_dir, device)
    if key not in _REAL_FID_CACHE:
        base = FrechetInceptionDistance(feature=2048, normalize=False).to(device)
        tf = T.Compose([T.Resize(256), T.CenterCrop(256), T.PILToTensor()])
        real = DataLoader(ImageFolder(real_dir, transform=lambda im: tf(im.convert("RGB"))),
                          batch_size=batch, num_workers=8)
        for imgs, _ in real:
            base.update(imgs.to(device), real=True)
        _REAL_FID_CACHE[key] = base

    fid = copy.deepcopy(_REAL_FID_CACHE[key])          # reuse real side, public state only
    for imgs in generate(model, vae, n, model.cfg.num_classes, cfg_scale, steps, batch, device):
        fid.update(imgs, real=False)
    return float(fid.compute())


@torch.no_grad()
def generate(model, vae, n, num_classes, cfg_scale, steps, batch, device):
    """Yield uint8 image batches; classes sampled uniformly (n/num_classes each)."""
    done = 0
    per = max(1, n // num_classes)
    labels = torch.arange(num_classes, device=device).repeat_interleave(per)[:n]
    while done < n:
        y = labels[done: done + batch]
        if len(y) == 0:
            y = torch.randint(0, num_classes, (batch,), device=device)
        lat = ddim_sample(model, len(y), y, cfg_scale=cfg_scale, steps=steps, device=device)
        yield decode_latents(vae, lat, device)
        done += len(y)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True, help="pruned+recovered MaskableDiT state_dict")
    ap.add_argument("--config", default="dit_xl")
    ap.add_argument("--vae", default="stabilityai/sd-vae-ft-ema")
    ap.add_argument("--n", type=int, default=50000)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--cfg", type=float, default=1.5)
    ap.add_argument("--steps", type=int, default=50)
    ap.add_argument("--mode", choices=["torchmetrics", "adm-npz"], default="torchmetrics")
    ap.add_argument("--real_dir", default=None, help="folder of real images (torchmetrics mode)")
    ap.add_argument("--save_dir", default=None, help="optional: dump generated PNGs here")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DiTConfig.dit_xl_2() if args.config == "dit_xl" else DiTConfig.tiny()
    model = build_model(cfg).to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device), strict=False)

    from diffusers.models import AutoencoderKL
    vae = AutoencoderKL.from_pretrained(args.vae).to(device).eval()

    if args.mode == "torchmetrics":
        from torchmetrics.image.fid import FrechetInceptionDistance
        import torchvision.transforms as T
        from torchvision.datasets import ImageFolder
        from torch.utils.data import DataLoader

        fid = FrechetInceptionDistance(feature=2048, normalize=False).to(device)
        # real
        assert args.real_dir, "torchmetrics mode needs --real_dir"
        tf = T.Compose([T.Resize(256), T.CenterCrop(256),
                        T.PILToTensor()])  # uint8
        real = DataLoader(ImageFolder(args.real_dir, transform=lambda im: tf(im.convert("RGB"))),
                          batch_size=args.batch, num_workers=8)
        for imgs, _ in real:
            fid.update(imgs.to(device), real=True)
        # fake
        seen = 0
        for imgs in generate(model, vae, args.n, cfg.num_classes, args.cfg,
                             args.steps, args.batch, device):
            fid.update(imgs, real=False)
            seen += imgs.shape[0]
            if seen % (args.batch * 20) == 0:
                print(f"  generated {seen}/{args.n}")
        print(f"FID = {float(fid.compute()):.4f}  (n={seen}, cfg={args.cfg}, steps={args.steps})")

    else:  # adm-npz
        print("ADM mode: save 50k PNGs then run guided-diffusion evaluator against")
        print("VIRTUAL_imagenet256_labeled.npz -- see GPU_RUNBOOK.md step 6b.")
        import numpy as np, os
        os.makedirs(args.save_dir or "samples", exist_ok=True)
        from PIL import Image
        k = 0
        for imgs in generate(model, vae, args.n, cfg.num_classes, args.cfg,
                             args.steps, args.batch, device):
            for im in imgs.permute(0, 2, 3, 1).cpu().numpy():
                Image.fromarray(im).save(f"{args.save_dir or 'samples'}/{k:06d}.png")
                k += 1
        print(f"wrote {k} PNGs -> run ADM evaluator next")


if __name__ == "__main__":
    main()
