"""Wall-clock latency + peak-memory measurement (CONTRIB1 Section 4.4).

Separates *theoretical compression* (FLOPs, from flops.py) from *measured
wall-clock*, which is the metric that actually matters and must be reported on
the real 3090/4090 -- never copied from a paper measured on datacenter GPUs
(PROPOSAL Section 6).
"""
from __future__ import annotations

import time
from contextlib import contextmanager

import torch


@contextmanager
def _sync(device):
    if device.type == "cuda":
        torch.cuda.synchronize()
    yield
    if device.type == "cuda":
        torch.cuda.synchronize()


@torch.no_grad()
def measure_latency(model, sample_fn, device, warmup=5, iters=20):
    """sample_fn() -> (x, t, y) forward inputs. Returns dict(ms_mean, ms_std)."""
    model.eval().to(device)
    device = torch.device(device)
    for _ in range(warmup):
        model(*sample_fn())
    with _sync(device):
        pass
    times = []
    for _ in range(iters):
        x = sample_fn()
        with _sync(device):
            t0 = time.perf_counter()
            model(*x)
        times.append((time.perf_counter() - t0) * 1000)
    t = torch.tensor(times)
    return dict(ms_mean=float(t.mean()), ms_std=float(t.std()), iters=iters)


@torch.no_grad()
def measure_peak_memory(model, sample_fn, device):
    """Peak allocated MB during one forward. CUDA only; returns None on CPU."""
    device = torch.device(device)
    if device.type != "cuda":
        return None
    model.eval().to(device)
    torch.cuda.reset_peak_memory_stats(device)
    model(*sample_fn())
    torch.cuda.synchronize(device)
    return torch.cuda.max_memory_allocated(device) / (1024 ** 2)


def param_count(model, only_alive=True):
    """Count params; if only_alive, skip sub-blocks marked not-alive (post-prune)."""
    from ..laamp.dit import DiTBlock
    total = 0
    dead = set()
    if only_alive:
        for blk in model.blocks:
            if not blk.alive_attn:
                dead.update(id(p) for p in blk.attn.parameters())
            if not blk.alive_mlp:
                dead.update(id(p) for p in blk.mlp.parameters())
    for p in model.parameters():
        if id(p) not in dead:
            total += p.numel()
    return total
