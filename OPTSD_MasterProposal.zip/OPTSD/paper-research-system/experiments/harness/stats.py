"""Statistical tests for method comparison (CONTRIB1 Section 4.4 / Section 5).

Paired bootstrap CI on the metric difference + Wilcoxon signed-rank, so a claim
like "LAAMP FID < TinyFusion" is backed by p<0.05 over >=3 seeds rather than a
single lucky run.
"""
from __future__ import annotations

import numpy as np


def paired_bootstrap_diff(a, b, n_boot=10000, seed=0, alpha=0.05):
    """Bootstrap CI for mean(a - b). a, b: per-seed metric arrays (a=method,
    b=baseline). Negative mean_diff => a is better when metric is lower-is-better
    (e.g. FID). Returns dict with mean_diff, ci_low, ci_high, prob_a_better."""
    rng = np.random.default_rng(seed)
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    n = len(d)
    boots = np.array([rng.choice(d, n, replace=True).mean() for _ in range(n_boot)])
    lo, hi = np.quantile(boots, [alpha / 2, 1 - alpha / 2])
    return dict(mean_diff=float(d.mean()), ci_low=float(lo), ci_high=float(hi),
                prob_a_lower=float((boots < 0).mean()), n=n)


def wilcoxon_test(a, b):
    from scipy import stats
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 3 or np.allclose(a, b):
        return dict(pvalue=float("nan"), note="need >=3 differing pairs")
    res = stats.wilcoxon(a, b)
    return dict(statistic=float(res.statistic), pvalue=float(res.pvalue))


def relative_improvement(method_metric, baseline_metric):
    """% relative reduction (lower-is-better metric). CONTRIB1 Section 5 uses a
    >=5% relative FID reduction threshold for RQ0a success."""
    m, b = np.mean(method_metric), np.mean(baseline_metric)
    return float((b - m) / b * 100.0)
