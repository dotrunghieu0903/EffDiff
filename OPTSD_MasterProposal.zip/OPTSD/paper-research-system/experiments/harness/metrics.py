"""Quality metric wrappers (CONTRIB1 Section 4.4).

FID/IS/CLIP/ImageReward/LPIPS need heavy extra deps + real images, so they are
imported lazily and each raises a clear install hint if missing. For the CPU
smoke test (no image data / no inception) we use `denoise_proxy`, a cheap
held-out denoise loss that stands in for quality while validating the pipeline
logic end-to-end. On the real 3090/4090 runs you call the real metrics.
"""
from __future__ import annotations

import torch


@torch.no_grad()
def denoise_proxy(model, objective, data_iter, n_batches=32):
    """Held-out mean denoise loss -- a monotone proxy for sample quality used to
    validate the harness before real FID is wired in. LOWER is better."""
    model.eval()
    tot, n = 0.0, 0
    for _ in range(n_batches):
        x0, y = next(data_iter)
        tot += float(objective.loss(model, x0, y)); n += 1
    return tot / max(n, 1)


def _hint(pkg, extra=""):
    raise ImportError(f"metric needs `{pkg}`. Install: pip install {pkg}. {extra}")


class FID:
    """torchmetrics FrechetInceptionDistance wrapper. Feed uint8 [0,255] images."""

    def __init__(self, device="cuda", feature=2048):
        try:
            from torchmetrics.image.fid import FrechetInceptionDistance
        except ImportError:
            _hint("torchmetrics[image]")
        self.m = FrechetInceptionDistance(feature=feature, normalize=False).to(device)
        self.device = device

    def update(self, imgs, real: bool):
        self.m.update(imgs.to(self.device), real=real)

    def compute(self):
        return float(self.m.compute())


def clip_score(images, prompts, device="cuda"):
    try:
        from torchmetrics.functional.multimodal import clip_score as _cs
    except ImportError:
        _hint("torchmetrics[multimodal]")
    return float(_cs(images.to(device), prompts, "openai/clip-vit-base-patch16"))


def image_reward(images_paths, prompts):
    """ImageReward score (T2I). Requires `image-reward`."""
    try:
        import ImageReward as RM
    except ImportError:
        _hint("image-reward", "see github.com/THUDM/ImageReward")
    model = RM.load("ImageReward-v1.0")
    return [model.score(p, img) for p, img in zip(prompts, images_paths)]


def lpips_psnr(gen, ref, device="cuda"):
    """Structural distortion vs the original (un-pruned) model's samples."""
    try:
        import lpips as _lpips
    except ImportError:
        _hint("lpips")
    loss_fn = _lpips.LPIPS(net="alex").to(device)
    l = float(loss_fn(gen.to(device), ref.to(device)).mean())
    mse = torch.mean((gen - ref) ** 2).item()
    psnr = float(-10 * torch.log10(torch.tensor(mse + 1e-12)))
    return dict(lpips=l, psnr=psnr)
