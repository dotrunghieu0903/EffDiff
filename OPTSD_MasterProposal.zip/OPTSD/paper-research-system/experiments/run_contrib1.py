"""Contribution-1 experiment runner: LAAMP vs baselines at iso-FLOPs.

Implements TN-2 (RQ0a: asymmetric vs monolithic) and TN-3 (RQ0b: learned vs
fixed criterion) from CONTRIB1 Section 4.5. For each method it:
  1. obtains a hard sub-block mask m* at the target FLOPs budget,
  2. physically removes dropped sub-blocks,
  3. runs the SAME recovery budget (fairness),
  4. evaluates held-out quality (denoise proxy here; real FID on GPU),
and finally runs the paired-bootstrap / Wilcoxon comparison across seeds.

Usage (CPU smoke): python -m experiments.run_contrib1 --config tiny --steps 300
Real run (GPU):    python -m experiments.run_contrib1 --config dit_xl --latents /path
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import torch

from .laamp import (DiTConfig, build_model, build_objective, SearchConfig,
                    run_search, apply_hard_mask, recover, asymmetry_index,
                    kept_counts, baselines)
from .laamp.flops import full_flops
from .harness import metrics, stats
from .data import synthetic_iter, latent_folder_iter


# tinyfusion = LEARNED coupled mask (TinyFusion reproduction, primary RQ0a control).
# coupled    = magnitude-coupled heuristic (weak reference only, NOT TinyFusion).
METHODS = ["laamp", "tinyfusion", "coupled", "magnitude", "taylor", "random", "uniform"]


def make_data(args, seed, device):
    if args.latents:
        return latent_folder_iter(args.latents, batch=args.batch, device=device)
    return synthetic_iter(batch=args.batch, channels=args.channels,
                          size=args.size, num_classes=args.classes,
                          seed=seed, device=device)


def get_mask(method, model, keep_ratio, objective, data_iter, seed, device, search_steps):
    """Return (m_star, extra) where extra holds search info for LAAMP."""
    if method == "laamp":
        scfg = SearchConfig(keep_ratio=keep_ratio, n_steps=search_steps, coupled=False)
        res = run_search(copy.deepcopy(model), objective, data_iter, scfg, device, verbose=False)
        return res["m_star"], {"achieved": res["achieved_flops"]}
    if method in ("laamp_coupled", "tinyfusion"):
        # TinyFusion reproduction (VainF/TinyFusion): LEARNED depth mask via the
        # SAME Gumbel+STE+LoRA-recoverability machinery, but coupled m_attn==m_mlp
        # (whole-block decision). This is the primary RQ0a control -- LAAMP minus
        # the asymmetry -- NOT the magnitude 'coupled' baseline.
        scfg = SearchConfig(keep_ratio=keep_ratio, n_steps=search_steps, coupled=True)
        res = run_search(copy.deepcopy(model), objective, data_iter, scfg, device, verbose=False)
        return res["m_star"], {"achieved": res["achieved_flops"]}
    m = baselines.select(method, model, keep_ratio, objective=objective,
                         data_iter=data_iter, seed=seed, device=device)
    return m, {}


def run_one(method, base_state, cfg, keep_ratio, objective, args, seed, device):
    torch.manual_seed(seed)
    model = build_model(cfg).to(device)
    model.load_state_dict(base_state)

    data_iter = make_data(args, seed, device)
    m_star, extra = get_mask(method, model, keep_ratio, objective, data_iter,
                             seed, device, args.search_steps)

    # fresh copy for prune+recover so the search LoRA doesn't leak
    model = build_model(cfg).to(device)
    model.load_state_dict(base_state)
    removed = apply_hard_mask(model, m_star)
    recover(model, objective, make_data(args, seed + 100, device),
            n_steps=args.recover_steps, lr=args.recover_lr, device=device, verbose=False)

    q = metrics.denoise_proxy(model, objective, make_data(args, seed + 999, device),
                              n_batches=args.eval_batches)
    depth = cfg.depth
    return {
        "method": method, "seed": seed, "keep_ratio": keep_ratio,
        "quality_proxy": q,
        "asymmetry": asymmetry_index(m_star, depth),
        "kept": kept_counts(m_star, depth),
        **extra,
    }


def pretrain_base(cfg, objective, args, device):
    """Quick base-model training so pruning has a meaningful model to cut.
    On real runs you load a released checkpoint instead (skip this)."""
    model = build_model(cfg).to(device)
    it = make_data(args, seed=0, device=device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    model.train()
    for step in range(args.pretrain_steps):
        x0, y = next(it)
        loss = objective.loss(model, x0, y)
        opt.zero_grad(); loss.backward(); opt.step()
        if step % 100 == 0:
            print(f"[pretrain] step={step} loss={loss.item():.4f}")
    return model.state_dict()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", choices=["tiny", "dit_xl"], default="tiny")
    ap.add_argument("--methods", nargs="+", default=["laamp", "tinyfusion", "random"])
    ap.add_argument("--keep_ratios", nargs="+", type=float, default=[0.5])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--objective", choices=["flow", "ddpm"], default="flow")
    ap.add_argument("--latents", default=None, help="folder of .pt latent shards (real run)")
    ap.add_argument("--ckpt", default=None, help="pretrained state_dict (.pt); else pretrain")
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--channels", type=int, default=4)
    ap.add_argument("--size", type=int, default=8)
    ap.add_argument("--classes", type=int, default=4)
    ap.add_argument("--pretrain_steps", type=int, default=400)
    ap.add_argument("--search_steps", type=int, default=300)
    ap.add_argument("--recover_steps", type=int, default=200)
    ap.add_argument("--recover_lr", type=float, default=5e-4)
    ap.add_argument("--eval_batches", type=int, default=16)
    ap.add_argument("--out", default="experiments/results/contrib1.json")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DiTConfig.dit_xl_2() if args.config == "dit_xl" else DiTConfig.tiny()
    if args.config == "tiny":
        args.channels, args.size, args.classes = cfg.in_channels, cfg.input_size, cfg.num_classes
    objective = build_objective(args.objective, device)
    print(f"device={device} config={args.config} full_flops={full_flops(cfg):.3e} MACs")

    if args.ckpt:
        base_state = torch.load(args.ckpt, map_location=device)
    else:
        base_state = pretrain_base(cfg, objective, args, device)

    results = []
    for kr in args.keep_ratios:
        for method in args.methods:
            for seed in args.seeds:
                r = run_one(method, base_state, cfg, kr, objective, args, seed, device)
                print(f"  keep={kr} {method:10s} seed={seed} "
                      f"quality={r['quality_proxy']:.4f} A={r['asymmetry']:.3f} "
                      f"kept={r['kept']}")
                results.append(r)

    # ---- comparisons (per keep_ratio, LAAMP vs each baseline) --------------
    comparisons = []
    for kr in args.keep_ratios:
        def q(m):
            return [x["quality_proxy"] for x in results
                    if x["method"] == m and x["keep_ratio"] == kr]
        if "laamp" in args.methods and q("laamp"):
            for baseline in args.methods:
                if baseline == "laamp" or not q(baseline):
                    continue
                bs = stats.paired_bootstrap_diff(q("laamp"), q(baseline))
                wc = stats.wilcoxon_test(q("laamp"), q(baseline))
                rel = stats.relative_improvement(q("laamp"), q(baseline))
                comparisons.append(dict(keep_ratio=kr, vs=baseline,
                                        rel_improvement_pct=rel, **bs, wilcoxon=wc))
                print(f"[cmp] keep={kr} LAAMP vs {baseline}: rel={rel:+.1f}% "
                      f"mean_diff={bs['mean_diff']:+.4f} "
                      f"CI=[{bs['ci_low']:+.4f},{bs['ci_high']:+.4f}] "
                      f"p(lower)={bs['prob_a_lower']:.2f}")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(dict(args=vars(args), results=results,
                                   comparisons=comparisons), indent=2))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
