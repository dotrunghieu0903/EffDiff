"""Unified validation harness — ONE file/command checks BOTH contributions'
hypotheses and emits PASS/FAIL against the proposal.

    python -m experiments.validate --config experiments/configs/validate.yaml

Checks:
  Contribution 1 (LAAMP)
    RQ0a  asymmetric (LAAMP) beats learned-coupled (tinyfusion) at iso-FLOPs,
          and the learned mask is actually asymmetric (A>0).
    RQ0b  learned (LAAMP) beats the best FIXED criterion (taylor/obs/magnitude).
  Contribution 2 (error-aware stack)
    H1    error-aware / coordinated stacking ≤ naive sequential (measured).
    RQ4   there is an NFE boundary k* where distillation overtakes many-step+cache.

IMPORTANT: on `mode: tiny` (CPU, synthetic data) this is a LOGIC check — it
mechanically evaluates each criterion, but random-data toys have no real
recoverability/interaction structure, so a FAIL there is not scientific evidence.
Real verdicts come from `mode: dit_xl` on the GPU (same file, same criteria).
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
import yaml

from .laamp import (DiTConfig, build_model, build_objective, apply_hard_mask,
                    recover, asymmetry_index)
from .data import synthetic_iter, latent_folder_iter
from .harness import metrics
from .run_pipeline import get_mask
from .stack import orchestrator as O, rq4 as R4
from .stack.errormodel import reference_sample


def g(d, p, default=None):
    cur = d
    for k in p.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def log(m): print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)
def banner(s): print("\n" + "=" * 64 + f"\n== {s}\n" + "=" * 64, flush=True)


# --------------------------------------------------------------------------
def _base_and_data(cfg, device):
    mode = g(cfg, "mode", "tiny")
    mcfg = DiTConfig.tiny() if mode == "tiny" else DiTConfig.dit_xl_2()
    objective = build_objective("flow" if mode == "tiny" else "ddpm", device)
    df = (lambda s=0: synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                                     num_classes=mcfg.num_classes, seed=s, device=device)) \
        if mode == "tiny" else \
        (lambda s=0: latent_folder_iter(g(cfg, "latents"), batch=g(cfg, "batch", 32), device=device))
    model = build_model(mcfg).to(device)
    if mode == "dit_xl" and g(cfg, "base_state"):
        model.load_state_dict(torch.load(g(cfg, "base_state"), map_location=device), strict=False)
    else:
        opt = torch.optim.AdamW(model.parameters(), lr=1e-3); model.train()
        it = df(0)
        for _ in range(g(cfg, "pretrain_steps", 250)):
            loss = objective.loss(model, *next(it)); opt.zero_grad(); loss.backward(); opt.step()
    return mcfg, objective, df, model


# --------------------------------------------------------------------------
def contrib1(cfg, mcfg, objective, df, base_state, device):
    kr = g(cfg, "c1.keep_ratio", 0.5)
    seeds = g(cfg, "c1.seeds", [0, 1, 2])
    methods = ["laamp", "tinyfusion", "taylor", "obs", "magnitude", "random"]
    ss, rs = g(cfg, "c1.search_steps", 150), g(cfg, "c1.recover_steps", 80)
    scores = {m: [] for m in methods}
    asym = {m: [] for m in methods}
    for m in methods:
        for s in seeds:
            torch.manual_seed(s)
            model = build_model(mcfg).to(device); model.load_state_dict(base_state, strict=False)
            mstar, _ = get_mask(m, model, kr, objective, df(s), s, device, ss, {})
            model = build_model(mcfg).to(device); model.load_state_dict(base_state, strict=False)
            apply_hard_mask(model, mstar)
            recover(model, objective, df(s + 100), n_steps=rs, lr=5e-4, device=device, verbose=False)
            q = metrics.denoise_proxy(model, objective, df(s + 900), n_batches=8)
            scores[m].append(q); asym[m].append(asymmetry_index(mstar, mcfg.depth))
            log(f"  C1 {m:10s} seed={s} score={q:.4f} A={asym[m][-1]:.2f}")
    mean = {m: sum(v) / len(v) for m, v in scores.items()}
    fixed = min(mean["taylor"], mean["obs"], mean["magnitude"])
    rq0a = mean["laamp"] < mean["tinyfusion"] and (sum(asym["laamp"]) / len(asym["laamp"])) > 1e-3
    rq0b = mean["laamp"] < fixed
    return dict(mean=mean, asym={m: sum(v) / len(v) for m, v in asym.items()},
                RQ0a=bool(rq0a), RQ0b=bool(rq0b))


# --------------------------------------------------------------------------
def contrib2(cfg, device):
    mcfg = DiTConfig.tiny()
    objective = build_objective("flow", device)
    it = synthetic_iter(batch=8, channels=mcfg.in_channels, size=mcfg.input_size,
                        num_classes=mcfg.num_classes, device=device)
    model = build_model(mcfg).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3); model.train()
    for _ in range(g(cfg, "pretrain_steps", 250)):
        loss = objective.loss(model, *next(it)); opt.zero_grad(); loss.backward(); opt.step()
    steps = g(cfg, "c2.steps", 20)
    x = torch.randn(g(cfg, "c2.n_probe", 16), mcfg.in_channels, mcfg.input_size, mcfg.input_size, device=device)
    y = torch.randint(0, mcfg.num_classes, (x.shape[0],), device=device)

    prof = O.profile(model, x, y, steps, objective=objective, data_iter=it, device=device, verbose=False)
    cmp = O.compare_planners(model, prof, x, y, steps, g(cfg, "c2.target", 4.0),
                             objective=objective, data_iter=it, device=device)
    kk = R4.find_kstar(model, x, y, steps, objective=objective, data_iter=it, device=device, verbose=True)

    na = cmp.get("naive", {}).get("measured_error")
    best_alt = min(v.get("measured_error", float("inf")) for k, v in cmp.items()
                   if k in ("error_aware", "coordinated") and isinstance(v, dict) and v.get("feasible"))
    h1 = (na is not None) and best_alt <= na + 1e-6
    return dict(orchestrator=cmp, kstar=kk["kstar"], H1=bool(h1),
                naive_error=na, best_alt_error=best_alt)


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="experiments/configs/validate.yaml")
    args = ap.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text()) if Path(args.config).exists() else {}
    device = "cuda" if torch.cuda.is_available() and g(cfg, "device") != "cpu" else "cpu"
    out = Path(g(cfg, "output_dir", "experiments/results/validate")); out.mkdir(parents=True, exist_ok=True)
    mode = g(cfg, "mode", "tiny")
    log(f"validate mode={mode} device={device}")

    banner("CONTRIBUTION 1 — LAAMP (RQ0a / RQ0b)")
    mcfg, objective, df, base = _base_and_data(cfg, device)
    c1 = contrib1(cfg, mcfg, objective, df, base.state_dict(), device)

    banner("CONTRIBUTION 2 — error-aware stack (H1 / RQ4)")
    c2 = contrib2(cfg, device)

    result = dict(mode=mode, device=device, contrib1=c1, contrib2=c2)
    (out / "validation.json").write_text(json.dumps(result, indent=2, default=float), encoding="utf-8")
    write_report(out, result)
    banner("VALIDATION DONE"); log(f"report -> {out/'VALIDATION.md'}")


def write_report(out, r):
    def mark(b): return "✅ PASS" if b else "❌ FAIL"
    c1, c2 = r["contrib1"], r["contrib2"]
    tiny = r["mode"] == "tiny"
    L = [f"# Validation report — mode `{r['mode']}` (device {r['device']})", ""]
    if tiny:
        L += ["> ⚠️ **tiny/synthetic = LOGIC check only.** Criteria are evaluated "
              "mechanically; random-data toys have no real structure, so a FAIL here "
              "is NOT scientific evidence. Run `mode: dit_xl` on GPU for real verdicts.", ""]
    L += ["## Contribution 1 — LAAMP", "",
          "| hypothesis | verdict |", "|---|---|",
          f"| RQ0a — asymmetric > learned-coupled (TinyFusion), mask A>0 | {mark(c1['RQ0a'])} |",
          f"| RQ0b — learned > best fixed criterion | {mark(c1['RQ0b'])} |", "",
          "scores (lower=better): " + ", ".join(f"{k}={v:.4f}" for k, v in c1["mean"].items()),
          "", f"LAAMP asymmetry A = {c1['asym']['laamp']:.3f}", "",
          "## Contribution 2 — error-aware stack", "",
          "| hypothesis | verdict |", "|---|---|",
          f"| H1 — error-aware/coordinated ≤ naive stacking | {mark(c2['H1'])} |",
          f"| RQ4 — distillation crossover k* exists | {'✅ k*=%.1fx' % c2['kstar'] if c2['kstar'] else '— none in range'} |",
          "", f"naive error={c2['naive_error']:.4f}, best error-aware/coordinated={c2['best_alt_error']:.4f}"]
    (out / "VALIDATION.md").write_text("\n".join(L), encoding="utf-8")


if __name__ == "__main__":
    main()
