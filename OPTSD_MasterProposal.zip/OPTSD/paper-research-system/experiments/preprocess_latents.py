"""Pre-encode ImageNet-256 to SD-VAE latents as .pt shards (DiT-XL/2 convention).

DiT trains in latent space: image 256x256 -> SD-VAE (/8) -> latent 32x32x4,
scaled by 0.18215. We cache these once so training/search never touches the VAE.
Output: <out>/shard_{k}.pt each {"latent": (N,4,32,32) f16/f32, "label": (N,)}.

Deps (GPU box):  pip install diffusers torchvision pillow
Run:
  python -m experiments.preprocess_latents \\
    --imagenet /data/imagenet/train --out /data/imagenet256_sdvae_latents \\
    --vae stabilityai/sd-vae-ft-ema --shard_size 10000 --img 256
"""
from __future__ import annotations

import argparse
from pathlib import Path

import torch


def encode_imagenet(imagenet, out, vae="stabilityai/sd-vae-ft-ema", img=256,
                    batch=64, shard_size=10000, dtype="fp16", num_workers=8):
    """Encode an ImageFolder to SD-VAE latent shards. Callable from run_pipeline."""
    import torchvision.transforms as T
    from torchvision.datasets import ImageFolder
    from torch.utils.data import DataLoader
    from diffusers.models import AutoencoderKL

    device = "cuda" if torch.cuda.is_available() else "cpu"
    td = torch.float16 if dtype == "fp16" else torch.float32

    tf = T.Compose([
        T.Lambda(lambda im: im.convert("RGB")),
        T.Resize(img), T.CenterCrop(img),
        T.ToTensor(), T.Normalize([0.5] * 3, [0.5] * 3),
    ])
    ds = ImageFolder(imagenet, transform=tf)
    dl = DataLoader(ds, batch_size=batch, num_workers=num_workers, shuffle=False)
    vae_m = AutoencoderKL.from_pretrained(vae).to(device).eval()
    outp = Path(out); outp.mkdir(parents=True, exist_ok=True)

    buf_lat, buf_lab, shard_k, n = [], [], 0, 0

    def flush():
        nonlocal buf_lat, buf_lab, shard_k
        if not buf_lat:
            return
        torch.save({"latent": torch.cat(buf_lat).to(td), "label": torch.cat(buf_lab)},
                   outp / f"shard_{shard_k:04d}.pt")
        print(f"  wrote shard_{shard_k:04d}.pt ({sum(x.shape[0] for x in buf_lat)} imgs)")
        buf_lat, buf_lab, shard_k = [], [], shard_k + 1

    with torch.no_grad():
        for imgs, labels in dl:
            lat = vae_m.encode(imgs.to(device)).latent_dist.sample().mul_(0.18215).cpu()
            buf_lat.append(lat); buf_lab.append(labels); n += imgs.shape[0]
            if sum(x.shape[0] for x in buf_lat) >= shard_size:
                flush()
    flush()
    print(f"done: {n} images -> {shard_k} shards under {outp}")
    return shard_k


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--imagenet", required=True, help="ImageFolder root (class subdirs)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--vae", default="stabilityai/sd-vae-ft-ema")
    ap.add_argument("--img", type=int, default=256)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--shard_size", type=int, default=10000)
    ap.add_argument("--dtype", choices=["fp16", "fp32"], default="fp16")
    args = ap.parse_args()
    encode_imagenet(args.imagenet, args.out, args.vae, args.img, args.batch,
                    args.shard_size, args.dtype)


if __name__ == "__main__":
    main()
