# ĐỀ CƯƠNG NGHIÊN CỨU B (PROPOSAL-B) — Nhánh Hopper / FA-3
## Thực thi full-low-precision cho Diffusion: co-design quản outlier FP8-attention × W4A4-weight
### *Unified Low-Precision Execution for Diffusion Transformers: Co-designing FP8 Attention and 4-bit Weights on Hopper*

**Ngày:** 18/07/2026 · **Quan hệ:** *nhánh song sinh* của [PROPOSAL.md](PROPOSAL.md) (Proposal A). A nhắm **1-GPU tiêu dùng (3090/4090), độ trễ**; B nhắm **H100/datacenter, thông lượng serving** — khác phần cứng, khác mục tiêu, khác đóng góp lõi.

> ⚠️ **Điều kiện tiên quyết:** cần truy cập **NVIDIA H100 (Hopper)** — thuê cloud (~vài USD/GPU-giờ) hoặc cluster. Nếu KHÔNG có Hopper, phần lõi (FA-3 FP8 async) **không kiểm chứng được** → chọn Proposal A. Đây là rẽ nhánh *phụ thuộc tài nguyên*, không phải bắt buộc.

---

## 1. Vì sao FA-3 mở ra một work riêng (không gộp được vào A)
FA-3 chỉ chạy nhanh trên Hopper vì dựa vào **WGMMA async + TMA + FP8 tensor core** — những thứ Ada (4090) không có. Ba năng lực Hopper-only tạo ra không gian nghiên cứu mà 3090/4090 không chạm tới:
1. **FP8 attention "chính xác"** (block quantization + incoherent processing) chạy ở tốc độ ~1.2 PFLOPs/s — cho phép **cả attention lẫn GEMM đều low-precision** trong một pipeline.
2. **Bất đồng bộ (warp-specialization, ping-pong)** — chồng lấp compute/data movement, nền cho **serving thông lượng cao**.
3. Kết hợp tự nhiên với **đa-GPU (xDiT/DistriFusion)** cho serving nhiều node.

## 2. Đóng góp lõi (khác hẳn A): co-design quản outlier HAI TẦNG
Đây là câu hỏi chưa ai trả lời, chỉ khả thi trên Hopper:

- **FA-3** quản outlier *activation attention* bằng **incoherent processing** = nhân Q,K với **ma trận trực giao ngẫu nhiên** để "trải" outlier trước khi lượng tử FP8.
- **SVDQuant** quản outlier *trọng số* bằng **nhánh low-rank 16-bit** hút outlier, phần dư W4A4.
- **Giả thuyết H-B:** khi bật đồng thời (FP8-attention + W4A4-weight), hai cơ chế quản outlier ở hai tầng **tương tác**: phép quay của FA-3 có thể (a) *cộng hưởng* — làm activation vào lớp lượng tử "hiền" hơn, hoặc (b) *triệt tiêu* — phá cấu trúc outlier mà nhánh low-rank của SVDQuant giả định. **Chưa ai đo.**

## 3. Câu hỏi nghiên cứu
- **RQ-B1:** Incoherent processing (rotation, FA-3) và low-rank absorption (SVDQuant) cộng hưởng hay triệt tiêu? Có nên **chia sẻ một phép quay chung** cho cả attention và weight không?
- **RQ-B2:** Pipeline **full-FP8/INT4** (FP8 attention + W4A4 GEMM + FP8 activation khác) đạt ngưỡng chất lượng nào ở thông lượng tối đa trên H100?
- **RQ-B3:** Lịch bất đồng bộ của FA-3 có che được overhead nhánh low-rank của SVDQuant (Nunchaku) khi hợp kernel không?
- **RQ-B4:** Ghép thêm caching (TaylorSeer) + đa-GPU (xDiT) cho **serving**: thông lượng ảnh/s/GPU đạt bao nhiêu ở chất lượng gần gốc?

## 4. Phương pháp
1. **Hợp nhất kernel:** tích hợp FA-3 (FP8 attention) với Nunchaku (W4A4 weight) trong một forward — điều tra chia sẻ phép quay trực giao (RQ-B1).
2. **Bộ quản outlier hợp nhất:** một scheme rotation/scale phối hợp giữa tầng attention và tầng weight thay vì mỗi bên tự xử.
3. **Pipeline serving:** FA-3 × SVDQuant × TaylorSeer × xDiT; đo thông lượng + độ trễ đuôi (p99) trên 1×H100 và multi-H100.
4. **Phân tích tương tác sai số FP8↔W4A4** (đóng góp khoa học chính của B).

## 5. Kế hoạch đánh giá
- **Phần cứng:** 1×H100 (chính), 2–8×H100 (serving scale). Đo lại toàn bộ, không copy số gốc.
- **Model:** FLUX.1-dev, SD3, HunyuanVideo (Hopper đủ mạnh cho video).
- **Chỉ số:** FID/ImageReward/CLIP + **thông lượng (img/s/GPU)**, độ trễ p50/p99, MFU, sai số số học FP8.
- **Baseline:** FA-3 FP16, SVDQuant đơn lẻ, ghép không co-design, xDiT thuần.
- **Mục tiêu:** thông lượng serving cao nhất ở chất lượng gần gốc + **bản đồ tương tác FP8-attention × W4A4-weight** (cái chưa ai công bố).

## 6. Khả thi & rủi ro
- **Khả thi kỹ thuật:** FA-3 (mã nguồn mở trong FlashAttention/CUTLASS), Nunchaku (mở), xDiT (mở) — đều composable; rào cản chính là **kỹ thuật merge kernel CUDA** hai hệ.
- **Khả thi tài nguyên:** phụ thuộc **truy cập H100** (thuê cloud theo giờ khả thi cho luận văn nếu có ngân sách; cluster trường là lý tưởng).
- **Rủi ro:** (a) hai cơ chế quản outlier có thể triệt tiêu → cần fallback tách riêng; (b) merge kernel phức tạp, tốn thời gian engineering; (c) FP8 gần-chính-xác, không bit-exact → cần kiểm chất lượng kỹ; (d) nếu mất quyền H100 giữa chừng → toàn bộ nhánh lõi dừng (rủi ro tài nguyên cao hơn A).

## 7. So sánh A vs B (chọn 1 hoặc làm A trước, B sau)
| | Proposal A | Proposal B |
|---|---|---|
| Phần cứng | 3090/4090 (tiêu dùng) | H100 (Hopper) |
| Mục tiêu | Độ trễ 1-GPU, deploy tiêu dùng | Thông lượng serving datacenter |
| Kernel | SageAttention2 / v1 | **FA-3 (FP8 async)** |
| Đóng góp lõi | Điều phối error-aware 4 trục nén | **Co-design quản outlier FP8-attn × W4A4-weight** |
| Rủi ro tài nguyên | Thấp (có sẵn máy) | Cao (phụ thuộc thuê H100) |
| Khe hở | Stack nén cho ảnh (Gap D) | Tương tác low-precision hai tầng trên Hopper |

**Khuyến nghị:** làm **A làm chính** (khả thi ngay với 3090/4090); B là **mở rộng/tham vọng** khi có H100 — hoặc thành một chương "scale-up" của luận văn. A và B **chia sẻ chung** phân tích tương tác sai số nên không lãng phí công.

---
*Nguồn: FlashAttention-3.md, SVDQuant.md, TaylorSeer.md, DistriFusion.md và PROPOSAL.md (Proposal A).*
