# Điểm yếu của Flash Attention / KV Cache / Pruning / Quantization & Đề xuất ATEA

Tài liệu này:
1. Phân tích **điểm yếu** của 4 kỹ thuật.
2. Chỉ ra **cổ chai chung**.
3. Đề xuất **ATEA** — *Adaptive Tier-Aware Efficient Attention* (reversible token tiering + mixed-precision KV cache cho I/O-aware attention) — một module nhỏ ghép thêm vào pipeline ở [flash_attn_kv_prune_quant.tex](flash_attn_kv_prune_quant.tex).

---

## 1. Điểm yếu của từng kỹ thuật

### 1.1 Flash Attention

| Điểm yếu | Giải thích |
|---|---|
| **Không giảm FLOPs** | Vẫn $O(T^2 d)$; chỉ tối ưu I/O HBM ↔ SRAM. Khi $T$ rất lớn, compute mới là cổ chai. |
| **Phụ thuộc kích thước SRAM** | Block size $B_r, B_c$ bị giới hạn bởi shared memory; trên GPU cũ (sm_70) hiệu năng kém. |
| **Khó kết hợp mask động** | Custom mask (sparse, block-sparse, không đối xứng) phải viết lại kernel. |
| **Backward tốn recompute** | Để tiết kiệm bộ nhớ, backward phải tính lại $S = QK^\top$ → tăng compute ~30%. |
| **Numerical underflow ở FP16** | Khi $T$ rất dài, online-softmax có thể tích lũy sai số nếu không dùng FP32 accumulator. |

### 1.2 KV Cache

| Điểm yếu | Giải thích |
|---|---|
| **Bộ nhớ tăng tuyến tính theo $T$** | $2 \cdot L \cdot H \cdot d \cdot T \cdot 2\text{B}$ → context dài giết VRAM. |
| **Băng thông HBM là cổ chai** | Decode autoregressive đọc lại toàn bộ cache mỗi bước → memory-bound, không compute-bound. |
| **Phân mảnh khi batch dynamic** | Các sequence dài-ngắn khác nhau gây phân mảnh (lý do PagedAttention ra đời). |
| **Không có "quên"** | Token cũ không còn liên quan vẫn nằm trong cache. |

### 1.3 Pruning (KV / token pruning)

| Điểm yếu | Giải thích |
|---|---|
| **Không thể hồi phục** | Đã xóa token khỏi cache thì không lấy lại được — dù sau này nó trở nên quan trọng. |
| **Score lỗi thời** | Importance ước lượng tại $t$ có thể sai cho query ở $t' \gg t$ (vd. câu hỏi đến muộn). |
| **Mất long-range dependency** | Pruning aggressive làm hỏng bài toán nhớ chi tiết xa (needle-in-a-haystack). |
| **Overhead Top-K** | Mỗi $\Delta$ bước phải sort/Top-K trên $T_k$ phần tử. |
| **Phá block layout** | Sau pruning, indices không liên tục → kernel Flash Attention mất khả năng tile gọn. |

### 1.4 Quantization (KV cache)

| Điểm yếu | Giải thích |
|---|---|
| **Outlier kênh** | Vài kênh có biên độ rất lớn → "đè" scale, các kênh khác mất bit. |
| **Suy giảm tích lũy** | Sai số lượng tử cộng dồn qua các layer, nhất là INT4. |
| **Calibration drift** | Phân phối $K, V$ ở runtime (domain khác) khác calibration set → scale lệch. |
| **Overhead dequant** | Mỗi bước decode phải dequant trong kernel; INT4 còn cần unpack bit. |
| **Không đồng nhất K vs V** | $K$ thường có outlier mạnh hơn $V$; dùng cùng $b$ là lãng phí. |

---

## 2. Cổ chai chung

> Cả 4 kỹ thuật đều **đối xử với mọi token / mọi kênh / mọi layer như nhau**, trong khi thực tế:
> - Một số token là "anchor" (đầu chuỗi, entropy thấp) → cần giữ độ chính xác cao.
> - Một số kênh là "outlier channel" → cần nhiều bit hơn.
> - Một số layer (đầu & cuối) nhạy cảm hơn các layer giữa.

→ Hướng khắc phục hiệu quả nhất là **adaptive** thay vì cấu hình tĩnh.

---

## 3. ATEA — Adaptive Tier-Aware Efficient Attention

> **Tên gọi:** *Adaptive Tier-Aware Efficient Attention* (**ATEA**).
> - **Adaptive** — calibration online + re-tier theo runtime.
> - **Tier-Aware** — phân tầng theo **2 trục**:
>   1. *Bit-width tier*: FP16 outlier / INT8 hot / INT4 cold (Quantization + KV).
>   2. *Importance tier*: hot/cold + demote/promote (Pruning có thể đảo ngược).
> - **Efficient Attention** — backend-agnostic: chạy trên mọi I/O-aware kernel
>   (FlashAttn-2/3, xFormers, FlexAttention…).

### 3.1 Ba thành phần

**(A) Mixed-precision KV theo importance**

Chia cache thành 2 tầng:

- **Hot tier** (INT8, có thể FP16 cho token siêu quan trọng): các token có $\sigma_t$ cao, ngân sách $L_{hot}$.
- **Cold tier** (INT4): các token còn lại — **không xóa**, chỉ "demote".

Khi một token cold sau này được "hỏi" nhiều (score tăng), **promote ngược** lên hot. Đây là **pruning có thể đảo ngược** — vá điểm yếu "không hồi phục được" của pruning.

$$
\text{tier}(t) =
\begin{cases}
\text{HOT (INT8)}  & \text{nếu } \sigma_t \in \text{Top-}L_{hot} \\
\text{COLD (INT4)} & \text{ngược lại}
\end{cases}
$$

**(B) Per-channel bit-budget (chống outlier)**

Trước calibration, đo $\kappa_j = \mathrm{kurtosis}(K[:, j])$ cho từng kênh. Top-$r\%$ kênh có $\kappa$ cao nhất → giữ FP16; phần còn lại lượng tử nhóm.

$$
b_j =
\begin{cases}
16 & \text{nếu } j \in \text{Top-}r\%(\kappa) \\
b  & \text{ngược lại}
\end{cases}
$$

Thực nghiệm trong các nghiên cứu LLM.int8()-style cho thấy $r \approx 1\%$ kênh giữ FP16 đã chặn được phần lớn sai số.

**(C) Online recalibration nhẹ**

Mỗi $N$ bước, cập nhật scale bằng EMA trên thống kê runtime:

$$
\alpha_t \gets \gamma\, \alpha_{t-1} + (1-\gamma)\, \mathrm{Percentile}(|x_t|, p),
\qquad
s_t \gets \alpha_t / q_{\max}
$$

Vá điểm yếu **calibration drift**.

### 3.2 Pseudo-code (Python)

```python
def adaptive_step(Q, K_new, V_new, cache, t):
    # --- (B) Tách outlier channels ---
    K_out, K_in = split_channels(K_new, outlier_idx)   # FP16, INT-b
    V_out, V_in = split_channels(V_new, outlier_idx)

    # --- (C) Online recalibration ---
    if t % N == 0:
        cache.s_k = update_scale_ema(cache.s_k, K_in, gamma, p)
        cache.s_v = update_scale_ema(cache.s_v, V_in, gamma, p)

    # Quantize phần "in" theo tier mặc định = HOT (INT8)
    K_q = quantize(K_in, cache.s_k, b=8)
    V_q = quantize(V_in, cache.s_v, b=8)
    cache.append(K_out, K_q, V_out, V_q)

    # --- (A) Re-tier dựa trên attention-score (mỗi Δ bước) ---
    if t % Delta == 0:
        sigma = compute_attention_score(Q, cache)        # EMA importance
        hot_idx  = topk(sigma, k=L_hot)
        cold_idx = complement(hot_idx)

        # Demote: INT8 -> INT4
        for i in cold_idx - cache.hot:
            x = dequantize(cache.K_q[i], cache.s_k, b=8)
            cache.K_q[i] = quantize(x, cache.s_k_int4, b=4)

        # Promote ngược: INT4 -> INT8
        for i in hot_idx - cache.cold:
            x = dequantize(cache.K_q[i], cache.s_k_int4, b=4)
            cache.K_q[i] = quantize(x, cache.s_k, b=8)

        cache.hot, cache.cold = hot_idx, cold_idx

    # --- Flash Attention với 2-tier dequant trong kernel ---
    return flash_attn_mixed(Q, cache, scale, causal, window_size)
```

### 3.3 Bảng đối chiếu: ATEA vá đúng điểm yếu nào?

| Điểm yếu gốc | ATEA vá bằng |
|---|---|
| Flash Attn không giảm FLOPs | Hot tier nhỏ → giảm $T$ hữu dụng cho phần FP-cao |
| KV cache phình | Cold tier INT4 + outlier-only FP16 → ~3.5–4× nén tổng |
| KV không có "quên" | Tier system tự nhiên degrade token ít quan trọng |
| Pruning không hồi phục | Demote thay vì delete → token cold vẫn truy cập được |
| Pruning score lỗi thời | EMA + re-tier định kỳ thay vì hard cut |
| Quant outlier channel | Tách $r\%$ kênh giữ FP16 |
| Quant calibration drift | Online recalibration EMA |
| Quant đồng nhất K / V | Đặt $b_K \neq b_V$ trong cùng framework |

### 3.4 Chi phí thêm

- **Bộ nhớ thêm**: bảng `tier_id` ($T_k$ bits) + bảng outlier-channel mask ($d$ bits) → không đáng kể.
- **Compute thêm**: re-tier mỗi $\Delta$ bước (Top-K + một vòng requant trên $|hot \triangle cold|$ token thay đổi) — $O(T_k \log L_{hot})$.
- **Kernel**: cần Flash-Attn 2-tier (đọc INT8 hoặc INT4 tùy `tier_id[t]`); có thể bắt đầu bằng version reference rồi tối ưu sau.

### 3.5 Cách đo hiệu quả (benchmark gợi ý)

1. **PPL** trên WikiText-103 / C4 với context dài (4k, 16k, 64k).
2. **Needle-in-a-haystack** ở 32k để kiểm tra pruning có làm mất long-range không.
3. **VRAM peak** và **decode tokens/s** ở batch=1 và batch=32.
4. **Ablation**: tắt từng thành phần (A), (B), (C) để định lượng đóng góp.

---

## 4. File đi kèm

- [flash_attn_kv_prune_quant.tex](flash_attn_kv_prune_quant.tex) — Algorithm 1 (Calibration) và Algorithm 2 (Flash Attn + Quant + Score Pruning), nay được mở rộng với **Algorithm 3: ATEA**.
- [flash_attn_kv_prune_quant.md](flash_attn_kv_prune_quant.md) — giải thích nền cho 2 algorithm gốc.
