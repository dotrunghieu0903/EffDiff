# Flash Attention với KV Cache, Attention-Score Pruning và Per-Head / Group-wise Quantization

Tài liệu này mô tả phiên bản mở rộng của Flash Attention with KV Cache, bổ sung:

1. **Calibration** offline để tính `scale` / `zero-point`.
2. **Per-head, group-wise quantization** (thay vì per-tensor).
3. **Pruning theo attention-score** (thay vì theo magnitude).

---

## 1. Ký hiệu

| Ký hiệu | Ý nghĩa |
|---|---|
| $Q, K, V$ | Query / Key / Value của bước hiện tại, shape $(B, H, T, d)$ |
| $K_{cache}, V_{cache}$ | KV cache đã **lượng tử hóa** (INT$b$) |
| $H$ | Số attention head |
| $d$ | Head dimension |
| $g$ | Group size theo chiều kênh ($d \bmod g = 0$) |
| $b$ | Bit-width lượng tử (vd. 8, 4) |
| $s^{(h,j)}, z^{(h,j)}$ | Scale / zero-point của head $h$, group $j$ |
| $\rho$ | Tỷ lệ token cần cắt tỉa khỏi cache, $\rho \in [0, 1)$ |
| $\Delta$ | Chu kỳ chạy lại pruning (mỗi $\Delta$ bước decode) |
| $p$ | Percentile dùng để clip outlier khi calibrate (vd. 99.9%) |

---

## 2. Calibration cho scale / zero-point

### 2.1 Mục tiêu

Tìm $(s, z)$ sao cho ánh xạ $x \mapsto \mathrm{round}(x/s) + z$ giảm thiểu sai số lượng tử trên phân phối thực của $K, V$.

### 2.2 Quy trình (offline, chạy 1 lần)

1. Chuẩn bị `calibration set` $\mathcal{D}_{cal}$ (vài trăm mẫu là đủ).
2. Forward model, **gom** tensor $K^{(h)}, V^{(h)}$ ở mọi layer/head.
3. Với mỗi cặp `(head h, group j)` (group là một slice $g$ kênh liên tiếp của $d$):
   - Tính $\alpha = \mathrm{Percentile}(|x|,\, p)$ — bỏ outlier để tránh "phình" scale.
   - **Symmetric (khuyến nghị cho INT8/INT4 trên GPU):**
     $$
     s = \frac{\alpha}{2^{b-1} - 1}, \qquad z = 0
     $$
   - **Asymmetric (khi phân phối lệch, vd. sau ReLU):**
     $$
     s = \frac{x_{\max} - x_{\min}}{2^{b} - 1}, \qquad
     z = \mathrm{round}\!\left(-\frac{x_{\min}}{s}\right)
     $$
4. Lưu bảng $\{(s_k^{(h,j)}, z_k^{(h,j)}), (s_v^{(h,j)}, z_v^{(h,j)})\}$ — kích thước rất nhỏ ($H \cdot d/g$ phần tử mỗi tensor).

> **Vì sao per-head + group-wise?**  
> Mỗi head học pattern khác nhau, và trong cùng một head các nhóm kênh cũng có biên độ khác nhau. Per-tensor scale làm INT4 mất nhiều thông tin; per-head + group-wise (vd. $g=128$) khôi phục gần như toàn bộ độ chính xác FP16.

---

## 3. Lượng tử hóa khi ghi vào cache (online)

Với mỗi token mới, theo từng `(h, j)`:

$$
\tilde{x}^{(h,j)} = \mathrm{clip}\!\left(
\mathrm{round}\!\left(\frac{x^{(h,j)}}{s^{(h,j)}}\right) + z^{(h,j)},\;
q_{\min},\, q_{\max}
\right)
$$

trong đó $q_{\min} = -2^{b-1}$, $q_{\max} = 2^{b-1} - 1$.

**Dequantize on-the-fly** trong Flash Attention kernel (đọc INT$b$ từ HBM → giải lượng tử trong SRAM → matmul FP16/BF16):

$$
\hat{x}^{(h,j)} = s^{(h,j)} \cdot \left(\tilde{x}^{(h,j)} - z^{(h,j)}\right)
$$

Lợi ích bộ nhớ KV cache:

| Precision | Bytes / phần tử | Tỷ lệ giảm so FP16 |
|---|---|---|
| FP16 | 2 | 1× |
| INT8 | 1 | 2× |
| INT4 | 0.5 | 4× |

---

## 4. Pruning theo attention-score

### 4.1 Vì sao không dùng magnitude?

Magnitude của $K$ **không** đo trực tiếp mức độ "được chú ý". Một key có chuẩn nhỏ vẫn có thể nhận điểm chú ý cao nếu hướng của nó khớp với query. Pruning theo attention-score giữ lại đúng các token thực sự đóng góp vào output.

### 4.2 Tính importance

Trong từng chu kỳ refresh ($t \bmod \Delta = 0$):

1. Dequantize tạm KV để xem trước:
   $$\hat{K} = s_k \odot (K_{cache} - z_k)$$
2. Tính ma trận attention (có thể dùng query gần nhất hoặc trung bình các query trong cửa sổ):
   $$A = \mathrm{softmax}\!\left(\frac{Q \hat{K}^\top}{\sqrt{d}}\right)
   \in \mathbb{R}^{H \times T_q \times T_k}$$
3. **Score per-token** (gộp head + query):
   $$\sigma_t = \frac{1}{H \cdot T_q} \sum_{h, i} A[h, i, t]$$
4. Giữ lại Top-$K$ token quan trọng nhất:
   $$\mathcal{I}_{keep} = \mathrm{TopK}\!\left(\bm{\sigma},\; k = \lceil (1-\rho)\, T_k \rceil\right)$$
5. Co lại cache:
   $$K_{cache} \gets K_{cache}[\mathcal{I}_{keep}], \quad
     V_{cache} \gets V_{cache}[\mathcal{I}_{keep}]$$

### 4.3 Mẹo triển khai

- **Bảo vệ token đặc biệt**: luôn giữ các "sink token" đầu chuỗi và $w$ token gần nhất (sliding window) — chỉ pruning ở đoạn giữa.
- **Ngân sách cố định**: thay vì $\rho$ cố định, giới hạn $|K_{cache}| \le L_{max}$ để dự đoán bộ nhớ.
- **Chu kỳ $\Delta$**: $\Delta = 32$–$128$ là cân bằng tốt giữa overhead và độ tươi của score.
- **Tích lũy EMA**: $\bm{\sigma}_t \gets \beta\, \bm{\sigma}_{t-1} + (1-\beta)\, \bm{\sigma}_{new}$, $\beta \approx 0.9$ — tránh đuổi theo nhiễu của một bước.

---

## 5. Pseudo-code tổng hợp

```text
# === Offline ===
(s_k, z_k), (s_v, z_v) = Calibrate(model, D_cal, b, g, percentile=p)

# === Online (mỗi bước decode t) ===
def step(Q, K_new, V_new, K_cache, V_cache, t):
    if K_new is not None:
        if RoPE: K_new, V_new = apply_rope(K_new, V_new, cos, sin)
        # Per-head, group-wise quantize
        K_q = quantize(K_new, s_k, z_k, b)   # shape giữ nguyên, dtype = int{b}
        V_q = quantize(V_new, s_v, z_v, b)
        K_cache = append(K_cache, K_q)
        V_cache = append(V_cache, V_q)

    # Pruning theo attention-score (định kỳ)
    if t % Delta == 0 and rho > 0:
        K_hat = dequantize(K_cache, s_k, z_k)
        A = softmax(Q @ K_hat.T * scale)         # [H, Tq, Tk]
        sigma = A.mean(dim=(0, 1))               # [Tk]
        sigma_ema = beta * sigma_prev + (1 - beta) * sigma
        keep = topk(sigma_ema, k=ceil((1-rho)*Tk))
        keep = protect_sinks_and_window(keep)
        K_cache, V_cache = K_cache[keep], V_cache[keep]

    # Flash-Attention với dequant on-the-fly trong kernel
    K_hat = dequantize(K_cache, s_k, z_k)
    V_hat = dequantize(V_cache, s_v, z_v)
    return flash_attn_func(Q, K_hat, V_hat,
                           scale, causal, window_size, alibi_slopes)
```

---

## 6. Tổng kết các siêu tham số

| Tham số | Khuyến nghị | Ghi chú |
|---|---|---|
| $b$ | 8 (an toàn) / 4 (tiết kiệm) | INT4 cần group-wise + percentile clip |
| $g$ | 64–128 | Cân bằng độ chính xác và overhead bảng scale |
| $p$ | 99.9% | Tránh outlier làm phình scale |
| $\rho$ | 0.3–0.5 | Phụ thuộc tác vụ; theo dõi PPL |
| $\Delta$ | 32–128 bước | Quá nhỏ → tốn compute; quá lớn → score lỗi thời |
| $\beta$ (EMA) | 0.9 | Làm mượt importance qua thời gian |
| sink tokens | 4–8 đầu chuỗi | Bắt buộc giữ với LLM dạng StreamingLLM |
| sliding window | $w = 256$–$1024$ | Luôn giữ token gần đây |

---

## 7. File đi kèm

- [flash_attn_kv_prune_quant.tex](flash_attn_kv_prune_quant.tex) — pseudo-code dạng LaTeX (`algorithm` + `algpseudocode`).
